"""Signal sanity checks shared by the executor (before an order), the scout
(before scoring a historical signal) and the performance ledger.

A garbled message must neither become a wrong order nor a wildly wrong
statistic: a stop loss 30% away or 0.01 points away would make R meaningless.
"""
from __future__ import annotations

import math

from signal_trader.models import OrderType, Side, Signal

# Minimum initial risk as a fraction of price: 0.02% (gold at 4300 -> 0.86 pts).
MIN_RISK_FRAC = 0.0002
# A quoted entry further than this from the live price is a pending level, not "buy now".
ENTRY_TOLERANCE_FRAC = 0.0005


def validate_signal(sig: Signal, require_sl: bool, max_sl_pct: float) -> str:
    """Return '' if the signal is sane to trade, else a short rejection reason.

    Catches inverted SL/TP, zero/absurd stops, ambiguous direction, and the
    not-yet-supported stop-order type — the ways a garbled message turns into
    a wrong order.
    """
    if "both buy and sell keywords present" in sig.warnings:
        return "ambiguous direction (buy and sell both present)"
    if sig.order_type == OrderType.STOP:
        return "stop orders not supported yet"
    if sig.take_profit_offsets:
        if sig.take_profits:
            return "mixed absolute and relative take profits"
        if any(not math.isfinite(v) or v <= 0 for v in sig.take_profit_offsets):
            return "take profit distances must be finite and positive"
    if require_sl and (sig.stop_loss is None or sig.stop_loss <= 0):
        return "missing or zero stop loss"
    sl, tp = sig.stop_loss, (sig.take_profits[0] if sig.take_profits else None)
    entry = sig.entry
    if sl is not None and sl > 0 and entry is None and tp is None:
        return "stop loss with no entry or take profit to validate against"
    if sl is not None and sl > 0:
        if sig.side == Side.BUY:
            if entry is not None and not (sl < entry):
                return "BUY stop loss is not below entry"
            if tp is not None and not (sl < tp):
                return "BUY stop loss is not below take profit"
        elif sig.side == Side.SELL:
            if entry is not None and not (sl > entry):
                return "SELL stop loss is not above entry"
            if tp is not None and not (sl > tp):
                return "SELL stop loss is not above take profit"
        ref = entry if entry else tp
        if ref and abs(ref - sl) / ref > max_sl_pct:
            return f"stop loss is {abs(ref - sl) / ref:.0%} from price (> {max_sl_pct:.0%} limit)"
    return ""


def risk_too_small(entry_ref: float, stop_loss: float, min_frac: float = MIN_RISK_FRAC) -> bool:
    """True when |entry - SL| is below ``min_frac`` of the price."""
    try:
        return abs(entry_ref - stop_loss) < min_frac * abs(entry_ref)
    except TypeError:
        return False
