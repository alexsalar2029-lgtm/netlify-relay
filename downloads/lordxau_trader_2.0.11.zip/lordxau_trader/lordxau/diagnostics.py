# -*- coding: utf-8 -*-
"""Offline report: only reads local settings/journals; never logs in or sends an order."""
from __future__ import annotations

import argparse
import json
from collections import deque
from datetime import datetime
from pathlib import Path

from lordxau import __version__
from lordxau.engine import EngineConfig
from lordxau.parse import SIGNAL, ZONE, parse
from signal_trader.filelog import scrub


def _tail_rows(path: Path, count: int = 40) -> list:
    rows = deque(maxlen=count)
    try:
        with path.open(encoding="utf-8-sig", errors="replace") as f:
            for line in f:
                try:
                    row = json.loads(line)
                    if isinstance(row, dict):
                        rows.append(row)
                except ValueError:
                    continue
    except OSError:
        pass
    return list(rows)


def build_report(root: Path) -> str:
    lines = [f"LORD XAU Trader {__version__} — گزارش تشخیص محلی",
             f"زمان تهیه: {datetime.now().isoformat(timespec='seconds')}",
             "این گزارش هیچ اتصالی به تلگرام/بروکر برقرار نمی‌کند و سفارشی ارسال نمی‌کند.", ""]
    settings = None
    try:
        raw = json.loads((root / "settings.json").read_text(encoding="utf-8-sig"))
        if not isinstance(raw, dict):
            raise ValueError("settings root is not an object")
        settings = raw
    except (OSError, ValueError):
        lines.append("settings.json خوانده نشد؛ وضعیت تنظیمات حساب شما در این گزارش معلوم نیست.")
    if settings is not None:
        ec = EngineConfig.from_dict(settings.get("engine"))
        fx = settings.get("fxtrendo") or {}
        risk = settings.get("risk") or {}
        lines += [f"اسکلپ: {'روشن' if ec.trade_scalp else 'خاموش'}",
                  f"ULTRA: {'روشن' if ec.trade_ultra else 'خاموش'}",
                  f"ارسال سفارش: {'فعال' if fx.get('enabled') and not fx.get('dry_run', True) else 'آزمایشی/خاموش'}",
                  f"نوع حساب انتخاب‌شده: {'REAL' if fx.get('use_real_wallet') else 'DEMO'}",
                  f"ریسک ثبت‌شده: {risk.get('risk_pct', 'نامعلوم')}%؛ حجم‌گذاری: {risk.get('sizing', 'نامعلوم')}",
                  f"حد ضرر روزانه: {risk.get('max_daily_loss', 'نامعلوم')}",
                  f"حداکثر پوزیشن باز: {fx.get('max_open_positions', 'نامعلوم')}",
                  f"اندازهٔ پیپ کانال: {ec.gold_pip_size:g} واحد قیمت"]
        if ec.trade_ultra:
            from lordxau.settings import effective_risk_pct
            lines.append(f"ریسک مؤثر برنامه با ULTRA روشن: {effective_risk_pct(settings):g}%")
        else:
            lines.append("Gold + ناحیه + TP/SL سیگنال ULTRA است؛ با این تنظیم به بروکر ارسال نمی‌شود.")

    logs = root / "logs"
    decision_files = sorted(logs.glob("decisions-*.jsonl"))[-2:]
    decisions = [o for p in decision_files for o in _tail_rows(p, 120)]
    relevant = [o for o in decisions if o.get("kind") in (SIGNAL, ZONE, "STOP") or o.get("lines")][-20:]
    lines += ["", "آخرین تصمیم‌های ثبت‌شدهٔ برنامه:"]
    if relevant:
        for o in relevant:
            lines.append(f"پیام {o.get('id', 'timer')} | {o.get('kind', o.get('type'))} | ویرایش={bool(o.get('edited'))}")
            lines += ["  " + str(x) for x in o.get("lines", [])]
            if not o.get("lines"):
                lines.append("  تصمیم اجرایی تازه ثبت نشده (مثلاً بازنشر تکراری).")
    else:
        lines.append("تصمیمی موجود نیست. این فایل‌ها فقط پس از اجرای نسخهٔ 2.0.10 به بعد ساخته می‌شوند.")

    message_files = sorted(logs.glob("messages-*.jsonl"))[-2:]
    numeric = []
    for path in message_files:
        for o in _tail_rows(path, 300):
            p = parse(o.get("text", ""))
            if p.kind in (SIGNAL, ZONE) or p.reason:
                numeric.append((o, p))
    lines += ["", "بازخوانی عددی پیام‌های اخیر (نتیجهٔ ارسال سفارش به بروکر نیست):"]
    for o, p in numeric[-10:]:
        lines.append(f"پیام {o.get('id')} | {o.get('date', '')} | {p.kind} | {p.side or '—'} | "
                     f"ورود={p.entries} | SL={p.sl} | TP={p.tps} | TP-pip={p.tp_pips}")
        if p.reason:
            lines.append("  " + p.reason)
        if p.kind == SIGNAL and settings is not None and not ec.trade_ultra:
            lines.append("  با تنظیم فعلی: ULTRA خاموش؛ ارسال نمی‌شود.")
    if not numeric:
        lines.append("پیام عددی قابل بازخوانی در آخرین فایل‌ها پیدا نشد.")

    lines += ["", "آخرین خط‌های مرتبط از logs/bot.log:"]
    try:
        with (logs / "bot.log").open(encoding="utf-8-sig", errors="replace") as f:
            tail = list(deque(f, maxlen=250))
        needles = ("رد", "⛔", "ULTRA", "سفارش", "استاپ", "quote", "rejected", "error", "limit", "socket")
        matches = [line.rstrip() for line in tail if any(n in line for n in needles)][-25:]
        lines += matches or ["خط مرتبطی در انتهای لاگ پیدا نشد."]
    except OSError:
        lines.append("bot.log موجود نیست؛ علت رد واقعی بروکر از پیام‌های تلگرام به‌تنهایی مشخص نمی‌شود.")
    return scrub("\n".join(lines)) + "\n"


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    ap.add_argument("--output", type=Path)
    args = ap.parse_args()
    output = args.output or args.root / "logs" / "diagnosis.txt"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(build_report(args.root), encoding="utf-8")
    print(f"گزارش آماده شد: {output}")


if __name__ == "__main__":
    main()
