# -*- coding: utf-8 -*-
"""Real October log regressions; offline parser and recording-executor checks."""
import pytest

from lordxau.llm_reader import Reading
from lordxau.parse import BE, CLOSE, MARKET_NOW, NOISE, REENTER, RESULT, parse
from test_engine import feed, make, run


@pytest.mark.parametrize("text", [
    "نرسید قیمت مارکت بزنش",  # lordxau 91246, 2026-10-08
    "نرسید قیمت مارکت بزنش!",
    "اگر نرسید قیمت مارکت بزنش",
])
def test_missed_market_command_with_object_suffix(text):
    p = parse(text)
    assert p.kind == MARKET_NOW and p.missed
    assert p.entries == [] and p.sl is None


@pytest.mark.parametrize("text", [
    "نرسید قیمت مارکت بزنش ولی نزن",
    "نرسید قیمت مارکت بزنش نزنش",
    "نرسید قیمت مارکت بزنش نگیرش",
    "نرسید قیمت مارکت بزنش نه",
    "نرسید قیمت مارکت بزنش؟",
    "اگر رفت بالا قیمت مارکت بزنش",
    "گفتم قیمت مارکت بزنش",
    "بزن نمیرسه",  # 91247: lacks an explicit market order on its own
    "بزن کم حجم ها",
])
def test_suffix_does_not_override_negation_conditions_or_chatter(text):
    assert parse(text).kind == NOISE


@pytest.mark.parametrize("text", ["بگیر\u200cیاز", "بگیر یاز", "بگیر یاز!"])
def test_exact_observed_standalone_reentry_typo(text):
    p = parse(text)  # 91012 immediately after "فری خورد"
    assert p.kind == REENTER and p.text == text


@pytest.mark.parametrize("text", [
    "گفتم بگیر یاز",
    "بگیر یاز؟",
    "بگیر یاز نزن",
    "یازده بار بگیر",
    "بگیرم دوباره ؟",
])
def test_typo_repair_does_not_guess_orders_in_other_text(text):
    assert parse(text).kind == NOISE


@pytest.mark.parametrize("text", [
    "هر جا سر به سر ببندید",  # 91842 was misread as an immediate close
    "هرجا سر به سر ببندید",
    "هر وقت رفت سود ببندش",
    "هر موقع سر به سر شد ببند",
    "هر زمان سود شد ببندید",
])
def test_conditional_close_has_a_diagnostic_and_is_not_immediate(text):
    p = parse(text)
    assert p.kind == NOISE and p.reason and not p.has(CLOSE)


@pytest.mark.parametrize("text", [
    "هرجا سربه سر شد",  # 91694..91696 are conditional fragments
    "سود شد حساب یا",
    "ببندیم",
    "اگر قبلی رو نتونستی سر به سر کنی این دومی هرجا جبران کرد ببند",
])
def test_conditional_fragments_are_not_standalone_close_orders(text):
    assert parse(text).kind == NOISE


NUMERIC_MANAGEMENT = [
    "رو 4118/4119فری کن",  # 91015; Gemini previously discarded these numbers
    "رو4119/4118فری کن",  # 91258; same unsafe LLM fallback
    "فریش کن رو4182",  # 91913; regex previously discarded this number
    "رو۴۱۸۲ فریش کن",
    "ریسک فری کن روی 4182",
    "اگر نبستی فریش کن رو4182",
    "فریش کن 4182",
    "فریش کن 4182/4181",
    "فریش کن ۴۱۸۲",
    "فریش کن 4182.50",
    "فریش کن ۴۱۸۲٫۵",
    "فریش کن 4182.50/4181.25!",
]


@pytest.mark.parametrize("text", NUMERIC_MANAGEMENT)
def test_explicit_management_level_is_not_silently_discarded(text):
    p = parse(text)
    assert p.kind == NOISE and p.reason and not p.has(BE)


@pytest.mark.parametrize("text", [
    "فریش کن",
    "ریسک فری کن بریم ببینیم 4080رو بهمون میده",
    "ریسک فری کن بریم ببینیم4080رو بهمون میده",
    "فری باشین تا4050میره",
])
def test_plain_protection_and_price_progress_keep_their_existing_reading(text):
    assert parse(text).kind == BE


@pytest.mark.parametrize("text", [
    "+50pip نرسید قیمت مارکت بزنش",
    "برایند امروز:+330pip\n+50\n+60",
])
def test_profit_summaries_remain_results(text):
    assert parse(text).kind == RESULT


@pytest.mark.parametrize("text", NUMERIC_MANAGEMENT + ["هر جا سر به سر ببندید"])
def test_refused_management_cannot_reach_the_llm_or_change_an_open_trade(text):
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192")])
    ex.fill("v1")
    calls = []
    eng.llm = lambda raw: (calls.append(raw), Reading(kind="risk_free", confidence=1,
                                                    source="offline_stub"))[1]
    ex.calls.clear()
    lines = feed(eng, clk, [(1, text)])
    assert not calls and not ex.calls and not eng.setup.be
    assert "v1" in ex.alive and any(parse(text).reason in line for line in lines)


def test_suffix_market_order_executes_only_from_existing_fresh_zone():
    eng, ex, clk = make()
    ex.mid = 4113
    feed(eng, clk, [(0, "Xau Buy Enter:4111/4112"), (3, "Stop:4109"),
                    (19, "نرسید قیمت مارکت بزنش")])
    assert [c for c in ex.calls if c[0] == "market_now"] == [("market_now", "BUY", 4109)]


@pytest.mark.parametrize("blocker", ["no_zone", "filled", "old_zone", "old_message", "risk"])
def test_suffix_market_order_keeps_existing_entry_safeguards(blocker):
    eng, ex, clk = make()
    ex.mid = 4113
    if blocker != "no_zone":
        feed(eng, clk, [(0, "Xau Buy Enter:4111/4112"), (3, "Stop:4109")])
    if blocker == "filled":
        ex.fill("v1")
    elif blocker == "old_zone":
        clk.t += eng.cfg.setup_ttl_sec + 1
    elif blocker == "risk":
        ex.mid = 4120
    ex.calls.clear()
    ts = clk.t - eng.cfg.max_msg_age_sec - 1 if blocker == "old_message" else clk.t
    run(eng.handle("نرسید قیمت مارکت بزنش", msg_id=91246, ts=ts))
    assert not [c for c in ex.calls if c[0] in ("market_now", "execute")]


def test_typo_reentry_does_not_replace_a_fresh_subsequent_channel_zone():
    eng, ex, clk = make(reenter_wait_sec=60)
    feed(eng, clk, [(0, "Xau Buy Enter:4118/4117"), (4, "Stop:4115"),
                    (5, "فری خورد"), (2, "بگیر\u200cیاز"),
                    (11, "Xau Buy Enter:4117/4116"), (4, "Stop:4114")])
    clk.t += 61
    run(eng.tick())
    assert [c[2] for c in ex.calls if c[0] == "execute"] == [[4118, 4117], [4117, 4116]]


def test_direct_immediate_close_still_closes_only_the_existing_bot_trade():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192")])
    ex.fill("v1")
    feed(eng, clk, [(1, "ببندش")])
    assert ex.calls[-1] == ("close", ["v1"])
