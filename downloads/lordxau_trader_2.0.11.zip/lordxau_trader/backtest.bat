@echo off
chcp 65001 >nul
cd /d "%~dp0"
set PYTHONUTF8=1
rem usage: backtest.bat 2026-09-28      (no date = today, UTC)
if "%~1"=="" (
  python -m lordxau.backtest --settings settings.json --trace logs\backtest-trace.txt
) else (
  python -m lordxau.backtest --day %1 --settings settings.json --trace logs\backtest-trace-%1.txt
)
pause
