# -*- coding: utf-8 -*-
"""The parser on real @lordxau messages (2026-09-20..28)."""
import pytest

from lordxau.parse import (BE, BE_HIT, CLOSE, HINT, IF_BE_REENTER, MARKET_NOW, NOISE, PRICE, REENTER,
                           RESULT, SHORTHAND, SIGNAL, SL_HIT, STOP, ZONE, parse)


@pytest.mark.parametrize("text,side,entries,sl", [
    ("Xau\n\nSell\n\nEnter:4190/4189", "SELL", [4190, 4189], None),
    ("Xau\n\nSell\n\nEnter:4187:4188", "SELL", [4187, 4188], None),
    ("Xau Sell  Enter:4185/4186", "SELL", [4185, 4186], None),
    ("Xau\n\nSell\n\nEntet:4180/4181", "SELL", [4180, 4181], None),
    ("Xau\n\nBuy\n\nEnter:4315/4314", "BUY", [4315, 4314], None),
    ("Xau\n\nSell\n\nEnter:4263/64", "SELL", [4263, 4264], None),
])
def test_zone(text, side, entries, sl):
    p = parse(text)
    assert p.kind == ZONE and p.side == side and p.entries == entries and p.sl == sl


def test_zone_100_point_typo_keeps_both_readings():
    p = parse("Xau\n\nBuy\n\nEnter:4363/4262")
    assert p.kind == ZONE and p.side == "BUY"
    assert sorted(p.entries) == [4262, 4263] and sorted(p.alt) == [4362, 4363]


def test_zone_cut_short_is_not_traded():
    assert parse("Xau\n\nBuy\n\nEnter:4311/431").kind == SHORTHAND


@pytest.mark.parametrize("text,sl", [("Stop:4192", 4192), ("Stop:4188", 4188), ("استاپ 4192", 4192)])
def test_stop(text, sl):
    p = parse(text)
    assert p.kind == STOP and p.sl == sl


@pytest.mark.parametrize("text", ["استاپ ۳۰۹", "تیپی ۲۶"])
def test_shorthand_never_traded(text):
    assert parse(text).kind == SHORTHAND


@pytest.mark.parametrize("text,side,entries,sl,tps", [
    ("Gold buy\n\n4145-4140\n\nTP 4162\nTP 4170\n\nSL 4135", "BUY", [4145, 4140], 4135, [4162, 4170]),
    ("GOLD BUY NOW\n\n4160-4155\n\nTP 4166\nTP 4173\n\nSL 4151", "BUY", [4160, 4155], 4151, [4166, 4173]),
    ("Gold sell\n\n4171-4176\n\nTP 4166\nTP 4158\n\nSL 4180", "SELL", [4171, 4176], 4180, [4166, 4158]),
    ("4348_4343\n\nTp4356\nTp4362\n\nSl4340", "BUY", [4348, 4343], 4340, [4356, 4362]),
])
def test_ultra(text, side, entries, sl, tps):
    p = parse(text)
    assert p.kind == SIGNAL and p.ultra and p.side == side
    assert p.entries == entries and p.sl == sl and p.tps == tps


@pytest.mark.parametrize("text,kind,side,also", [
    ("سل بزن", HINT, "SELL", []),
    ("بای بزنید", HINT, "BUY", []),
    ("GOLD SELL NOW", HINT, "SELL", []),
    ("بزن سلشو", HINT, "SELL", []),
    ("سل بزن دوباره", HINT, "SELL", [REENTER]),
    ("فریش کن", BE, None, []),
    ("ریسک فری کنید", BE, None, []),
    ("فری بزار", BE, None, []),
    ("ببندش", CLOSE, None, []),
    ("ببند سل بگیر", CLOSE, "SELL", [HINT]),
    ("ببندش سلش بزن", CLOSE, "SELL", [HINT]),
    ("بای ها کامل خروج بزن", CLOSE, "BUY", []),
    ("بگیر باز", REENTER, None, []),
    ("فری خورد بگیر باز", REENTER, None, []),
    ("فری خورد بگیرش مجدد", REENTER, None, []),
    ("جا موندی قیمت مارکت نزدیکش بزن", MARKET_NOW, None, []),
    ("نرسید قیمت مارکت بزن", MARKET_NOW, None, []),
    ("اگر فری خورد میگیریم باز", IF_BE_REENTER, None, []),
    ("فری خورد", BE_HIT, None, []),
    ("استاپ خورد", SL_HIT, None, []),
    ("Xau:4185", PRICE, None, []),
    ("+80pip", RESULT, None, []),
    ("برایند امروز: +160pip\n\n+80\n+80", RESULT, None, []),
])
def test_commands(text, kind, side, also):
    p = parse(text)
    assert (p.kind, p.side, p.also) == (kind, side, also)


@pytest.mark.parametrize("text", [
    "تا گفتم ببند رفت پایین",
    "پس چرا اعلام نکردی که ببند",
    "هر ۲ورود فعال هست ۴۵ رو با سود ببند الان ۴۰ رو ریسک فری کن",
    "اونم ریسک فریه",
    "🔺 4351 1405/06/30 11:36:13",
    "دلارو هفته ی قبل اینجا توی 226خرید زدیم الان 235هس اگر بریزه بازم  میخریم هدف اول 260 به زودی",
    "اینورم جوین باشید شاگرد های الترا سیگنال میدن https://t.me/lordclubnumber",
    "بزارید بهش برسه",
])
def test_chatter_is_noise(text):
    assert parse(text).kind == NOISE


def test_persian_digits_and_zwnj():
    p = parse("Xau‌ Sell Enter:۴۱۸۵/۴۱۸۶")
    assert p.kind == ZONE and p.entries == [4185, 4186]


@pytest.mark.parametrize("text", ["جا موندی نزن", "نرسیدی بیخیال نگیرید", "قیمت مارکت 4185 هست"])
def test_market_now_needs_a_positive_verb(text):
    assert parse(text).kind != MARKET_NOW and MARKET_NOW not in parse(text).also


def test_zwnj_verb_prefix_keeps_chatter_noise():
    assert parse("نمی‌گم ببندش").kind == NOISE
    assert parse("می‌گم ببند").kind == NOISE


@pytest.mark.parametrize("text", ["ریسک فری", "ریسک فری ✅"])
def test_risk_free_alone_is_breakeven(text):
    assert parse(text).kind == BE
