# -*- coding: utf-8 -*-
"""LORD XAU Trader — control window. Starts trading @lordxau by itself when opened
(settings.json: auto_start), shows the log, backtests a day of the channel, and lets the user
paste/rotate an LLM key straight into the panel (never a hand-edited file).

Look: dark «trading terminal» theme shared with the live dashboard — one palette, two surfaces."""
from __future__ import annotations

import copy
import datetime as dt
import os
import queue
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk
from tkinter.scrolledtext import ScrolledText

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from lordxau import CHANNEL, __version__  # noqa: E402
from lordxau import settings as st_mod  # noqa: E402
from lordxau.runner import Runner  # noqa: E402

# ------------------------------------------------------------------ palette (same tokens as dashboard.html, B design)
BG, BG2 = "#0a0e14", "#0e131b"
PANEL, PANEL2, PANEL3 = "#111722", "#141b27", "#18202e"
HOVER, LINE, LINE2 = "#1b2432", "#1e2733", "#273242"
FG, FG2, FG3, FG4 = "#e6edf3", "#aab6c4", "#6b7884", "#4a5560"
UP, DOWN, ACCENT, INFO, AI = "#16c784", "#ea3943", "#f0b90b", "#4a90e2", "#a259ff"

# colour roles the old code used by name (kept so the status logic reads the same)
GREEN, RED, GREY = UP, DOWN, FG3

FONT = ("Tahoma", 10)
FONT_SM = ("Tahoma", 8)
FONT_LBL = ("Tahoma", 8, "bold")
FONT_BRAND = ("Tahoma", 15, "bold")
FONT_MONO = ("Consolas", 10)
FONT_PILL = ("Tahoma", 9, "bold")


def _num(v, default: float) -> float:
    """float(v) that tolerates a hand-corrupted settings value (so the window still opens)."""
    try:
        return float(v)
    except (TypeError, ValueError):
        return float(default)


class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.q: queue.Queue = queue.Queue()
        self.runner = Runner(sink=self.q.put)
        self.settings_error = ""
        try:                                   # read only: the runner imports the old program at Start
            self.settings = st_mod.load(ROOT, log=self.q.put, do_import=False)
        except st_mod.SettingsError as exc:
            self.settings_error = str(exc)
            self.settings = copy.deepcopy(st_mod.DEFAULTS)
            self.q.put(f"⛔ settings.json خراب است ({exc}) — اصلاحش کنید یا حذفش کنید "
                       "(حذف = برداشتن دوبارهٔ تنظیمات از برنامهٔ قبلی). تا آن موقع «شروع» و «ذخیره» کار نمی‌کنند.")
        root.title(f"LORD XAU Trader {__version__} — فقط @{CHANNEL}")
        root.geometry("1040x760")
        root.minsize(900, 680)
        root.configure(bg=BG)
        root.option_add("*Font", FONT)
        self._build_theme()

        self._header()
        self._chips()
        self._toolbar()

        # ---- settings vars ----
        self.v_ultra, self.v_autobe, self.v_maxstop = tk.BooleanVar(), tk.DoubleVar(), tk.DoubleVar()
        self.v_mnow, self.v_auto, self.v_tp = tk.DoubleVar(), tk.BooleanVar(), tk.DoubleVar()
        self.v_llm = tk.BooleanVar()
        self._load_widgets(self.settings)

        self._account_panel()
        self._settings_panel()
        self._ai_panel()

        self._show_llm()
        self._show_account()
        self._fill_wallets()
        self._log_panel()

        root.protocol("WM_DELETE_WINDOW", self.on_close)
        root.after(200, self.pump)
        if self.v_auto.get():
            root.after(800, self.start)

    # ================================================================ theme
    def _build_theme(self) -> None:
        """One dark ttk theme (clam base) so every widget matches the live dashboard."""
        s = ttk.Style(self.root)
        try:
            s.theme_use("clam")
        except tk.TclError:
            pass
        self.root.option_add("*TCombobox*Listbox.background", PANEL2)
        self.root.option_add("*TCombobox*Listbox.foreground", FG)
        self.root.option_add("*TCombobox*Listbox.selectBackground", ACCENT)
        self.root.option_add("*TCombobox*Listbox.selectForeground", BG)
        self.root.option_add("*TCombobox*Listbox.font", FONT)

        s.configure(".", background=PANEL, foreground=FG2, fieldbackground=PANEL3,
                    bordercolor=LINE, lightcolor=PANEL, darkcolor=PANEL, focuscolor=PANEL)
        s.configure("TFrame", background=PANEL)
        s.configure("Bg.TFrame", background=BG)
        s.configure("TLabel", background=PANEL, foreground=FG2)
        s.configure("Hint.TLabel", background=PANEL, foreground=FG3, font=FONT_SM)

        s.configure("TLabelframe", background=PANEL, bordercolor=LINE, relief="solid", borderwidth=1)
        s.configure("TLabelframe.Label", background=PANEL, foreground=ACCENT, font=FONT_LBL)

        s.configure("TButton", background=PANEL3, foreground=FG, bordercolor=LINE2,
                    relief="flat", padding=(12, 6), focuscolor=PANEL3)
        s.map("TButton", background=[("active", HOVER), ("disabled", PANEL)],
              foreground=[("disabled", FG4)], bordercolor=[("active", LINE2)])
        s.configure("Accent.TButton", background=ACCENT, foreground=BG, padding=(14, 6))
        s.map("Accent.TButton", background=[("active", "#ffcd2e"), ("disabled", PANEL3)],
              foreground=[("disabled", FG4)])
        s.configure("Danger.TButton", background=PANEL3, foreground=DOWN)
        s.map("Danger.TButton", background=[("active", "#2a1416")], foreground=[("disabled", FG4)])
        s.configure("Ghost.TButton", background=PANEL, foreground=FG2, padding=(10, 5))
        s.map("Ghost.TButton", background=[("active", HOVER)])

        s.configure("TCheckbutton", background=PANEL, foreground=FG2, focuscolor=PANEL)
        s.map("TCheckbutton", background=[("active", PANEL)], foreground=[("active", FG)],
              indicatorcolor=[("selected", ACCENT), ("!selected", PANEL3)])

        for w in ("TEntry", "TSpinbox", "TCombobox"):
            s.configure(w, fieldbackground=PANEL3, foreground=FG, bordercolor=LINE2,
                        lightcolor=LINE2, darkcolor=LINE2, arrowcolor=FG2, insertcolor=FG,
                        selectbackground=LINE2, selectforeground=FG, padding=3)
        s.map("TCombobox", fieldbackground=[("readonly", PANEL3)], foreground=[("readonly", FG)],
              selectbackground=[("readonly", PANEL3)], selectforeground=[("readonly", FG)],
              arrowcolor=[("active", ACCENT)])
        s.map("TSpinbox", arrowcolor=[("active", ACCENT)])
        s.configure("TSeparator", background=LINE)

    # ================================================================ header / chips / toolbar
    def _header(self) -> None:
        h = tk.Frame(self.root, bg=BG2, height=58)
        h.pack(fill="x")
        h.pack_propagate(False)
        badge = tk.Label(h, text="LX", bg=ACCENT, fg=BG, font=FONT_BRAND, width=4)
        badge.pack(side="left", padx=(14, 10), pady=10, fill="y")
        box = tk.Frame(h, bg=BG2)
        box.pack(side="left", pady=10)
        tk.Label(box, text="LORD XAU Trader", bg=BG2, fg=FG, font=FONT_BRAND).pack(anchor="w")
        tk.Label(box, text=f"XAUUSD · فقط @{CHANNEL} · نسخه {__version__}",
                 bg=BG2, fg=FG3, font=FONT_SM).pack(anchor="w")
        self.pill = tk.Label(h, text="● متوقف", bg=PANEL3, fg=FG3, font=FONT_PILL,
                             padx=12, pady=5)
        self.pill.pack(side="right", padx=14)

    def _chips(self) -> None:
        wrap = tk.Frame(self.root, bg=BG)
        wrap.pack(fill="x", padx=10, pady=(10, 4))
        self.lbl = {}
        specs = (("telegram", "تلگرام"), ("broker", "بروکر"), ("wallet", "کیف‌پول"),
                 ("orders", "سفارش‌های باز"), ("last_msg", "آخرین پیام"))
        for k, t in specs:
            chip = tk.Frame(wrap, bg=PANEL2, highlightbackground=LINE, highlightthickness=1)
            chip.pack(side="left", padx=(0, 8), ipadx=10, ipady=5)
            tk.Label(chip, text=t, bg=PANEL2, fg=FG3, font=FONT_SM).pack(anchor="w", padx=8, pady=(4, 0))
            self.lbl[k] = tk.Label(chip, text="—", bg=PANEL2, fg=FG3, font=FONT_MONO)
            self.lbl[k].pack(anchor="w", padx=8, pady=(0, 4))

    def _toolbar(self) -> None:
        bar = ttk.Frame(self.root, style="Bg.TFrame", padding=(10, 2))
        bar.pack(fill="x")
        self.b_start = ttk.Button(bar, text="▶ شروع", style="Accent.TButton", command=self.start)
        self.b_stop = ttk.Button(bar, text="■ توقف", style="Danger.TButton", command=self.stop)
        self.b_start.pack(side="left", padx=(0, 4))
        self.b_stop.pack(side="left", padx=4)
        ttk.Separator(bar, orient="vertical").pack(side="left", fill="y", padx=10)
        ttk.Button(bar, text="📊 داشبورد زنده", style="Ghost.TButton",
                   command=self.open_dashboard).pack(side="left", padx=4)
        ttk.Button(bar, text="📁 پوشهٔ لاگ", style="Ghost.TButton",
                   command=lambda: os.startfile(str(ROOT / "logs"))
                   if (ROOT / "logs").exists() else None).pack(side="left", padx=4)
        ttk.Separator(bar, orient="vertical").pack(side="left", fill="y", padx=10)
        ttk.Label(bar, text="بک‌تست روز (UTC):", style="Hint.TLabel",
                  background=BG).pack(side="left", padx=(0, 4))
        self.bt_day = tk.StringVar(value=dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d"))
        ttk.Entry(bar, textvariable=self.bt_day, width=12).pack(side="left", padx=2)
        self.b_bt = ttk.Button(bar, text="اجرای بک‌تست", style="Ghost.TButton", command=self.backtest)
        self.b_bt.pack(side="left", padx=4)

    # ================================================================ panels
    def _account_panel(self) -> None:
        acc = ttk.LabelFrame(self.root, text="حساب بروکر  —  با انتخاب، ربات روی همین حساب دوباره شروع می‌کند",
                             padding=8)
        acc.pack(fill="x", padx=10, pady=(6, 0))
        ttk.Label(acc, text="کیف‌پول:").pack(side="left")
        self.v_wallet = tk.StringVar()
        self.cb_wallet = ttk.Combobox(acc, textvariable=self.v_wallet, state="readonly", width=52)
        self.cb_wallet.pack(side="left", padx=8)
        self.cb_wallet.bind("<<ComboboxSelected>>", self.on_wallet)
        self.acct = tk.Label(acc, text="", bg=PANEL, fg=FG2, font=FONT_SM, justify="left")
        self.acct.pack(side="left", padx=8)
        self._wallet_rows: list = []               # [(label, is_real, wallet_id)] behind the combobox
        self._wallet_sig = None
        self._restart_after_stop = False

    def _settings_panel(self) -> None:
        opt = ttk.LabelFrame(self.root, text="تنظیمات  —  با «ذخیره» از شروع بعدی اعمال می‌شود", padding=8)
        opt.pack(fill="x", padx=10, pady=6)
        ttk.Checkbutton(opt, text="سیگنال‌های ULTRA هم باز شود (استاپ ~۱۰ واحد، ریسک بالا)",
                        variable=self.v_ultra).grid(row=0, column=0, columnspan=2, sticky="w", pady=2)
        ttk.Checkbutton(opt, text="شروع خودکار با باز شدن برنامه", variable=self.v_auto).grid(
            row=0, column=2, columnspan=2, sticky="w", pady=2)
        for i, (t, v) in enumerate((("فری خودکار بعد از (واحد سود)", self.v_autobe),
                                    ("حد سود خودکار (واحد، ۰=خاموش)", self.v_tp),
                                    ("حداکثر فاصلهٔ استاپ اسکلپ (واحد)", self.v_maxstop),
                                    ("«جا موندی»: حداکثر فاصله از ناحیه", self.v_mnow))):
            r, c = 1 + i // 2, 2 * (i % 2)
            ttk.Label(opt, text=t).grid(row=r, column=c, sticky="e", padx=(10, 4), pady=2)
            ttk.Spinbox(opt, textvariable=v, from_=0, to=20, increment=0.25, width=6).grid(
                row=r, column=c + 1, sticky="w", pady=2)
        ttk.Button(opt, text="💾 ذخیره", style="Accent.TButton", command=self.save).grid(
            row=1, column=4, rowspan=2, padx=12, sticky="ns")

    def _ai_panel(self) -> None:
        """Assistant on/off + in-panel key entry (paste / test / rotate) — no hand-edited file."""
        ai = ttk.LabelFrame(self.root, text="🤖 دستیار هوش مصنوعی  —  کلید را همین‌جا وارد کنید", padding=8)
        ai.pack(fill="x", padx=10, pady=(0, 6))
        ai.columnconfigure(5, weight=1)

        ttk.Checkbutton(ai, text="روشن (فقط برای بستن/فری‌کردن معاملهٔ بازِ موجود با پیام فارسیِ بدون‌عدد "
                        "— هرگز معاملهٔ تازه باز نمی‌کند)", variable=self.v_llm).grid(
            row=0, column=0, columnspan=5, sticky="w")
        self.lbl_llm = tk.Label(ai, text="", bg=PANEL, fg=FG3, font=FONT_SM)
        self.lbl_llm.grid(row=0, column=5, sticky="e", padx=4)

        ttk.Label(ai, text="ارائه‌دهنده:").grid(row=1, column=0, sticky="e", padx=(0, 4), pady=(8, 0))
        self._providers = list(st_mod.LLM_PROVIDERS)              # (name, env, label)
        self.v_prov = tk.StringVar(value=self._providers[0][2])
        self.cb_prov = ttk.Combobox(ai, textvariable=self.v_prov, state="readonly", width=26,
                                    values=[p[2] for p in self._providers])
        self.cb_prov.grid(row=1, column=1, sticky="w", pady=(8, 0))
        self.cb_prov.bind("<<ComboboxSelected>>", lambda _e: self._show_llm())

        ttk.Label(ai, text="کلید:").grid(row=1, column=2, sticky="e", padx=(10, 4), pady=(8, 0))
        self.v_key = tk.StringVar()
        self.e_key = ttk.Entry(ai, textvariable=self.v_key, width=34, show="•")
        self.e_key.grid(row=1, column=3, sticky="w", pady=(8, 0))
        self.v_show = tk.BooleanVar(value=False)
        ttk.Checkbutton(ai, text="نمایش", variable=self.v_show,
                        command=self._toggle_key).grid(row=1, column=4, sticky="w", padx=(6, 0), pady=(8, 0))

        btns = ttk.Frame(ai)
        btns.grid(row=1, column=5, sticky="e", pady=(8, 0))
        ttk.Button(btns, text="💾 ذخیرهٔ کلید", style="Accent.TButton",
                   command=self._save_key).pack(side="left", padx=2)
        self.b_test = ttk.Button(btns, text="🔌 تست کلید", command=self._test_key)
        self.b_test.pack(side="left", padx=2)
        ttk.Button(btns, text="🗑 حذف", style="Danger.TButton",
                   command=self._del_key).pack(side="left", padx=2)

        self.lbl_key = tk.Label(ai, text="", bg=PANEL, fg=FG3, font=FONT_SM, anchor="w", justify="left")
        self.lbl_key.grid(row=2, column=0, columnspan=6, sticky="we", pady=(6, 0))
        tk.Label(ai, text="کلید فقط در فایل محلی .env.llm کنار برنامه ذخیره می‌شود — هرگز در settings.json "
                 "یا لاگ نوشته یا چاپ نمی‌شود. راهنمای گرفتن کلید در README آمده.",
                 bg=PANEL, fg=FG4, font=FONT_SM, anchor="w", justify="left").grid(
            row=3, column=0, columnspan=6, sticky="we", pady=(2, 0))

    def _log_panel(self) -> None:
        self.txt = ScrolledText(self.root, height=18, font=FONT_MONO, wrap="word",
                                bg=BG2, fg=FG, insertbackground=FG, selectbackground=LINE2,
                                relief="flat", borderwidth=0, padx=10, pady=8)
        self.txt.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    # ================================================================ helpers used across panels
    def _env_file(self) -> str:
        return str((st_mod.llm_config(self.settings).get("env_file") or ".env.llm"))

    def _provider(self) -> tuple:
        i = self.cb_prov.current()
        return self._providers[i if 0 <= i < len(self._providers) else 0]

    def _toggle_key(self) -> None:
        self.e_key.configure(show="" if self.v_show.get() else "•")

    def _load_widgets(self, s: dict) -> None:
        """The option widgets show ``s`` (called whenever a real settings file was read)."""
        ec = st_mod.engine_config(s)         # tolerant of bad values (falls back to defaults), unlike raw float()
        self.v_ultra.set(bool(ec.trade_ultra))
        self.v_autobe.set(_num(s.get("auto_breakeven_points"), 0.0))
        self.v_tp.set(st_mod.take_profit_points(s))
        self.v_maxstop.set(float(ec.max_stop_pts))
        self.v_mnow.set(float(ec.market_now_max_past))
        self.v_auto.set(bool(s.get("auto_start", True)))
        self.v_llm.set(bool((s.get("llm") or {}).get("enabled")))

    def _show_llm(self) -> None:
        """Line beside the checkbox: whether the *selected* provider (and any provider) has a key — so the
        user knows turning the assistant on will do something. Keys are never shown."""
        have = st_mod.llm_available_providers(self.settings, ROOT)
        sel = self._provider()[0] if getattr(self, "cb_prov", None) else None
        if have:
            self.lbl_llm.configure(text=f"کلید موجود: {', '.join(have)}", fg=UP)
        else:
            self.lbl_llm.configure(text="بدون کلید — کلید را پایین وارد کنید", fg=FG3)
        if getattr(self, "lbl_key", None):
            if sel in have:
                self.lbl_key.configure(text=f"✓ «{self._provider()[2]}» کلید دارد — می‌توانید «تست کلید» بزنید.",
                                       fg=UP)
            else:
                self.lbl_key.configure(text=f"«{self._provider()[2]}» هنوز کلید ندارد — کلید را بچسبانید و "
                                       "«ذخیرهٔ کلید» بزنید.", fg=FG3)

    def open_dashboard(self) -> None:
        url = self.runner.open_dashboard()
        if url:
            self.q.put(f"📊 داشبورد زنده باز شد: {url}")
        else:
            self.q.put("📊 داشبورد هنوز آماده نیست — «شروع» را بزنید؛ داشبورد با شروع ربات بالا می‌آید "
                       "(اگر در تنظیمات خاموشش نکرده باشید).")

    def _show_account(self):
        s = self.settings
        fx = s.get("fxtrendo") or {}
        risk = s.get("risk") or {}
        kind = "واقعی (REAL)" if fx.get("use_real_wallet") else "دمو (DEMO)"
        live = "ارسال سفارش فعال" if fx.get("enabled") and not fx.get("dry_run") else "آزمایشی — بدون ارسال سفارش"
        base = float(risk.get("risk_pct") or 2.0)
        eff = st_mod.effective_risk_pct(s)
        r = f"ریسک هر معامله {base:g}%" + (f" (با ULTRA روشن: {eff:g}%)" if eff != base else "")
        modes = st_mod.engine_config(s)
        r += f" — اسکلپ {'روشن' if modes.trade_scalp else 'خاموش'} / ULTRA {'روشن' if modes.trade_ultra else 'خاموش'}"
        src = {"user": "انتخاب شما", "old_program": "از برنامهٔ قبلی"}.get(
            st_mod.wallet_source(s), "پیش‌فرض — برنامهٔ قبلی پیدا نشد")
        self.acct.configure(text=f"{kind} ({src}) — {live} — {r} — حد ضرر روزانه {risk.get('max_daily_loss')}",
                            fg=DOWN if fx.get("use_real_wallet") else UP)

    # -------------------------------------------------------------- API key (in-panel)
    def _save_key(self):
        name, _env, label = self._provider()
        key = self.v_key.get().strip()
        if not key:
            messagebox.showinfo("کلید", "ابتدا کلید را در کادر بچسبانید. (برای حذف، دکمهٔ «حذف» را بزنید.)")
            return
        try:
            st_mod.set_llm_key(name, key, ROOT, self._env_file())    # writes .env.llm only; never logs the value
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("کلید", f"ذخیرهٔ کلید نشد: {type(exc).__name__}")
            return
        self.v_key.set("")                                          # clear the box so the key isn't left on screen
        self.v_show.set(False)
        self._toggle_key()
        self.settings_error = ""
        self._show_llm()
        self.q.put(f"🔑 کلید «{label}» ذخیره شد (در .env.llm). برای فعال‌سازی، تیک «روشن» را بزنید و «ذخیره».")
        if not self.v_llm.get():
            if messagebox.askyesno("دستیار", f"کلید «{label}» ذخیره شد.\nدستیار هوش مصنوعی همین حالا روشن شود؟"):
                self.v_llm.set(True)
                self.save()

    def _del_key(self):
        name, _env, label = self._provider()
        if not messagebox.askyesno("حذف کلید", f"کلید «{label}» از فایل .env.llm حذف شود؟"):
            return
        try:
            st_mod.set_llm_key(name, "", ROOT, self._env_file())     # empty value removes the line
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("کلید", f"حذف نشد: {type(exc).__name__}")
            return
        self._show_llm()
        self.q.put(f"🗑 کلید «{label}» حذف شد.")

    def _test_key(self):
        name, _env, label = self._provider()
        typed = self.v_key.get().strip() or None                    # test the typed key if any, else the saved one
        self.b_test.state(["disabled"])
        self.lbl_key.configure(text=f"… در حال تست «{label}» (یک درخواست شبکه)", fg=INFO)
        env_file = self._env_file()
        threading.Thread(target=self._test_worker, args=(name, label, typed, env_file), daemon=True).start()

    def _test_worker(self, name, label, typed, env_file):
        try:
            ok, msg = st_mod.probe_llm_key(name, ROOT, env_file, key=typed)    # one network call; never logs the key
        except Exception as exc:  # noqa: BLE001
            ok, msg = False, f"خطا: {type(exc).__name__}"
        self.root.after(0, lambda: self._test_done(label, ok, msg))

    def _test_done(self, label, ok, msg):
        self.b_test.state(["!disabled"])
        self.lbl_key.configure(text=f"{'✓' if ok else '✗'} {label}: {msg}", fg=UP if ok else DOWN)
        self.q.put(f"{'✅' if ok else '⛔'} تست کلید «{label}»: {msg}")

    # -------------------------------------------------------------- account
    def _fill_wallets(self) -> None:
        """Combobox rows: the account's wallets after a broker login, else the two kinds."""
        ws = self.runner.wallets()
        if ws:
            rows = [(f"{'واقعی REAL' if w['is_real'] else 'دمو DEMO'} — {w['id']} — موجودی {w['balance']} "
                     f"{w['currency']}".strip(), w["is_real"], w["id"]) for w in ws]
        else:
            rows = [("دمو (DEMO)", False, None), ("واقعی (REAL)", True, None)]
        self._wallet_rows = rows
        self.cb_wallet.configure(values=[r[0] for r in rows])
        self._show_wallet_choice()

    def _current_row(self) -> int:
        fx = self.settings.get("fxtrendo") or {}
        real, wid = bool(fx.get("use_real_wallet")), fx.get("wallet_id")
        active = [w for w in self.runner.wallets() if w["active"]]
        has_id = wid not in (None, "")
        for i, (_, r, rid) in enumerate(self._wallet_rows):
            if r != real:
                continue
            if has_id and (rid is None or str(rid) == str(wid)):     # a generic row stands for its kind
                return i
            if not has_id and (rid is None or (active and str(active[0]["id"]) == str(rid))):
                return i
        if has_id:                                 # the saved wallet is not in the list: nothing is "current"
            return -1
        for i, (_, r, _rid) in enumerate(self._wallet_rows):
            if r == real:
                return i
        return -1

    def _show_wallet_choice(self) -> None:
        i = self._current_row()
        self.v_wallet.set(self._wallet_rows[i][0] if i >= 0 else "")

    def on_wallet(self, _event=None):
        i = self.cb_wallet.current()
        if i < 0 or i >= len(self._wallet_rows):
            return
        if i == self._current_row():
            return
        label, real, wid = self._wallet_rows[i]
        if real:
            ok = messagebox.askyesno("حساب واقعی", "از این به بعد معامله‌ها روی حساب واقعی (پول واقعی) باز می‌شوند:\n"
                                                  f"{label}\n\nادامه؟")
        else:
            ok = messagebox.askyesno("حساب دمو", f"ربات روی حساب دمو معامله کند؟\n{label}")
        if not ok:
            self._show_wallet_choice()
            return
        try:
            self.settings = st_mod.set_wallet(ROOT, real, wid)
        except st_mod.SettingsError as exc:
            messagebox.showerror("حساب", f"settings.json خراب است و بازنویسی نمی‌شود:\n{exc}")
            self._show_wallet_choice()
            return
        self.settings_error = ""
        self._show_account()
        self._show_wallet_choice()
        if self.runner.running():
            self.q.put(f"🔁 حساب عوض شد ({label}) — ربات متوقف و روی حساب جدید دوباره شروع می‌شود …")
            self._restart_after_stop = True
            self.runner.stop()
        else:
            self.q.put(f"✅ حساب ذخیره شد ({label}) — شروع …")
            self.start()

    # -------------------------------------------------------------- actions
    def start(self):
        if self.runner.running():
            return
        if self.settings_error and (ROOT / "settings.json").is_file():
            try:
                self.settings = st_mod.read_file(ROOT / "settings.json")
                self.settings_error = ""
                self._load_widgets(self.settings)
                self._show_account()
            except st_mod.SettingsError:
                pass
        self.runner.start()

    def stop(self):
        self._restart_after_stop = False
        if self.runner.running():
            self.q.put("در حال توقف …")
            self.runner.stop()

    def save(self):
        path = ROOT / "settings.json"
        try:
            s = st_mod.read_file(path) if path.is_file() else st_mod.load(ROOT, log=self.q.put, do_import=False)
        except st_mod.SettingsError as exc:
            messagebox.showerror("ذخیره", f"settings.json خراب است و بازنویسی نمی‌شود:\n{exc}")
            return
        if self.settings_error:                  # the widgets still hold defaults, not this file
            self.settings, self.settings_error = s, ""
            self._load_widgets(s)
            self._show_account()
            messagebox.showinfo("ذخیره", "settings.json درست شده بود — مقدارهایش در پنجره آمد. "
                                         "اگر تغییری می‌خواهید بدهید و دوباره «ذخیره» بزنید.")
            return
        eng = dict(s.get("engine") or {})
        if self.v_ultra.get() and not eng.get("trade_ultra"):
            if not messagebox.askyesno("ULTRA", "سیگنال‌های ULTRA استاپ حدود ۱۰ واحد دارند "
                                               "(با ۰٫۰۱ لات حدود ۱۰ دلار = ~۱۰٪ این حساب در هر معامله).\n"
                                               f"تا ULTRA روشن است ریسک هر معامله (اسکلپ‌ها هم) "
                                               f"{st_mod.ULTRA_RISK_PCT:g}% حساب می‌شود؛ با خاموش کردنش برمی‌گردد.\n"
                                               "در بک‌تست ULTRA جمعاً ضرر داد.\nمطمئن هستید؟"):
                self.v_ultra.set(False)
        eng.update(trade_ultra=bool(self.v_ultra.get()), max_stop_pts=float(self.v_maxstop.get()),
                   market_now_max_past=float(self.v_mnow.get()))
        s["engine"] = eng
        s["auto_breakeven_points"] = float(self.v_autobe.get())
        s["take_profit_points"] = float(self.v_tp.get())
        s["auto_start"] = bool(self.v_auto.get())
        if self.v_llm.get() and not st_mod.llm_available_providers(s, ROOT):
            if not messagebox.askyesno("هوش مصنوعی", "دستیار هوش مصنوعی را روشن کردید ولی هیچ کلیدی ذخیره نشده.\n"
                                       "بدون کلید، دستیار خاموش می‌ماند و ربات فقط با regex کار می‌کند.\n"
                                       "به‌هرحال ذخیره شود؟"):
                self.v_llm.set(False)
        llm = dict(s.get("llm") or {})
        llm["enabled"] = bool(self.v_llm.get())
        s["llm"] = llm
        st_mod.save(s, ROOT)
        self.settings = s
        self.settings_error = ""
        self._show_account()
        self._show_llm()
        self.q.put("✅ تنظیمات ذخیره شد" + (" — برای اعمال: توقف و شروع" if self.runner.running() else ""))

    def backtest(self):
        day = self.bt_day.get().strip()
        try:
            d = dt.date.fromisoformat(day)
        except ValueError:
            messagebox.showerror("بک‌تست", "تاریخ را به شکل 2026-09-28 بنویسید")
            return
        self.b_bt.state(["disabled"])
        threading.Thread(target=self._bt, args=(d,), daemon=True).start()

    def _bt(self, d):
        from lordxau import backtest as bt
        try:
            s = self.settings
            since = dt.datetime(d.year, d.month, d.day, tzinfo=dt.timezone.utc)
            self.q.put(f"🔎 بک‌تست {d}: خواندن پیام‌های @{CHANNEL} از صفحهٔ عمومی t.me/s/{CHANNEL} …")
            rows = bt.fetch_channel(since, since + dt.timedelta(days=1), log=self.q.put)
            self.q.put(f"   {len(rows)} پیام — دریافت قیمت‌های تیک XAUUSD (Dukascopy) …")
            bt.fetch_ticks(d, bt.hours_of(rows, d), log=self.q.put)
            ticks = bt.load_ticks([d])
            if not ticks or not rows:
                self.q.put("⛔ داده کافی نیست (پیام یا تیک)")
                return
            bal = 105.0
            try:
                w = getattr(self.runner.broker, "wallet", None) or {}
                bal = float(w.get("balance") or bal)
            except (TypeError, ValueError):
                pass
            scfg = bt.sim_config_from_settings(s, bal)       # the same risk / limits as the live run
            tr: list = []
            res = bt.replay(rows, ticks, st_mod.engine_config(s), scfg, latency=6.0, trace=tr)
            out = ROOT / "logs" / f"backtest-{d}.txt"
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(bt.report(res, f"@{CHANNEL} {d}") + "\n\n" + "\n".join(tr), encoding="utf-8")
            for line in bt.report(res, f"📊 نتیجهٔ بک‌تست {d} (لات 0.01، تأخیر پیام 6 ثانیه):").splitlines():
                self.q.put(line)
            self.q.put(f"   جزئیات پیام‌به‌پیام: {out}")
        except Exception as exc:
            self.q.put(f"⛔ خطای بک‌تست: {exc!r}")
        finally:
            self.root.after(0, lambda: self.b_bt.state(["!disabled"]))

    def on_close(self):
        if self.runner.running():
            if not messagebox.askyesno("خروج", "ربات در حال اجراست. متوقف شود و برنامه بسته شود؟"):
                return                             # a pending restart (wallet switch) still happens
            self._restart_after_stop = False
            self.runner.stop()
            self._close_wait(40)
            return
        self.root.destroy()

    def _close_wait(self, n):
        if self.runner.running() and n > 0:
            self.root.after(250, lambda: self._close_wait(n - 1))
            return
        self.root.destroy()

    # -------------------------------------------------------------- ui loop
    def pump(self):
        try:
            while True:
                line = self.q.get_nowait()
                self.txt.insert("end", str(line) + "\n")
                self.txt.see("end")
        except queue.Empty:
            pass
        rs = self.runner.settings                  # what the last Start really loaded (first run: imported)
        if rs and id(rs) != getattr(self, "_rs_id", None):
            self._rs_id = id(rs)
            self.settings = rs
            self.settings_error = ""
            self._load_widgets(rs)
            self._show_account()
            self._show_wallet_choice()
            self._show_llm()
        ws = self.runner.wallets()
        sig = tuple((w["id"], w["is_real"], w["balance"], w["active"]) for w in ws)
        if sig != self._wallet_sig:                # a login brought (new) wallets / balances
            self._wallet_sig = sig
            self._fill_wallets()
        if self._restart_after_stop and not self.runner.running():
            self._restart_after_stop = False
            self.start()
        st = self.runner.status
        for k, w in self.lbl.items():
            v = st.get(k)
            if k == "last_msg":
                v = dt.datetime.fromtimestamp(v).strftime("%H:%M:%S") if v else "—"
            w.configure(text=str(v if v not in (None, "") else "—"),
                        fg=UP if v in ("متصل",) else (DOWN if v in ("خطا", "قطع", "وارد نشده") else FG))
        running = self.runner.running()
        self.b_start.state(["disabled"] if running else ["!disabled"])
        self.b_stop.state(["!disabled"] if running else ["disabled"])
        if running:
            self.pill.configure(text="● زنده", bg="#0f2a1f", fg=UP)
        else:
            self.pill.configure(text="● متوقف", bg=PANEL3, fg=FG3)
        if running:                                 # live state of the assistant while trading
            llm = st.get("llm")
            if llm == "روشن":
                self.lbl_llm.configure(text="🤖 دستیار روشن است", fg=UP)
            elif llm == "خاموش":
                self.lbl_llm.configure(text="دستیار خاموش است (فقط regex)", fg=FG3)
        self.root.after(300, self.pump)


def main():
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
