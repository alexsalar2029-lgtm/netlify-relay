#!/usr/bin/env python3
"""Offline, sanitized audit; emits no credential, wallet or broker order identifiers."""
import argparse
import collections
import datetime
import json
import math
from pathlib import Path
import re
import statistics


def read_jsonl(path):
    rows = []
    for line in path.read_text(encoding='utf-8').splitlines():
        if line.strip():
            rows.append(json.loads(line))
    return rows


def number(value):
    if isinstance(value, bool) or value is None:
        return None
    try:
        v = float(value)
    except (TypeError, ValueError):
        return None
    return v if math.isfinite(v) else None


def summarize(rows):
    pp = [number(t.get('profit')) for t in rows]
    pp = [p for p in pp if p is not None]
    wins = [p for p in pp if p > 0]
    losses = [p for p in pp if p < 0]
    return {
        'trade_count': len(rows), 'known_profit_count': len(pp),
        'unknown_profit_count': len(rows) - len(pp),
        'broker_reported_profit_sum': round(sum(pp), 4),
        'wins': len(wins), 'losses': len(losses), 'flat': pp.count(0.0),
        'profit_factor': round(sum(wins)/(-sum(losses)), 4) if losses else None,
        'average_win': round(statistics.mean(wins), 4) if wins else None,
        'average_loss': round(statistics.mean(losses), 4) if losses else None,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    root = Path(__file__).resolve().parent
    parser.add_argument('--logs', type=Path, default=root / 'logs')
    parser.add_argument('--output', type=Path, default=root / 'logs' / 'audit_latest.json')
    args = parser.parse_args()
    trades_raw = read_jsonl(args.logs / 'trades.jsonl')
    # One row per wallet and order. An observed numeric final profit supersedes
    # an unknown closure; unknown later snapshots do not erase that observation.
    trades = {}
    for index, row in enumerate(trades_raw):
        key = (str(row.get('wallet')), str(row.get('id')))
        if row.get('id') is None:
            key = (str(row.get('wallet')), f'missing-{index}')
        old = trades.get(key)
        if old is None or number(row.get('profit')) is not None or number(old.get('profit')) is None:
            trades[key] = row
    rows = list(trades.values())
    decisions = [row for file in sorted(args.logs.glob('decisions-*.jsonl')) for row in read_jsonl(file)]
    messages = [row for file in sorted(args.logs.glob('messages-*.jsonl')) for row in read_jsonl(file)]
    target_messages = list({(m.get('id'), m.get('text')): m for m in messages
                            if m.get('channel') == 'lordxau'}.values())
    groups = collections.defaultdict(list)
    wallet_labels = {}
    for row in rows:
        wallet = str(row.get('wallet'))
        label = wallet_labels.setdefault(wallet, f'wallet_group_{len(wallet_labels)+1}')
        groups[(label, str(row.get('currency') or 'unknown'))].append(row)
    modes = collections.Counter((d.get('modes', {}).get('trade_scalp'),
                                 d.get('modes', {}).get('trade_ultra'))
                                for d in decisions if d.get('type') == 'message')
    by_id = {d['id']: d for d in decisions if d.get('id') is not None}
    evidence = []
    for mid in [91246, 91015, 91258, 91913, 91842]:
        d = by_id[mid]
        llm = d.get('llm') or {}
        # Only channel message ID and body are copied. Executor lines can carry
        # broker order identifiers and are intentionally not copied wholesale.
        evidence.append({'channel_message_id': mid, 'text': d.get('text'),
                         'recorded_parser_kind': d.get('kind'),
                         'recorded_llm_action': llm.get('action'),
                         'timestamp_utc': datetime.datetime.fromtimestamp(d['ts'], datetime.timezone.utc).isoformat()})
    latencies = [d['recv'] - d['ts'] for d in decisions if d.get('type') == 'message'
                 and d.get('recv') is not None and d.get('ts') is not None
                 and d.get('kind') in ('ZONE', 'STOP', 'BE', 'CLOSE')]
    guard_closures = []
    raw_by_order = {str(row.get('id')): row for row in rows}
    diagnostics = (args.logs / 'bot.log').read_text(encoding='utf-8', errors='replace').splitlines()
    risks = []
    for line in diagnostics:
        if 'signal_trader.fxtrendo:' not in line:
            continue
        r = re.search(r'min_lot \(actual risk ([0-9.]+)%, budget ([0-9.]+)%', line)
        if r:
            risks.append(tuple(map(float, r.groups())))
        if 'گارد بریک' not in line:
            continue
        m = re.search(r'ورود ([0-9.]+).*?سفارش (\d+).*?\(bid=([0-9.]+) ask=([0-9.]+)\)', line)
        if not m:
            continue
        level, oid, bid, ask = m.groups()
        t = raw_by_order.get(oid)
        if not t:
            continue
        guard_closures.append({'bot_log_timestamp_as_stored': line[:23],
                               'side': t['side'], 'actual_fill': number(t['open']),
                               'guard_level': number(level), 'bid': number(bid), 'ask': number(ask),
                               'broker_reported_profit': number(t['profit'])})
    be_groups = collections.defaultdict(list)
    for row in rows:
        fill, stop = number(row.get('open')), number(row.get('sl'))
        if fill is None or stop is None:
            kind = 'unknown'
        elif abs(fill-stop) < 1e-6:
            kind = 'stop_at_actual_fill'
        elif abs(fill-stop) <= 1.35:
            kind = 'stop_near_actual_fill_not_equal'
        else:
            kind = 'stop_more_than_1_35_points_from_fill'
        be_groups[kind].append(row)
    small_losses = [row for row in rows if number(row.get('profit')) is not None and -1.0 < number(row['profit']) < 0.0]
    result = {
        'analysis_scope': 'Offline uploaded logs; recorded 2.0.10 classifications, no broker/Telegram calls',
        'raw_trade_rows': len(trades_raw), 'duplicate_trade_rows': len(trades_raw)-len(rows),
        'closed_unseen_raw_event_count': sum(row.get('type') == 'closed_unseen' for row in trades_raw),
        'trades': summarize(rows),
        'groups': [{'wallet_group': label, 'currency': currency, **summarize(group)}
                   for (label, currency), group in groups.items()],
        'per_day': [{'day': day, **summarize([r for r in rows if r.get('day') == day])}
                    for day in sorted(set(r.get('day') for r in rows))],
        'raw_message_rows': len(messages), 'distinct_target_message_bodies': len(target_messages),
        'decision_count': len(decisions),
        'recorded_parser_kinds': dict(collections.Counter(d.get('kind') or 'timer' for d in decisions)),
        'message_modes': [{'trade_scalp': scalp, 'trade_ultra': ultra, 'count': count}
                          for (scalp, ultra), count in modes.items()],
        'llm': {'calls': sum(bool(d.get('llm')) for d in decisions),
                'risk_free_actions': sum((d.get('llm') or {}).get('action') == 'risk_free' for d in decisions)},
        'small_negative_profit': summarize(small_losses),
        'stops_relative_to_fill': {kind: summarize(group) for kind, group in be_groups.items()},
        'virtual_guard_closures': guard_closures,
        'virtual_guard_broker_profit_sum': round(sum(x['broker_reported_profit'] for x in guard_closures), 4),
        'executor_min_lot_diagnostics': {'count': len(risks),
                                      'actual_risk_mean_percent': round(statistics.mean(x[0] for x in risks), 4) if risks else None,
                                      'actual_risk_max_percent': max(x[0] for x in risks) if risks else None,
                                      'configured_budgets_percent': sorted(set(x[1] for x in risks))},
        'management_message_latency_seconds': {'sample_count': len(latencies),
                                             'median': round(statistics.median(latencies), 4),
                                             'max': round(max(latencies), 4),
                                             'more_than_5_seconds': sum(v > 5 for v in latencies)},
        'regression_evidence': evidence,
        'limitations': [
            'Broker reported profit is not complete net account return; separate commission/fees are not fields in trades.jsonl.',
            'Only closed logged trades are counted. No complete tick history or open-position mark-to-market is present.',
            'Stop-near-fill categories are descriptive; they do not prove all exits were caused by breakeven.',
            'Observed mode evidence applies to recorded message decisions; no claim about absent historical settings.',
            'Bot log timestamps and message date strings use host-local presentation; epoch timestamps provide UTC when available.',
            'backtest-2026-09-29.txt contains one trade and warns of messages after the last tick; it cannot establish out-of-sample improvement.',
            'No profit or Sharpe optimization can be validated from these logs; frozen-risk safety regressions are suitable.',
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result['trades'], ensure_ascii=False))
    print('Sanitized audit written:', args.output)


if __name__ == '__main__':
    main()
