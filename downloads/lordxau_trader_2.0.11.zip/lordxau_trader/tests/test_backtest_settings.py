# -*- coding: utf-8 -*-
"""The simulated broker / replay, and settings import (all in tmp dirs)."""
import asyncio
import json

import pytest

from lordxau import settings as st_mod
from lordxau.backtest import SimBroker, SimConfig, replay, sim_config_from_settings
from lordxau.engine import EngineConfig
from signal_trader.models import OrderType, Side, Signal

T0 = 1_790_000_000.0


def ticks(path):
    """[(t, bid)] -> [(t, bid, ask)] with a 0.1 spread, one tick per second."""
    out = []
    for (t0, b0), (t1, b1) in zip(path, path[1:]):
        n = int(t1 - t0)
        for i in range(n):
            b = b0 + (b1 - b0) * i / n
            out.append((T0 + t0 + i, b, b + 0.1))
    return out


def run(coro):
    return asyncio.run(coro)


def test_sell_zone_fills_and_closes_in_profit():
    tk = ticks([(0, 4187.0), (30, 4189.2), (60, 4184.0), (200, 4183.0)])
    rows = [{"id": 1, "ts": T0 + 1, "text": "Xau Sell Enter:4190/4189"},
            {"id": 2, "ts": T0 + 3, "text": "Stop:4192"},
            {"id": 3, "ts": T0 + 100, "text": "ببندش"}]
    res = replay(rows, tk, EngineConfig(), SimConfig(auto_tp={"lordxau": 0.0}), latency=1.0)
    assert len(res["trades"]) == 1
    t = res["trades"][0]
    assert t["side"] == "SELL" and t["why"] == "CLOSE" and t["pts"] > 3
    t = replay(rows, tk, EngineConfig(), SimConfig(), latency=1.0)["trades"][0]   # default TP 2.75
    assert t["why"] == "TP" and t["pts"] == pytest.approx(2.75, abs=0.01)     # TP rounded to the cent


def test_zone_never_reached_is_no_trade():
    tk = ticks([(0, 4187.0), (100, 4183.0), (300, 4180.0)])
    rows = [{"id": 1, "ts": T0 + 1, "text": "Xau Sell Enter:4190/4189"},
            {"id": 2, "ts": T0 + 3, "text": "Stop:4192"},
            {"id": 3, "ts": T0 + 50, "text": "فریش کن"},
            {"id": 4, "ts": T0 + 150, "text": "ببندش"}]
    res = replay(rows, tk, EngineConfig(), SimConfig(), latency=1.0)
    assert res["trades"] == []


def test_sizing_is_the_executors():
    sim = SimBroker(ticks([(0, 4150.0), (10, 4150.0)]), SimConfig(balance=105.0, risk_pct=2.0))
    sim.advance(T0 + 5)
    lot, why = sim._size("BUY", [4150.0], 4140.0, 4150.0)
    assert lot == 0 and "would risk" in why                         # 10 $ = 9.5 % > 6 %
    assert sim._size("BUY", [4150.0], 4147.0, 4150.0) == (0.01, "")  # 3 $ = 2.9 %
    assert sim._size("BUY", [4150.0], 4149.0, 4150.0) == (0.02, "")  # 2.1 $ / 1 pt -> 0.02 lot
    fixed = SimBroker(sim.ticks, SimConfig(sizing="fixed"))
    assert fixed._size("BUY", [4150.0], 4140.0, 4150.0) == (0.01, "")


def test_breakeven_ref_rule_matches_executor():
    p = {"side": "SELL", "fill": 4185.5, "sl": 4189.0}
    assert SimBroker._be_ref(p, 4186.0) == 4186.0                # 0.5 worse, within half of 3.5
    assert SimBroker._be_ref(p, 4190.0) == 4185.5                # far worse -> own fill
    assert SimBroker._be_ref({"side": "SELL", "fill": 4185.5, "sl": 4185.0}, 4186.0) == 4185.0   # never loosen


def _sig(side, entries, sl, tp=None, market=False):
    return Signal(symbol="XAUUSD", side=Side(side), order_type=OrderType.MARKET if market else OrderType.LIMIT,
                  entries=list(entries), stop_loss=sl, take_profits=[tp] if tp else [], source="lordxau")


def test_close_and_breakeven_with_a_stale_quote_do_not_crash():
    tk = ticks([(0, 4190.0), (60, 4190.0)])
    sim = SimBroker(tk, SimConfig())
    sim.advance(T0 + 10)
    res = run(sim.execute(_sig("SELL", [4190.0, 4189.0], 4192.0)))
    assert res["action"] == "placed"
    sim.advance(T0 + 2000)                                       # 30 min without a tick
    assert sim.q is None
    assert run(sim.breakeven(order_ids=[1]))["action"] == "breakeven_virtual"
    run(sim.close(order_ids=[1]))
    assert sim.closed and sim.closed[0]["why"] == "CLOSE-stale"


def test_open_trade_at_end_of_data_is_booked():
    tk = ticks([(0, 4190.0), (30, 4190.0), (60, 4195.0)])
    rows = [{"id": 1, "ts": T0 + 1, "text": "Xau Sell Enter:4190/4189"},
            {"id": 2, "ts": T0 + 2, "text": "Stop:4196"}]
    res = replay(rows, tk, EngineConfig(max_stop_pts=8.0), SimConfig(risk_pct=5.0), latency=1.0)
    assert len(res["trades"]) == 1 and res["trades"][0]["why"].startswith("END")
    assert res["trades"][0]["pts"] < 0


def test_tp_first_rule_is_decided_once():
    # registered with the price beyond TP (4165 > 4162): the zone keeps waiting after a dip
    tk = ticks([(0, 4165.0), (20, 4160.0), (40, 4164.0), (80, 4144.0), (100, 4144.0)])
    sim = SimBroker(tk, SimConfig(risk_pct=10.0))
    sim.advance(T0 + 1)
    res = run(sim.execute(_sig("BUY", [4145.0, 4140.0], 4135.0, tp=4162.0)))
    assert res["action"] == "pending_virtual"
    sim.advance(T0 + 99)
    assert [p for p in sim.pos if p["state"] == "open"]


def test_update_levels_refuses_a_stop_past_the_fill():
    tk = ticks([(0, 4188.12), (60, 4188.12)])
    sim = SimBroker(tk, SimConfig())
    sim.advance(T0 + 1)
    run(sim.execute(_sig("BUY", [4188.12], 4186.0, market=True)))
    res = run(sim.update_levels(sl=4188.2, order_ids=[1]))
    assert res["action"] == "levels_rejected" and sim.pos[0]["sl"] == 4186.0
    assert run(sim.update_levels(sl=4186.5, order_ids=[1]))["action"] == "levels_updated"


def test_edit_of_a_message_never_delivered_is_ignored():
    tk = ticks([(0, 4189.5), (100, 4189.5)])
    rows = [{"id": 7, "ts": T0 + 1, "text": "Xau Sell Enter:4190/4189 Stop:4192", "edited": True}]
    res = replay(rows, tk, EngineConfig(), SimConfig(), latency=1.0)
    assert res["trades"] == [] and not res["counts"]


@pytest.fixture(autouse=True)
def _no_desktop_search(monkeypatch):
    """Tests never find a real telegram_signal_trader on this machine's Desktop."""
    monkeypatch.setattr(st_mod, "_desktop_candidates", lambda: [])


def _old_program(tmp_path, real=True):
    old = tmp_path / "telegram_signal_trader"
    (old / "signal_trader").mkdir(parents=True)
    (old / "data").mkdir()
    (old / "gui.py").write_text("# old program\n", encoding="utf-8")
    (old / "config.yaml").write_text(
        "mode: fxtrendo\n"
        "telegram:\n  session_name: signal_trader\n"
        "fxtrendo:\n  enabled: true\n  dry_run: false\n"
        f"  use_real_wallet: {'true' if real else 'false'}\n  wallet_id: 12345\n  max_open_positions: 3\n"
        "  order:\n    event: order_add\n"
        "risk:\n  sizing: risk_pct\n  risk_pct: 2\n  max_daily_loss: 8\n", encoding="utf-8")
    (old / ".env").write_text("TG_API_ID=1\n", encoding="utf-8")
    (old / "signal_trader.session").write_bytes(b"x")
    (old / "data" / "bot_orders.json").write_text(json.dumps({
        "orders": {"11": 1.0, "12": 2.0},
        "owners": {"11": ["lordxau", "XAUUSD", None], "12": ["other_channel", "XAUUSD", None]}}),
        encoding="utf-8")
    new = tmp_path / "lordxau_trader"
    new.mkdir()
    return old, new


def test_first_run_imports_the_old_program(tmp_path):
    old, new = _old_program(tmp_path)
    s = st_mod.load(new, log=lambda *_: None)
    assert s["fxtrendo"]["use_real_wallet"] is True and s["fxtrendo"]["wallet_id"] == 12345
    assert s["fxtrendo"]["order"]["event"] == "order_add"
    assert s["fxtrendo"]["max_open_positions"] == 1                # forced for the scalp
    assert s["risk"]["max_daily_loss"] == 8
    assert (new / ".env").is_file() and (new / "signal_trader.session").is_file()
    assert json.loads((new / "settings.json").read_text(encoding="utf-8"))["imported_from"] == str(old)


def test_window_preview_never_writes(tmp_path):
    old, new = _old_program(tmp_path)
    s = st_mod.load(new, log=lambda *_: None, do_import=False)
    assert s["fxtrendo"]["use_real_wallet"] is True
    assert not (new / "settings.json").exists() and not (new / ".env").exists()


def test_old_orders_merge_keeps_only_this_channel(tmp_path):
    old, new = _old_program(tmp_path)
    assert st_mod.merge_old_orders(old, new) == 1
    d = json.loads((new / "data" / "bot_orders.json").read_text(encoding="utf-8"))
    assert list(d["orders"]) == ["11"] and d["owners"]["11"][0] == "lordxau"
    assert st_mod.merge_old_orders(old, new) == 0                  # a union: nothing twice


def test_daily_state_carries_over(tmp_path):
    old, new = _old_program(tmp_path)
    day = "2026-09-29"
    (old / "daily_state.json").write_text(json.dumps(
        {"day": day, "trades": 3, "start_balance": 110.0, "wallet": "w1", "other_baselines": {}}), encoding="utf-8")
    (new / "daily_state.json").write_text(json.dumps(
        {"day": day, "trades": 1, "start_balance": 104.0, "wallet": "w1", "other_baselines": {}}), encoding="utf-8")
    assert st_mod.merge_daily_state(old, new, today=day)
    d = json.loads((new / "daily_state.json").read_text(encoding="utf-8"))
    assert d["start_balance"] == 110.0 and d["trades"] == 3          # the earlier (higher) baseline counts the loss
    (new / "daily_state.json").unlink()
    assert st_mod.merge_daily_state(old, new, today=day)
    assert json.loads((new / "daily_state.json").read_text(encoding="utf-8"))["start_balance"] == 110.0
    assert not st_mod.merge_daily_state(old, new, today="2026-09-30")    # yesterday's is not carried


def test_first_run_never_overwrites_existing_files(tmp_path):
    old, new = _old_program(tmp_path)
    (new / ".env").write_text("MINE=1\n", encoding="utf-8")
    st_mod.load(new, log=lambda *_: None)
    assert (new / ".env").read_text(encoding="utf-8") == "MINE=1\n"


def test_no_old_program_means_demo(tmp_path):
    new = tmp_path / "alone" / "lordxau_trader"
    new.mkdir(parents=True)
    s = st_mod.load(new, log=lambda *_: None)
    assert s["fxtrendo"]["use_real_wallet"] is False


def test_broken_settings_are_never_replaced_by_defaults(tmp_path):
    new = tmp_path / "x"
    new.mkdir()
    (new / "settings.json").write_text('{"fxtrendo": {"use_real_wallet": true', encoding="utf-8")
    with pytest.raises(st_mod.SettingsError):
        st_mod.load(new, log=lambda *_: None)
    (new / "settings.json").write_text('{"fxtrendo": null}', encoding="utf-8")
    with pytest.raises(st_mod.SettingsError):
        st_mod.load(new, log=lambda *_: None)
    (new / "settings.json").write_text('\ufeff{"fxtrendo": {"use_real_wallet": true}}', encoding="utf-8")
    assert st_mod.load(new, log=lambda *_: None)["fxtrendo"]["use_real_wallet"] is True


def test_broker_config_carries_auto_breakeven(tmp_path):
    new = tmp_path / "x"
    new.mkdir()
    s = st_mod.load(new, log=lambda *_: None)
    cfg = st_mod.broker_config(s)
    assert cfg.channel_settings["lordxau"].auto_breakeven_points == 1.5
    assert cfg.channel_settings["lordxau_ultra"].auto_breakeven_points == 0.0
    assert cfg.mode == "fxtrendo" and cfg.fxtrendo["virtual_limits"] is True


def test_ultra_risk_bump_is_never_saved(tmp_path):
    new = tmp_path / "x"
    new.mkdir()
    s = st_mod.load(new, log=lambda *_: None)
    s["engine"] = {"trade_ultra": True}
    assert st_mod.broker_config(s).risk["risk_pct"] == 3.5 and s["risk"]["risk_pct"] == 2.0
    s["engine"] = {"trade_ultra": False}
    assert st_mod.broker_config(s).risk["risk_pct"] == 2.0


def test_sim_config_follows_settings(tmp_path):
    new = tmp_path / "x"
    new.mkdir()
    s = st_mod.load(new, log=lambda *_: None)
    s["risk"].update(risk_pct=1.0, max_daily_loss=5.0)
    s["auto_breakeven_points"] = 2.0
    c = sim_config_from_settings(s, 150.0)
    assert (c.balance, c.risk_pct, c.max_daily_loss, c.sizing) == (150.0, 1.0, 5.0, "risk_pct")
    assert c.auto_be["lordxau"] == 2.0 and c.max_open == 1 and c.zone_chase_frac == 0.2


def test_old_program_command_lines():
    from lordxau.runner import is_old_cmd
    assert is_old_cmd(r'"C:\Python311\python.exe" gui.py')
    assert is_old_cmd(r"pythonw.exe C:\Users\Administrator\Desktop\telegram_signal_trader\gui.py")
    assert is_old_cmd("python run.py")
    assert is_old_cmd("python -m signal_trader.app")
    assert not is_old_cmd("python lordxau_gui.py")
    assert not is_old_cmd("python -m lordxau.runner")
    assert not is_old_cmd(r"C:\x\lordxau_trader\lordxau_gui.py")
    assert not is_old_cmd("python some_other_tool.py")


def test_daily_state_reviewer_scenario_keeps_the_loss(tmp_path):
    # new program first today at 105 -> 100; old program 100 -> 96; back to the new one
    old, new = _old_program(tmp_path)
    day = "2026-09-29"
    (new / "daily_state.json").write_text(json.dumps(
        {"day": day, "trades": 2, "start_balance": 105.0, "wallet": "R", "other_baselines": {}}), encoding="utf-8")
    (old / "daily_state.json").write_text(json.dumps(
        {"day": day, "trades": 1, "start_balance": 100.0, "wallet": "R", "other_baselines": {}}), encoding="utf-8")
    st_mod.merge_daily_state(old, new, today=day)
    assert json.loads((new / "daily_state.json").read_text(encoding="utf-8"))["start_balance"] == 105.0


def test_waiting_zones_count_for_max_open_like_the_executor():
    # SELL filled and still open when the next zone comes: the executor refuses it (1 + 1 > 1)
    tk = ticks([(0, 4189.6), (40, 4189.6), (80, 4192.5), (120, 4194.5), (200, 4188.0)])
    rows = [{"id": 1, "ts": T0 + 1, "text": "Xau Sell Enter:4190/4189"},
            {"id": 2, "ts": T0 + 2, "text": "Stop:4192"},
            {"id": 3, "ts": T0 + 50, "text": "Xau Sell Enter:4194/4195"},
            {"id": 4, "ts": T0 + 51, "text": "Stop:4197"}]
    res = replay(rows, tk, EngineConfig(), SimConfig(), latency=1.0)
    assert len(res["trades"]) == 1


def test_old_program_found_through_the_extract_all_folder(tmp_path):
    old, _ = _old_program(tmp_path)
    nested = old / "lordxau_trader_2.0.0" / "lordxau_trader"      # Windows "Extract All" adds a folder
    nested.mkdir(parents=True)
    assert st_mod.find_old_program(nested) == old
    s = st_mod.load(nested, log=lambda *_: None)
    assert s["fxtrendo"]["use_real_wallet"] is True and (nested / ".env").is_file()


def test_old_program_found_on_the_desktop(tmp_path, monkeypatch):
    old, _ = _old_program(tmp_path)
    far = tmp_path / "somewhere" / "else" / "x" / "y" / "lordxau_trader"
    far.mkdir(parents=True)
    monkeypatch.setattr(st_mod, "_desktop_candidates", lambda: [old])
    assert st_mod.find_old_program(far) == old


def test_our_own_folder_is_never_the_old_program(tmp_path):
    other = tmp_path / "telegram_signal_trader"                    # a copy of THIS program
    (other / "signal_trader").mkdir(parents=True)
    (other / "lordxau").mkdir()
    (other / "config.yaml").write_text("fxtrendo:\n  use_real_wallet: true\n", encoding="utf-8")
    (other / "gui.py").write_text("", encoding="utf-8")
    new = tmp_path / "lordxau_trader"
    new.mkdir()
    assert st_mod.find_old_program(new) is None


def test_config_read_without_pyyaml():
    text = ("﻿# server\nmode: fxtrendo   # live\ntelegram:\n  session_name: signal_trader\n"
            "channels:\n  - name: lordxau\n    trade: true\n"
            "fxtrendo:\n  enabled: yes\n  use_real_wallet: true\n  wallet_id: 3388415\n"
            "  login:\n    url: \"https://x/y\"\n  max_lot: 0.01\n"
            "risk:\n  risk_pct: 2\n  max_daily_loss: 8.5\n")
    d = st_mod._read_yaml_plain(text.lstrip("﻿"))
    assert d["mode"] == "fxtrendo" and d["telegram"]["session_name"] == "signal_trader"
    assert d["fxtrendo"]["use_real_wallet"] is True and d["fxtrendo"]["wallet_id"] == 3388415
    assert d["fxtrendo"]["login"]["url"] == "https://x/y" and d["fxtrendo"]["max_lot"] == 0.01
    assert d["risk"] == {"risk_pct": 2, "max_daily_loss": 8.5}


def test_config_read_falls_back_when_pyyaml_is_missing(tmp_path, monkeypatch):
    import builtins
    real_import = builtins.__import__

    def no_yaml(name, *a, **k):
        if name == "yaml":
            raise ImportError("no yaml")
        return real_import(name, *a, **k)
    monkeypatch.setattr(builtins, "__import__", no_yaml)
    old, new = _old_program(tmp_path)
    s = st_mod.from_old(old)
    assert s["fxtrendo"]["use_real_wallet"] is True and s["fxtrendo"]["wallet_id"] == 12345


def test_settings_made_without_the_old_program_take_its_account_later(tmp_path):
    old, new = _old_program(tmp_path)
    st_mod.save({**st_mod.DEFAULTS, "auto_breakeven_points": 2.0}, new)   # v2.0.0: old program not found
    preview = st_mod.load(new, log=lambda *_: None, do_import=False)
    assert preview["fxtrendo"]["use_real_wallet"] is True
    assert not json.loads((new / "settings.json").read_text(encoding="utf-8"))["fxtrendo"]["use_real_wallet"]
    s = st_mod.load(new, log=lambda *_: None)
    assert s["fxtrendo"]["use_real_wallet"] is True and s["fxtrendo"]["wallet_id"] == 12345
    assert s["auto_breakeven_points"] == 2.0 and st_mod.wallet_source(s) == "old_program"
    saved = json.loads((new / "settings.json").read_text(encoding="utf-8"))
    assert saved["fxtrendo"]["use_real_wallet"] is True and (new / ".env").is_file()


def test_a_wallet_chosen_in_the_window_is_never_overridden(tmp_path):
    old, new = _old_program(tmp_path)
    st_mod.save(dict(st_mod.DEFAULTS), new)
    s = st_mod.set_wallet(new, False, 777)
    assert s["fxtrendo"]["use_real_wallet"] is False and s["fxtrendo"]["wallet_id"] == 777
    s = st_mod.load(new, log=lambda *_: None)
    assert s["fxtrendo"]["use_real_wallet"] is False and st_mod.wallet_source(s) == "user"
    s = st_mod.set_wallet(new, True, 3388415)
    again = st_mod.load(new, log=lambda *_: None)
    assert again["fxtrendo"]["use_real_wallet"] is True and again["fxtrendo"]["wallet_id"] == 3388415


def test_set_wallet_never_overwrites_a_broken_file(tmp_path):
    new = tmp_path / "x"
    new.mkdir()
    (new / "settings.json").write_text("{broken", encoding="utf-8")
    with pytest.raises(st_mod.SettingsError):
        st_mod.set_wallet(new, True, 1)
    assert (new / "settings.json").read_text(encoding="utf-8") == "{broken"


def test_wallet_choice_rebuilds_the_broker_client():
    from types import SimpleNamespace
    from lordxau.runner import _client_key
    a = SimpleNamespace(fxtrendo={"use_real_wallet": False, "wallet_id": None})
    b = SimpleNamespace(fxtrendo={"use_real_wallet": True, "wallet_id": 3388415})
    assert _client_key(a) != _client_key(b)


def test_runner_lists_the_wallets_for_the_window():
    from types import SimpleNamespace
    from lordxau.runner import Runner
    r = Runner(sink=lambda *_: None)
    assert r.wallets() == []
    r.broker = SimpleNamespace(wallet={"id": 2}, wallets=[
        {"id": 1, "is_real": False, "balance": 10000, "currency": "USD"},
        {"id": 2, "is_real": True, "balance": 105.2, "currency": "USD"},
        {"id": 3, "is_real": True, "balance": 0, "is_archive": True}])
    ws = r.wallets()
    assert [(w["id"], w["is_real"], w["active"]) for w in ws] == [(1, False, False), (2, True, True)]


def test_config_pyyaml_refuses_is_never_guessed(tmp_path):
    old, new = _old_program(tmp_path)
    (old / "config.yaml").write_text("fxtrendo:\n  use_real_wallet: false\t# DEMO until tested\n  bad: [\n",
                                     encoding="utf-8")
    logs = []
    s = st_mod.load(new, log=logs.append)
    assert s["fxtrendo"]["use_real_wallet"] is False and not s.get("imported_from")
    assert any("خوانده نشد" in l for l in logs)


@pytest.mark.parametrize("val,real", [("true", True), ("'true'", False), ("yes", True), ("\"no\"", False), ("", False)])
def test_only_an_explicit_true_is_real(tmp_path, val, real):
    old, new = _old_program(tmp_path)
    (old / "config.yaml").write_text(f"mode: fxtrendo\nfxtrendo:\n  use_real_wallet: {val}\n  wallet_id:\n",
                                     encoding="utf-8")
    s = st_mod.from_old(old)
    assert s["fxtrendo"]["use_real_wallet"] is real and s["fxtrendo"]["wallet_id"] is None


def test_defaults_can_send_orders_without_the_old_program(tmp_path):
    new = tmp_path / "alone" / "lordxau_trader"
    new.mkdir(parents=True)
    s = st_mod.set_wallet(new, True, None)
    order = st_mod.broker_config(s).fxtrendo["order"]
    assert order["event"] == "order_add" and order["fields"]["volume"] == "size" and order["modify_event"] == "order_edit"


def test_choice_before_the_first_import_keeps_the_old_programs_protocol_and_risk(tmp_path):
    old, new = _old_program(tmp_path, real=False)
    (old / "config.yaml").write_text(
        "mode: fxtrendo\ntelegram:\n  session_name: my_sess\n"
        "fxtrendo:\n  use_real_wallet: false\n  max_lot: 0.01\n  order:\n    event: order_add\n    ack_wait_sec: 2\n"
        "risk:\n  risk_pct: 1.5\n  max_daily_loss: 5\n", encoding="utf-8")
    st_mod.save(dict(st_mod.DEFAULTS), new)                        # a 2.0.0 settings.json (never imported)
    s = st_mod.set_wallet(new, True, 3388415)
    assert (s["fxtrendo"]["use_real_wallet"], s["fxtrendo"]["wallet_id"]) == (True, 3388415)
    assert s["risk"]["max_daily_loss"] == 5 and s["telegram"]["session_name"] == "my_sess"
    assert s["fxtrendo"]["max_lot"] == 0.01 and s["fxtrendo"]["order"]["ack_wait_sec"] == 2
    again = st_mod.load(new, log=lambda *_: None)
    assert again["fxtrendo"]["use_real_wallet"] is True and again["risk"]["risk_pct"] == 1.5


def test_a_choice_made_without_the_old_program_gets_its_protocol_later(tmp_path):
    new = tmp_path / "telegram_signal_trader" / "lordxau_trader"
    new.mkdir(parents=True)
    st_mod.set_wallet(new, True, 3388415)                          # old program not found yet
    old, _ = _old_program(tmp_path, real=False)                    # found later (its files put in place)
    s = st_mod.load(new, log=lambda *_: None)
    assert (s["fxtrendo"]["use_real_wallet"], s["fxtrendo"]["wallet_id"]) == (True, 3388415)
    assert s["imported_from"] == str(old) and st_mod.wallet_source(s) == "user"
    assert s["fxtrendo"]["order"]["event"] == "order_add"


def test_desktop_search_is_this_users_only():
    from pathlib import Path
    home = str(Path.home()).lower()
    for d in st_mod._user_desktops():
        assert str(d).lower().startswith(home) or "onedrive" in str(d).lower() or str(d).lower().endswith("desktop")
    assert Path.home() / "Desktop" in st_mod._user_desktops()


def test_same_account_is_reused():
    from types import SimpleNamespace
    from lordxau.runner import _creds_key, same_account
    demo = SimpleNamespace(fxtrendo={"use_real_wallet": False, "wallet_id": None})
    client = SimpleNamespace(use_real=False, wallet={"id": 3})
    k = _creds_key(demo)
    assert same_account(client, demo, k)
    assert same_account(client, SimpleNamespace(fxtrendo={"use_real_wallet": False, "wallet_id": 3}), k)
    assert not same_account(client, SimpleNamespace(fxtrendo={"use_real_wallet": False, "wallet_id": 4}), k)
    assert not same_account(client, SimpleNamespace(fxtrendo={"use_real_wallet": True, "wallet_id": None}), k)
    assert not same_account(None, demo, k)


def test_account_switch_waits_for_every_runs_guards(tmp_path, monkeypatch):
    import asyncio
    from types import SimpleNamespace
    import signal_trader.brokers.trendo_client as tc
    import signal_trader.executors.fxtrendo as fxm
    from lordxau.runner import Runner, _creds_key

    class FakeClient:
        built = []

        def __init__(self, cfg):
            self.use_real = bool(cfg.fxtrendo.get("use_real_wallet"))
            self.wallet, self.wallets, self.dropped = None, [], False
            FakeClient.built.append(self)

        def login(self):
            self.wallets = [{"id": 7, "is_real": True, "balance": 105}]
            self.wallet = self.wallets[0]

        def wallet_kind(self):
            return "REAL" if self.use_real else "DEMO"

        def is_alive(self):
            return True

        def subscribe_prices(self, syms):
            pass

        def _drop_socket(self):
            self.dropped = True

    class FakeEx:
        def __init__(self, cfg, client=None):
            self.client, self._auto_be, self._be_guards, self._be_retry = client, {}, {}, {}

        def remember_orders(self, path):
            return 0

        def stop_watchdog(self):
            pass

        def adopt_auto_be(self, prev):
            return 0

    monkeypatch.setattr(tc, "TrendoClient", FakeClient)
    monkeypatch.setattr(fxm, "FxTrendoExecutor", FakeEx)
    r = Runner(sink=lambda *_: None, root=tmp_path)
    r.guard_poll_sec = 0.01
    demo = SimpleNamespace(fxtrendo={"use_real_wallet": False, "wallet_id": None})
    old_client = SimpleNamespace(use_real=False, wallet={"id": 3}, dropped=False,
                                 _drop_socket=lambda: setattr(old_client, "dropped", True))
    r.broker, r._broker_key = old_client, _creds_key(demo)
    e1 = FakeEx(demo, old_client)
    e1._be_guards = {111: {}}                                     # an EARLIER run's guard
    r._execs, r.executor = [e1], FakeEx(demo, old_client)
    real = SimpleNamespace(fxtrendo={"use_real_wallet": True, "wallet_id": None})

    async def go():
        t = asyncio.ensure_future(r._connect_broker(real))
        await asyncio.sleep(0.1)
        assert not t.done() and not old_client.dropped and "منتظر" in r.status["broker"]
        e1._be_guards = {}                                        # the trade closed
        return await asyncio.wait_for(t, 2.0)

    assert asyncio.run(go()) is True
    assert old_client.dropped and r.broker is FakeClient.built[-1] and r.broker.use_real


def test_generic_row_of_the_same_kind_keeps_the_imported_wallet(tmp_path):
    old, new = _old_program(tmp_path)                              # REAL wallet 12345
    st_mod.load(new, log=lambda *_: None)
    s = st_mod.set_wallet(new, True, None)                         # "واقعی (REAL)" before any login
    assert (s["fxtrendo"]["use_real_wallet"], s["fxtrendo"]["wallet_id"]) == (True, 12345)
    s = st_mod.set_wallet(new, False, None)                        # the other kind: its first wallet
    assert (s["fxtrendo"]["use_real_wallet"], s["fxtrendo"]["wallet_id"]) == (False, None)


def test_a_guard_close_in_flight_still_counts_as_open():
    import threading
    from types import SimpleNamespace
    from lordxau.runner import _guards_open
    base = dict(_auto_be={}, _be_guards={}, _be_retry={}, _be_closing=set(), _be_deferred={}, _be_workers=[])
    assert not _guards_open(SimpleNamespace(**base))
    assert _guards_open(SimpleNamespace(**{**base, "_be_closing": {5}}))
    assert _guards_open(SimpleNamespace(**{**base, "_be_deferred": {5: 1.0}}))
    ev = threading.Event()
    t = threading.Thread(target=ev.wait)
    t.start()
    try:
        assert _guards_open(SimpleNamespace(**{**base, "_be_workers": [t]}))
    finally:
        ev.set()
        t.join()
    assert not _guards_open(SimpleNamespace(**{**base, "_be_workers": [t]}))


def test_closed_bot_trades_are_reported_with_todays_total(tmp_path):
    from types import SimpleNamespace
    from lordxau.runner import Runner, tehran_day
    lines = []
    r = Runner(sink=lines.append, root=tmp_path)
    c = SimpleNamespace(my_order_ids={5, 6}, wallet={"id": 7, "currency": "USD"}, balance=100.0)
    r._on_order_event(c, {"id": 5, "type": 1, "size": 0.01, "open": 4155.4, "profit": 0,
                          "close_time_current": 0})                        # still open: nothing
    r._on_order_event(c, {"id": 99, "type": 1, "profit": 5, "close_time_current": 1})   # not the bot's
    assert not lines
    r._on_order_event(c, {"id": 5, "type": 1, "size": 0.01, "open": 4155.4, "profit": -3.62,
                          "close_time_current": 1790687302, "wallet_data": {"balance": 101.45}})
    r._on_order_event(c, {"id": 5, "type": 1, "profit": -3.62, "close_time_current": 1790687302})  # echo
    r._on_order_event(c, {"id": 6, "type": 0, "size": 0.01, "open": 4150, "profit": 1.5,
                          "close_time_current": 1790687400})
    assert len(lines) == 4
    assert "SELL" in lines[0] and "-3.62 USD" in lines[0] and "101.45" in lines[0]
    assert "-3.62 USD در 1 معامله" in lines[1]
    assert "BUY" in lines[2] and "-2.12 USD در 2 معامله" in lines[3]
    rows = [json.loads(x) for x in (tmp_path / "logs" / "trades.jsonl").read_text(encoding="utf-8").splitlines()]
    assert [x["id"] for x in rows] == [5, 6] and {x["day"] for x in rows} == {tehran_day()}
    assert r._day_result(tehran_day(), 7) == (pytest.approx(-2.12), 2, 0)
    assert r._day_result(tehran_day(), 8) == (0.0, 0, 0)                     # another wallet
    # a bot order that closed while the socket was down: reported once, no result
    c.my_order_ids.add(8)
    r._on_orders_vanished(c, [8, 5])                                       # 5 was already reported
    r._on_orders_vanished(c, [8])
    assert len(lines) == 6 and "8" in lines[4] and "1 معامله بدون نتیجه" in lines[5]
    assert r._day_result(tehran_day(), 7) == (pytest.approx(-2.12), 3, 1)
    # ... and its real close arrives later: the broker's profit replaces it
    r._on_order_event(c, {"id": 8, "type": 0, "size": 0.01, "open": 4150, "profit": 2.75,
                          "close_time_current": 1790687500})
    assert r._day_result(tehran_day(), 7) == (pytest.approx(0.63), 3, 0)
    with (tmp_path / "logs" / "trades.jsonl").open("ab") as fh:
        fh.write(bytes([0xFF, 0xFE]) + b" broken" + bytes([10]))          # never breaks the report
    assert r._day_result(tehran_day(), 7) == (pytest.approx(0.63), 3, 0)


def test_client_reports_bot_orders_gone_after_a_reconnect():
    from types import SimpleNamespace
    from signal_trader.brokers.trendo_client import TrendoClient
    c = TrendoClient(SimpleNamespace(fxtrendo={}))
    gone = []
    c.on_orders_vanished = gone.append
    c.my_order_ids = {5, 6}
    c._handle_send_message({"event": "all_orders_wallet", "wallet_data": {"balance": 100},
                            "orders": [{"id": 5}, {"id": 6}, {"id": 99}]})
    assert not gone
    c._handle_send_message({"event": "order_change", "id": 6, "close_time_current": 123, "profit": 1})
    c._handle_send_message({"event": "order_change", "id": 7, "close_time_current": 0})   # not the bot's
    c.my_order_ids.add(8)
    c._handle_send_message({"event": "order_change", "id": 8, "close_time_current": 0})
    c.open_orders = {}                                           # connect() after a drop
    c._handle_send_message({"event": "all_orders_wallet", "wallet_data": {"balance": 99},
                            "orders": [{"id": 99}]})
    assert gone == [[5, 8]]                                      # 6 closed normally, 99 / 7 not the bot's


def test_tehran_day_boundary():
    import calendar
    from lordxau.runner import tehran_day
    t = calendar.timegm((2026, 9, 28, 20, 29, 0))                 # 23:59 Tehran
    assert tehran_day(t) == "2026-09-28" and tehran_day(t + 60) == "2026-09-29"


def _plan_executor(tmp_path, monkeypatch, s):
    from types import SimpleNamespace
    import signal_trader.executors.fxtrendo as fxm
    monkeypatch.setattr(fxm, "PROJECT_ROOT", tmp_path)               # the daily guard's file
    client = SimpleNamespace(wallet={"id": 7, "is_real": 0, "balance": 105.0}, wallet_data=None,
                             open_orders={}, balance=105.0)
    return fxm.FxTrendoExecutor(st_mod.broker_config(s), client=client)


def test_scalp_gets_a_take_profit_from_its_fill(tmp_path, monkeypatch):
    s = st_mod._deep_merge(st_mod.DEFAULTS, {})
    ex = _plan_executor(tmp_path, monkeypatch, s)
    sell = Signal(symbol="XAUUSD", side=Side.SELL, order_type=OrderType.MARKET, entries=[4155.0],
                  stop_loss=4158.0, source="lordxau")
    plan, note = ex._plan(sell, fill=4154.43)
    assert plan == [(0.01, 4151.68)] and "TP 4151.68" in note
    buy = Signal(symbol="XAUUSD", side=Side.BUY, order_type=OrderType.MARKET, entries=[4156.0],
                 stop_loss=4153.0, source="lordxau")
    assert ex._plan(buy, fill=4156.2)[0] == [(0.01, 4158.95)]
    assert ex._plan(buy)[0] == [(0.01, None)]                         # a waiting zone: no TP yet
    ultra = Signal(symbol="XAUUSD", side=Side.BUY, order_type=OrderType.MARKET, entries=[4140.0],
                   stop_loss=4136.0, take_profits=[4150.0], source="lordxau_ultra")
    assert ex._plan(ultra, fill=4140.0)[0][0][1] == 4150.0            # the channel's own TP stays
    s["take_profit_points"] = 0
    ex = _plan_executor(tmp_path, monkeypatch, s)
    assert ex._plan(sell, fill=4154.43)[0] == [(0.01, None)]          # 0 = off


def test_sim_take_profit_matches_the_executor():
    ticks = [(0.0, 4154.43, 4154.48), (1.0, 4153.0, 4153.05), (2.0, 4151.70, 4151.75),
             (3.0, 4151.60, 4151.62), (4.0, 4150.0, 4150.05)]
    sim = SimBroker(ticks, SimConfig())
    sim.advance(0.0)
    sig = Signal(symbol="XAUUSD", side=Side.SELL, order_type=OrderType.LIMIT, entries=[4155.0, 4156.0],
                 stop_loss=4158.0, source="lordxau")
    r = asyncio.run(sim.execute(sig))
    assert r["action"] == "placed" and sim.pos[0]["tp"] == 4151.68
    sim.advance(4.0)
    assert sim.closed[0]["why"] == "TP" and sim.closed[0]["exit"] == 4151.68
    assert sim_config_from_settings(st_mod._deep_merge(st_mod.DEFAULTS, {"take_profit_points": 0})).auto_tp["lordxau"] == 0


def test_a_retried_send_measures_the_auto_tp_from_its_own_price(tmp_path, monkeypatch):
    s = st_mod._deep_merge(st_mod.DEFAULTS, {})
    ex = _plan_executor(tmp_path, monkeypatch, s)
    sent = []
    ex.client.broker_symbol = lambda sym: "xauusd"
    ex.client.price = lambda b: (4152.50, 4152.60)                    # moved during a re-login
    ex.client.place_order = lambda sig, dry_run=False, lot=None, tp=None: sent.append(tp) or {"action": "placed"}
    sell = Signal(symbol="XAUUSD", side=Side.SELL, order_type=OrderType.MARKET, entries=[4155.0],
                  stop_loss=4158.0, source="lordxau")
    ex._place_live(sell, 0.01, 4151.35)                                 # planned at bid 4154.10
    assert sent == [4149.75]
    ex.client.price = lambda b: None                                    # no fresh quote: the plan's TP
    ex._place_live(sell, 0.01, 4151.35)
    own = Signal(symbol="XAUUSD", side=Side.SELL, order_type=OrderType.MARKET, entries=[4155.0],
                 stop_loss=4158.0, take_profits=[4150.0], source="lordxau")
    ex.client.price = lambda b: (4152.50, 4152.60)
    ex._place_live(own, 0.01, 4150.0)                                   # the channel's own TP stays
    assert sent == [4149.75, 4151.35, 4150.0]


def test_kept_tp_near_the_price_never_blocks_a_breakeven_edit():
    from types import SimpleNamespace
    from signal_trader.brokers.trendo_client import TrendoClient
    c = TrendoClient(SimpleNamespace(fxtrendo={"order": {"modify_event": "order_edit"}}))
    c.open_orders = {5: {"id": 5, "token": "t", "symbol": "xauusd", "type": 0, "size": 0.01,
                         "open": 4150.30, "sl": 4147.0, "tp": 4153.05}}
    c.symbol_props = {"xauusd": {"digits": 2, "stop_level": 0.1}}
    c.price = lambda b: (4152.70, 4153.00)                              # ask within 0.1 of the TP
    c.price_age = lambda b: 0.1
    emitted = []
    c._ensure_socket = lambda: None
    c.wallet = {"is_real": 0, "id": 1, "token": "w"}                    # a DEMO test wallet
    c._emit_user = emitted.append
    c._ack_wait = lambda w: 0.0
    r = c.modify_order(5, sl=4150.30)
    assert r["action"] != "rejected_local" and emitted and emitted[0]["tp"] == 4153.05
    assert c.modify_order(5, tp=4153.05)["action"] == "rejected_local"   # a TP edit itself is checked
