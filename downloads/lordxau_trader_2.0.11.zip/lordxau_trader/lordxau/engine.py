# -*- coding: utf-8 -*-
"""The @lordxau trade logic: one message in -> executor calls out.

Only this channel is traded. The engine keeps the CURRENT scalp setup (the
last zone the leader posted) and a list of LIVE setups - every placed order
(scalp or ULTRA) that is not known to be over. Commands act on the live
setups, so a trade is never lost when the leader posts the next zone.

Scalp, as the leader posts it (09-20..28: 78 zones, every one 1 point wide, the
stop 2 points past the far edge in 67 of 75, 3-42 s after the zone):

    "سل بزن"                      HINT     remembered (side) - no order
    "Xau Sell Enter:4190/4189"    ZONE     new setup; placed at once when the
                                           stop is known, else when "Stop:" comes
                                           (or after stop_wait_sec with the
                                           default stop, far edge +- 2)
    "Stop:4192"                   STOP     the setup's stop (placed / updated)
    "فریش کن"                     BE       breakeven of the live scalps (an
                                           unfilled zone is dropped)
    "ببندش"                       CLOSE    close the live scalps (no scalp: ULTRA)
    "بگیر باز" / "فری خورد بگیر"   REENTER  the last zone again, unless a new
                                           zone arrives within reenter_wait_sec
    "اگر فری خورد بگیر باز"        IF_BE_REENTER  armed; the next "فری خورد" re-enters
    "اگه استاپ تاچ کرد بگیر باز"   IF_SL_REENTER  the bot's trade of the zone is already
                                           over: re-enter; else armed for "استاپ خورد"
                                           (an arm ends with "ببند" / a new zone)
    "جا موندی قیمت مارکت بزن"      MARKET_NOW     market entry, only when the price
                                           is within market_now_max_past of the zone
ULTRA ("Gold buy 4145-4140 TP.. SL.."; ~10 point stops, reposted for hours):
    traded only when trade_ultra is on, once per signal (reposts ignored).

A message that arrives more than max_msg_age_sec after it was posted (a
reconnect catch-up) never opens anything; a late close / breakeven acts only
on setups older than it.

The executor (signal_trader.executors.fxtrendo) does the rest: virtual limits
(a zone is sent at market when the price reaches it), the 1.5 point automatic
breakeven, the risk sizing / daily guards and the wallet checks.
"""
from __future__ import annotations

import asyncio
import math
import time
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from lordxau import CHANNEL, SYMBOL
from lordxau.parse import (BE, BE_HIT, CLOSE, EXTEND, HINT, IF_BE_REENTER, IF_SL_REENTER, MARKET_NOW,
                           NOISE, PRICE, REENTER, RESULT, SHORTHAND, SIGNAL, SL_HIT, STOP, WAIT, ZONE,
                           Parsed, _edits, parse)
from signal_trader.models import OrderType, Side, Signal
from lordxau.llm_gate import GateContext, gate, likely_command

OK_ACTIONS = ("emitted", "placed", "order", "pending_virtual", "dry_run", "dry_run_no_event")
BE_OK_ACTIONS = ("breakeven_set", "breakeven_virtual", "pending_cancelled", "dry_run")
ULTRA_SOURCE = CHANNEL + "_ultra"


@dataclass
class EngineConfig:
    symbol: str = SYMBOL
    trade_scalp: bool = True
    trade_ultra: bool = False
    default_stop_pts: float = 2.0       # stop = far zone edge +- this when "Stop:" is late / missing
    stop_wait_sec: float = 30.0         # wait this long for "Stop:" before using the default stop
    # True: the zone is placed at once with the default stop (as the channel's members
    # do) and moved to the channel's "Stop:" when it comes; the price often touches
    # the zone only in the 3-40 s before "Stop:" arrives.
    place_before_stop: bool = True
    max_stop_pts: float = 6.0           # a scalp whose stop is further than this from the edge is skipped
    # "بگیر باز": the leader's fresh zone usually follows within 10-30 s (bursts):
    # the old zone is re-placed only when none came within this (<= 0: never).
    # Replayed 09-20..25: 20 s -8.6 $, 40 s -2.5 $, 60 s -0.7 $ (the old zone re-entered first).
    reenter_wait_sec: float = 60.0
    setup_ttl_sec: float = 900.0        # REENTER / MARKET_NOW use a setup at most this old
    market_now_max_past: float = 1.0    # "جا موندی": market only this far (points) past the zone edge
    # "نرسیدی قیمت مارکت بزن" (the price never came back to the zone): the leader's
    # explicit market order - this far past the edge (the stop distance limit still holds)
    market_now_missed_max_past: float = 3.0
    stop_match_sec: float = 120.0       # "Stop:" belongs to a zone posted at most this long before
    hint_ttl_sec: float = 180.0
    # "سل بزن" is followed by its zone within seconds (3 months: median 13 s, 99 % under 58 s):
    # only a zone this soon after the order is checked against it (side typo in the zone post)
    hint_zone_sec: float = 60.0
    # "فری": protect the bot's actual broker fill by default. The channel's
    # zone can be worse than that fill, locking in a small loss on each retrace.
    # True explicitly restores the legacy zone-reference rule (executor _be_ref).
    # A fill-price stop does not cover broker commission or execution slippage.
    breakeven_at_zone: bool = False
    # "فری" while the bot's zone has not filled: the leader is still in his trade, so the
    # zone is kept and put at breakeven the moment it fills (instead of being cancelled).
    # "فری خورد" / "استاپ خورد" / "بگیر باز" drop a kept zone that has not filled yet.
    # 4 weeks 09-08..29 replayed: +6.5 $ at 4-6 s, +10 $ at 10 s (7 more take profits
    # against ~19 breakeven exits of -0.5..-0.9 - a small sample).
    keep_zone_on_be: bool = True
    max_msg_age_sec: float = 180.0      # older messages (reconnect catch-up) never open anything
    ultra_repeat_sec: float = 6 * 3600.0
    gold_pip_size: float = 0.1         # @lordxau: +70pip corresponds to about 7 gold price units

    @classmethod
    def from_dict(cls, d: Optional[dict]) -> "EngineConfig":
        out = cls()
        for k, v in (d.items() if isinstance(d, dict) else ()):
            if not hasattr(out, k) or v is None:
                continue
            cur = getattr(out, k)
            try:
                if isinstance(cur, bool):
                    setattr(out, k, v if isinstance(v, bool) else str(v).strip().lower() in ("1", "true", "yes", "on"))
                elif isinstance(cur, float):
                    setattr(out, k, float(v))
                else:
                    setattr(out, k, type(cur)(v))
            except (TypeError, ValueError):
                pass
        return out


@dataclass
class Setup:
    side: str                           # "BUY" | "SELL"
    entries: list
    sl: Optional[float]
    sl_known: bool                      # the channel's own "Stop:" (not the default)
    t: float                            # when the zone arrived
    msg_id: Any = None
    raw_sl: Optional[float] = None      # the channel's stop as written (before a typo fix)
    ids: list = field(default_factory=list)   # executor ids of the order placed for it
    placed: bool = False
    be: bool = False
    done: bool = False                  # closed / dropped / refused - never placed again
    tries: int = 0
    retry_at: Optional[float] = None
    ultra: bool = False
    tps: list = field(default_factory=list)
    closed: bool = False                # the channel's own close was sent for it
    be_wait: bool = False               # "فری" came before the fill: breakeven as soon as it fills
    be_tries: int = 0
    refused: bool = False               # not traded (stop too far): never re-entered either
    ext_from: list = field(default_factory=list)   # the levels as posted, before "..هم بود بگیر"
    # the zone post says BUY right after the leader ordered a SELL ("بگیر باز" of a SELL zone,
    # "سل بزن") and the price is not where a BUY zone waits: one of the two is a slip - never
    # placed (zone, re-entry, market order, extension) until his "Stop:" shows the side
    side_doubt: Optional[str] = None
    side_fixed: bool = False            # the side is the one his stop showed, not the word in the zone post
    against: Optional[str] = None       # placed as typed on the price's word although his order just before said this side
    # the other reading of a mistyped zone that the price does not rule out ("4054/4045" with
    # gold between the two, or no live price): not placed until the "Stop:" as written fits one
    alt: list = field(default_factory=list)
    typed: list = field(default_factory=list)      # the levels as posted, when moved by hundreds to the price
    tp_pips: list = field(default_factory=list)
    entry_rejected: bool = False        # an explicit no-order verdict; an uncertain send is not one

    @property
    def near(self) -> float:            # the edge the price reaches first
        return max(self.entries) if self.side == "BUY" else min(self.entries)

    @property
    def far(self) -> float:
        return min(self.entries) if self.side == "BUY" else max(self.entries)

    def text(self) -> str:
        sl = "?" if self.sl is None else f"{self.sl:g}" + ("" if self.sl_known else " (پیش‌فرض)")
        return (("ULTRA " if self.ultra else "") + f"{self.side} {'/'.join(f'{e:g}' for e in self.entries)} SL {sl}"
                + (f" TP {'/'.join(f'{t:g}' for t in self.tps)}" if self.tps else "")
                + (f" TP {'/'.join(f'{t:g}' for t in self.tp_pips)} pip از ورود" if self.tp_pips else ""))


def _ids(res: dict) -> list:
    out = []
    for o in res.get("orders") or []:
        if isinstance(o, dict) and o.get("order_id") is not None and o.get("order_id") not in out:
            out.append(o.get("order_id"))
    if not out and res.get("order_id") is not None:
        out.append(res["order_id"])
    return out


def _why(res: dict) -> str:
    for child in res.get("results") or []:
        if isinstance(child, dict) and _close_failed(child):
            return _why(child)
    return str(res.get("reason") or res.get("error") or res.get("action") or "?")


def _close_failed(res: dict) -> bool:
    """The broker wraps even rejected order_close acknowledgements in action=close."""
    if res.get("action") in ("refused", "rejected", "rejected_local", "unconfirmed", "error"):
        return True
    return any(_close_failed(r) for r in res.get("results") or [] if isinstance(r, dict))


def _older(st: "Setup", before_id: Any) -> bool:
    """``st`` came from a message older than ``before_id`` (None = no limit)."""
    if before_id is None:
        return True
    try:
        return st.msg_id is not None and int(st.msg_id) < int(before_id)
    except (TypeError, ValueError):
        return False


class Engine:
    def __init__(self, executor: Any, cfg: Optional[EngineConfig] = None,
                 clock: Optional[Callable[[], float]] = None):
        self.ex = executor
        self.cfg = cfg or EngineConfig()
        self.clock = clock or time.time
        self.setup: Optional[Setup] = None       # the current scalp zone
        self.live: list = []                    # placed setups (scalp + ULTRA) not known to be over
        self.hint: Optional[tuple] = None       # (side, t)
        self.hint_fresh = False                 # no zone has come since the hint
        self.reenter_due: Optional[float] = None
        self.if_be_armed: Optional[float] = None
        self.if_sl_armed: Optional[float] = None
        self.last_ultra_t: Optional[float] = None  # the last new ULTRA signal (conditionals may be about it)
        self.ultra_seen: dict = {}              # (side, entries, sl) -> t first seen
        self.ultra_messages: OrderedDict = OrderedDict() # id -> setup; None marks a repost
        self.received_ids: OrderedDict = OrderedDict()   # id -> arrival sequence, time
        self._recv_seq = self._latest_entry_seq = 0
        self.close_retry: Optional[dict] = None  # {ids, setups, next, until} after a close that raised
        self.be_retries: dict = {}              # bounded retries, retaining the original order ids
        self.stop_messages: OrderedDict = OrderedDict()  # edited Stop belongs to its original setup
        self.last_msg_t: Optional[float] = None
        self.last_tick_t: Optional[float] = None
        self.counts: dict = {}
        self.zone_ids: set = set()              # messages that made a setup
        self._lock: Optional[asyncio.Lock] = None
        # optional gated LLM reader: a callable text -> llm_reader.Reading, consulted ONLY on NOISE messages
        # while a trade is open, and only able to CLOSE / RISK-FREE / RE-ENTER it (never open one). None = off
        # (backtests and the test suite run with it off, so behaviour is unchanged).
        self.llm: Optional[Callable[[str], Any]] = None
        self.llm_calls = 0
        self.llm_actions = 0
        # hard wall-clock cap (seconds) for ONE llm consult: the call runs under the engine lock, and urllib's
        # per-operation socket timeout does NOT bound DNS resolution or a slow-trickle body, so without this a hung
        # provider could freeze handling of the next message / timer. None = no cap (tests use a local stub).
        self.llm_hard_timeout: Optional[float] = None
        # optional dashboard hook: called with a structured event per handled message. None = off.
        self.on_event: Optional[Callable[[dict], None]] = None
        self._last_llm: Optional[dict] = None

    # ------------------------------------------------------------------ helpers
    def _get_lock(self) -> asyncio.Lock:
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    def _now(self) -> float:
        return float(self.clock())

    def _count(self, k: str) -> None:
        self.counts[k] = self.counts.get(k, 0) + 1

    def _mid(self) -> Optional[float]:
        fn = getattr(self.ex, "live_quote_mid", None)
        try:
            v = fn(self.cfg.symbol) if callable(fn) else None
            return float(v) if v else None
        except Exception:
            return None

    def _alive(self, ids: list) -> Optional[bool]:
        """True = an order of ``ids`` is open or waiting; False = none is; None = unknown."""
        if not ids:
            return False
        fn = getattr(self.ex, "trade_state", None)
        if not callable(fn):
            return None
        try:
            return fn(list(ids))
        except Exception:
            return None

    def _waiting_only(self, ids: list) -> bool:
        """Every id is a virtual limit that has not filled yet."""
        fn = getattr(self.ex, "virtual_orders", None)
        if not ids or not callable(fn):
            return False
        try:
            pend = set(fn().keys())
        except Exception:
            return False
        for i in ids:
            s = str(i)
            if not s.startswith("v"):
                return False
            try:
                if int(s[1:]) not in pend:
                    return False
            except ValueError:
                return False
        return True

    def _cancel(self, st: Setup, why: str) -> bool:
        """Drop ``st``'s waiting zone. True only when every id was really dropped
        (a zone the executor is sending right now is left alone)."""
        fn = getattr(self.ex, "cancel_virtual", None)
        if not callable(fn):
            return False
        try:
            got = fn(self.cfg.symbol, list(st.ids), why) or []
        except Exception:
            return False
        dropped = {str(d.get("order_id")) for d in got if isinstance(d, dict)}
        return bool(st.ids) and {str(i) for i in st.ids} <= dropped

    def _prune(self) -> None:
        """Forget the live setups whose orders are known to be over."""
        self.live = [s for s in self.live if self._alive(s.ids) is not False]

    def _untrack(self, st: Setup) -> None:
        self.live = [s for s in self.live if s is not st]

    def _open_scalps(self) -> list:
        """Live scalps that are (or may be) FILLED - not only waiting."""
        return [s for s in self.live if not s.ultra and not self._waiting_only(s.ids)
                and self._alive(s.ids) is not False]

    def _targets(self, now: float, before_id: Any) -> list:
        """The live setups a scalp command ("ببندش" / "فریش کن") acts on: the
        live scalps. The live ULTRA trades only when there is no current scalp
        at all - a scalp the executor refused, or one already over at the
        broker, must never make the leader's scalp command hit an ULTRA trade."""
        cands = [s for s in self.live if _older(s, before_id)]
        scalps = [s for s in cands if not s.ultra]
        st = self.setup
        ctx = (st is not None and not st.closed and _older(st, before_id)
               and now - st.t <= self.cfg.setup_ttl_sec)
        return scalps if (scalps or ctx) else [s for s in cands if s.ultra]

    def _channel_bot_ids(self, include_ultra: bool = True, side: Optional[str] = None) -> Optional[list]:
        """After a restart (no setups): the bot orders this channel opened, from
        the order memory; None = not known (the executor decides)."""
        client = getattr(self.ex, "client", None)
        fn = getattr(client, "bot_orders_of", None)
        if not callable(fn):
            return None
        try:
            mine = fn() or {}
        except Exception:
            return None
        out = []
        for src in ((CHANNEL, ULTRA_SOURCE) if include_ultra else (CHANNEL,)):
            out += list((mine.get(src) or {}).get(self.cfg.symbol) or [])
        out = list(dict.fromkeys(i for i in out if self._alive([i]) is not False))
        if side is not None:
            order_side = getattr(self.ex, "_order_side", None)
            orders_for = getattr(client, "orders_for", None)
            if not callable(order_side) or not callable(orders_for):
                return []                       # unknown side never means all restored orders
            try:
                matching = {str(o.get("id")) for o in orders_for(self.cfg.symbol) or []
                            if getattr(order_side(o), "value", None) == side}
                out = [i for i in out if str(i) in matching]
            except Exception:
                return []
        return out

    def _restored_targets(self, now: float, before_id: Any, side: Optional[str] = None) -> Optional[list]:
        if before_id is not None:
            return []                           # cannot date a restored trade relative to an old message
        st = self.setup
        scalp_context = st is not None and not st.closed and now - st.t <= self.cfg.setup_ttl_sec
        ids = self._channel_bot_ids(include_ultra=not scalp_context, side=side)
        # No order memory: keep the legacy executor fallback only directly after
        # restart, never after a refused scalp or for a side-specific command.
        if ids is None and (st is not None or self.live or side is not None):
            return []
        return ids

    def _signal(self, st: Setup, market: bool = False) -> Signal:
        return Signal(symbol=self.cfg.symbol, side=Side(st.side),
                      order_type=OrderType.MARKET if market else OrderType.LIMIT,
                      entries=list(st.entries), stop_loss=st.sl, take_profits=list(st.tps[:1]),
                      take_profit_offsets=[v * self.cfg.gold_pip_size for v in st.tp_pips[:1]],
                      raw_text=f"lordxau {st.text()}", source=ULTRA_SOURCE if st.ultra else CHANNEL,
                      confidence=1.0)

    def next_due(self) -> Optional[float]:
        due = [self.reenter_due, self._stop_deadline()]
        st = self.setup
        if st is not None and st.retry_at is not None and not st.placed and not st.done:
            due.append(st.retry_at)
        if self.close_retry:
            due.append(self.close_retry["next"])
        due += [r["next"] for r in self.be_retries.values()]
        if self.last_tick_t is not None and any(s.be_wait for s in self.live):
            due.append(self.last_tick_t + 1.0)       # watch the kept zone's fill every second
        due = [d for d in due if d is not None]
        return min(due) if due else None

    def _stop_deadline(self) -> Optional[float]:
        st = self.setup
        if st is None or st.placed or st.done or st.sl_known or st.tries or st.retry_at is not None:
            return None
        # a zone whose side / reading is open waits for its "Stop:" as long as a stop can belong to it
        return st.t + (self.cfg.stop_match_sec if self._unsettled(st) else self.cfg.stop_wait_sec)

    # ------------------------------------------------------------------ entry points
    async def handle(self, text: str, msg_id: Any = None, channel: str = CHANNEL,
                     ts: Optional[float] = None) -> list:
        async with self._get_lock():
            now = self._now()
            lines = await self._tick(now)
            p = parse(text)
            if msg_id is not None and msg_id not in self.received_ids:
                self._recv_seq += 1
                self.received_ids[msg_id] = (self._recv_seq, now)
                while len(self.received_ids) > 2000:
                    self.received_ids.popitem(last=False)
            self._count(p.kind)
            self.last_msg_t = now
            age = (now - float(ts)) if ts else 0.0
            self._last_llm = None
            acted = len(lines)
            if age > self.cfg.max_msg_age_sec and p.kind not in (NOISE, PRICE, RESULT, SHORTHAND):
                if p.kind in (CLOSE, BE) and msg_id is not None:
                    lines += [f"⏳ پیام {age:.0f} ثانیه دیر رسید — فقط روی معامله‌های قدیمی‌تر از آن"]
                    lines += await self._on(p, msg_id, now, before_id=msg_id)
                else:
                    lines += [f"⏳ پیام {age:.0f} ثانیه دیر رسید ({p.kind}) — کاری انجام نشد"]
                self._emit(text, msg_id, ts, now, p, lines[acted:], edited=False)
                return lines
            if msg_id in self.received_ids and p.kind in (ZONE, SIGNAL):
                self._latest_entry_seq = self.received_ids[msg_id][0]
            lines += await self._on(p, msg_id, now)
            # the LLM assistant runs only on a FRESH NOISE line: NOISE is exempt from the age guard above (it is
            # normally a no-op), so without this a reconnect that replays hours-old chatter could make the LLM
            # close / free / re-enter the live trade on an expired message (defeats the max_msg_age_sec invariant).
            if p.kind == NOISE and not p.reason and self.llm is not None and age <= self.cfg.max_msg_age_sec:
                lines += await self._consult_llm(text, now)
            self._emit(text, msg_id, ts, now, p, lines[acted:], edited=False)
            return lines

    def _setup_snap(self) -> Optional[dict]:
        st = self.setup
        if st is None:
            return None
        return {"side": st.side, "entries": list(st.entries), "sl": st.sl, "sl_known": st.sl_known,
                "placed": st.placed, "done": st.done, "be": st.be,
                "doubt": getattr(st, "side_doubt", None), "ids": [str(i) for i in st.ids]}

    def _emit(self, text, msg_id, ts, now, p, lines, edited) -> None:
        ev = {"type": "message", "t": now, "ts": ts, "id": msg_id, "text": text,
              "kind": p.kind, "also": list(p.also), "edited": edited,
              "llm": self._last_llm, "lines": [str(x) for x in lines],
              "setup": self._setup_snap(),
              "parsed": {"side": p.side, "entries": list(p.entries), "sl": p.sl,
                         "tps": list(p.tps), "tp_pips": list(p.tp_pips), "reason": p.reason},
              "modes": {"trade_scalp": self.cfg.trade_scalp, "trade_ultra": self.cfg.trade_ultra}}
        from signal_trader import filelog
        filelog.decision(ev)                   # records decisions even with the dashboard disabled
        try:
            if self.on_event is not None:
                self.on_event(ev)
        except Exception:                      # the dashboard must never break trading
            pass

    async def _consult_llm(self, text: str, now: float) -> list:
        """Fallback for a message the regex read as NOISE: let the gated LLM manage an OPEN trade only.
        Skipped entirely when nothing is open (no latency / no quota spent), and every action goes through
        llm_gate.gate, so a price print or outcome report can never open or move a trade."""
        open_scalps = [s for s in self.live if not s.ultra and not self._waiting_only(s.ids)
                       and self._alive(s.ids) is not False]
        # the LLM is worth a call only while a trade is actually OPEN (its job is novel close / risk-free
        # wording on a live trade); re-entry / opening stay regex-only. No open trade -> no call (no latency/quota).
        if not open_scalps:
            return []
        # a management command is SHORT ("ببندش", "جمعش کن", "سوده فری کن"); skip ads / motivation / links
        # AND the bulk of this channel's noise -- bare price prints ("Xau:4190") and outcome reports
        # ("فری خورد") -- so the LLM is spent only on likely tone orders (and the feed stays clean).
        if not likely_command(text):
            return []
        recent = self.setup.side if self.setup is not None else (self.hint[0] if self.hint else None)
        try:
            call = asyncio.to_thread(self.llm, text)
            if self.llm_hard_timeout:       # bound the lock-hold even if the provider hangs (DNS / slow body)
                reading = await asyncio.wait_for(call, self.llm_hard_timeout)
            else:
                reading = await call
        except asyncio.TimeoutError:        # the orphaned worker finishes later; its result is simply discarded
            return ["🤖 LLM بیش از حد طول کشید — نادیده گرفته شد (فقط regex ادامه داد)"]
        except Exception as exc:            # a provider hiccup must never break message handling
            return [f"🤖 خطای LLM ({type(exc).__name__}) — نادیده گرفته شد"]
        if reading is None:
            return []
        self.llm_calls += 1
        ctx = GateContext(regex_kind=NOISE, text=text, has_open=bool(open_scalps),
                          open_side=open_scalps[0].side if open_scalps else None, recent_side=recent)
        d = gate(reading, ctx)
        self._last_llm = {"kind": reading.kind, "side": reading.side, "confidence": reading.confidence,
                          "why": reading.why, "source": reading.source, "latency": round(reading.latency, 2),
                          "action": d.action, "reason": d.reason}
        if d.action is None:
            return [f"🤖 {d.reason}"] if d.reason else []
        self.llm_actions += 1
        if d.action == "close":
            return [f"🤖 {d.reason}"] + await self._on_close(None, now)
        if d.action == "risk_free":
            return [f"🤖 {d.reason}"] + await self._on_be(now)
        if d.action == "reenter":
            return [f"🤖 {d.reason}"] + self._schedule_reenter(now)
        return []

    async def handle_edit(self, text: str, msg_id: Any = None, channel: str = CHANNEL,
                          ts: Optional[float] = None, now: Optional[float] = None) -> list:
        async with self._get_lock():
            now = self._now() if now is None else now
            self._last_llm = None
            lines = await self._edit(text, msg_id, now, ts)
            self._emit(text, msg_id, ts, now, parse(text), lines, edited=True)   # show the edit on the dashboard too
            return lines

    async def tick(self, now: Optional[float] = None) -> list:
        """Timers: the default-stop placement, a failed placement's retry, the
        delayed re-entry and a failed close's retry."""
        async with self._get_lock():
            return await self._tick(self._now() if now is None else now)

    async def _tick(self, now: float) -> list:
        lines: list = []
        self.last_tick_t = now
        if any(s.be_wait for s in self.live):
            lines += await self._be_after_fill()
        dl = self._stop_deadline()
        if dl is not None and now >= dl:
            st = self.setup
            if st.alt:
                st.done = True
                lines.append(f"⛔ {st.text()}: ناحیه دو خوانش دارد و «Stop» نیامد — معامله نشد")
            elif st.side_doubt:
                st.done = True
                lines.append(f"⛔ {st.text()}: جهت ناحیه با دستور قبلی کانال ({st.side_doubt}) نمی‌خواند و "
                             "«Stop» نیامد — معامله نشد")
            else:
                st.sl = self._default_sl(st)
                lines.append(f"⏱ «Stop» تا {self.cfg.stop_wait_sec:.0f} ثانیه نیامد — استاپ پیش‌فرض {st.sl:g}")
                lines += await self._place(st, "ناحیه بدون Stop")
        st = self.setup
        if st is not None and st.retry_at is not None and now >= st.retry_at and not st.placed and not st.done:
            st.retry_at = None
            lines += await self._place(st, "تلاش دوباره")
        if self.reenter_due is not None and now >= self.reenter_due:
            self.reenter_due = None
            lines += await self._reenter_now(now)
        cr = self.close_retry
        if cr and now >= cr["next"]:
            if now > cr["until"]:
                self.close_retry = None
                lines.append("❌ بستن بعد از چند تلاش انجام نشد — معامله با استاپ خودش در بروکر است")
            else:
                cr["next"] = now + 5.0
                lines += await self._close_ids(cr["ids"], cr["setups"], now, retry=True)
        for key, br in list(self.be_retries.items()):
            if now < br["next"]:
                continue
            s = br["setup"]
            if (s is not None and (s.done or s.closed)) or self._alive(br["ids"] or []) is False:
                self.be_retries.pop(key, None)
            elif now >= br["until"]:
                self.be_retries.pop(key, None)
                lines.append("❌ فری بعد از چند تلاش انجام نشد — استاپ قبلی معامله برقرار است")
            else:
                lines += await self._be_call(br["ids"], br["ref"], s, retry=True)
        return lines

    async def _edit(self, text: str, msg_id: Any, now: float, ts: Optional[float] = None) -> list:
        lines = await self._tick(now)
        st = self.setup
        p = parse(text)
        if p.kind == SIGNAL:
            return lines + await self._edit_ultra(p, msg_id, now, ts)
        fresh = ts is None or now - float(ts) <= self.cfg.stop_match_sec
        if p.kind == STOP and msg_id is not None:
            owner = self.stop_messages.get(msg_id)
            if not fresh or owner is None or owner is not st:
                return lines + [f"✏️ ویرایش Stop {msg_id} متعلق به ناحیهٔ فعلی/پیام تازه نیست — فقط ثبت شد"]
            return lines + ["✏️ استاپ کانال با ویرایش اصلاح شد"] + await self._on_stop(p, now)
        if p.kind != ZONE or not p.entries or msg_id is None:
            return lines + [f"✏️ ویرایش پیام {msg_id} فقط ثبت شد"]
        # a zone corrected by an edit ("Enter:4311/431" -> "4311/4310") that was
        # not traded as posted is a NEW zone while it is fresh
        if msg_id not in self.zone_ids and (st is None or st.msg_id != msg_id):
            if not fresh:
                return lines + [f"✏️ ویرایش پیام {msg_id} (قدیمی) فقط ثبت شد"]
            return lines + ["✏️ ناحیهٔ اصلاح‌شده با ویرایش"] + await self._on_zone(p, msg_id, now)
        if st is None or st.msg_id != msg_id:
            return lines + [f"✏️ ویرایش ناحیهٔ قبلی {msg_id} فقط ثبت شد"]
        same = (sorted(p.entries) == sorted(st.entries) or (p.alt and sorted(p.alt) == sorted(st.entries))
                or (st.ext_from and sorted(p.entries) == sorted(st.ext_from))
                or (st.typed and sorted(p.entries) == sorted(st.typed)))
        if same and (p.side is None or p.side == st.side or st.side_fixed):
            if p.sl is not None and fresh and p.sl != st.sl:
                lines += await self._on_stop(Parsed(STOP, sl=p.sl), now)
            if st.alt and not p.alt and fresh and not st.placed and not st.done \
                    and sorted(p.entries) == sorted(st.entries):
                st.alt = []                              # the edit left one reading only
                lines.append(f"✏️ ناحیه با ویرایش روشن شد: {st.text()}")
                if not self._unsettled(st) and self.cfg.place_before_stop:
                    lines += await self._place(st, "ویرایش ناحیه")
            return lines                             # same levels (a reaction / formatting edit)
        if not fresh:
            return lines + [f"✏️ ویرایش دیرهنگام ناحیه {msg_id} فقط ثبت شد"]
        if st.placed and not self._waiting_only(st.ids):
            return lines + ["✏️ ناحیه ویرایش شد — سفارش قبلاً پر شده، تغییری داده نشد"]
        new = self._zone_setup(p, msg_id, now)
        if new is None:
            return lines + ["✏️ ویرایش ناحیه نامعتبر — نادیده گرفته شد"]
        new.t = st.t
        if st.side_fixed and new.side != st.side:
            new.side, new.side_fixed = st.side, True  # the edit still has the mistyped side word: his stop showed the side
        elif st.side_doubt and new.side == st.side:
            new.side_doubt = st.side_doubt            # the edit did not touch the side: still in doubt
        if st.raw_sl is not None:
            self._reading_by_stop(new, st.raw_sl)
            sl = self._fix_stop(new, st.raw_sl)
            if sl is not None:
                new.sl, new.sl_known, new.raw_sl = sl, True, st.raw_sl
        if st.placed and not st.done:
            if not self._cancel(st, "ناحیه با ویرایش کانال عوض شد"):
                return lines + ["✏️ ناحیه ویرایش شد — سفارش قبلی در حال پر شدن است، تغییری داده نشد"]
            st.done = True
            self._untrack(st)
        lines.append(f"✏️ ناحیه ویرایش شد: {st.text()} → {new.text()}")
        self.setup = new
        why = self._unsettled(new)
        if why:
            return lines + [f"⚠️ {why} — منتظر «Stop»"]
        if new.sl is not None or st.placed or st.tries or (self._unsettled(st) and self.cfg.place_before_stop):
            lines += await self._place(new, "ویرایش ناحیه")
        return lines

    # ------------------------------------------------------------------ dispatch
    async def _on(self, p: Parsed, msg_id: Any, now: float, before_id: Any = None) -> list:
        k = p.kind
        if k in (NOISE, PRICE, RESULT):
            return [f"⛔ سیگنال خوانده نشد — {p.reason}"] if p.reason else []
        if k == SHORTHAND:
            return ["ℹ️ سطح کوتاه‌نویسی‌شده (مثل «استاپ ۳۰۹») — معامله نمی‌شود"]
        if k == ZONE:
            return await self._on_zone(p, msg_id, now)
        if k == STOP:
            if msg_id is not None and self.setup is not None:
                self.stop_messages[msg_id] = self.setup
                self.stop_messages.move_to_end(msg_id)
                while len(self.stop_messages) > 2000:
                    self.stop_messages.popitem(last=False)
            return await self._on_stop(p, now)
        if k == SIGNAL:
            self.hint_fresh = False                   # "GOLD SELL NOW" was the header of this signal
            return await self._on_ultra(p, msg_id, now)
        if k == BE_HIT:
            lines = await self._drop_kept("فری خورد")        # the leader's trade is over
            if self.if_be_armed is not None and now - self.if_be_armed <= self.cfg.setup_ttl_sec:
                self.if_be_armed = None
                return lines + ["↩️ «فری خورد» بعد از «اگر فری خورد بگیر باز»"] + self._schedule_reenter(now)
            return lines
        if k == SL_HIT:
            lines = await self._drop_kept("استاپ خورد")
            if self.if_sl_armed is not None and now - self.if_sl_armed <= self.cfg.setup_ttl_sec:
                self.if_sl_armed = None
                return lines + ["↩️ «استاپ خورد» بعد از «اگر استاپ تاچ کرد بگیر باز»"] + self._schedule_reenter(now)
            return lines
        if k in (IF_BE_REENTER, IF_SL_REENTER) and before_id is None and self._ultra_context():
            return ["↩️ دستور شرطی دربارهٔ سیگنال ULTRA است (نه ناحیهٔ اسکلپ) — کاری انجام نشد"]
        if k == IF_BE_REENTER:
            if before_id is not None:
                return []
            self.if_be_armed = now
            return ["↩️ ورود مجدد مشروط ثبت شد (با «فری خورد» اجرا می‌شود)"]
        if k == IF_SL_REENTER:
            if before_id is not None:
                return []
            return self._on_if_sl(now, p.side)
        if k == WAIT:
            self.hint_fresh = False                   # "صبر": the order before it is taken back
            return await self._on_wait(now)
        if k == EXTEND:
            if before_id is not None:
                return []
            return await self._on_extend(p, now)
        kinds = [k] + list(p.also)
        lines: list = []
        for kind in kinds:
            if kind == CLOSE:
                # "ببندش سلش بزن": the side belongs to the NEXT trade, not to the close
                side = None if HINT in kinds else p.side
                self.hint_fresh = False               # an order from before the close is over
                lines += await self._on_close(side, now, before_id)
            elif kind == BE:
                lines += await self._on_be(now, before_id)
            elif before_id is not None:
                continue                              # a late message only closes / breaks even
            elif kind == HINT:
                if p.side:
                    self.hint = (p.side, now)
                    # "سل بزن" right AFTER its own zone belongs to that zone, not to the next one
                    st = self.setup
                    self.hint_fresh = not (st is not None and not st.ultra and st.side == p.side
                                           and now - st.t <= self.cfg.hint_zone_sec)
                    lines.append(f"↩️ جهت بعدی: {p.side} — منتظر ناحیهٔ ورود")
            elif kind == REENTER:
                lines += await self._drop_kept("ورود مجدد")     # a re-entry is a new trade with its own stop
                lines += self._schedule_reenter(now, p.side)
            elif kind == MARKET_NOW:
                lines += await self._on_market_now(now, missed=p.missed)
        return lines

    # ------------------------------------------------------------------ scalp
    def _default_sl(self, st: Setup) -> float:
        d = self.cfg.default_stop_pts
        return round(st.far + d if st.side == "SELL" else st.far - d, 2)

    def _zone_setup(self, p: Parsed, msg_id: Any, now: float) -> Optional[Setup]:
        side = p.side
        if side is None and self.hint and now - self.hint[1] <= self.cfg.hint_ttl_sec:
            side = self.hint[0]
        if side not in ("BUY", "SELL") or not p.entries:
            return None
        entries = list(p.entries)
        alt = list(p.alt)
        typed: list = []
        mid = self._mid()
        if mid is not None:
            if alt:                                 # "4363/4262": keep the reading next to the price
                if min(abs(e - mid) for e in alt) < min(abs(e - mid) for e in entries):
                    entries, alt = alt, entries
                if min(abs(e - mid) for e in alt) > 20.0:
                    alt = []                        # the price rules the other reading out
            # both levels mistyped in the hundreds / thousands digit ("4190/4189" with gold
            # at 4290, "4061/4060" at 4361): the zone a whole number of hundreds away
            shift = round((mid - entries[0]) / 100.0) * 100.0
            if shift and abs(shift) <= 1000.0 and all(abs(e + shift - mid) <= 10.0 for e in entries):
                typed = list(entries)
                entries = [e + shift for e in entries]
                alt = []
        st = Setup(side=side, entries=entries, sl=None, sl_known=False, t=now, msg_id=msg_id,
                   alt=alt, typed=typed)
        if p.sl is not None:
            st.raw_sl = float(p.sl)
            self._reading_by_stop(st, float(p.sl))
            sl = self._fix_stop(st, p.sl)
            if sl is not None:
                st.sl, st.sl_known = sl, True
        return st

    def _fits(self, st: Setup, sl: float) -> bool:
        """The stop exactly as written is the leader's usual stop for ``st``."""
        return (sl > st.far if st.side == "SELL" else sl < st.far) and abs(sl - self._default_sl(st)) <= 3.0

    def _reading_by_stop(self, st: Setup, sl: float) -> None:
        """Two readings of the zone are still open ("4054/4045" = 4054/4055 or 4044/4045, both
        near the price - or no price): the stop as written fits exactly one of them."""
        if not st.alt:
            return
        other = Setup(side=st.side, entries=list(st.alt), sl=None, sl_known=False, t=st.t, msg_id=st.msg_id)
        mid = self._mid()

        def alive(s: Setup) -> bool:                # the price has not passed this reading's stop already
            return mid is None or (mid < self._default_sl(s) if s.side == "SELL" else mid > self._default_sl(s))
        a, b = self._fits(st, sl) and alive(st), self._fits(other, sl) and alive(other)
        if b and not a:
            st.entries = list(st.alt)
        if a != b:
            st.alt = []

    def _unsettled(self, st: Setup) -> Optional[str]:
        """Why ``st`` must not be traded by any path yet (None: nothing open about it)."""
        if st.side_doubt:
            return "جهت ناحیه هنوز روشن نیست"
        if st.alt:
            return "ناحیه دو خوانش دارد"
        return None

    def _context_side(self, now: float) -> Optional[str]:
        """The side the leader's last order named and no zone has used yet: "سل بزن", or
        the re-entry ("بگیر باز") of the previous zone."""
        if self.hint and self.hint_fresh and now - self.hint[1] <= self.cfg.hint_zone_sec:
            return self.hint[0]
        st = self.setup
        if st is not None and st.side_doubt and now - st.t <= self.cfg.stop_match_sec:
            return st.side_doubt                      # the same zone posted again / edited: still that order
        if self.reenter_due is not None and st is not None and not st.side_doubt:
            return st.side
        return None

    def _price_side(self, st: Setup) -> Optional[str]:
        """The side the live price speaks for: the leader's zone waits behind the price (a
        BUY zone below it, a SELL zone above it - 900 of 937 zones in 3 months, and the two
        zone posts with the wrong side word were among the 7 on the other side).
        None: the price is inside the zone, or there is no price."""
        mid = self._mid()
        if mid is None:
            return None
        if mid > max(st.entries):
            return "BUY"
        if mid < min(st.entries):
            return "SELL"
        return None

    def _flipped(self, st: Setup) -> Setup:
        return Setup(side="SELL" if st.side == "BUY" else "BUY", entries=list(st.entries), sl=None,
                     sl_known=False, t=st.t, msg_id=st.msg_id)

    def _settle_side(self, st: Setup, sl: float) -> bool:
        """A zone whose side is in doubt: the stop shows it (above the zone = SELL, below =
        BUY). True when the stop fits one of the two sides; ``st`` then has that side and stop.
        (The doubt exists only because the price did not speak for the typed side at the zone
        post; the other side is not taken when the price is already beyond that stop.)"""
        for cand in (st, self._flipped(st)):
            fixed = self._fix_stop(cand, sl, tens=False)      # a guessed digit does not show a side
            if fixed is None:
                continue
            mid = self._mid()
            if cand is not st and mid is not None and (mid >= fixed if cand.side == "SELL" else mid <= fixed):
                return False
            st.side_fixed = cand is not st
            st.side, st.sl, st.sl_known, st.raw_sl, st.side_doubt = cand.side, fixed, True, float(sl), None
            return True
        return False

    def _fix_stop(self, st: Setup, sl: float, tens: bool = True) -> Optional[float]:
        """The channel's stop for ``st``: a 100-point typo is corrected; a stop on
        the wrong side of the zone or further than max_stop_pts is refused."""
        sl = float(sl)
        exp = self._default_sl(st)

        def ok(cand: float) -> bool:
            return (cand > st.far if st.side == "SELL" else cand < st.far) and abs(cand - exp) <= 3.0

        # as written, or the hundreds / thousands digit mistyped ("Stop:4240" at 4340, "Stip;5053")
        for k in range(0, 11):
            for cand in ((sl,) if k == 0 else (sl + 100.0 * k, sl - 100.0 * k)):
                if ok(cand):
                    return cand
        ok_side = sl > st.far if st.side == "SELL" else sl < st.far
        if ok_side and abs(sl - st.near) <= self.cfg.max_stop_pts:
            return sl
        # the tens digit mistyped ("Stop:4167" for the zone 4154/4155): the leader's scalp stop is
        # 2 points behind the zone (906 of 928 stops; 10 at 1 point), so the one-keystroke reading
        # exactly there is his stop - unless the number is a normal stop for the OTHER side (then
        # the side is the question). A different LAST digit, or a repair that is not his usual
        # stop ("Stop:4110" for 4095/4096), is a wider stop: refused as before.
        d = self.cfg.default_stop_pts
        other = (min(st.entries) - d) if st.side == "SELL" else (max(st.entries) + d)
        if tens and sl == int(sl) and abs(sl - other) > 3.0:
            fixes = sorted((c for c in _edits(str(int(sl))) if ok(c) and abs(c - exp) <= 1.0 and (c - sl) % 10 == 0),
                           key=lambda c: abs(c - exp))
            if fixes:
                return fixes[0]
        return None

    async def _on_zone(self, p: Parsed, msg_id: Any, now: float) -> list:
        if not self.cfg.trade_scalp:
            return ["ℹ️ ناحیهٔ اسکلپ — معاملهٔ اسکلپ خاموش است"]
        st = self._zone_setup(p, msg_id, now)
        if st is None:
            return ["⚠️ ناحیهٔ ورود بدون جهت/سطح معتبر — نادیده گرفته شد"]
        ctx = self._context_side(now)
        self.hint_fresh = False
        cur = self.setup
        if (cur is not None and cur.side_fixed and p.side is not None and st.side != cur.side
                and sorted(st.entries) == sorted(cur.entries) and now - cur.t <= self.cfg.stop_match_sec):
            st.side, st.side_fixed, ctx = cur.side, True, None   # the same post again, the same slip in the side word
            if p.sl is None and cur.raw_sl is not None:
                sl = self._fix_stop(st, cur.raw_sl)
                if sl is not None:
                    st.sl, st.sl_known, st.raw_sl = sl, True, cur.raw_sl
        if (cur is not None and st.alt and p.sl is None and cur.raw_sl is not None and cur.sl_known
                and cur.side == st.side and now - cur.t <= self.cfg.stop_match_sec
                and sorted(cur.entries) in (sorted(st.entries), sorted(st.alt))):
            self._reading_by_stop(st, cur.raw_sl)             # the same post again: his stop already chose the reading
            if not st.alt:
                sl = self._fix_stop(st, cur.raw_sl)
                if sl is not None:
                    st.sl, st.sl_known, st.raw_sl = sl, True, cur.raw_sl
        # the side word against the leader's order just before it: a doubt only when the price
        # does not settle it (it is where a zone of the typed side waits in 96 % of his zones)
        if ctx is not None and p.side is not None and st.side != ctx and self._price_side(st) != st.side:
            st.side_doubt = ctx
            if st.sl is not None and self._fix_stop(st, float(p.sl), tens=False) is not None:
                st.side_doubt = None                          # the stop in the zone post fits the side as typed
            elif p.sl is not None:
                st.sl, st.sl_known = None, False
                self._settle_side(st, float(p.sl))
        if ctx is not None and p.side is not None and st.side != ctx and not st.side_doubt and st.sl is None:
            st.against = ctx
        lines: list = []
        if self.reenter_due is not None:
            self.reenter_due = None
            lines.append("↪ ورود مجدد با ناحیهٔ تازه جایگزین شد")
        self.if_be_armed = self.if_sl_armed = None    # a conditional re-entry belonged to the old zone
        self._prune()
        old = self.setup
        # the previous zone that is only waiting is dropped - if the executor
        # really dropped it (one being filled right now stays tracked)
        if old is not None and old.placed and not old.done and self._waiting_only(old.ids):
            if self._cancel(old, "ناحیهٔ تازهٔ کانال"):
                old.done = True
                self._untrack(old)
        opened = self._open_scalps()
        for s in opened:
            if s.side == st.side and abs(s.near - st.near) <= 3.0:
                # not traded twice, but it IS the leader's current zone: its "Stop:" and a
                # later "بگیر باز" use these levels ("ده پیپ ورود بیار بالا" + a new zone)
                st.done = True
                if old is not None and not old.placed:
                    old.done = True
                self.setup = st
                if msg_id is not None:
                    self.zone_ids.add(msg_id)
                return lines + [f"ℹ️ ناحیهٔ تکراری {st.text()} — معاملهٔ قبلی هنوز باز است (برای ورود مجدد ثبت شد)"]
        if opened:
            lines.append(f"ℹ️ ناحیهٔ جدید {st.text()} در حالی که معاملهٔ قبلی هنوز باز است")
        if old is not None and not old.placed:
            old.done = True
        self.setup = st
        if msg_id is not None:
            self.zone_ids.add(msg_id)
        lines.append(f"📥 ناحیهٔ ورود: {st.text()}")
        if st.typed:
            lines.append(f"✏️ ناحیه {'/'.join(f'{e:g}' for e in st.typed)} غلط تایپی — با قیمت زنده "
                         f"{'/'.join(f'{e:g}' for e in st.entries)} خوانده شد")
        if st.alt:
            if p.sl is None:
                lines.append(f"⚠️ ناحیه دو خوانش دارد ({'/'.join(f'{e:g}' for e in st.entries)} یا "
                             f"{'/'.join(f'{e:g}' for e in st.alt)}) — منتظر «Stop» تا روشن شود")
            else:
                st.done = True
                lines.append(f"⛔ {st.text()}: ناحیه دو خوانش دارد و «Stop» آن را روشن نکرد — معامله نشد")
        elif st.side_doubt and st.sl is None:
            lines.append(f"⚠️ جهت ناحیه ({st.side}) با دستور قبلی کانال ({st.side_doubt}) نمی‌خواند — "
                         "منتظر «Stop» تا جهت روشن شود")
        elif st.sl is not None:
            lines += await self._place(st, "ناحیه + استاپ")
        elif self.cfg.place_before_stop:
            st.sl = self._default_sl(st)
            lines += await self._place(st, "ناحیه (استاپ پیش‌فرض تا رسیدن Stop)")
        else:
            lines.append("⏳ منتظر «Stop» …")
        return lines

    async def _on_stop(self, p: Parsed, now: float) -> list:
        """The zone's "Stop:" - also a correction of it ("Stop:4158" then "Stop:4159") and
        the stop of a zone that is over / not traded (used by a later re-entry)."""
        st = self.setup
        # an older zone still takes the stop the leader posts for its re-entry ("بگیر باز", "Stop:4275")
        if st is None or (now - st.t > self.cfg.stop_match_sec
                          and (self.reenter_due is None or now - st.t > self.cfg.setup_ttl_sec)):
            return [f"ℹ️ Stop {p.sl:g} بدون ناحیهٔ منتظر — نادیده گرفته شد"]
        if st.alt and not st.placed:
            self._reading_by_stop(st, float(p.sl))
            if st.alt:                              # not traded; a corrected "Stop:" can still settle it
                return [f"⚠️ {st.text()}: ناحیه دو خوانش دارد و «Stop {p.sl:g}» آن را روشن نکرد — معامله نمی‌شود"]
        if st.side_doubt and not st.placed:
            typed = st.side
            if not self._settle_side(st, float(p.sl)):
                return [f"⚠️ Stop {p.sl:g} با ناحیهٔ {st.text()} نمی‌خواند — جهت هنوز روشن نیست"]
            note = " (در پیام ناحیه اشتباه تایپ شده بود)" if st.side != typed else ""
            lines = [f"✏️ جهت ناحیه از روی «Stop {p.sl:g}» روشن شد: {st.side}{note}"]
            if st.done:                               # given up / dropped meanwhile: only for a re-entry
                return lines + [f"✅ Stop {st.sl:g} برای ناحیهٔ {st.text()} ثبت شد (برای ورود مجدد)"]
            return lines + await self._place(st, "ناحیه + استاپ")
        sl = self._fix_stop(st, float(p.sl))
        if (sl is None and st.against and not st.done and not st.sl_known
                and self._fix_stop(self._flipped(st), float(p.sl), tens=False) is not None):
            # typed side against his order just before AND his stop fits only the other side: not on a guess
            if not st.placed or (self._waiting_only(st.ids) and self._cancel(st, "جهت ناحیه با Stop نمی‌خواند")):
                st.done = True
                self._untrack(st)
                st.side_doubt = st.against
                return [f"⛔ {st.text()}: جهت ناحیه با دستور قبلی کانال ({st.against}) و «Stop {p.sl:g}» نمی‌خواند — "
                        "لیمیت لغو شد، معامله نشد"]
        if sl is None:
            wide = (float(p.sl) > st.far) if st.side == "SELL" else (float(p.sl) < st.far)
            if wide and not st.sl_known and not st.done and not st.ultra:
                # the channel's stop is too far for a scalp: the zone (placed with the
                # default stop) is not traded after all, unless it has filled already
                risk = abs(st.near - float(p.sl))
                st.raw_sl = float(p.sl)
                if not st.placed:
                    st.done = st.refused = True
                    return [f"⛔ {st.text()}: فاصلهٔ استاپ کانال {risk:.1f} > {self.cfg.max_stop_pts:g} — معامله نشد"]
                if self._waiting_only(st.ids) and self._cancel(st, "استاپ کانال خیلی دور است"):
                    st.done = st.refused = True
                    self._untrack(st)
                    return [f"⛔ {st.text()}: فاصلهٔ استاپ کانال {risk:.1f} > {self.cfg.max_stop_pts:g} — لیمیت لغو شد"]
                return [f"⚠️ Stop {p.sl:g} خیلی دور است — معامله با استاپ {st.sl:g} ماند"]
            return [f"⚠️ Stop {p.sl:g} با ناحیهٔ {st.text()} نمی‌خواند — نادیده گرفته شد"]
        lines: list = []
        if abs(sl - float(p.sl)) > 1e-9:
            lines.append(f"✏️ Stop {p.sl:g} غلط تایپی — {sl:g} استفاده شد")
        if st.sl_known and st.sl is not None and abs(st.sl - sl) < 1e-9:
            return lines + [f"ℹ️ Stop {sl:g} تکراری است"]
        fix = "اصلاح استاپ" if st.sl_known else "استاپ"
        st.raw_sl = float(p.sl)
        if not st.placed:
            st.sl, st.sl_known = sl, True
            if st.done:
                return lines + [f"✅ Stop {sl:g} برای ناحیهٔ {st.text()} ثبت شد (برای ورود مجدد)"]
            if st.retry_at is not None:
                return lines + [f"✅ Stop {sl:g} ثبت شد (سفارش در حال تلاش دوباره)"]
            return lines + await self._place(st, "ناحیه + استاپ")
        if st.done or self._alive(st.ids) is False:
            st.sl, st.sl_known = sl, True
            return lines + [f"✅ Stop {sl:g} ثبت شد — سفارش این ناحیه دیگر باز نیست (برای ورود مجدد)"]
        if st.be and not st.be_wait:
            st.sl_known = True
            return lines + [f"ℹ️ Stop {sl:g}: معاملهٔ این ناحیه فری شده — استاپ تغییر نکرد"]
        if st.sl is not None and abs(st.sl - sl) < 1e-9:
            st.sl_known = True
            return lines + [f"✅ Stop {sl:g} همان استاپ پیش‌فرض است"]
        try:
            res = await self.ex.update_levels(self.cfg.symbol, sl=sl, order_ids=list(st.ids))
        except Exception as exc:
            return lines + [f"❌ اصلاح استاپ به {sl:g} ناموفق: {exc!r}"]
        st.sl_known = True
        if res.get("action") == "levels_updated":
            st.sl = sl
            return lines + [f"✅ {fix} به {sl:g} اصلاح شد"]
        return lines + [f"⚠️ {fix} به {sl:g}: {_why(res)}"]

    async def _place(self, st: Setup, why: str, market: bool = False) -> list:
        if st.sl is None:
            st.sl = self._default_sl(st)
        if not st.ultra:
            risk = abs(st.near - st.sl)
            if risk > self.cfg.max_stop_pts:
                st.done = st.refused = True
                return [f"⛔ {st.text()}: فاصلهٔ استاپ {risk:.1f} > {self.cfg.max_stop_pts:g} — معامله نشد"]
        sig = self._signal(st, market=market)
        st.tries += 1
        try:
            if market:
                res = await self.ex.market_now(self.cfg.symbol, sig)
            else:
                res = await self.ex.execute(sig)
        except Exception as exc:
            now = self._now()
            if st.tries < 3 and now - st.t <= self.cfg.stop_match_sec and not market:
                st.retry_at = now + 5.0
                return [f"❌ خطای ارسال سفارش ({exc!r}) — ۵ ثانیه بعد دوباره"]
            st.done = True
            return [f"❌ خطای ارسال سفارش: {exc!r} — رها شد"]
        st.retry_at = None
        act = res.get("action")
        if act in OK_ACTIONS:
            st.placed = True
            st.ids = _ids(res)
            if st not in self.live:
                self.live.append(st)
            self._count("orders")
            note = res.get("entry_adjusted") or res.get("sizing") or ""
            kind = "لیمیت مجازی (با رسیدن قیمت وارد می‌شود)" if act == "pending_virtual" else "سفارش ارسال شد"
            return [f"✅ {why}: {st.text()} → {kind} {st.ids}" + (f" — {note}" if note else "")]
        st.done = True
        st.entry_rejected = act in ("rejected", "rejected_local", "skipped_daily_limit", "skipped_max_open")
        if act == "order_exists":
            return [f"ℹ️ {why}: معاملهٔ باز دیگری هست — ورود تازه انجام نشد"]
        return [f"⛔ {why}: {st.text()} رد شد — {_why(res)}"]

    async def _on_be(self, now: float, before_id: Any = None) -> list:
        """"فریش کن": protect live scalps at their actual fills by default.
        With keep_zone_on_be, an unfilled scalp waits for its fill; otherwise it
        is dropped. No scalp: live ULTRA trades; after restart: channel bot orders.
        breakeven_at_zone=True explicitly retains the legacy scalp zone reference."""
        lines: list = []
        st = self.setup
        if self.reenter_due is not None and before_id is None:
            self.reenter_due = None                 # "فری" ends the trade idea: no re-entry of it
            lines.append("🟡 فری: ورود مجدد در انتظار لغو شد")
        if (st is not None and not st.placed and not st.done and _older(st, before_id)
                and now - st.t <= self.cfg.setup_ttl_sec):
            st.done = True                          # a zone still waiting for "Stop:" is given up
            lines.append("🟡 فری: ناحیهٔ ثبت‌نشده رها شد")
        self._prune()
        targets = self._targets(now, before_id)
        if not targets:
            ids = self._restored_targets(now, before_id)
            if ids == []:
                return lines or ["🟡 فری: سفارش فعالی از ربات نیست"]
            return lines + await self._be_call(ids, None, None)
        for s in targets:
            ref = s.near if self.cfg.breakeven_at_zone and not s.ultra else None
            if (self.cfg.keep_zone_on_be and not s.ultra and before_id is None
                    and self._waiting_only(s.ids)):
                s.be = s.be_wait = True
                s.be_tries = 0
                lines.append(f"🟡 فری ({s.text()}): لیمیت پرنشده می‌ماند — اگر پر شود، استاپ همان لحظه "
                             f"به نقطهٔ ورود می‌رود")
                continue
            lines += await self._be_call(list(s.ids), ref, s)
        return lines

    def _ultra_context(self) -> bool:
        """The leader's latest trade idea is an ULTRA signal (newer than the scalp zone):
        "اگر استاپ بخوره دوباره بگیر" then speaks about it, not about the scalp zone."""
        st = self.setup
        return self.last_ultra_t is not None and (st is None or self.last_ultra_t > st.t)

    async def _drop_kept(self, why: str) -> list:
        """The leader's trade is over ("فری خورد" / "استاپ خورد" / "بگیر باز"): a zone kept at
        "فری" that has not filled is not entered any more."""
        out: list = []
        for s in [x for x in self.live if x.be_wait and self._waiting_only(x.ids)]:
            if self._cancel(s, why):
                s.be_wait = False
                s.done = True
                self._untrack(s)
                out.append(f"🟡 «{why}»: لیمیت پرنشدهٔ فری‌شده ({s.text()}) لغو شد")
        return out

    async def _be_after_fill(self) -> list:
        """A zone kept at "فری" has filled: the executor's breakeven (the same call as
        "فری" on an open trade: the stop to the entry, or a close when the price is
        already past it). Still waiting: nothing; gone: forgotten."""
        out: list = []
        for s in [x for x in self.live if x.be_wait]:
            if self._waiting_only(s.ids):
                continue
            s.be_tries += 1
            if self._alive(s.ids) is False:
                s.be_wait = False
                continue
            if s.be_tries > 30:
                s.be_wait = False
                s.be = False
                out.append(f"⚠️ فری بعد از پر شدن ({s.text()}) انجام نشد — استاپ قبلی معامله برقرار است")
                continue
            ref = s.near if self.cfg.breakeven_at_zone else None
            try:
                res = await self.ex.breakeven(self.cfg.symbol, order_ids=list(s.ids), ref_price=ref)
            except Exception as exc:
                if s.be_tries == 1:
                    out.append(f"❌ فری بعد از پر شدن ناموفق ({exc!r}) — هر ثانیه دوباره")
                continue
            act = res.get("action")
            if act not in BE_OK_ACTIONS:
                if s.be_tries == 1 and act != "no_open_order":
                    out.append(f"⚠️ فری بعد از پر شدن ({s.text()}) رد شد: {_why(res)} — دوباره تلاش می‌شود")
                continue                              # failed / fill not in the book yet: next tick
            s.be_wait = False
            if act == "pending_cancelled":
                s.done = True
                self._untrack(s)
            names = {"breakeven_set": "استاپ به نقطهٔ ورود رفت", "breakeven_virtual": "گارد نقطهٔ ورود فعال شد",
                     "pending_cancelled": "لیمیت لغو شد", "dry_run": "حالت آزمایشی"}
            if act == "breakeven_virtual" and any(o.get("waiting_for_price") for o in res.get("orders", [])):
                names[act] = "گارد ورود ثبت شد؛ پس از رسیدن قیمت به ورود فعال می‌شود"
            out.append(f"🟡 لیمیتِ فری‌شده پر شد ({s.text()}): {names.get(act, _why(res))}")
        return out

    async def _be_call(self, ids: Optional[list], ref: Optional[float], s: Optional[Setup],
                       retry: bool = False) -> list:
        if ids == []:
            return ["🟡 فری: سفارشی از ربات نیست"]
        key = None if ids is None else tuple(sorted(str(i) for i in ids))
        try:
            res = await self.ex.breakeven(self.cfg.symbol, order_ids=ids, ref_price=ref)
        except Exception as exc:
            res = {"action": "error", "reason": repr(exc)}
        act = res.get("action")
        if act in BE_OK_ACTIONS:
            self.be_retries.pop(key, None)
            if s is not None:
                s.be = True
            if act == "pending_cancelled":
                if s is not None:
                    s.done = True
                    self._untrack(s)
        elif ids is not None and self._alive(ids) is not False:
            now = self._now()
            previous = self.be_retries.get(key)
            self.be_retries[key] = {"ids": list(ids), "ref": ref, "setup": s,
                                    "next": now + 5.0,
                                    "until": previous["until"] if retry and previous else now + 60.0}
        names = {"breakeven_set": "استاپ به نقطهٔ ورود رفت", "breakeven_virtual": "گارد نقطهٔ ورود فعال شد",
                 "pending_cancelled": "لیمیت پرنشده لغو شد (ورود بعد از فری معنی ندارد)",
                 "no_open_order": "سفارش بازی نیست", "dry_run": "حالت آزمایشی"}
        if act == "breakeven_virtual" and any(o.get("waiting_for_price") for o in res.get("orders", [])):
            names[act] = "گارد ورود ثبت شد؛ پس از رسیدن قیمت به ورود فعال می‌شود"
        who = f" ({s.text()})" if s is not None else ""
        line = f"🟡 فری{who}: {names.get(act, _why(res))}"
        if act not in BE_OK_ACTIONS and key in self.be_retries:
            line += " — فری تأیید نشد؛ ۵ ثانیه بعد دوباره"
        return [line]

    async def _on_close(self, side: Optional[str], now: float, before_id: Any = None) -> list:
        """"ببندش": every live scalp (no scalp: the live ULTRA trades).
        "بای ها کامل خروج بزن": every live trade of that side. Nothing known
        (a restart): the channel's own bot orders on the symbol."""
        st = self.setup
        self.reenter_due = None
        if before_id is None:
            self.if_be_armed = self.if_sl_armed = None   # the trade the condition was about is closed
        if (st is not None and not st.placed and not st.done and _older(st, before_id)
                and (side is None or side == st.side)):
            st.done = True
        self._prune()
        if side is not None:
            targets = [s for s in self.live if _older(s, before_id) and s.side == side]
        else:
            targets = self._targets(now, before_id)
        if not targets:
            ids = self._restored_targets(now, before_id, side=side)
            if ids == []:
                return ["🛑 بستن: سفارش بازی از ربات برای این دستور نیست"]
            return await self._close_ids(ids, [], now)
        ids = [i for s in targets for i in s.ids]
        return await self._close_ids(ids, targets, now)

    async def _close_ids(self, ids: Optional[list], setups: list, now: float, retry: bool = False) -> list:
        if ids == []:
            return ["🛑 بستن: سفارشی از ربات نیست"]
        try:
            res = await self.ex.close(self.cfg.symbol, order_ids=ids)
        except Exception as exc:
            if not retry:
                self.close_retry = {"ids": ids, "setups": setups, "next": now + 5.0, "until": now + 60.0}
            return [f"❌ بستن ناموفق ({exc!r}) — ۵ ثانیه بعد دوباره"]
        act = res.get("action")
        sent = act in ("close", "closed", "no_open_order", "dry_run_close", "dry_run", "pending_cancelled") \
            and not _close_failed(res)
        kept = 0
        for s in setups:
            alive = self._alive(s.ids)
            if sent:
                s.closed = True
            if alive is False or (act == "no_open_order" and alive is not True) or (sent and alive is None):
                s.done = True
                self._untrack(s)
            else:
                kept += 1                           # still open: stays tracked for the next close / فری
        state = self._alive(ids) if ids else None
        pending = bool(kept) or (not setups and bool(ids) and state is not False
                                and act not in ("dry_run_close", "dry_run")
                                and (act not in ("no_open_order", "pending_cancelled") or state is True))
        if sent and not pending:
            self.close_retry = None
        elif pending and not retry:                # rejected OR sent but still open: check and retry the same ids
            self.close_retry = {"ids": ids, "setups": [s for s in setups if s in self.live],
                                "next": now + 5.0, "until": now + 60.0}
        elif not pending:
            self.close_retry = None
        names = {"close": "بسته شد", "no_open_order": "سفارش بازی نبود", "dry_run_close": "حالت آزمایشی"}
        line = f"🛑 بستن: {names.get(act, _why(res))}"
        if pending:
            line = "🛑 بستن: " + ("درخواست ارسال شد؛ بسته‌شدن هنوز تأیید نشده" if sent else _why(res))
            line += " — ۵ ثانیه بعد روی همان سفارش‌ها دوباره"
        elif not sent:
            line += " — بستن تأیید نشد"
        return [line]

    def _schedule_reenter(self, now: float, side: Optional[str] = None) -> list:
        base = self.setup
        if base is None or now - base.t > self.cfg.setup_ttl_sec:
            return ["↩️ ورود مجدد: ناحیهٔ قبلی نیست/قدیمی است — منتظر ناحیهٔ تازه"]
        if side is not None and side != base.side:
            return [f"↩️ ورود مجدد {side}: ناحیهٔ قبلی {base.side} است — منتظر ناحیهٔ تازه"]
        if base.refused:
            return ["↩️ ورود مجدد: ناحیهٔ قبلی به‌خاطر استاپ دورِ کانال معامله نشد — منتظر ناحیهٔ تازه"]
        if self._unsettled(base):
            return [f"↩️ ورود مجدد: {self._unsettled(base)} — منتظر ناحیهٔ تازه"]
        if self.cfg.reenter_wait_sec <= 0:
            return ["↩️ ورود مجدد: منتظر ناحیهٔ تازهٔ کانال"]
        due = now + self.cfg.reenter_wait_sec
        if self.reenter_due is None or due < self.reenter_due:
            self.reenter_due = due
        return [f"🔁 ورود مجدد {base.text()} تا {self.cfg.reenter_wait_sec:.0f} ثانیه (ناحیهٔ تازه جایش را می‌گیرد)"]

    def _on_if_sl(self, now: float, side: Optional[str]) -> list:
        """"اگه استاپ تاچ کرد بگیر باز": the bot's trade of the current zone is already
        over (its stop - or its breakeven / take profit - came first): the zone is
        re-entered (like "بگیر باز"); still open: armed for the leader's "استاپ خورد"."""
        base = self.setup
        if base is None or now - base.t > self.cfg.setup_ttl_sec or base.closed:
            return ["↩️ «اگر استاپ تاچ کرد»: ناحیهٔ فعالی نیست — کاری انجام نشد"]
        self._prune()
        if base.placed and not self._waiting_only(base.ids) and self._alive(base.ids) is False:
            return ["↩️ «اگر استاپ تاچ کرد»: معاملهٔ ربات بسته شده است"] + self._schedule_reenter(now, side)
        if base.placed and not base.done and self._alive(base.ids) is not False:
            self.if_sl_armed = now
            return ["↩️ ورود مجدد مشروط ثبت شد (با «استاپ خورد» اجرا می‌شود)"]
        return ["↩️ «اگر استاپ تاچ کرد»: ربات در این معامله نیست — کاری انجام نشد"]

    async def _reenter_now(self, now: float) -> list:
        base = self.setup
        if base is None or now - base.t > self.cfg.setup_ttl_sec or self._unsettled(base):
            return []
        self._prune()
        if self._open_scalps():
            return ["ℹ️ ورود مجدد لازم نشد — معاملهٔ قبلی هنوز باز است"]
        if base.placed and base in self.live:
            return ["ℹ️ ورود مجدد لازم نشد — سفارش قبلی هنوز منتظر است"]
        st = Setup(side=base.side, entries=list(base.entries), sl=base.sl, sl_known=base.sl_known,
                   t=base.t, msg_id=base.msg_id, raw_sl=base.raw_sl)
        self.setup = st
        return await self._place(st, "ورود مجدد")

    async def _on_wait(self, now: float) -> list:
        """"صبر میگم کجا بگیری" / "فعلا صبر": no entry now - a pending re-entry, a
        conditional one and a zone that has not filled yet are dropped (the leader
        posts the next zone)."""
        out: list = []
        if self.reenter_due is not None:
            self.reenter_due = None
            out.append("✋ «صبر»: ورود مجدد در انتظار لغو شد")
        if self.if_be_armed is not None or self.if_sl_armed is not None:
            self.if_be_armed = self.if_sl_armed = None
            out.append("✋ «صبر»: ورود مجدد مشروط لغو شد")
        st = self.setup
        if st is not None and not st.done and now - st.t <= self.cfg.setup_ttl_sec:
            if not st.placed:
                st.done = True
                out.append(f"✋ «صبر»: ناحیهٔ {st.text()} ثبت نشد")
            elif self._waiting_only(st.ids) and self._cancel(st, "صبر کانال"):
                st.done = True
                self._untrack(st)
                out.append(f"✋ «صبر»: لیمیت پرنشدهٔ {st.text()} لغو شد")
        return out

    async def _on_extend(self, p: Parsed, now: float) -> list:
        """"48هم بود بگیر": the leader takes the current zone up to ..48 too (a BUY
        4346/4347 whose price is 1 point above it). The zone's near edge moves there
        (at most 3 points, the stop stays) and its waiting order is placed again."""
        st = self.setup
        if st is None or st.ultra or st.closed or now - st.t > self.cfg.setup_ttl_sec:
            return ["ℹ️ «... هم بود بگیر»: ناحیه‌ای نیست — کاری انجام نشد"]
        if self._unsettled(st):
            return [f"ℹ️ «... هم بود بگیر»: {self._unsettled(st)} — کاری انجام نشد"]
        try:
            lvl = float(str(int(st.near))[:2] + f"{int(p.price):02d}")
        except (TypeError, ValueError):
            return []
        move = (lvl - st.near) if st.side == "BUY" else (st.near - lvl)
        if not 0 < move <= 3.0:
            return [f"ℹ️ «... هم بود بگیر»: سطح {lvl:g} با ناحیهٔ {st.text()} نمی‌خواند — نادیده گرفته شد"]
        self._prune()
        if self._open_scalps():
            return ["ℹ️ «... هم بود بگیر»: معامله از قبل باز است"]
        if st.placed:
            if st.done or not self._waiting_only(st.ids):
                return ["ℹ️ «... هم بود بگیر»: سفارش این ناحیه دیگر منتظر نیست — کاری انجام نشد"]
            if not self._cancel(st, "ناحیه با پیام کانال گسترش یافت"):
                return ["ℹ️ «... هم بود بگیر»: سفارش قبلی در حال پر شدن است"]
            self._untrack(st)
        st.done = True
        new = Setup(side=st.side, entries=[lvl, st.near], sl=st.sl, sl_known=st.sl_known, t=st.t,
                    msg_id=st.msg_id, raw_sl=st.raw_sl, be=st.be, be_wait=st.be_wait,
                    ext_from=list(st.ext_from or st.entries))
        self.setup = new
        return [f"📥 ناحیه تا {lvl:g} گسترش یافت"] + await self._place(new, "ناحیهٔ گسترش‌یافته")

    async def _on_market_now(self, now: float, missed: bool = False) -> list:
        st = self.setup
        if st is None or now - st.t > self.cfg.setup_ttl_sec:
            return ["ℹ️ «جا موندی»: ناحیه‌ای برای ورود نیست"]
        if self._unsettled(st):
            return [f"ℹ️ «جا موندی»: {self._unsettled(st)} — وارد نشد"]
        self._prune()
        if self._open_scalps():
            return ["ℹ️ «جا موندی»: معامله از قبل باز است"]
        mid = self._mid()
        if mid is None:
            return ["ℹ️ «جا موندی»: قیمت زنده نیست — وارد نشد"]
        past = (st.near - mid) if st.side == "SELL" else (mid - st.near)
        lim = max(self.cfg.market_now_max_past, self.cfg.market_now_missed_max_past) if missed \
            else self.cfg.market_now_max_past
        if past > lim:
            return [f"ℹ️ «جا موندی»: قیمت {past:.1f} واحد از ناحیه دور است (حد {lim:g}) — وارد نشد"]
        sl = st.sl if st.sl is not None else self._default_sl(st)
        risk = abs(mid - sl)
        if risk > self.cfg.max_stop_pts:
            return [f"ℹ️ «جا موندی»: ریسک {risk:.1f} > {self.cfg.max_stop_pts:g} — وارد نشد"]
        st2 = Setup(side=st.side, entries=list(st.entries), sl=sl, sl_known=st.sl_known, t=st.t,
                    msg_id=st.msg_id, raw_sl=st.raw_sl)
        lines = await self._place(st2, "ورود مارکت («جا موندی»)", market=True)
        if st2.placed:                              # the zone it replaced is over (executor dropped it)
            if st.placed and self._alive(st.ids) is False:
                st.done = True
                self._untrack(st)
            if not st.placed:
                st.done = True
            self.setup = st2
        return lines

    # ------------------------------------------------------------------ ultra
    async def _on_ultra(self, p: Parsed, msg_id: Any, now: float, replace_owned: bool = False) -> list:
        key = (p.side, tuple(p.entries), p.sl)
        first = self.ultra_seen.get(key)
        if not replace_owned and first is not None and now - first <= self.cfg.ultra_repeat_sec:
            if msg_id is not None and msg_id not in self.ultra_messages:
                self._remember_ultra(msg_id, None)
            return []                               # an advert repost of the same signal
        self.ultra_seen[key] = now
        self.last_ultra_t = now
        self.if_be_armed = self.if_sl_armed = None  # a conditional before it was about another trade
        st = Setup(side=p.side, entries=list(p.entries), sl=p.sl, sl_known=True, t=now, msg_id=msg_id,
                   raw_sl=p.sl, ultra=True, tps=list(p.tps), tp_pips=list(p.tp_pips))
        if msg_id is not None:
            self._remember_ultra(msg_id, st)
        if not self.cfg.trade_ultra:
            return [f"ℹ️ {st.text()} — معاملهٔ ULTRA خاموش است؛ این پیام رد بروکر نیست. "
                    "برای اجرای این نوع سیگنال، گزینهٔ «سیگنال‌های ULTRA هم باز شود» در پنجره بررسی شود"]
        if p.tp_pips and (not math.isfinite(self.cfg.gold_pip_size) or self.cfg.gold_pip_size <= 0):
            return ["⛔ اندازهٔ پیپ طلا نامعتبر است (gold_pip_size) — ورود انجام نشد"]
        self._prune()
        return await self._place(st, "ULTRA")

    def _remember_ultra(self, msg_id: Any, st: Optional[Setup]) -> None:
        self.ultra_messages[msg_id] = st
        self.ultra_messages.move_to_end(msg_id)
        while len(self.ultra_messages) > 2000:
            self.ultra_messages.popitem(last=False)

    async def _edit_ultra(self, p: Parsed, msg_id: Any, now: float, ts: Optional[float]) -> list:
        original = self.received_ids.get(msg_id)
        if original is None:
            return [f"✏️ سیگنال {msg_id} در این اجرا دریافت نشده — ویرایش فقط ثبت شد"]
        if msg_id in self.zone_ids:
            return ["✏️ افزودن قالب سیگنال کامل به ناحیهٔ اسکلپ قبلی — سفارش دوم ایجاد نشد"]
        seq, received = original
        age = now - (float(ts) if ts is not None else received)
        if age > min(self.cfg.max_msg_age_sec, self.cfg.stop_match_sec) or seq < self._latest_entry_seq:
            return [f"✏️ سیگنال {msg_id} قدیمی است یا ناحیهٔ تازه‌تری آمده — ویرایش فقط ثبت شد"]
        known = msg_id in self.ultra_messages
        old = self.ultra_messages.get(msg_id)
        if known and old is None:
            return ["✏️ ویرایش بازنشر سیگنال ULTRA — ورود دوباره انجام نشد"]
        if old is not None:
            same = (old.side == p.side and sorted(old.entries) == sorted(p.entries)
                    and old.sl == p.sl and old.tps == p.tps and old.tp_pips == p.tp_pips)
            if same:
                return ["✏️ اعداد سیگنال ULTRA تغییری نکرده — ورود دوباره انجام نشد"]
            old_key = (old.side, tuple(old.entries), old.sl)
            key = (p.side, tuple(p.entries), p.sl)
            seen = self.ultra_seen.get(key)
            if key != old_key and seen is not None and now - seen <= self.cfg.ultra_repeat_sec:
                return ["✏️ اصلاح به یک سیگنال ULTRA تکراری است — سفارش فعلی حفظ شد"]
            if (old.done and not old.entry_rejected) or old.closed or old.be:
                return ["✏️ سیگنال ULTRA قبلاً خاتمه/مدیریت شده — ورود دوباره انجام نشد"]
            if old.placed:
                if not self._waiting_only(old.ids):
                    return ["✏️ سفارش ULTRA قبلاً ارسال/پر شده — ویرایش ورود تازه ایجاد نمی‌کند"]
                if not self._cancel(old, "سیگنال ULTRA با ویرایش کانال اصلاح شد"):
                    return ["✏️ لیمیت ULTRA در حال ارسال است — ویرایش ورود تازه ایجاد نمی‌کند"]
                old.done = True
                self._untrack(old)
        # Also accepts a fresh invalid initial post corrected by its author.
        # Both the router and received_ids require delivery in this exact run.
        self._latest_entry_seq = seq
        return ["✏️ سیگنال کامل با ویرایش کانال اصلاح شد"] + await self._on_ultra(
            p, msg_id, now, replace_owned=old is not None)
