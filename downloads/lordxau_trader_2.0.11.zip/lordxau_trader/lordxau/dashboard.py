# -*- coding: utf-8 -*-
"""Live dashboard for LORD XAU Trader: a small local web page that shows, in real time,
every channel message -> what the bot understood (regex or 🤖 LLM) -> the order on the broker,
plus the open trade, balance and a price chart. Same visual as the lab replay page.

The running program feeds a DashboardState (engine events + broker quote + closed trades) and serves it on
127.0.0.1 only. Nothing is sent anywhere; the page just polls /state.json. Safe to run beside the trader.
"""
from __future__ import annotations

import datetime as dt
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Optional

from lordxau import CHANNEL, __version__

TEH = 12600
KIND_FA = {"ZONE": "ناحیهٔ ورود", "STOP": "استاپ", "BE": "فری (ریسک‌فری)", "CLOSE": "ببند", "REENTER": "بگیر باز",
           "MARKET_NOW": "مارکت بزن", "HINT": "جهت", "WAIT": "صبر", "SIGNAL": "سیگنال ULTRA", "SL_HIT": "استاپ خورد",
           "BE_HIT": "فری خورد", "EXTEND": "گسترش ناحیه", "NOISE": "گفت‌وگو", "SHORTHAND": "کوتاه‌نوشت",
           "IF_SL_REENTER": "اگر استاپ خورد بگیر", "IF_BE_REENTER": "اگر فری خورد بگیر", "PRICE": "اعلام قیمت",
           "RESULT": "اعلام نتیجه"}


class DashboardState:
    """Thread-safe. Fed by the runner; serialized for the page. Keeps a rolling window so memory is bounded."""

    def __init__(self, balance0: float = 105.0, max_events: int = 1200, max_ticks: int = 4000,
                 source_msgs: str = f"تلگرام @{CHANNEL}", source_price: str = "بروکر Trendo"):
        self.lock = threading.Lock()
        self.balance0 = balance0
        self.balance = balance0
        self.max_events = max_events
        self.max_ticks = max_ticks
        self.events: list = []
        self.ticks: list = []           # [t, bid, ask]
        self.trades: list = []
        self.posts = 0
        self.t0 = self.t1 = _now()
        self.quote: Optional[list] = None
        self.pos: list = []             # [{id, side, state, fill, sl, tp, lot, be, edge, entries, opened}]
        self.feed = {"telegram": "—", "broker": "—", "wallet": "—", "market": "—"}
        self.source = {"messages": source_msgs, "price": source_price}

    # ---- feeders (called from the runner / backtest) -------------------
    def on_message(self, ev: dict) -> None:
        """ev: the engine's on_event dict (type=message)."""
        with self.lock:
            t = float(ev.get("t") or _now())
            kind = ev.get("kind", "NOISE")
            llm = ev.get("llm")
            parsed = kind + (("+" + "+".join(ev.get("also") or [])) if ev.get("also") else "")
            rec = {"kind": "msg", "t": t, "ts": float(ev.get("ts") or t), "id": ev.get("id"),
                   "text": ev.get("text") or "", "photos": int(ev.get("photos") or 0),
                   "edited": bool(ev.get("edited")), "was_edited": bool(ev.get("edited")),
                   "q": list(self.quote) if self.quote else None, "parsed": parsed,
                   "kind_fa": KIND_FA.get(kind, kind), "also_fa": [KIND_FA.get(k, k) for k in (ev.get("also") or [])],
                   "llm": llm, "lines": [str(x) for x in (ev.get("lines") or [])],
                   "setup": ev.get("setup"), "state": self._snapshot()}
            self.posts += 1
            self._add(rec, t)

    def on_broker_line(self, text: str, t: Optional[float] = None) -> None:
        """A broker event already formatted (fill / close / cancel …)."""
        t = _now() if t is None else t
        with self.lock:
            self._add({"kind": "sim", "t": t, "text": text, "state": self._snapshot()}, t)

    def on_timer(self, text: str, t: Optional[float] = None) -> None:
        t = _now() if t is None else t
        with self.lock:
            self._add({"kind": "timer", "t": t, "text": str(text)}, t)

    def push_tick(self, bid: float, ask: float, t: Optional[float] = None) -> None:
        t = _now() if t is None else t
        with self.lock:
            if self.ticks and t <= self.ticks[-1][0]:
                t = self.ticks[-1][0] + 0.001
            self.ticks.append([round(t, 1), round(bid, 2), round(ask, 2)])
            if len(self.ticks) > self.max_ticks:
                self.ticks = self.ticks[-self.max_ticks:]
            self.quote = [round(bid, 2), round(ask, 2)]
            self.t1 = t

    def on_trade(self, trade: dict) -> None:
        """A closed trade: {id, side, fill, exit, pts, usd, why, open, close, lot, sl0}."""
        with self.lock:
            self.trades.append(trade)
            if trade.get("balance") is not None:
                self.balance = float(trade["balance"])

    def set_positions(self, pos: list) -> None:
        with self.lock:
            self.pos = list(pos or [])

    def set_feed(self, **kw) -> None:
        with self.lock:
            self.feed.update({k: v for k, v in kw.items() if v is not None})

    def set_balance(self, balance: float) -> None:
        with self.lock:
            self.balance = float(balance)

    def reset(self, balance0: Optional[float] = None, price_label: Optional[str] = None) -> None:
        """Clear the session and re-baseline P/L. Called when the account (wallet / REAL-vs-DEMO) changes, so the
        page does not show the previous wallet's balance baseline, trades or DEMO/REAL label on the new account."""
        with self.lock:
            if balance0 is not None:
                self.balance0 = self.balance = float(balance0)
            if price_label is not None:
                self.source["price"] = price_label
            self.events = []
            self.ticks = []
            self.trades = []
            self.posts = 0
            self.pos = []
            self.quote = None

    # ---- internals -----------------------------------------------------
    def _add(self, rec: dict, t: float) -> None:
        self.events.append(rec)
        if len(self.events) > self.max_events:
            self.events = self.events[-self.max_events:]
        self.t1 = max(self.t1, t)

    def _snapshot(self) -> dict:
        return {"balance": round(self.balance, 2), "pos": list(self.pos)}

    def to_json(self) -> str:
        with self.lock:
            day = dt.datetime.utcfromtimestamp(self.t1 + TEH).strftime("%Y-%m-%d")
            d = {"day": day, "version": __version__, "latency": None, "balance0": self.balance0,
                 "balance": round(self.balance, 2), "posts": self.posts, "events": list(self.events),
                 "ticks": list(self.ticks), "t0": self.t0, "t1": self.t1, "live": True,
                 "trades": list(self.trades), "pnl": round(self.balance - self.balance0, 2),
                 "leader": None, "counts": {}, "state": self._snapshot(), "quote": self.quote,
                 "feed": dict(self.feed), "source": dict(self.source)}
            return json.dumps({day: d}, ensure_ascii=False)


def _now() -> float:
    import time
    return time.time()


def start_server(state: DashboardState, port: int = 8799, page: Optional[Path] = None,
                 host: str = "127.0.0.1", log=print) -> "ThreadingHTTPServer":
    """Serve the dashboard on host:port (localhost only). Returns the server (call .shutdown() to stop)."""
    page = page or (Path(__file__).resolve().parent / "dashboard.html")
    html = page.read_bytes()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):            # keep the console quiet
            pass

        def _send(self, body: bytes, ctype: str):
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if self.path.split("?")[0] in ("/", "/index.html", "/dashboard.html"):
                self._send(html, "text/html; charset=utf-8")
            elif self.path.split("?")[0] == "/state.json":
                self._send(state.to_json().encode("utf-8"), "application/json; charset=utf-8")
            else:
                self.send_response(404); self.end_headers()

    srv = ThreadingHTTPServer((host, port), Handler)
    threading.Thread(target=srv.serve_forever, name="lordxau-dashboard", daemon=True).start()
    log(f"📊 داشبورد روی http://{host}:{port} باز است")
    return srv
