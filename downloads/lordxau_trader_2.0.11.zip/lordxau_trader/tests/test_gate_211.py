"""2.0.11: a tone-only reader must not discard numeric/future conditions."""
import pytest

from lordxau.llm_gate import GateContext, gate, likely_command
from lordxau.llm_reader import Reading
from test_engine import make, run


@pytest.mark.parametrize("text", [
    "رو 4118/4119فری کن",                 # actual 91015, Gemini previously acted
    "رو4119/4118فری کن",                  # actual 91258
    "فریش کن رو4182",                    # actual 91913
    "جمعش کن وقتی رسید به ۴۱۸۲",         # Persian digits
    "فری رو ٤١٨٢ بذار",                  # Arabic digits
    "یکیشو ½ سیو کن",                    # numeric fraction cannot be represented
    "هر جا سر به سر ببندید",             # actual 91842, future condition
    "هرجا سود کرد جمعش کن",
    "هر وقت برگشت جمعش کن",
    "اگه سوده جمعش کن",
    "وقتی برگشت بی ریسکش کن",
])
@pytest.mark.parametrize("action", ["close", "risk_free", "reenter"])
def test_prefilter_and_gate_reject_unsupported_management(text, action):
    assert not likely_command(text)
    reading = Reading(kind=action, confidence=1.0, source="stub")
    decision = gate(reading, GateContext("NOISE", text, has_open=True, recent_side="BUY"))
    assert decision.action is None and decision.reason


@pytest.mark.parametrize("text,action", [
    ("جمعش کن", "close"),
    ("بی ریسکش کن", "risk_free"),
])
def test_supported_numberless_immediate_tone_still_passes(text, action):
    assert likely_command(text)
    decision = gate(Reading(kind=action, confidence=0.9, source="stub"),
                    GateContext("NOISE", text, has_open=True))
    assert decision.action == action


@pytest.mark.parametrize("text", ["جمعش کن نزدیک ۴۱۸۲", "اگه برگشت جمعش کن"])
def test_open_trade_does_not_call_provider_for_unsupported_fallback(text):
    eng, ex, clk = make()
    run(eng.handle("Xau Buy Enter:4187/4186", msg_id=1, ts=clk.t))
    ex.fill("v1")
    calls = []
    eng.llm = lambda body: (calls.append(body), Reading(kind="close", confidence=1.0, source="stub"))[1]
    before = list(ex.calls)
    run(eng.handle(text, msg_id=2, ts=clk.t))
    assert not calls and ex.calls == before and ex.alive == {"v1"}
