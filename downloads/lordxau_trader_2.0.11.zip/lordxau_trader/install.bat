@echo off
chcp 65001 >nul
cd /d "%~dp0"
set PYTHONUTF8=1
echo === LORD XAU Trader - install (one time) ===
where python >nul 2>nul
if errorlevel 1 (
  py -m pip install -r requirements.txt
) else (
  python -m pip install -r requirements.txt
)
echo.
echo Creating the desktop shortcut "LORD XAU Trader" ...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\LORD XAU Trader.lnk'); $s.TargetPath='%~dp0start.bat'; $s.WorkingDirectory='%~dp0'; $s.Save()"
echo.
echo Done. Close the OLD program window, then open "LORD XAU Trader" on the desktop.
pause
