# -*- coding: utf-8 -*-
"""settings.json of the @lordxau trader (next to start.bat).

First run: the broker / risk / Telegram settings are taken from the previous
program (telegram_signal_trader: its config.yaml, .env, Telegram session and
the ids of the orders it opened), found as the parent folder or a sibling
folder - so the account (REAL or DEMO, the wallet) stays exactly as it was set
up there and nothing has to be typed. Without a previous program the
defaults are the DEMO wallet.

The files are copied only by Runner._prepare, after it made sure the previous
program is not running (load(do_import=False) only reads). On every Start the
previous program's @lordxau order ids and today's daily-loss baseline are
merged in again (sync_from_old), so switching programs never forgets an open
trade nor restarts the daily loss limit from zero.

A settings.json that exists but cannot be read raises SettingsError: the
program never falls back to the DEMO defaults behind the user's back, and the
window never overwrites it.

Secrets (.env: TG_API_ID / TG_API_HASH / FXTRENDO_USERNAME / FXTRENDO_PASSWORD,
and the *.session file) are copied as files, never read into settings.json
and never logged.
"""
from __future__ import annotations

import copy
import datetime as _dt
import io
import json
import os
import re
import shutil
from pathlib import Path
from types import SimpleNamespace
from typing import Optional

from lordxau import CHANNEL
from lordxau.engine import ULTRA_SOURCE, EngineConfig

ROOT = Path(__file__).resolve().parents[1]
SETTINGS = ROOT / "settings.json"
OLD_NAMES = ("telegram_signal_trader",)
ULTRA_RISK_PCT = 3.5                 # min lot on a ~10-point ULTRA stop needs 3 x 3.5 % on ~105 $

# broker keys this program always sets itself (the @lordxau scalp needs them)
_FORCED_FX = {
    "virtual_limits": True,          # a zone waits in memory, sent at market in the zone
    "zone_chase_frac": 0.2,          # replayed: 0 / 0.5 / 1.0 all worse
    "virtual_limit_ttl_sec": 900,    # a scalp zone older than 15 min is over
    "max_open_positions": 1,
    "close_only_bot_orders": True,   # never touches a manual trade
    "require_stop_loss": True,
    "act_on_level_updates": True,
}

# Trendo's order protocol (docs/CONNECT_FXTRENDO.md; the old program's config.yaml
# overrides it when imported): without it no order could be sent at all.
_ORDER = {"event": "order_add", "modify_event": "order_edit", "ack_wait_sec": 4.0,
          "side_map": {"BUY": 0, "SELL": 1},
          "fields": {"symbol": "symbol", "side": "type", "volume": "size", "price": "open", "sl": "sl", "tp": "tp"}}

# Telegram fast poll (fast_poll_sec, fast_poll_max_wait_sec): @lordxau is asked every
# ~1.5 s. 2.0.0-2.0.3 asked every ~5.1 s (3 s / 5 s): the live journal 09-25..10-01 had
# a median delay of 5.7 s, about half of it that wait. Settings saved with exactly those
# old defaults are moved to the new ones (_upgrade_poll); the poller falls back to
# 5 s by itself on a Telegram flood (fastpoll.SAFE_MAX_WAIT).
FAST_POLL = (1.0, 1.5)
_OLD_FAST_POLL = (3.0, 5.0)

DEFAULTS = {
    "version": 1,
    "fxtrendo": {"enabled": True, "dry_run": False, "use_real_wallet": False, "max_lot": 0.10,
                 "default_lot": 0.01, "allow_sl_widening": True, "order": _ORDER, **_FORCED_FX},
    "risk": {"sizing": "risk_pct", "risk_pct": 2.0, "min_lot": 0.01, "lot_step": 0.01,
             "max_daily_loss": 8.0, "max_trades_per_day": 0},
    "telegram": {"session_name": "signal_trader", "fast_poll_sec": FAST_POLL[0],
                 "fast_poll_max_wait_sec": FAST_POLL[1]},
    "auto_breakeven_points": 1.5,     # executor: stop to the fill once 1.5 points in profit
    "ultra_auto_breakeven_points": 0.0,
    # executor: a scalp (no TP of its own) gets a take profit this many points from
    # its fill; 0 = off. Replayed 2026-09-08..29 on Trendo prices: trades that reach
    # +3 mostly came back to the auto-breakeven before the leader's late "ببند".
    "take_profit_points": 2.75,
    "engine": {},                     # EngineConfig overrides (see lordxau/engine.py)
    # Gated LLM assistant (lordxau/llm_reader.py + llm_gate.py). OFF by default: the regex parser alone is the
    # proven 2.0.6 behaviour (~99.7% on numeric zones, 0 phantom trades). When on, the LLM is consulted ONLY on a
    # message the regex read as NOISE while a trade is OPEN, and may only CLOSE / risk-free / re-enter it -- never
    # open or invent a trade. Keys live in `env_file` (next to start.bat), NEVER in settings.json.
    "llm": {"enabled": False, "provider": None, "timeout_sec": 4.0, "env_file": ".env.llm"},
    # Live dashboard (lordxau/dashboard.py): a local web page (127.0.0.1 only) that shows each message -> what the
    # bot understood -> the order on the broker. Nothing leaves the machine. The window opens it with a button.
    "dashboard": {"enabled": True, "host": "127.0.0.1", "port": 8799, "open_browser": False},
    "auto_start": True,               # the window starts trading by itself
    "imported_from": None,
    "wallet_source": None,            # "user" once the account was chosen in the window
}
_SECTIONS = ("fxtrendo", "risk", "telegram", "engine", "llm", "dashboard")


class SettingsError(Exception):
    """settings.json exists but cannot be used - never replaced by defaults."""


def _user_desktops() -> list:
    """THIS Windows user's Desktop folder(s) - the real one (it can be moved,
    e.g. into OneDrive) and the classic home\\Desktop. Never another user's."""
    out = []
    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes

            class GUID(ctypes.Structure):
                _fields_ = [("a", wintypes.DWORD), ("b", wintypes.WORD), ("c", wintypes.WORD),
                            ("d", ctypes.c_ubyte * 8)]
            # FOLDERID_Desktop {B4BFCC3A-DB2C-424C-B029-7FE99A87C641}
            fid = GUID(0xB4BFCC3A, 0xDB2C, 0x424C, (ctypes.c_ubyte * 8)(0xB0, 0x29, 0x7F, 0xE9, 0x9A, 0x87, 0xC6, 0x41))
            p = ctypes.c_wchar_p()
            if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(fid), 0, None, ctypes.byref(p)) == 0:
                out.append(Path(p.value))
                ctypes.windll.ole32.CoTaskMemFree(p)
        except Exception:  # noqa: BLE001
            pass
    out.append(Path.home() / "Desktop")
    return out


def _desktop_candidates() -> list:
    """<this user's Desktop>\\telegram_signal_trader."""
    return [d / n for d in _user_desktops() for n in OLD_NAMES]


def old_program_candidates(root: Path = ROOT) -> list:
    """Where the previous program may be, nearest first: every folder above
    this one (Windows "Extract All" adds a folder: ...\\telegram_signal_trader\\
    lordxau_trader_2.0.0\\lordxau_trader) and a telegram_signal_trader next to
    each of them, then the Desktop's telegram_signal_trader."""
    out: list = []
    try:
        ups = list(root.resolve().parents)[:4]
    except OSError:
        ups = list(root.parents)[:4]
    for up in ups:
        out.append(up)
        out += [up / n for n in OLD_NAMES]
    out += _desktop_candidates()
    seen, uniq = set(), []
    for c in out:
        k = str(c).lower()
        if k not in seen:
            seen.add(k)
            uniq.append(c)
    return uniq


def _is_old_program(c: Path, root: Path) -> bool:
    try:
        return ((c / "config.yaml").is_file() and (c / "signal_trader").is_dir()
                and ((c / "gui.py").is_file() or (c / "run.py").is_file())
                and c.resolve() != root.resolve() and not (c / "lordxau").is_dir())
    except OSError:
        return False


def find_old_program(root: Path = ROOT) -> Optional[Path]:
    """The previous program's folder (telegram_signal_trader: config.yaml +
    signal_trader/ + gui.py or run.py), see old_program_candidates."""
    for c in old_program_candidates(root):
        if _is_old_program(c, root):
            return c
    return None


def _scalar(v: str):
    v = v.split(" #", 1)[0].strip()
    if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
        return v[1:-1]
    low = v.lower()
    if low in ("true", "yes", "on"):
        return True
    if low in ("false", "no", "off"):
        return False
    if low in ("", "null", "none", "~"):
        return None
    for cast in (int, float):
        try:
            return cast(v)
        except ValueError:
            pass
    return v


def _read_yaml_plain(text: str) -> dict:
    """Minimal reader for config.yaml when PyYAML is missing / fails: nested
    "key: value" maps by indentation (lists and flow values are skipped)."""
    out: dict = {}
    stack = [(-1, out)]
    for raw in text.splitlines():
        if not raw.strip() or raw.lstrip().startswith(("#", "-")):
            continue
        ind = len(raw) - len(raw.lstrip(" "))
        line = raw.strip()
        if ":" not in line:
            continue
        k, _, v = line.partition(":")
        k = k.strip().strip("\"'")
        while stack and ind <= stack[-1][0]:
            stack.pop()
        cur = stack[-1][1] if stack else out
        if not v.strip() or v.strip().startswith("#"):
            cur[k] = {}
            stack.append((ind, cur[k]))
        elif not v.strip().startswith(("[", "{", "|", ">", "&", "*")):
            cur[k] = _scalar(v)
    return out


class OldConfigError(Exception):
    """The previous program's config.yaml cannot be read - nothing is imported."""


def _read_yaml(path: Path) -> Optional[dict]:
    """config.yaml -> dict; None when it cannot be read. PyYAML (the old
    program's own reader); the plain reader only when PyYAML is not installed
    - a file PyYAML refuses is unreadable, never guessed."""
    try:
        text = path.read_text(encoding="utf-8-sig")
    except (OSError, UnicodeDecodeError):
        return None
    try:
        import yaml
    except ImportError:
        try:
            return _read_yaml_plain(text)
        except Exception:  # noqa: BLE001
            return None
    try:
        data = yaml.safe_load(text)
    except Exception:  # noqa: BLE001
        return None
    if data is None:
        return {}
    return data if isinstance(data, dict) else None


def _deep_merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def from_old(old: Path, notes: Optional[list] = None) -> dict:
    """Settings built from the old program's config.yaml (reads only).
    OldConfigError when it cannot be read. ``notes`` gets warnings."""
    cfg = _read_yaml(old / "config.yaml")
    if cfg is None:
        raise OldConfigError(f"config.yaml برنامهٔ قبلی ({old}) خوانده نشد")
    s = copy.deepcopy(DEFAULTS)
    fx = cfg.get("fxtrendo")
    if isinstance(fx, dict) and fx:
        s["fxtrendo"] = _deep_merge(s["fxtrendo"], fx)
        # the old program's mode decides whether orders were really sent
        if str(cfg.get("mode", "")).lower() != "fxtrendo":
            s["fxtrendo"]["enabled"] = False
    f = s["fxtrendo"]
    # REAL only for an explicit boolean true (the old program's own reading); anything else is DEMO
    raw = f.get("use_real_wallet")
    f["use_real_wallet"] = raw is True
    if raw not in (True, False, None) and notes is not None:
        notes.append(f"use_real_wallet در config.yaml مقدار نامعتبر {raw!r} دارد — دمو در نظر گرفته شد")
    wid = f.get("wallet_id")
    if isinstance(wid, bool) or not (isinstance(wid, int) or (isinstance(wid, str) and wid.strip().isdigit())):
        f["wallet_id"] = None
    if not isinstance(f.get("order"), dict) or not f["order"].get("event"):
        f["order"] = copy.deepcopy(_ORDER)
    s["fxtrendo"].update(_FORCED_FX)
    if isinstance(cfg.get("risk"), dict):
        s["risk"] = _deep_merge(s["risk"], cfg["risk"])
    tg = cfg.get("telegram") if isinstance(cfg.get("telegram"), dict) else {}
    if tg.get("session_name"):
        s["telegram"]["session_name"] = str(tg["session_name"])
    for k in ("fast_poll_sec", "fast_poll_max_wait_sec"):
        if cfg.get(k) is not None:
            s["telegram"][k] = cfg[k]
    s["imported_from"] = str(old)
    return _upgrade_poll(s)


def _upgrade_poll(s: dict) -> dict:
    """The 2.0.0-2.0.3 fast-poll defaults (3 s / 5 s) -> FAST_POLL; other values stay."""
    tg = s.get("telegram")
    if not isinstance(tg, dict):
        return s
    try:
        cur = (float(tg.get("fast_poll_sec")), float(tg.get("fast_poll_max_wait_sec")))
    except (TypeError, ValueError):
        return s
    if cur == _OLD_FAST_POLL:
        tg["fast_poll_sec"], tg["fast_poll_max_wait_sec"] = FAST_POLL
    return s


def copy_old_files(old: Path, s: dict, root: Path = ROOT) -> list:
    """Copy .env and the Telegram session (never overwriting a file here)."""
    copied = []
    for name in (".env", str(s["telegram"]["session_name"]) + ".session"):
        src, dst = old / name, root / name
        if src.is_file() and not dst.exists():
            shutil.copy2(src, dst)
            copied.append(name)
    return copied


def _own_owner(ow) -> bool:
    return (isinstance(ow, list) and ow and str(ow[0] or "").lstrip("@").lower() in (CHANNEL, ULTRA_SOURCE))


def merge_old_orders(old: Path, root: Path = ROOT) -> int:
    """Union the previous program's @lordxau order ids into data/bot_orders.json
    (other channels' orders are never taken). -> how many were added."""
    src, dst = old / "data" / "bot_orders.json", root / "data" / "bot_orders.json"
    try:
        with io.open(src, encoding="utf-8") as fh:
            od = json.load(fh)
    except (OSError, ValueError):
        return 0
    if not isinstance(od, dict) or not isinstance(od.get("orders"), dict):
        return 0
    try:
        with io.open(dst, encoding="utf-8") as fh:
            nd = json.load(fh)
    except (OSError, ValueError):
        nd = {}
    if not isinstance(nd, dict):
        nd = {}
    orders = nd.get("orders") if isinstance(nd.get("orders"), dict) else {}
    owners = nd.get("owners") if isinstance(nd.get("owners"), dict) else {}
    o_owners = od.get("owners") if isinstance(od.get("owners"), dict) else {}
    n = 0
    for k, ts in od["orders"].items():
        ow = o_owners.get(str(k))
        if not _own_owner(ow) or str(k) in orders:
            continue
        orders[str(k)] = ts
        owners[str(k)] = ow
        n += 1
    if n:
        dst.parent.mkdir(parents=True, exist_ok=True)
        tmp = dst.with_suffix(".json.tmp")
        with io.open(tmp, "w", encoding="utf-8") as fh:
            json.dump({"orders": orders, "owners": owners}, fh, sort_keys=True)
        tmp.replace(dst)
    return n


def merge_daily_state(old: Path, root: Path = ROOT, today: Optional[str] = None) -> bool:
    """Carry today's daily-loss baseline (and trade count) of the previous
    program into daily_state.json here. Same wallet -> the HIGHER start balance
    (the loss is start - now: a later baseline taken after losses is lower and
    would forget them; a withdrawal at worst blocks the rest of the day).
    -> True when something changed."""
    today = today or _dt.datetime.now().strftime("%Y-%m-%d")      # DailyGuard's own day

    def rd(p: Path) -> dict:
        try:
            with io.open(p, encoding="utf-8") as fh:
                d = json.load(fh)
            return d if isinstance(d, dict) and d.get("day") == today else {}
        except (OSError, ValueError):
            return {}

    o, n = rd(old / "daily_state.json"), rd(root / "daily_state.json")
    if not o:
        return False
    if not n:
        out = o
    else:
        out = dict(n)
        base = {str(k): float(v) for k, v in (n.get("other_baselines") or {}).items() if v is not None}
        for k, v in (o.get("other_baselines") or {}).items():
            if v is not None:
                base[str(k)] = max(float(v), base.get(str(k), float(v)))
        ow, osb = o.get("wallet"), o.get("start_balance")
        if osb is not None and ow is not None:
            base[str(ow)] = max(float(osb), base.get(str(ow), float(osb)))
        nw = n.get("wallet")
        if nw is not None and str(nw) in base:        # the new program's own wallet: into start_balance
            nsb = n.get("start_balance")
            v = base.pop(str(nw))
            out["start_balance"] = max(v, float(nsb)) if nsb is not None else v
        out["other_baselines"] = base
        out["trades"] = max(int(o.get("trades") or 0), int(n.get("trades") or 0))
    if out == n:
        return False
    p = root / "daily_state.json"
    tmp = p.with_suffix(".json.tmp")
    with io.open(tmp, "w", encoding="utf-8") as fh:
        json.dump(out, fh)
    tmp.replace(p)
    return True


def read_file(path: Path) -> dict:
    """settings.json -> full settings (DEFAULTS merged in). SettingsError when
    it cannot be read or has the wrong shape."""
    try:
        with io.open(path, encoding="utf-8-sig") as fh:
            data = json.load(fh)
    except (OSError, ValueError) as exc:
        raise SettingsError(f"{path.name}: {exc}") from exc
    if not isinstance(data, dict):
        raise SettingsError(f"{path.name}: not a JSON object")
    for k in _SECTIONS:
        if k in data and not isinstance(data[k], dict):
            raise SettingsError(f"{path.name}: \"{k}\" must be an object")
    s = _deep_merge(DEFAULTS, data)
    s["fxtrendo"].update(_FORCED_FX)
    return _upgrade_poll(s)


def _adopt_old(s: dict, old: Path, keep_wallet: bool = False, notes: Optional[list] = None) -> dict:
    """``s`` with the previous program's account (wallet), broker protocol, risk
    and Telegram session; the window's own options (engine, auto start,
    breakeven) stay. ``keep_wallet``: the account the user chose in the window
    stays too. OldConfigError when its config.yaml cannot be read."""
    imp = from_old(old, notes)
    out = copy.deepcopy(s)
    fx0 = dict(s.get("fxtrendo") or {})
    for k in ("fxtrendo", "risk", "telegram", "imported_from"):
        out[k] = imp[k]
    if keep_wallet:
        out["fxtrendo"]["use_real_wallet"] = bool(fx0.get("use_real_wallet"))
        out["fxtrendo"]["wallet_id"] = fx0.get("wallet_id")
    else:
        out["wallet_source"] = "old_program"
    return out


def wallet_source(s: dict) -> str:
    """"user" (chosen in the window), "old_program" (imported) or "default" (DEMO)."""
    return str(s.get("wallet_source") or ("old_program" if s.get("imported_from") else "default"))


def _kind(s: dict) -> str:
    return "REAL" if s["fxtrendo"].get("use_real_wallet") else "DEMO"


def load(root: Path = ROOT, log=print, do_import: bool = True) -> dict:
    """The settings. Without settings.json: built from the previous program
    (do_import: its files copied and settings.json written - only the runner,
    after the previous program was checked; else read-only). A settings.json
    made while the previous program was not found takes its account, broker
    protocol and risk as soon as it is found (a wallet the user chose in the
    window is kept)."""
    path = root / "settings.json"
    if path.is_file():
        s = read_file(path)
        if not s.get("imported_from"):
            old = find_old_program(root)
            if old is not None:
                notes: list = []
                try:
                    s2 = _adopt_old(s, old, keep_wallet=wallet_source(s) == "user", notes=notes)
                except OldConfigError as exc:
                    if do_import:
                        log(f"⚠️ {exc} — حساب از آن برداشته نشد")
                    return s
                if do_import:
                    copied = copy_old_files(old, s2, root)
                    save(s2, root)
                    for n in notes:
                        log("⚠️ " + n)
                    log(f"تنظیمات حساب از برنامهٔ قبلی برداشته شد ({old}) — کیف‌پول {_kind(s2)}"
                        + (" (انتخاب شما نگه داشته شد)" if wallet_source(s2) == "user" else "")
                        + (f"؛ کپی شد: {', '.join(copied)}" if copied else ""))
                s = s2
        return s
    old = find_old_program(root)
    notes = []
    s = None
    if old is not None:
        try:
            s = from_old(old, notes)
            s["wallet_source"] = "old_program"
        except OldConfigError as exc:
            if do_import:
                log(f"⚠️ {exc} — تنظیمات پیش‌فرض (کیف‌پول دمو)")
            old = None
    if not do_import:
        return s if s is not None else copy.deepcopy(DEFAULTS)
    if s is None:
        s = copy.deepcopy(DEFAULTS)
        log("برنامهٔ قبلی پیدا نشد — تنظیمات پیش‌فرض (کیف‌پول دمو)")
    else:
        copied = copy_old_files(old, s, root)
        for n in notes:
            log("⚠️ " + n)
        log(f"تنظیمات از برنامهٔ قبلی برداشته شد ({old}) — کیف‌پول {_kind(s)}"
            + (f"؛ کپی شد: {', '.join(copied)}" if copied else ""))
    save(s, root)
    return s


def set_wallet(root: Path, is_real: bool, wallet_id=None) -> dict:
    """The user chose the account in the window: saved to settings.json (a
    corrupt file raises SettingsError and is never overwritten). Built on the
    previous program's settings when they were never imported, so its broker
    protocol / risk / session are not lost by the choice."""
    path = root / "settings.json"
    s = read_file(path) if path.is_file() else copy.deepcopy(DEFAULTS)
    if not s.get("imported_from"):
        old = find_old_program(root)
        if old is not None:
            try:
                s = _adopt_old(s, old)
            except OldConfigError:
                pass
    fx = s["fxtrendo"]
    if wallet_id in (None, "") and bool(fx.get("use_real_wallet")) == bool(is_real):
        wallet_id = fx.get("wallet_id")       # "REAL" / "DEMO" of the kind already set keeps its wallet
    fx["use_real_wallet"] = bool(is_real)
    fx["wallet_id"] = wallet_id
    s["wallet_source"] = "user"
    save(s, root)
    return s


def sync_from_old(root: Path = ROOT, log=print, s: Optional[dict] = None) -> None:
    """Every Start (previous program not running): a missing .env / Telegram
    session is copied, its @lordxau order ids and today's daily-loss baseline
    are merged in. Never raises."""
    old = find_old_program(root)
    if old is None:
        return
    try:
        copied = copy_old_files(old, s if s is not None else from_old(old), root)
        if copied:
            log(f"از برنامهٔ قبلی کپی شد: {', '.join(copied)}")
    except Exception as exc:  # noqa: BLE001
        log(f"⚠️ کپی فایل‌های برنامهٔ قبلی ناموفق: {exc!r}")
    try:
        n = merge_old_orders(old, root)
        if n:
            log(f"♻️ {n} سفارش @{CHANNEL} از برنامهٔ قبلی به فهرست سفارش‌های ربات اضافه شد")
    except Exception as exc:  # noqa: BLE001
        log(f"⚠️ فهرست سفارش‌های برنامهٔ قبلی خوانده نشد: {exc!r}")
    try:
        if merge_daily_state(old, root):
            log("♻️ حد ضرر روزانهٔ امروز از برنامهٔ قبلی ادامه پیدا کرد")
    except Exception as exc:  # noqa: BLE001
        log(f"⚠️ وضعیت روزانهٔ برنامهٔ قبلی خوانده نشد: {exc!r}")


def save(s: dict, root: Path = ROOT) -> None:
    path = root / "settings.json"
    tmp = path.with_suffix(".json.tmp")
    with io.open(tmp, "w", encoding="utf-8") as fh:
        json.dump(s, fh, ensure_ascii=False, indent=2)
    tmp.replace(path)


def engine_config(s: dict) -> EngineConfig:
    return EngineConfig.from_dict(s.get("engine") or {})


def llm_config(s: dict) -> dict:
    return dict(s.get("llm") or {})


def dashboard_config(s: dict) -> dict:
    d = dict(DEFAULTS["dashboard"])
    d.update(s.get("dashboard") or {})
    return d


def _llm_env(cfg: dict, root: Path) -> tuple:
    """Return ({KEY_ENV: value} for every provider, [provider names that have a key]). A key is taken from the
    env_file (default .env.llm, next to start.bat) first, then the process environment. Never read from or
    written to settings.json, never logged."""
    from lordxau.llm_reader import DEFAULT_PROVIDERS, load_env
    file_env = load_env(root / str(cfg.get("env_file") or ".env.llm"))
    env, have = {}, []
    for p in DEFAULT_PROVIDERS:
        v = (file_env.get(p.key_env) or os.getenv(p.key_env, "") or "").strip()
        env[p.key_env] = v
        if v:
            have.append(p.name)
    return env, have


LLM_PROVIDERS = (("gemini", "GEMINI_API_KEY", "Google Gemini (پیشنهادی، سریع)"),
                 ("openrouter", "OPENROUTER_API_KEY", "OpenRouter"),
                 ("zhipu", "ZHIPU_API_KEY", "Zhipu GLM"),
                 ("groq", "GROQ_API_KEY", "Groq"))
_PROVIDER_ENV = {name: env for name, env, _ in LLM_PROVIDERS}


def set_llm_key(provider: str, key: str, root: Path = ROOT, env_file: str = ".env.llm") -> None:
    """Write/replace ONE provider's key in env_file (next to start.bat). Other keys are kept; the value is never
    logged or returned. An empty key removes that provider's line. The window calls this so the user never edits
    the file by hand. Keys never go in settings.json."""
    env_name = _PROVIDER_ENV.get(provider)
    if not env_name:
        raise ValueError(f"unknown provider {provider!r}")
    path = root / env_file
    out, found = [], False
    if path.is_file():
        for raw in path.read_text(encoding="utf-8-sig", errors="replace").splitlines():
            m = re.match(r"\s*([A-Za-z0-9_]+)\s*=", raw)
            if m and m.group(1) == env_name:
                found = True
                if key:
                    out.append(f"{env_name}={key}")          # else: drop the line (removal)
            else:
                out.append(raw)
    if key and not found:
        out.append(f"{env_name}={key}")
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text("\n".join(out).rstrip("\n") + "\n", encoding="utf-8")
    tmp.replace(path)


def probe_llm_key(provider: str, root: Path = ROOT, env_file: str = ".env.llm", text: str = "ببند",
                  key: Optional[str] = None) -> tuple:
    """User-initiated «test key»: build a reader for JUST this provider and classify a tiny phrase. ``key``
    (optional) tests a value typed in the window before it is saved; else the one in env_file is used.
    Returns (ok: bool, short_fa_message). Makes ONE network call; never returns or logs the key."""
    from lordxau.llm_reader import DEFAULT_PROVIDERS, LLMReader, load_env
    env_name = _PROVIDER_ENV.get(provider)
    pc = [p for p in DEFAULT_PROVIDERS if p.name == provider]
    if not env_name or not pc:
        return (False, "ارائه‌دهندهٔ نامعتبر")
    key = (key or load_env(root / env_file).get(env_name) or os.getenv(env_name, "") or "").strip()
    if not key:
        return (False, "برای این ارائه‌دهنده کلیدی ذخیره نشده")
    errs: list = []
    reader = LLMReader(providers=pc, env={env_name: key}, timeout=12.0, max_total=12.0,
                       log=lambda m: errs.append(str(m)))
    try:
        r = reader.classify(text)
    except Exception as exc:  # noqa: BLE001
        return (False, f"خطا: {type(exc).__name__}")
    if r.source:
        return (True, f"اتصال موفق ({r.latency:.1f}s)")
    return (False, "پاسخ نگرفت — کلید/شبکه را بررسی کنید" + (f" ({errs[-1]})" if errs else ""))


def llm_available_providers(s: dict, root: Path = ROOT) -> list:
    """Names of the LLM providers that currently have a key (from env_file or the environment). [] when none.
    For the window to tell the user whether turning the assistant on will actually do anything."""
    try:
        _, have = _llm_env(llm_config(s), root)
        return have
    except Exception:  # noqa: BLE001
        return []


def build_llm_reader(s: dict, root: Path = ROOT, log=print):
    """Build the gated LLM reader when llm.enabled AND at least one provider key exists; else None (the engine
    then stays regex-only). `provider` (optional) forces that provider to be tried first. Returns an object with
    a .classify(text)->Reading method (set engine.llm = reader.classify)."""
    cfg = llm_config(s)
    if not cfg.get("enabled"):
        return None
    from lordxau.llm_reader import DEFAULT_PROVIDERS, LLMReader
    env, have = _llm_env(cfg, root)
    if not have:
        log(f"⚠️ LLM روشن است ولی هیچ کلیدی در {cfg.get('env_file') or '.env.llm'} (یا محیط) نبود — "
            "LLM خاموش ماند و ربات فقط با regex کار می‌کند")
        return None
    providers = list(DEFAULT_PROVIDERS)
    name = cfg.get("provider")
    if name:                               # force one provider to the front of the fallback chain
        providers.sort(key=lambda p: 0 if p.name == name else 1)
    timeout = float(cfg.get("timeout_sec") or 4.0)
    # max_total == timeout: the engine consults UNDER its lock, so cap the WHOLE fallback chain to one provider's
    # budget -- a slow/hung provider can freeze trading for at most ~timeout seconds, then it falls back to regex.
    reader = LLMReader(providers=providers, env=env, timeout=timeout, max_total=timeout, log=log)
    log(f"🤖 دستیار LLM روشن است (ارائه‌دهنده‌های دارای کلید: {', '.join(have)}) — فقط برای مدیریت "
        "معاملهٔ باز با پیام بدون‌عدد، و هر اقدام از نردهٔ ایمنی رد می‌شود")
    return reader


def effective_risk_pct(s: dict) -> float:
    """risk_pct the executor trades with: the user's value, raised to 3.5 % only
    while ULTRA is on (never written back to settings.json)."""
    pct = float((s.get("risk") or {}).get("risk_pct") or 2.0)
    return max(pct, ULTRA_RISK_PCT) if engine_config(s).trade_ultra else pct


def take_profit_points(s: dict) -> float:
    """The scalp auto take profit in points (0 = off; a negative or broken value = off)."""
    try:
        return max(0.0, float(s.get("take_profit_points") or 0.0))
    except (TypeError, ValueError):
        return 0.0


def _safe_float(v, default: float = 0.0) -> float:
    """float(v) tolerant of a hand-corrupted settings value (read_file only checks section shapes, not numbers)."""
    try:
        return float(v)
    except (TypeError, ValueError):
        return float(default)


def broker_config(s: dict) -> SimpleNamespace:
    """What FxTrendoExecutor / TrendoClient read (config.fxtrendo, .risk,
    .channel_settings, .mode)."""
    rows = {
        CHANNEL: SimpleNamespace(auto_breakeven_points=_safe_float(s.get("auto_breakeven_points"), 0.0),
                                 take_profit_points=take_profit_points(s),
                                 lot_multiplier=1.0),
        ULTRA_SOURCE: SimpleNamespace(auto_breakeven_points=_safe_float(s.get("ultra_auto_breakeven_points"), 0.0),
                                      take_profit_points=0.0, lot_multiplier=1.0),
    }
    risk = copy.deepcopy(s["risk"])
    risk["risk_pct"] = effective_risk_pct(s)
    return SimpleNamespace(mode="fxtrendo", fxtrendo=copy.deepcopy(s["fxtrendo"]),
                           risk=risk, channel_settings=rows)
