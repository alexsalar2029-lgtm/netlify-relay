# -*- coding: utf-8 -*-
"""Safety gate between the LLM reader and the engine ("gated assistant").

The LLM is consulted ONLY on messages the regex could not read (kind NOISE). Even then it may NOT open or invent a
trade -- opening stays regex-only on a written numeric zone. The LLM may only MANAGE a trade that already exists:
close it, move its stop to entry (risk-free), or re-enter the same side the leader just traded -- and only when the
message is genuinely a tone instruction, never a price print or an outcome report. These rules exist because a live
test on 2026-10-03 showed a raw LLM reads "Xau:4186" / "رو 4189" (price prints) as entry zones and "فری خورد" /
"استاپ خورد" (outcome reports) as live orders; the gate makes those impossible.
"""
import re
from dataclasses import dataclass
from typing import Optional

from lordxau.parse import norm

MIN_CONF = 0.6
MANAGE = ("close", "risk_free", "reenter")          # the only actions the LLM is ever allowed to cause
OPENING = ("zone", "stop", "market_now", "hint")    # the LLM is never allowed to cause these

# a bare price print or an outcome report: never a tone instruction, whatever the LLM says
_PRICE_PRINT = re.compile(r"^\s*(?:x[a-z]{1,3}\s*[:：]?\s*)?(?:رو\s*)?\d{3,5}(?:[.,]\d+)?\s*[.!✅⭕️🔺🔻]*\s*$", re.I)
# NOTE: [\s‌]* allows the zero-width non-joiner (نیم‌فاصله) that "تی‌پی" is usually typed with -- plain \s does
# not match U+200C, so without it an outcome report of a take-profit hit would slip past this guard.
_OUTCOME = re.compile(r"(?:استاپ|stop|فری|سیو|تی[\s‌]*پی|tp|هدف|تارگت)[\s‌]*\S{0,6}[\s‌]*"
                      r"(?:خورد|زد|شد|رفت|تاچ|hit)|خورد[\s‌]*(?:استاپ|فری)")
_CONDITION = re.compile(
    r"(?<!\w)(?:اگر|اگه|اکر|هر\s*(?:جا|وقت|زمان|موقع)|وقتی|زمانی\s*که|در\s*صورتی\s*که)(?!\w)")


def _unsupported_management(text: str) -> str:
    """Unknown numeric/conditional instructions need deterministic semantics.

    The tone reader cannot represent a requested level or a future trigger.
    Dropping either would turn 'at 4182' into an immediate action. Apply this
    check before consulting a provider AND at the action boundary.
    """
    if any(c.isnumeric() for c in str(text or "")):
        return "پیام مدیریت عددی فقط با خوانش صریح پردازش می‌شود؛ LLM نمی‌تواند سطح را حذف کند"
    if _CONDITION.search(norm(text)):
        return "دستور شرطی با LLM فوری اجرا نمی‌شود؛ شرط باید صریحاً پشتیبانی شود"
    return ""


def likely_command(text: str) -> bool:
    """Cheap pre-filter (no network): is this NOISE message worth an LLM call at all? A management command is
    SHORT and not a price print / outcome report / ad / link. Cuts quota and keeps the feed clean."""
    t = (text or "").strip()
    if not t or len(t) > 60 or "\n" in t or "http" in t or "@" in t or "www." in t:
        return False
    if _PRICE_PRINT.match(t) or _OUTCOME.search(t):
        return False
    if _unsupported_management(t):
        return False
    return True


@dataclass
class GateContext:
    regex_kind: str                   # the engine's parse().kind for this message
    text: str
    has_open: bool = False            # an open trade exists right now
    open_side: Optional[str] = None   # "BUY" / "SELL" of that open trade
    waiting: bool = False             # a pending (unfilled) limit exists
    recent_side: Optional[str] = None # side of the latest setup/trade (for re-enter)


@dataclass
class GateDecision:
    action: Optional[str] = None      # None = do nothing; else one of MANAGE
    reason: str = ""                  # Persian line for the log / UI


def gate(reading, ctx: GateContext) -> GateDecision:
    """reading: an llm_reader.Reading. Returns the single allowed action, or none with a reason."""
    # 1) the LLM is only a fallback: if the regex already understood the message, the regex wins.
    if ctx.regex_kind not in ("NOISE",):
        return GateDecision(None, "")
    if reading is None or reading.source == "":
        return GateDecision(None, "")
    k = reading.kind
    # 2) the LLM may never open or invent a trade.
    if k in OPENING:
        return GateDecision(None, f"LLM «{k}» نادیده گرفته شد — باز کردن معامله فقط با ناحیهٔ عددی")
    if k not in MANAGE:
        return GateDecision(None, "")                 # result / noise
    # 3) a price print or an outcome report is never a tone order, whatever the LLM guessed.
    if _PRICE_PRINT.match(ctx.text) or _OUTCOME.search(ctx.text):
        return GateDecision(None, "LLM روی اعلام‌قیمت/گزارش‌نتیجه نادیده گرفته شد")
    unsupported = _unsupported_management(ctx.text)
    if unsupported:
        return GateDecision(None, unsupported)
    # 4) confidence floor.
    if reading.confidence < MIN_CONF:
        return GateDecision(None, f"LLM «{k}» با اطمینان پایین ({reading.confidence:.2f}) نادیده گرفته شد")
    # 5) the action must have something to act on.
    why = reading.why or f"{reading.confidence:.2f}"
    if k in ("close", "risk_free"):
        if not ctx.has_open:
            return GateDecision(None, f"LLM «{k}» نادیده گرفته شد — معاملهٔ بازی نیست")
        return GateDecision(k, f"LLM لحن «{k}» را خواند ({why}) — روی معاملهٔ باز اجرا شد")
    if k == "reenter":
        if not (ctx.has_open or ctx.recent_side):
            return GateDecision(None, "LLM «reenter» نادیده گرفته شد — معاملهٔ اخیری نیست")
        return GateDecision("reenter", f"LLM لحن «ورود مجدد» را خواند ({why}) — روی سمت اخیر اجرا شد")
    return GateDecision(None, "")
