"""Trendo / FxTrendo platform client — REST login + Socket.IO trading.

Reverse-engineered from real HAR captures. Architecture:

  * LOGIN (REST):  POST https://api.trendofx.com/api/v1/user/login  (form body)
      -> token.token (JWT), user.id, wallets[] {id, token, is_real, balance, ...}
  * REALTIME (Socket.IO / Engine.IO v4, WSS :8443) at *.apitrendo.com:8443
      auth = CONNECT packet {user_id, user_token=JWT, wallet_id, wallet_token, +device}
      server -> login_client {isLogin, wallet_id}
             -> send_message {event:"all_orders_wallet", wallet_data, orders[]}
             -> send_message {event:"order_change", id, token, symbol, size, open, sl, tp,
                              profit, close_time_current, primary_order, ...}
  * LIVE PRICES: emit user_join {room:"item_price_<sym>"} -> item_price_<sym>
  * OPEN ORDER:  emit user_emit {event:"order_add", symbol, type(0=buy,1=sell),
                 open(entry|0=market), size(lots), sl, tp, primary_order, +envelope}
  * CLOSE ORDER: emit user_emit {event:"order_close", id, token, size, +envelope}
  * MODIFY SL/TP (captured 2026-09-15, demo, xauusd — tests/fixtures/
    trendo_order_edit_2026-09-15.json): emit user_emit {event:"order_edit", id,
    token (the order's own token from its order_change), symbol, type (0/1),
    size (lots), open (fill price), tp, sl (0 = none), primary_order, +envelope}.
    The event name comes from fxtrendo.order.modify_event (see modify_order).
  * ACKS: success = send_message {event:"order_change", primary_order: <ours>, ...};
    FAILURE = send_message WITHOUT "event": {primary_order: <ours>,
    status: {error:<int>, msg:"<text>", message_mode, statusDialog, title}, wallet_id}.
    Observed: 2 "Stop loss level is out of the allowed range",
    1 "Take profit level is out of the allowed range", 1001 "لطفاً دوباره وارد شوید"
    (session expired -> needs_relogin). Every emit (order_add / order_edit /
    order_close) is correlated by primary_order and signalled through a
    threading.Event so callers can wait for the verdict.
  * SYMBOL PROPS: symbol_list_give -> chart_propertis.data[] {name, digits,
    stop_level, tick_size, contract_size, trade_mode}. stop_level (xauusd: 0.1
    price units) is the minimum SL/TP distance from the CURRENT quote: BUY sl <=
    bid - stop_level, tp >= ask + stop_level; SELL sl >= ask + stop_level,
    tp <= bid - stop_level (broker rejected sl 4276.61 at bid 4276.65, accepted
    it at bid 4276.93). modify_order() pre-checks this locally when a live
    quote is known.
  * mode_close in a closing order_change: 2 seen for an SL hit, 1 for a TP hit
    — INFERRED from one capture only, unverified; manual closes not compared.
  * PENDING-ORDER CANCEL / LIMIT->MARKET conversion: not captured — never invented.

SAFETY: defaults to the DEMO wallet. Never sends unless dry_run=False.
"""
from __future__ import annotations

import json
import logging
import os
import random
import threading
import time
from typing import Any, Callable, Optional

try:
    import socketio  # python-socketio[client]
except Exception:  # pragma: no cover
    socketio = None

try:
    from curl_cffi import requests as curl_requests
except Exception:  # pragma: no cover
    curl_requests = None

from signal_trader.models import OrderType, Signal

log = logging.getLogger("signal_trader.trendo")

_DEVICE = {
    "os": "web", "build_number": "5093", "version_name": "5.0.93",
    "package_name": "trendo", "market": "web", "device": "web_chrome", "lang": "en",
    "device_id": "web_pybot_0001",
}
_DEVICE_KEYS = ("os", "build_number", "version_name", "package_name", "market",
                "device_id", "device", "lang")
_SECRET_KEYS = ("wallet_token", "user_token", "token", "password")


class BrokerDisconnected(RuntimeError):
    """The Socket.IO link is down: nothing was sent. The owner reconnects
    (login + connect) and may retry the action once - no duplicate is possible
    because the payload never left this process."""


def _redact(payload: dict) -> dict:
    """Copy with trading credentials masked, for logging / returning."""
    return {k: ("***" if k in _SECRET_KEYS and v else v) for k, v in payload.items()}


def _num(v, default: float = 0.0) -> float:
    """Broker numbers arrive as strings ("0", "4276.34"); None/'' -> default."""
    try:
        if v is None or v == "":
            return default
        return float(v)
    except (TypeError, ValueError):
        return default


def _round_price(v: float, digits) -> float:
    try:
        return round(float(v), int(digits)) if digits is not None else float(v)
    except (TypeError, ValueError):
        return float(v)


_PROP_KEYS = ("digits", "stop_level", "tick_size", "contract_size", "trade_mode")


def parse_symbol_props(data) -> dict[str, dict]:
    """symbol_list_give payload -> {broker_symbol: {digits, stop_level, ...}}.

    Tolerant: ``chart_propertis.data`` may be a list of rows or a dict keyed by
    symbol; rows name the symbol as ``name``/``symbol``. Numbers are converted
    (digits -> int, the rest -> float); unknown keys are ignored."""
    out: dict[str, dict] = {}
    if isinstance(data, list):
        # REAL shape (captured 2026-09-15): a list of per-symbol rows, each
        # {name, data{props}, chart_propertis{Ask, Bid, data{props}}, Candle...}
        items: list = []
        for row in data:
            if not isinstance(row, dict):
                continue
            cp = row.get("chart_propertis") or row.get("chart_properties") or {}
            inner = cp.get("data") if isinstance(cp, dict) else None
            if not isinstance(inner, dict):
                inner = row.get("data") if isinstance(row.get("data"), dict) else row
            merged = dict(inner)
            merged.setdefault("name", row.get("name") or row.get("symbol"))
            items.append(merged)
    elif isinstance(data, dict):
        cp = data.get("chart_propertis")
        if cp is None:
            cp = data.get("chart_properties", data)
        rows = cp.get("data", cp) if isinstance(cp, dict) else cp
        if isinstance(rows, dict):
            items = [({"name": k, **v} if isinstance(v, dict) and "name" not in v else v)
                     for k, v in rows.items()]
        elif isinstance(rows, list):
            items = rows
        else:
            return out
    else:
        return out
    for row in items:
        if not isinstance(row, dict):
            continue
        name = row.get("name") or row.get("symbol")
        if not name:
            continue
        props: dict[str, Any] = {}
        for k in _PROP_KEYS:
            if k not in row or row[k] in (None, ""):
                continue
            try:
                props[k] = int(row[k]) if k == "digits" else float(row[k])
            except (TypeError, ValueError):
                props[k] = row[k]
        out[str(name).lower()] = props
    return out


def stop_level_reject(order_type, sl: float, tp: float, quote, stop_level) -> str:
    """'' when ``sl``/``tp`` (0 = none) respect the broker's minimum distance
    from the live ``quote`` (bid, ask); otherwise the reason. BUY (type 0):
    sl <= bid - stop_level and tp >= ask + stop_level; SELL mirrored."""
    if quote is None or stop_level is None or order_type is None:
        return ""
    try:
        bid, ask, lvl = float(quote[0]), float(quote[1]), float(stop_level)
        t = int(order_type)
    except (TypeError, ValueError, IndexError):
        return ""
    eps = 1e-9
    if t == 0:                                   # BUY
        if sl and sl > bid - lvl + eps:
            return f"sl {sl:g} closer than stop_level {lvl:g} to bid {bid:g} (max {bid - lvl:g})"
        if tp and tp < ask + lvl - eps:
            return f"tp {tp:g} closer than stop_level {lvl:g} to ask {ask:g} (min {ask + lvl:g})"
    elif t == 1:                                 # SELL
        if sl and sl < ask + lvl - eps:
            return f"sl {sl:g} closer than stop_level {lvl:g} to ask {ask:g} (min {ask + lvl:g})"
        if tp and tp > bid - lvl + eps:
            return f"tp {tp:g} closer than stop_level {lvl:g} to bid {bid:g} (max {bid - lvl:g})"
    return ""


class TrendoClient:
    def __init__(self, config: Any):
        ft = getattr(config, "fxtrendo", {}) or {}
        self.ft = ft
        lg = ft.get("login", {}) or {}
        self.login_url = lg.get("url", "https://api.trendofx.com/api/v1/user/login")
        self.token_path = lg.get("token_path", "token.token")
        self.socket_url = (ft.get("socket", {}) or {}).get("url", "https://en.apitrendo.com:8443")
        self.use_real = bool(ft.get("use_real_wallet", False))
        self.wallet_id_cfg = ft.get("wallet_id")          # explicit wallet id (same kind only)
        # Persian note when a configured wallet_id was ignored (S1), else None.
        self.wallet_warning: Optional[str] = None
        self.impersonate = ft.get("impersonate", "chrome124")
        self.device = {**_DEVICE, **(ft.get("device", {}) or {})}
        self.username = os.getenv("FXTRENDO_USERNAME")
        self.password = os.getenv("FXTRENDO_PASSWORD")

        self.user_id: Optional[int] = None
        self.user_token: Optional[str] = None
        self.wallets: list[dict] = []
        self.wallet: Optional[dict] = None
        self.wallet_data: dict = {}
        self.balance: Optional[str] = None
        self.sio = None
        self.connected = False
        self._prices: dict[str, tuple] = {}
        self._price_ts: dict[str, float] = {}     # broker symbol -> time of the last tick
        # Price rooms to keep joined on EVERY socket (a reconnect loses the
        # server-side rooms; they are re-joined from the connect handler).
        self._wanted: set[str] = set()
        self.link_down_since: Optional[float] = None
        self.on_link_event: Optional[Callable[[str], None]] = None   # "down" | "up"
        # Optional callback (symbol, bid, ask) invoked on every live quote (the
        # GUI / performance ledger). Extra listeners with the same signature
        # can be attached with add_price_listener() (e.g. the executor's
        # virtual-breakeven guard) without displacing on_price.
        self.on_price = None
        self._price_listeners: list = []
        self._listeners_lock = threading.Lock()
        self._subscribed: set[str] = set()
        self._ready = threading.Event()
        self._orders_ready = threading.Event()   # set once the open-orders snapshot arrived
        self.open_orders: dict[int, dict] = {}
        # Emitted records keyed by primary_order, each {payload(redacted), t0,
        # done: threading.Event, result, +confirmed|error/msg}. _placed also
        # keeps the Signal (order_add); _edits = order_edit; _closes = order_close.
        self._placed: dict[int, dict] = {}
        self._edits: dict[int, dict] = {}
        self._closes: dict[int, dict] = {}
        self._ack_lock = threading.Lock()        # guards the three dicts (never held while waiting)
        self.my_order_ids: set[int] = set()      # orders THIS bot opened (confirmed)
        # remember_orders: my_order_ids kept on disk across a restart (opt-in).
        self._mine_path: Optional[str] = None
        self._mine_at: dict[int, float] = {}
        self._mine_lock = threading.Lock()
        self._mine_dirty = False
        # bot order id -> [channel key, canonical symbol] of the signal that
        # opened it: after a restart a fill / late ack the engine never saved
        # still belongs to its channel (R6-1 / RS-2).
        self._mine_owner: dict[int, list] = {}
        self.on_order_event: Optional[Callable[[dict], None]] = None
        # bot orders seen OPEN (order book / order_change): one missing from a
        # later all_orders_wallet book closed while the socket was down - its
        # closing order_change never came -> on_orders_vanished([ids])
        self._open_bot_seen: set = set()
        self._seen_lock = threading.Lock()
        self.on_orders_vanished: Optional[Callable[[list], None]] = None
        # broker symbol -> {digits, stop_level, tick_size, contract_size, trade_mode}
        self.symbol_props: dict[str, dict] = {}
        # Set by a status ack with error 1001 ("لطفاً دوباره وارد شوید"): the
        # session expired; the owner must login()+connect() again. Never
        # auto-reconnected in a loop.
        self.needs_relogin = False
        # Thread-local flag: True while a Socket.IO callback of this client is
        # running. An emit issued from inside a callback must not wait for its
        # ack (the ack is delivered by the same machinery).
        self._tls = threading.local()

    # -- REST login -----------------------------------------------------------
    def login(self) -> dict:
        if curl_requests is None:
            raise RuntimeError("curl_cffi لازم است: pip install curl_cffi")
        if not (self.username and self.password):
            raise RuntimeError("FXTRENDO_USERNAME و FXTRENDO_PASSWORD را در .env بگذارید.")
        body = {
            "email": self.username, "password": self.password,
            "device_id": self.device["device_id"], "device": self.device["device"],
            "versionName": self.device["version_name"], "buildNumber": self.device["build_number"],
            "lang": self.device["lang"], "os": self.device["os"], "theme": "true",
            "packageName": self.device["package_name"],
        }
        r = curl_requests.post(self.login_url, data=body, impersonate=self.impersonate)
        r.raise_for_status()
        d = r.json()
        cur: Any = d
        for part in self.token_path.split("."):
            cur = cur.get(part) if isinstance(cur, dict) else None
        self.user_token = cur
        self.user_id = (d.get("user") or {}).get("id")
        self.wallets = d.get("wallets") or []
        self.wallet = self._choose_wallet()
        if not self.user_token:
            raise RuntimeError(f"توکن پیدا نشد (token_path={self.token_path}).")
        if self.wallet is None:
            raise RuntimeError("هیچ کیف‌پولی در پاسخ لاگین نبود.")
        self.needs_relogin = False               # a fresh session: the 1001 flag is stale now
        log.info("login OK: user=%s wallet=%s [%s] balance=%s %s",
                 self.user_id, self.wallet.get("id"), self.wallet_kind(),
                 self.wallet.get("balance"), self.wallet.get("currency"))
        return d

    def _choose_wallet(self) -> Optional[dict]:
        """The wallet to trade on. use_real_wallet decides the KIND; a
        configured wallet_id only picks among wallets of that kind (server
        2026-09-23: the GUI saved a REAL wallet_id while use_real_wallet=false
        and every order died on the send assert). A configured wallet of the
        other kind is ignored with a warning (DEMO) or refused (REAL) — REAL
        is never chosen unless use_real_wallet is true."""
        active = [w for w in self.wallets if not w.get("is_archive")]
        self.wallet_warning = None
        if self.wallet_id_cfg is not None:
            for w in active:
                if str(w.get("id")) != str(self.wallet_id_cfg):
                    continue
                if bool(w.get("is_real")) == self.use_real:
                    return w
                if self.use_real:
                    raise RuntimeError(
                        f"کیف‌پول پیکربندی‌شده {self.wallet_id_cfg} دمو است ولی use_real_wallet=true — "
                        "برای ایمنی کیف‌پول دیگری انتخاب نمی‌شود؛ wallet_id را اصلاح کنید.")
                self.wallet_warning = (
                    f"کیف‌پول پیکربندی‌شده {self.wallet_id_cfg} واقعی (REAL) است ولی use_real_wallet=false — "
                    "نادیده گرفته شد و کیف‌پول دمو انتخاب شد. در داشبورد کیف‌پول DEMO را انتخاب کنید "
                    "(یا wallet_id را در config.yaml خالی کنید).")
                log.warning("configured wallet %s is REAL but use_real_wallet=false -> ignored, DEMO pool",
                            self.wallet_id_cfg)
                break
            else:
                raise RuntimeError(f"کیف‌پول پیکربندی‌شده {self.wallet_id_cfg} پیدا نشد.")
        # Only wallets whose is_real matches the setting. NEVER silently fall
        # back to another wallet — that could put orders on the REAL account.
        pool = [w for w in active if bool(w.get("is_real")) == self.use_real]
        if not pool:
            kind = "واقعی" if self.use_real else "دمو"
            raise RuntimeError(f"هیچ کیف‌پول {kind} پیدا نشد؛ برای ایمنی معامله نمی‌کنم.")
        return pool[0]

    def wallet_kind(self, w: Optional[dict] = None) -> str:
        w = w or self.wallet or {}
        return "REAL" if w.get("is_real") else "DEMO"

    def select_wallet(self, wallet_id) -> dict:
        """Switch the active wallet (reconnects the socket if connected). A
        wallet whose real/demo kind differs from use_real_wallet is refused
        (ValueError) — the active wallet never becomes REAL by a click (S1)."""
        for w in self.wallets:
            if str(w.get("id")) == str(wallet_id):
                if bool(w.get("is_real")) != self.use_real:
                    if self.use_real:
                        raise ValueError(f"کیف‌پول {wallet_id} دمو است ولی use_real_wallet=true — انتخاب نشد.")
                    raise ValueError(f"کیف‌پول {wallet_id} واقعی (REAL) است ولی use_real_wallet=false — "
                                     "انتخاب نشد؛ برای ایمنی فقط کیف‌پول DEMO قابل انتخاب است.")
                self.wallet = w
                self.wallet_id_cfg = wallet_id
                if self.connected:
                    self.disconnect()
                    self.connect()
                return w
        raise ValueError(f"wallet {wallet_id} not found")

    # -- Socket.IO ------------------------------------------------------------
    def connect(self, timeout: float = 15.0):
        if socketio is None:
            raise RuntimeError('python-socketio لازم است: pip install "python-socketio[client]"')
        if self.wallet is None:
            self.login()
        self._drop_socket()            # never leave an old socket auto-reconnecting behind
        self._ready.clear()
        self._orders_ready.clear()
        self.open_orders = {}
        self._subscribed = set()       # a new socket needs its rooms joined again
        self.sio = socketio.Client(reconnection=True, logger=False, engineio_logger=False)
        sio = self.sio

        @self.sio.event
        def connect():  # noqa: ANN001 - fires on the first connect AND on every auto-reconnect
            if self.sio is sio:
                self._on_socket_up()

        @self.sio.on("login_client")
        def _login_client(data):  # noqa: ANN001
            if self.sio is not sio:            # a retired socket never sets _ready
                return
            ok = data.get("isLogin") if isinstance(data, dict) else data
            log.info("login_client: isLogin=%s wallet_id=%s", ok,
                     data.get("wallet_id") if isinstance(data, dict) else "?")
            self._ready.set()

        @self.sio.on("send_message")
        def _send_message(data):  # noqa: ANN001
            if self.sio is sio:                # a retired socket's order book is stale
                self._on_send_message(data)

        @self.sio.on("symbol_list_give")
        def _symbol_list(data):  # noqa: ANN001
            if self.sio is sio:
                self._on_symbol_list(data)

        @self.sio.event
        def disconnect():  # noqa: ANN001
            if self.sio is sio:
                self._on_socket_down()

        auth = {
            "user_id": self.user_id, "user_token": self.user_token,
            "wallet_id": self.wallet["id"], "wallet_token": self.wallet["token"],
            **{k: self.device[k] for k in _DEVICE_KEYS},
        }
        self.sio.connect(self.socket_url, auth=auth, transports=["websocket"],
                         socketio_path="socket.io", wait_timeout=10)
        if not self._ready.wait(timeout=timeout):
            raise RuntimeError("login_client not received — socket auth failed or timed out")
        # Wait (briefly) for the open-orders snapshot so position limits see reality.
        if not self._orders_ready.wait(timeout=5.0):
            log.warning("open-orders snapshot not received yet; position count may be stale")
        self.connected = True
        self.link_down_since = None
        self._join_rooms(self._wanted)          # no-op for rooms the connect handler joined
        return self

    # -- link state -----------------------------------------------------------
    def is_alive(self) -> bool:
        """True only while the socket is REALLY connected (``connected`` alone
        stays True after a silent drop)."""
        if not self.connected or self.sio is None:
            return False
        return bool(getattr(self.sio, "connected", True))

    def _link_event(self, kind: str) -> None:
        cb = self.on_link_event
        if cb is not None:
            try:
                cb(kind)
            except Exception:  # pragma: no cover - never break the socket thread
                log.debug("on_link_event sink failed", exc_info=True)

    def _on_socket_up(self) -> None:
        was_down = self.link_down_since is not None
        self.link_down_since = None
        self._subscribed = set()                # server-side rooms died with the old link
        self._join_rooms(self._wanted)
        if was_down:
            log.warning("socket reconnected - %d price rooms re-joined", len(self._wanted))
            self._link_event("up")

    def _on_socket_down(self) -> None:
        if self.link_down_since is None:
            self.link_down_since = time.time()
        self._subscribed = set()
        log.warning("socket disconnected (auto-reconnect enabled)")
        self._link_event("down")

    def _drop_socket(self) -> None:
        """Retire the current socket for good. After a transport drop its
        auto-reconnect loop is running and ``disconnect()`` does not stop it
        (NET-1: hidden extra sessions on the same account); ``shutdown()``
        aborts that loop."""
        old, self.sio = self.sio, None
        self.connected = False
        if old is None:
            return
        try:
            old.reconnection = False             # no new reconnect loop for it
        except Exception:
            pass
        try:
            old.shutdown()
        except AttributeError:                   # python-socketio without shutdown()
            try:
                old.disconnect()
            except Exception:
                pass
        except Exception:
            pass
        try:
            if getattr(old, "connected", False):  # a reconnect that won the race
                old.disconnect()
        except Exception:
            pass

    def _join_rooms(self, symbols) -> None:
        for s in list(symbols):
            s = str(s).lower()
            if s in self._subscribed or self.sio is None:
                continue
            if not getattr(self.sio, "connected", True):
                continue
            try:
                self.sio.on(f"item_price_{s}", self._price_handler(s))
                self.sio.emit("user_join", {"join": "join", "room": f"item_price_{s}", **self.device})
                self._subscribed.add(s)
            except Exception as exc:
                log.warning("joining price room %s failed: %s", s, exc)

    def rejoin_prices(self, symbols=None) -> None:
        """Force a fresh join of the price rooms (stale feed on a live socket)."""
        targets = {str(x).lower() for x in (symbols or self._wanted)}
        self._wanted |= targets
        self._subscribed -= targets
        self._join_rooms(targets)

    def price_age(self, symbol: str) -> Optional[float]:
        """Seconds since the last tick of ``symbol`` (None = never seen)."""
        t = self._price_ts.get(str(symbol).lower())
        return None if t is None else max(0.0, time.time() - t)

    def _emit_user(self, payload: dict) -> None:
        """Emit user_emit, or raise BrokerDisconnected when the link is down
        (nothing is sent in that case)."""
        if self.sio is None or not getattr(self.sio, "connected", True):
            self.connected = False
            raise BrokerDisconnected("socket is not connected")
        try:
            self.sio.emit("user_emit", payload)
        except Exception as exc:
            base = getattr(getattr(socketio, "exceptions", None), "SocketIOError", None)
            if (base is not None and isinstance(exc, base)) or not getattr(self.sio, "connected", True):
                self.connected = False
                raise BrokerDisconnected(f"socket emit failed: {exc!r}") from exc
            raise

    def _ensure_socket(self) -> None:
        if not self.is_alive():
            self.connect()

    def pending_count(self, max_age: float = 60.0) -> int:
        """Orders we emitted that the server has neither confirmed nor rejected
        yet (recent only)."""
        now = time.time()
        with self._ack_lock:
            return sum(1 for p in self._placed.values()
                       if "confirmed" not in p and "error" not in p
                       and now - p.get("t0", 0) < max_age)

    # -- symbol properties ----------------------------------------------------
    def _on_symbol_list(self, data) -> None:
        props = parse_symbol_props(data)
        if props:
            self.symbol_props.update(props)
            log.info("symbol_list_give: %d symbols (stop_level xauusd=%s)", len(props),
                     self.symbol_props.get("xauusd", {}).get("stop_level"))

    def props_for(self, broker_symbol: Optional[str]) -> dict:
        """{digits, stop_level, tick_size, contract_size, trade_mode} of a broker
        symbol ({} when symbol_list_give has not delivered it)."""
        return dict(self.symbol_props.get(str(broker_symbol or "").lower(), {}))

    # -- ack correlation ------------------------------------------------------
    def _new_record(self, store: dict, po: int, payload: dict, **extra) -> dict:
        rec = {"payload": _redact(payload), "t0": time.time(),
               "done": threading.Event(), "result": None, **extra}
        with self._ack_lock:
            store[po] = rec
        return rec

    def _find_record(self, po) -> Optional[dict]:
        with self._ack_lock:
            for store in (self._placed, self._edits, self._closes):
                if po in store:
                    return store[po]
        return None

    def _on_status_ack(self, data: dict) -> None:
        """A send_message WITHOUT "event": the broker rejected one of our emits.
        {primary_order, status: {error, msg, ...}, wallet_id}."""
        st = data.get("status") or {}
        if not isinstance(st, dict):
            st = {"msg": str(st)}
        err, msg = st.get("error"), st.get("msg") or st.get("message") or ""
        po = data.get("primary_order")
        rec = self._find_record(po)
        kind = "?"
        if rec is not None:
            kind = str((rec.get("payload") or {}).get("event") or "order_add")
            rec["error"], rec["msg"] = err, msg
            rec["result"] = {"error": err, "msg": msg}
            rec["t_ack"] = time.time()
            rec["done"].set()
        if err == 1001:
            self.needs_relogin = True
            log.warning("⚠️ بروکر: نشست منقضی شده (error 1001 «%s») — لاگین دوباره لازم است؛ "
                        "تا آن زمان سفارش‌ها/ویرایش‌ها رد می‌شوند.", msg)
        log.warning("broker rejected %s (primary_order=%s): error=%s msg=%s", kind, po, err, msg)

    def _on_send_message(self, data):
        if not isinstance(data, dict):
            return
        self._tls.in_callback = True
        try:
            self._handle_send_message(data)
        finally:
            self._tls.in_callback = False

    def _handle_send_message(self, data: dict) -> None:
        ev = data.get("event")
        if ev is None:
            if "status" in data or "primary_order" in data:
                self._on_status_ack(data)
            return
        if ev == "symbol_list_give":
            self._on_symbol_list(data)
        elif ev == "all_orders_wallet":
            wd = data.get("wallet_data") or {}
            self.wallet_data, self.balance = wd, wd.get("balance")
            orders = data.get("orders") or []
            self.open_orders = {int(o["id"]): o for o in orders
                                if isinstance(o, dict) and o.get("id") is not None}
            now_ids, mine = set(self.open_orders), set(self.my_order_ids)
            with self._seen_lock:
                gone = sorted(i for i in self._open_bot_seen if i not in now_ids)
                self._open_bot_seen = {i for i in now_ids if i in mine}
            self._orders_ready.set()
            log.info("wallet: balance=%s %s open_orders=%d",
                     wd.get("balance"), wd.get("currency"), len(self.open_orders))
            if gone and self.on_orders_vanished:
                try:
                    self.on_orders_vanished(gone)
                except Exception:  # pragma: no cover - a report sink must never break the feed
                    pass
        elif ev == "order_change":
            oid = data.get("id")
            if oid is None:
                return
            if self._mine_dirty:
                self._save_mine()
            closed = data.get("close_time_current") not in (0, None, "0", "")
            if closed:
                self.open_orders.pop(int(oid), None)
            else:
                self.open_orders[int(oid)] = data
            wd = data.get("wallet_data")
            if isinstance(wd, dict):
                self.wallet_data, self.balance = wd, wd.get("balance")
            po = data.get("primary_order")
            rec = self._find_record(po) if po not in (None, 0, "0") else None
            if rec is not None:
                rec["confirmed"] = data
                rec["t_confirm"] = time.time()
                rec["result"] = {"order_id": int(oid), "sl": _num(data.get("sl")),
                                 "tp": _num(data.get("tp")), "closed": closed}
                if "signal" in rec:                      # an order_add echo
                    s = rec.get("signal")
                    self._add_mine(int(oid), getattr(s, "source", None), getattr(s, "symbol", None),
                                   po)
                rec["done"].set()
            try:
                with self._seen_lock:
                    if closed:
                        self._open_bot_seen.discard(int(oid))
                    elif int(oid) in self.my_order_ids:
                        self._open_bot_seen.add(int(oid))
            except (TypeError, ValueError):
                pass
            log.info("order_change: id=%s %s %s open=%s profit=%s %s",
                     oid, data.get("symbol"), "closed" if closed else "open",
                     data.get("open"), data.get("profit"), "")
            if self.on_order_event:
                try:
                    self.on_order_event(data)
                except Exception:  # pragma: no cover
                    pass

    # -- live prices ----------------------------------------------------------
    def add_price_listener(self, fn: Callable[[str, Any, Any], None]) -> None:
        """Attach an extra (broker_symbol, bid, ask) callback. Called on the
        Socket.IO thread; the listener must be quick and thread-safe."""
        with self._listeners_lock:
            if fn not in self._price_listeners:
                self._price_listeners.append(fn)

    def remove_price_listener(self, fn: Callable[[str, Any, Any], None]) -> None:
        with self._listeners_lock:
            if fn in self._price_listeners:
                self._price_listeners.remove(fn)

    def _dispatch_price(self, symbol: str, bid, ask) -> None:
        """Fan a quote out to on_price and every extra listener (each isolated,
        so one failing callback cannot starve the others)."""
        self._prices[symbol] = (bid, ask)
        self._price_ts[symbol] = time.time()
        with self._listeners_lock:
            targets = ([self.on_price] if self.on_price is not None else []) + list(self._price_listeners)
        self._tls.in_callback = True
        try:
            for cb in targets:
                try:
                    cb(symbol, bid, ask)
                except Exception:  # pragma: no cover - never break the socket thread
                    log.debug("price listener failed", exc_info=True)
        finally:
            self._tls.in_callback = False

    def _in_callback(self) -> bool:
        return bool(getattr(self._tls, "in_callback", False))

    def _ack_wait(self, wait_sec: Optional[float]) -> float:
        """Seconds to wait for an ack: the argument, else
        fxtrendo.order.ack_wait_sec (default 4.0; 0 = do not wait). Always 0
        inside a Socket.IO callback (the ack would arrive on this very path)."""
        if self._in_callback():
            return 0.0
        if wait_sec is None:
            od = self.ft.get("order", {}) or {}
            try:
                wait_sec = float(od.get("ack_wait_sec", 4.0))
            except (TypeError, ValueError):
                wait_sec = 4.0
        return max(0.0, float(wait_sec))

    @staticmethod
    def _wait_ack(rec: dict, wait_sec: float) -> str:
        """Block (without any lock) until the record is acked or the timeout
        passes -> 'rejected' | 'confirmed' | 'timeout'."""
        if wait_sec > 0:
            rec["done"].wait(wait_sec)
        if "error" in rec:
            return "rejected"
        if "confirmed" in rec:
            return "confirmed"
        return "timeout"

    def _price_handler(self, sym: str):
        def handler(data):  # noqa: ANN001
            try:
                row = data[0] if isinstance(data, list) else data
                name = str(row.get("name") or sym).lower()
                self._dispatch_price(name, row.get("Bid"), row.get("Ask"))
            except Exception:
                pass
        return handler

    def subscribe_prices(self, symbols):
        """Join the price room of each symbol (idempotent per socket). The
        symbols are remembered and re-joined on every later (re)connect."""
        wanted = {str(s).lower() for s in symbols}
        self._wanted |= wanted
        self._join_rooms(wanted)

    def price(self, symbol: str):
        return self._prices.get(symbol.lower())

    def disconnect(self):
        try:
            if self.sio is not None:
                self.sio.disconnect()
        except Exception:
            pass
        self.connected = False

    # -- orders ---------------------------------------------------------------
    def _lot(self, signal: Signal) -> float:
        return max(0.0, min(float(self.ft.get("default_lot", 0.01)),
                            float(self.ft.get("max_lot", 0.10))))

    def _envelope(self) -> dict[str, Any]:
        return {
            "user_id": self.user_id,
            "wallet_token": self.wallet["token"] if self.wallet else None,
            "wallet_id": self.wallet["id"] if self.wallet else None,
            **{k: self.device[k] for k in _DEVICE_KEYS},
        }

    def broker_symbol(self, symbol: Optional[str]) -> str:
        return (self.ft.get("symbol_map", {}) or {}).get(symbol, (symbol or "").lower())

    def build_order_fields(self, signal: Signal, lot: Optional[float] = None,
                           tp: Optional[float] = None) -> dict[str, Any]:
        """Map a Signal to order_add fields (no envelope). Offline-safe.
        ``lot`` / ``tp`` override the default volume / first take-profit.

        type: 0=buy, 1=sell. open: entry price for a pending order, 0 = market.
        size: lots. sl/tp: absolute prices, 0 = none.
        """
        od = self.ft.get("order", {}) or {}
        fields = od.get("fields", {}) or {}
        side_map = od.get("side_map", {"BUY": 0, "SELL": 1})
        out: dict[str, Any] = {}

        def put(key, value):
            name = fields.get(key)
            if name is not None and value is not None:
                out[name] = value

        put("symbol", self.broker_symbol(signal.symbol))
        side_val = signal.side.value if signal.side else None
        put("side", side_map.get(side_val) if side_val else None)
        put("volume", self._lot(signal) if lot is None else lot)
        if signal.order_type != OrderType.MARKET and signal.entry is not None:
            put("price", signal.entry)
        else:
            put("price", 0)
        put("sl", signal.stop_loss if signal.stop_loss is not None else 0)
        if tp is not None:
            put("tp", tp)
        else:
            put("tp", signal.take_profits[0] if signal.take_profits else 0)
        return out

    def place_order(self, signal: Signal, dry_run: bool = True,
                    lot: Optional[float] = None, tp: Optional[float] = None,
                    wait_sec: Optional[float] = None,
                    guard: Optional[Callable[[], bool]] = None) -> dict[str, Any]:
        """Emit order_add. Live path waits up to ``wait_sec`` (default
        fxtrendo.order.ack_wait_sec, 4.0; 0 = today's fire-and-forget) for the
        broker's verdict -> action "placed" (+order_id) | "rejected" (+error,
        reason) | "emitted" (no ack yet). ``guard`` (optional): checked right
        before the emit - after the socket's own reconnect, which can take
        seconds; True -> nothing is sent, action "cancelled_guard" (R9-1)."""
        od = self.ft.get("order", {}) or {}
        event = od.get("event")
        order_fields = self.build_order_fields(signal, lot=lot, tp=tp)
        if not event:
            if dry_run:
                return {"action": "dry_run_no_event", "order_fields": order_fields}
            raise NotImplementedError("fxtrendo.order.event تنظیم نشده است.")
        po = random.randint(1, 999_999_999)
        payload = {"event": event, **self._envelope(), **order_fields, "primary_order": po}
        safe = _redact(payload)
        if dry_run:
            log.warning("[DRY-RUN] user_emit -> %s", safe)
            return {"action": "dry_run", "payload": safe}
        self._ensure_socket()
        if guard is not None and guard():
            return {"action": "cancelled_guard", "primary_order": po}
        # Final guard: the active wallet's real/demo flag MUST match the setting.
        assert bool(self.wallet.get("is_real")) == self.use_real, \
            "wallet is_real does not match use_real_wallet — refusing to send"
        rec = self._new_record(self._placed, po, payload, signal=signal)
        try:
            self._emit_user(payload)
        except BrokerDisconnected:
            with self._ack_lock:
                self._placed.pop(po, None)      # never sent: not a pending order
            raise
        log.info("order emitted: %s", safe)
        out = {"action": "emitted", "payload": safe, "primary_order": po}
        verdict = self._wait_ack(rec, self._ack_wait(wait_sec))
        if verdict == "rejected":
            log.warning("order_add rejected by broker: error=%s %s", rec.get("error"), rec.get("msg"))
            return {**out, "action": "rejected", "error": rec.get("error"),
                    "reason": str(rec.get("msg") or "")}
        if verdict == "confirmed":
            return {**out, "action": "placed", "order_id": rec["result"]["order_id"]}
        return out

    def orders_for(self, symbol: Optional[str] = None) -> list[dict]:
        sym = self.broker_symbol(symbol) if symbol else None
        return [o for o in self.open_orders.values()
                if not sym or str(o.get("symbol", "")).lower() == sym]

    # -- restart memory of the bot's own orders --------------------------------
    # close_only_bot_orders (default on) acts only on my_order_ids, which lived
    # in memory: after a restart (every server update) a channel's "ببند" /
    # breakeven / new stop found no bot order and the positions opened before
    # it were left to their broker SL/TP alone.
    MINE_KEEP_SEC = 7 * 86400.0

    def remember_orders(self, path: str) -> int:
        """Keep my_order_ids in ``path`` (JSON under data/) and restore the ids
        saved there: those at most MINE_KEEP_SEC old, and older ones still open
        (all of them while the order book has not arrived yet - pruned once it
        has). Opt-in: only the GUI / CLI call it - tests never write it.
        Returns how many ids were added."""
        data: Any = {}
        try:
            with open(path, encoding="utf-8") as fh:
                data = json.load(fh)
        except FileNotFoundError:
            data = {}
        except Exception as exc:
            log.warning("order memory %s unreadable: %s", path, exc)
            data = {}
        saved = data.get("orders") if isinstance(data, dict) else None
        owners = data.get("owners") if isinstance(data, dict) else None
        owners = owners if isinstance(owners, dict) else {}
        now = time.time()
        ready, open_now = self._mine_book()
        n = 0
        with self._mine_lock:
            self._mine_path = path
            for k, ts in (saved.items() if isinstance(saved, dict) else ()):
                try:
                    oid, ts = int(k), float(ts)
                except (TypeError, ValueError):
                    continue
                if now - ts > self.MINE_KEEP_SEC and ready and oid not in open_now:
                    continue
                self._mine_at.setdefault(oid, ts)
                ow = owners.get(str(k))
                if (isinstance(ow, list) and len(ow) in (2, 3) and oid not in self._mine_owner
                        and all(isinstance(x, (str, int)) or x is None for x in ow)):
                    self._mine_owner[oid] = (list(ow) + [None])[:3]
                if oid not in self.my_order_ids:
                    self.my_order_ids.add(oid)
                    n += 1
            for oid in list(self.my_order_ids):
                self._mine_at.setdefault(int(oid), now)
        if ready:                              # restored bot orders open right now
            with self._seen_lock:
                self._open_bot_seen |= {i for i in open_now if i in self.my_order_ids}
        self._save_mine()
        return n

    def _mine_book(self) -> tuple[bool, set]:
        """(order book loaded?, the open order ids)."""
        ready = getattr(self, "_orders_ready", None)
        ok = ready is not None and callable(getattr(ready, "is_set", None)) and ready.is_set()
        open_now: set = set()
        for k in list(getattr(self, "open_orders", {}) or {}):
            try:
                open_now.add(int(k))
            except (TypeError, ValueError):
                continue
        return ok, open_now

    def _add_mine(self, oid: int, owner: Optional[str] = None, symbol: Optional[str] = None,
                  po: Any = None) -> None:
        try:
            po = int(po) if po not in (None, "", 0, "0") else None
        except (TypeError, ValueError):
            po = None
        with self._mine_lock:
            if owner is not None or symbol is not None:
                # [channel, symbol, primary_order]: po maps an engine 'p<po>' leg
                # saved before its ack to this order after a restart (RS7-6)
                self._mine_owner.setdefault(oid, [owner, symbol, po])
            self._mine_at.setdefault(oid, time.time())
        # published last: whoever sees the new id also sees its owner (R8-5)
        self.my_order_ids.add(oid)
        if self._mine_path:
            self._save_mine()

    def bot_orders_of(self) -> dict:
        """{channel: {symbol: [bot order ids]}} of the bot's own orders whose
        opening channel is known (restored ones included)."""
        out: dict = {}
        with self._mine_lock:
            items = list(self._mine_owner.items())
        mine = set(self.my_order_ids)
        for oid, ow in items:
            ch, sym = ow[0], ow[1]
            if oid in mine and ch is not None and sym:
                out.setdefault(ch, {}).setdefault(sym, []).append(oid)
        return out

    def bot_orders_detail(self) -> list:
        """[(order id, channel, symbol, primary_order, time recorded)] of the bot's
        own orders whose opening channel is known."""
        with self._mine_lock:
            items = [(oid, list(ow), self._mine_at.get(oid)) for oid, ow in self._mine_owner.items()]
        mine = set(self.my_order_ids)
        return [(oid, ow[0], ow[1], ow[2] if len(ow) > 2 else None, at)
                for oid, ow, at in items if oid in mine and ow[0] is not None and ow[1]]

    def bot_order_symbol(self, oid: int) -> Optional[str]:
        with self._mine_lock:
            ow = self._mine_owner.get(oid)
        return ow[1] if ow else None

    def _save_mine(self) -> None:
        path = self._mine_path
        if not path:
            return
        try:
            now = time.time()
            ready, open_now = self._mine_book()
            with self._mine_lock:
                keep = {str(k): v for k, v in self._mine_at.items()
                        if now - v <= self.MINE_KEEP_SEC or k in open_now or not ready}
                owners = {str(k): v for k, v in self._mine_owner.items() if str(k) in keep}
                os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
                tmp = path + ".tmp"
                with open(tmp, "w", encoding="utf-8") as fh:
                    json.dump({"orders": keep, "owners": owners}, fh, sort_keys=True)
                # a scanner / backup may hold the file for a moment (Windows)
                for i in range(3):
                    try:
                        os.replace(tmp, path)
                        break
                    except PermissionError:
                        if i == 2:
                            raise
                        time.sleep(0.05 * (i + 1))
            self._mine_dirty = False
        except Exception as exc:
            self._mine_dirty = True           # retried with the next order event
            log.warning("order memory not saved: %s", exc)

    def close_order(self, order_id=None, symbol: Optional[str] = None,
                    fraction: float = 1.0, dry_run: bool = False,
                    only_mine: bool = False, wait_sec: Optional[float] = None) -> dict[str, Any]:
        """Close one order (by id) or the open orders on ``symbol``.

        ``fraction`` < 1 closes part of the size (e.g. 0.5 = half).
        ``only_mine`` restricts a symbol-wide close to orders this bot opened
        (confirmed in this session), so a channel "close" never touches
        positions you opened by hand. Each close waits up to ``wait_sec``
        (default fxtrendo.order.ack_wait_sec) for its ack -> per-order action
        "closed" | "rejected" (+error, reason) | "emitted" (no ack yet).

        An explicit ``order_id`` closes THAT order or nothing: one that is no
        longer open (its SL/TP hit meanwhile) -> no_open_order, never a
        fallback to every order on the symbol (VL-1: that closed manual
        positions and the other trade).
        """
        if order_id is not None:
            try:
                o = self.open_orders.get(int(order_id))
            except (TypeError, ValueError):
                o = None
            if o is None:
                return {"action": "no_open_order", "symbol": symbol, "order_id": order_id}
            targets = [o]
        else:
            targets = self.orders_for(symbol)
            if only_mine:
                targets = [o for o in targets if int(o.get("id", -1)) in self.my_order_ids]
        if not targets:
            return {"action": "no_open_order", "symbol": symbol}
        results = []
        for o in targets:
            size = float(o.get("size") or o.get("open_size") or 0)
            close_size = round(size * fraction, 2) if fraction < 1 else size
            payload = {
                "event": "order_close", "id": o.get("id"), "token": o.get("token"),
                "size": close_size, **self._envelope(), "symbol": o.get("symbol"),
                "primary_order": random.randint(1, 999_999_999),
            }
            if dry_run:
                results.append({"action": "dry_run", "payload": _redact(payload)})
                continue
            self._ensure_socket()
            po = payload["primary_order"]
            rec = self._new_record(self._closes, po, payload)
            try:
                self._emit_user(payload)
            except BrokerDisconnected:
                with self._ack_lock:
                    self._closes.pop(po, None)
                raise
            log.info("close emitted: id=%s size=%s", o.get("id"), close_size)
            res = {"action": "emitted", "order_id": o.get("id"), "size": close_size,
                   "primary_order": po}
            verdict = self._wait_ack(rec, self._ack_wait(wait_sec))
            if verdict == "rejected":
                log.warning("order_close of %s rejected: error=%s %s",
                            o.get("id"), rec.get("error"), rec.get("msg"))
                res.update(action="rejected", error=rec.get("error"),
                           reason=str(rec.get("msg") or ""))
            elif verdict == "confirmed":
                res["action"] = "closed"
            results.append(res)
        return {"action": "close", "results": results}

    def _order_type(self, o: dict):
        """0 = buy / 1 = sell of an open order (from the order itself, else from
        the Signal that placed it)."""
        t = o.get("type")
        if t is not None:
            try:
                return int(t)
            except (TypeError, ValueError):
                pass
        with self._ack_lock:
            placed = self._placed.get(o.get("primary_order"))
        sig = placed.get("signal") if isinstance(placed, dict) else None
        if sig is not None and sig.side is not None:
            side_map = (self.ft.get("order", {}) or {}).get("side_map", {"BUY": 0, "SELL": 1})
            return side_map.get(sig.side.value)
        return None

    def modify_order(self, order_id, sl=None, tp=None, dry_run: bool = False,
                     wait_sec: Optional[float] = 5.0) -> dict[str, Any]:
        """Change SL/TP of an open order via fxtrendo.order.modify_event
        (``order_edit`` as captured 2026-09-15).

        The payload mirrors the capture: id, token, symbol, type, size, open of
        the OPEN order plus the new sl/tp (None keeps the current level; 0 =
        none; rounded to the symbol's digits). When a live quote and the
        symbol's stop_level are known the edit is checked locally first ->
        {"action": "rejected_local", "reason"} without emitting. Otherwise it
        is emitted and the ack awaited up to ``wait_sec`` ->
        {"action": "modified", order_id, sl, tp} | {"action": "rejected",
        error, reason} | {"action": "unconfirmed"}. ``dry_run`` returns the
        redacted payload."""
        ev = (self.ft.get("order", {}) or {}).get("modify_event")
        if not ev:
            raise NotImplementedError(
                "رویداد ویرایش SL/TP تنظیم نشده (fxtrendo.order.modify_event). "
                "مقدار کپچرشده: order_edit (config.yaml)."
            )
        o = self.open_orders.get(int(order_id))
        if not o:
            return {"action": "no_open_order", "order_id": order_id}
        bsym = str(o.get("symbol") or "").lower()
        props = self.props_for(bsym)
        digits = props.get("digits", o.get("digits"))
        sl_v = _num(o.get("sl")) if sl is None else float(sl)
        tp_v = _num(o.get("tp")) if tp is None else float(tp)
        sl_v = _round_price(sl_v, digits) if sl_v else 0
        tp_v = _round_price(tp_v, digits) if tp_v else 0
        otype = self._order_type(o)
        payload = {"event": ev, **self._envelope(),
                   "id": o.get("id"), "token": o.get("token"), "symbol": bsym,
                   "type": otype, "size": _num(o.get("size") or o.get("open_size")),
                   "open": _num(o.get("open")), "tp": tp_v, "sl": sl_v,
                   "primary_order": random.randint(1, 999_999_999)}
        safe = _redact(payload)
        if dry_run:
            return {"action": "dry_run", "payload": safe}
        quote = self.price(bsym)
        age = self.price_age(bsym)
        try:
            max_age = float(self.ft.get("quote_max_age_sec", 30.0))
        except (TypeError, ValueError):
            max_age = 30.0
        if age is not None and max_age > 0 and age > max_age:
            quote = None                          # frozen feed: let the broker decide
        # only the levels this edit CHANGES are pre-checked: a kept take profit
        # near the price must not block a breakeven SL edit - the broker decides
        reason = stop_level_reject(otype, sl_v if sl is not None else 0, tp_v if tp is not None else 0,
                                   quote, props.get("stop_level"))
        if reason:
            log.warning("order_edit of %s not sent: %s", o.get("id"), reason)
            return {"action": "rejected_local", "order_id": o.get("id"), "reason": reason,
                    "sl": sl_v, "tp": tp_v}
        self._ensure_socket()
        # Same guard as place_order: the active wallet's real/demo flag MUST
        # match use_real_wallet — an edit never goes to the REAL account by
        # accident (e.g. after a wallet switch in the GUI).
        if bool((self.wallet or {}).get("is_real")) != self.use_real:
            raise RuntimeError("wallet is_real does not match use_real_wallet — refusing to edit")
        po = payload["primary_order"]
        rec = self._new_record(self._edits, po, payload)
        try:
            self._emit_user(payload)
        except BrokerDisconnected:
            with self._ack_lock:
                self._edits.pop(po, None)
            raise
        log.info("order_edit emitted: %s", safe)
        verdict = self._wait_ack(rec, self._ack_wait(wait_sec))
        if verdict == "rejected":
            return {"action": "rejected", "order_id": o.get("id"), "error": rec.get("error"),
                    "reason": str(rec.get("msg") or ""), "sl": sl_v, "tp": tp_v,
                    "primary_order": po}
        if verdict == "confirmed":
            r = rec["result"]
            return {"action": "modified", "order_id": r["order_id"], "sl": r["sl"], "tp": r["tp"],
                    "primary_order": po}
        return {"action": "unconfirmed", "order_id": o.get("id"), "sl": sl_v, "tp": tp_v,
                "payload": safe, "primary_order": po}
