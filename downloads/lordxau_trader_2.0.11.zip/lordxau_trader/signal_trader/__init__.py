"""Proven broker layer kept from the original program: Trendo client, executor,
risk/daily guard, fast Telegram poll and file log."""

__version__ = "2.0.0"
