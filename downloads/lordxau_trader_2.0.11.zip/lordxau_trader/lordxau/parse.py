# -*- coding: utf-8 -*-
"""Classify one @lordxau message.

Built from every short message of the channel between 2026-09-20 and 09-28
(the server journal + the channel's public web page). The channel posts two
families of trades:

SCALP (the "+80pip" list):  "سل بزن"            -> HINT   SELL
                            "Xau | Sell | Enter:4190/4189"  -> ZONE  SELL [4190, 4189]
                            "Stop:4192"          -> STOP   4192
                            "ریخت" / "Xau:4185"  -> progress (PRICE / NOISE)
                            "فریش کن"            -> BE
                            "ببندش"              -> CLOSE
                            "فری خورد بگیر باز"  -> REENTER
                            "اگه استاپ تاچ کرد بگیر باز" -> IF_SL_REENTER
                            "صبر میگم کجا بگیری" -> WAIT
                            "48هم بود بگیر"      -> EXTEND (the zone's edge moves to ..48)
                            "+80pip"             -> RESULT
ULTRA (student signals, ~10 point stops, reposted for hours as adverts):
                            "Gold buy 4145-4140 TP 4162 TP 4170 SL 4135" -> SIGNAL (ultra)

Everything is normalised first (Persian / Arabic digits and letters, ZWNJ,
case, whitespace). A price is always written with 4 digits; 2-3 digit
shorthand ("استاپ ۳۰۹") is reported as SHORTHAND and never traded.
"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from typing import Optional

_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
_LETTERS = str.maketrans({"ي": "ی", "ى": "ی", "ك": "ک", "ة": "ه", "ۀ": "ه", "أ": "ا", "إ": "ا",
                          "‌": " ", "‏": " ", "‎": " ", " ": " ", "|": " ",
                          "–": "-", "—": "-", "：": ":", "؛": ";", "٫": ".", "٬": ",",
                          "\u200b": " ", "\ufeff": " "})

HINT, ZONE, STOP, SIGNAL, BE, CLOSE, REENTER, MARKET_NOW = (
    "HINT", "ZONE", "STOP", "SIGNAL", "BE", "CLOSE", "REENTER", "MARKET_NOW")
PRICE, RESULT, BE_HIT, SL_HIT, SHORTHAND, IF_BE_REENTER, IF_SL_REENTER, NOISE = (
    "PRICE", "RESULT", "BE_HIT", "SL_HIT", "SHORTHAND", "IF_BE_REENTER", "IF_SL_REENTER", "NOISE")
WAIT, EXTEND = "WAIT", "EXTEND"      # "صبر میگم کجا بگیری" / "48هم بود بگیر" (the zone's edge moved)
ACTIONS = (HINT, ZONE, STOP, SIGNAL, BE, CLOSE, REENTER, MARKET_NOW, EXTEND)


@dataclass
class Parsed:
    kind: str
    side: Optional[str] = None            # "BUY" | "SELL"
    entries: list = field(default_factory=list)
    sl: Optional[float] = None
    tps: list = field(default_factory=list)
    price: Optional[float] = None
    ultra: bool = False
    also: list = field(default_factory=list)   # extra kinds in the same message ("ببند سل بگیر")
    text: str = ""
    alt: list = field(default_factory=list)    # ZONE with a 100-point typo: the other reading
    missed: bool = False                       # MARKET_NOW for a zone not reached ("نرسیدی قیمت مارکت بزن")
    tp_pips: list = field(default_factory=list) # explicit pip distances, not absolute gold prices
    reason: str = ""                           # unreadable numeric signal (never handed to the LLM)

    def has(self, kind: str) -> bool:
        return self.kind == kind or kind in self.also


def norm(text: str) -> str:
    # "می‌گم" / "نمی‌گم": the verb prefix stays joined (ZWNJ is a space elsewhere)
    s = unicodedata.normalize("NFKC", str(text or ""))
    s = re.sub("(?<![^\\s‌])(ن?م[یي])‌", r"\1", s)
    s = s.translate(_DIGITS).translate(_LETTERS).lower()
    # Channel commands often touch an emoji/comma: "🔴سل بگیر", "ریخت،فری کن".
    # Keep price/result operators; decorative symbols are word separators.
    s = "".join(" " if (unicodedata.category(c).startswith("S") and c not in "+-/=")
                or c in "\ufe0e\ufe0f" else c for c in s)
    s = re.sub(r"(?<=[ء-ی])[،,;:]|[،,;:](?=[ء-ی])", " ", s)
    s = re.sub(r"(!)(?=[ء-ی])", r"\1 ", s)
    s = re.sub(r"(?<=\d),(?=\d{3}\b)", "", s)            # 4,322.46 -> 4322.46
    s = re.sub("ب{3,}", "بب", s)                           # "ببببند" -> "ببند"
    s = re.sub("([ء-يپ-ی])\\1{2,}", r"\1", s)   # "فرییییش" -> "فریش"
    s = re.sub("فری{2,}", "فری", s)                         # "فریی کن" -> "فری کن"
    s = re.sub("(?<![ء-ی])ببنذ(?![ء-ی])", "ببند", s)        # "ببنذ" -> "ببند" (the key next to it)
    return re.sub(r"\s+", " ", s).strip()


_P = r"(\d{4}(?:\.\d+)?)"                                   # a full price
_SIDE_EN = r"(buy|sell)"
_SELL_FA = r"(?:سل|فروش)"
_BUY_FA = r"(?:بای|خرید)"
_VERB = r"(?:بزن|بزنید|بزنین|بگیر|بگیرید|بگیرین|بگیرش|کن|کنید)"
_AGAIN = r"(?:باز|دوباره|مجدد|مجددا)"

# the side word of a zone post, with the leader's typos ("Slel", "Sel")
_SIDE_Z = r"(buy|sell|slel|sel|seel|sele|sll|bay|buu|buyy|سل|فروش|بای|خرید)"
# a zone price: 4 digits, at most 2 decimals ("Entet:4113.4112" is two prices, not 4113.4112)
_PZ = r"(\d{4}(?:\.\d{1,2})?)(?!\d)"
# "Enter:4190/4189" and its typos ("Entrt:4143/4142", "Entet", "Ent", "Enter;4081/4082",
# "Enter::4189/4190"); "4267/:4268"; a 5-digit slip in the second level ("4093/49094")
_ZONE = re.compile(r"(?:x[a-z]{1,2}\s*:?\s*)?(?:" + _SIDE_Z + r"\s*:?\s*)?"
                   r"(?:enter|entet|entre|entr|entry|ent|(?<![a-z])en[a-z]{1,4}(?=\s*[:;]+\s*\d{4})"
                   r"|(?<![ء-ی])(?:ناحیه\s*|محدوده\s*|قیمت\s*|نقطه\s*)?ورود|انتری)\s*"
                   r"[:;]*\s*" + _PZ + r"(?:\s*(?:[/:\-_ .]{1,3}|تا|الی|و)\s*(\d{2,5}(?:\.\d{1,2})?)(?!\d))?")
# "Xau:\n\nBuy\n\n4086/4085" - the zone without the word Enter (3 months: 1 post); whole message only
_ZONE_BARE = re.compile(r"x[a-z]{1,2}\s*:?\s*" + _SIDE_EN + r"\s*:?\s*" + _P + r"\s*[/:\-_ ]{1,3}\s*(\d{2,4}(?:\.\d+)?)")
# "Stop:4192", "Stop;4578", "Stip;5053"
_STOP_W = r"(?:stop(?:\s*loss)?|stip|stpo|sotp|stoo|atop|sl|استاپ(?:\s*لاس)?|استپ|حد\s*(?:ضرر|زیان))"
_STOP = re.compile(r"(?:^|\s)" + _STOP_W + r"\s*(?:(?:رو|را|روی)\s*)?[:;=]?\s*(\d{2,4}(?:\.\d+)?)(?!\d)")
_STOP_SLIP = re.compile(_STOP_W + r"\s*[:;]?\s*(\d{3})[op]")      # "Stop:438p": the last 0 typed as its neighbour key
_PRICE = re.compile(r"^x[a-z]{1,2}\s*:\s*" + _P + r"$")
_RESULT = re.compile(r"^[+\-]\s*\d+\s*(?:pip|پیپ)")
_KW_TP = re.compile(r"\btp\s*:?")
_KW_SL = re.compile(r"\bsl\s*:?")
_TP_PIPS = re.compile(r"(?<![\w.])(\d+(?:\.\d+)?)\s*(?:pips?|پیپ)(?!\w)")


def _num(v) -> Optional[float]:
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _expand(second: str, first: float) -> Optional[float]:
    """'4263/64' -> 4264: a 2-3 digit second level borrows the leading digits
    of the first. Only when the result is within 20 points of the first."""
    try:
        if len(second.split(".")[0]) >= 4:
            v = float(second)
        else:
            head = str(int(first))[: 4 - len(second.split(".")[0])]
            v = float(head + second)
    except (TypeError, ValueError):
        return None
    return v if abs(v - first) <= 20 else None


def _edits(raw: str) -> set:
    """The prices one keystroke away from ``raw``: one digit replaced (4 digits) or one
    digit too many dropped (5 digits)."""
    d = raw.split(".")[0]
    out: set = set()
    if len(d) == 4:
        for i in range(4):
            for c in "0123456789":
                if c != d[i]:
                    out.add(int(d[:i] + c + d[i + 1:]))
    elif len(d) == 5:
        for i in range(5):
            out.add(int(d[:i] + d[i + 1:]))
    return {float(v) for v in out if 1000 <= v <= 9999}


def _pair(first_raw: str, second_raw: str) -> Optional[tuple]:
    """The two levels of a zone -> (entries, alt); None: not readable (shorthand).

    The leader's scalp zone is two prices one point apart. When the two numbers as typed
    are not neighbours, one keystroke is wrong: "5072/4071", "4093/49094", "4054/4045",
    "4363/4262". The reading with the FIRST level mistyped is ``entries`` and the one with
    the second mistyped is ``alt``; the engine keeps the one next to the live price, or - when
    both are near it ("4054/4045") - the one his "Stop:" fits."""
    a = float(first_raw)
    n2 = len(second_raw.split(".")[0])
    if n2 <= 3:                                             # "4263/64"
        b = _expand(second_raw, a)
        return None if b is None else (([a] if b == a else [a, b]), [])
    b = float(second_raw) if n2 == 4 else None
    if b is not None and abs(a - b) <= 3.0:
        return ([a] if b == a else [a, b]), []
    typed_ok = b is not None and abs(a - b) <= 20
    for width in ((1.0,) if typed_ok else (1.0, 2.0)):
        fix_b = sorted(v for v in _edits(second_raw) if 0 < abs(v - a) <= width)
        fix_a = sorted(v for v in _edits(first_raw) if b is not None and 0 < abs(v - b) <= width)
        if len(fix_b) > 1 or len(fix_a) > 1:
            break                                           # two repairs fit: not decidable
        if fix_a and fix_b:
            return [fix_a[0], b], [a, fix_b[0]]
        if typed_ok:
            break                                           # one repair only: a wider zone, as typed ("4304_ 4299")
        if fix_b:
            return [a, fix_b[0]], []
        if fix_a:
            return [fix_a[0], b], []
    if typed_ok:
        return [a, b], []                                   # a wider zone, as typed
    if b is not None and 90 <= abs(b - a) <= 110:           # a wider zone with a 100-point slip
        shift = 100.0 if b > a else -100.0
        return [a + shift, b], [a, b - shift]
    return None


def _side_z(word: Optional[str]) -> Optional[str]:
    if not word:
        return None
    return "SELL" if word[0] == "s" or word in ("سل", "فروش") else "BUY"


def _side_words(s: str) -> Optional[str]:
    # "فشار فروش" (selling pressure) is market talk, not a side
    sell = re.search(r"(?<![0-9a-zء-ی])(?<!فشار )" + _SELL_FA + r"(?:ها|شو|ش)?" + _END, s) or re.search(r"\bsell\b", s)
    buy = re.search(r"(?<![0-9a-zء-ی])(?<!فشار )" + _BUY_FA + r"(?:ها|شو|ش)?" + _END, s) or re.search(r"\bbuy\b", s)
    if sell and not buy:
        return "SELL"
    if buy and not sell:
        return "BUY"
    return None


def _ultra(s: str) -> Optional[Parsed]:
    """'gold buy 4145-4140 tp 4162 tp 4170 sl 4135' and its variants
    ('4263_4258 tp4270 tp4280 sl4253', 'gold buy entry 4263 _ 4258 tp 4270 _ 4280 sl 4253')."""
    if "tp" not in s and "sl" not in s:
        return None
    m_sl = _KW_SL.search(s)
    if not m_sl:
        return None
    first_kw = min([m.start() for m in (_KW_TP.search(s), m_sl) if m])
    head = s[:first_kw]
    entries = [float(x) for x in re.findall(_P, head)]
    if not entries:
        return None
    sl_nums = re.findall(_P, s[m_sl.end():])
    if not sl_nums:
        return None
    sl = float(sl_nums[0])
    tps: list = []
    tp_pips: list = []
    for m in _KW_TP.finditer(s):
        tail = s[m.end():]
        stop = _KW_SL.search(tail)
        seg = tail[: stop.start()] if stop else tail
        nxt = _KW_TP.search(seg)
        seg = seg[: nxt.start()] if nxt else seg
        tp_pips += [float(m.group(1)) for m in _TP_PIPS.finditer(seg)]
        # A '1000pip' target is a distance, never the absolute price 1000.
        seg = _TP_PIPS.sub(" ", seg)
        tps += [float(x) for x in re.findall(_P, seg)]
    entries = entries[:2]
    side = None
    m_side = re.search(_SIDE_EN, head)
    if m_side:
        side = m_side.group(1).upper()
    else:
        side = _side_words(head)
    lo, hi = min(entries), max(entries)
    inferred = "BUY" if sl < lo else ("SELL" if sl > hi else None)
    if side is None:
        side = inferred
    if side is None or inferred != side:
        if _ZONE.search(s):
            return None # labelled scalp zones retain their existing stop-typo repair path
        return Parsed(NOISE, side=side, entries=entries, sl=sl,
                      reason="جهت سیگنال با محل استاپ نسبت به ناحیه نمی‌خواند؛ منتظر اصلاح کانال")
    if any(abs(e - sl) > 40 for e in entries):
        if _ZONE.search(s):
            return None
        return Parsed(NOISE, side=side, entries=entries, sl=sl,
                      reason="فاصلهٔ استاپ سیگنال کامل بیش از ۴۰ واحد است؛ اعداد بررسی شوند")
    if tps and tp_pips:
        return Parsed(NOISE, side=side, entries=entries, sl=sl, tps=tps, tp_pips=tp_pips,
                      reason="هدف قیمتی و پیپی در یک سیگنال مخلوط شده؛ ورود انجام نشد")
    if any(v <= 0 for v in tp_pips):
        return Parsed(NOISE, side=side, entries=entries, sl=sl, tp_pips=tp_pips,
                      reason="فاصلهٔ هدف پیپی باید مثبت باشد؛ ورود انجام نشد")
    tps = [t for t in tps if (t > hi if side == "BUY" else t < lo)]
    return Parsed(SIGNAL, side=side, entries=entries, sl=sl, tps=tps, tp_pips=tp_pips, ultra=True)


def parse(text: str) -> Parsed:
    raw = str(text or "")
    # Only a standalone signature of this exact channel is removable. An advert
    # with another URL must still be ignored, even if it quotes a signal.
    body = re.sub(r"(?im)^\s*(?:@lordxau|https?://t\.me/(?:s/)?lordxau/?)\s*$", "", raw)
    s = norm(body)
    out = _parse(s)
    out.text = raw
    return out


def _parse(s: str) -> Parsed:
    if not s:
        return Parsed(NOISE)
    if len(s) > 160:                                       # speeches / adverts
        return Parsed(NOISE)
    if re.search(r"https?://|t\.me/", s):
        return Parsed(NOISE)
    if re.search(r"\?|؟", s):
        return Parsed(NOISE)                              # numeric questions are not orders either

    # The observed standalone typo (91012) follows "فری خورد". Restrict the
    # repair to this complete imperative, rather than guessing words in talk.
    if re.fullmatch(r"بگیر\s*یاز[\s!.]*", s):
        s = "بگیر باز"

    m = _PRICE.match(s)
    if m:
        return Parsed(PRICE, price=float(m.group(1)))
    if _RESULT.match(s) or s.startswith("برایند"):
        return Parsed(RESULT)

    # An explicitly labelled scalp zone with only SL used to be misclassified
    # as ULTRA (off by default), so its order was silently skipped.
    u = None if _ZONE.search(s) and not _KW_TP.search(s) else _ultra(s)
    if u is not None:
        return u

    # SCALP zone "xau sell enter:4190/4189" (+ maybe the stop in the same message)
    mb = _ZONE_BARE.fullmatch(s)
    if mb:
        s = f"xau {mb.group(1)} enter:{mb.group(2)}/{mb.group(3)}"
    m = _ZONE.search(s)
    if m:
        side = _side_z(m.group(1))
        if side is None:
            m2 = re.search(r"\b" + _SIDE_Z + r"\b", s)
            side = _side_z(m2.group(1)) if m2 else _side_words(s)
        first = float(m.group(2))
        entries = [first]
        alt: list = []
        if m.group(3):
            pair = _pair(m.group(2), m.group(3))
            if pair is None:
                return Parsed(SHORTHAND, side=side)
            entries, alt = pair
        sl = None
        ms = _STOP.search(s[m.end():])
        if ms:
            v = ms.group(1)
            if len(v.split(".")[0]) < 4:
                return Parsed(SHORTHAND, side=side, entries=entries)
            sl = float(v)
        return Parsed(ZONE, side=side, entries=entries, sl=sl, alt=alt)

    # SCALP stop "stop:4192" / "استاپ 4192"
    m = _STOP_SLIP.fullmatch(s)
    if m:
        return Parsed(STOP, sl=float(m.group(1) + "0"))
    m = _STOP.search(s)
    if m and len(s) <= 60 and not re.search(r"خورد|تاچ|زد", s) and (len(s) <= 24 or re.fullmatch(
            r"[\s!✅]*" + _STOP.pattern + r"(?:\s*(?:باشه|فقط|بزار|بذار|بزارید|بذارید|کن|کنید))*[\s!.✅]*", s)):
        v = m.group(1)
        if len(v.split(".")[0]) < 4:
            return Parsed(SHORTHAND)
        return Parsed(STOP, sl=float(v))

    # a bare 2-3 digit level pair next to a side / level word ("بای بزن 317و312") is shorthand
    if (re.search(r"(?<!\d)\d{2,3}\s*(?:و|/)\s*\d{2,3}(?!\d)", s) and len(s) <= 30
            and re.search(r"(?:" + _SELL_FA + r"|" + _BUY_FA + r"|استاپ|تیپی|ورود|buy|sell)", s)):
        return Parsed(SHORTHAND, side=_side_words(s))
    if re.search(r"(?:^|\s)(?:استاپ|استپ|تیپی|تی پی)\s*\d{2,3}(?!\d)", s) and len(s) <= 20:
        return Parsed(SHORTHAND)

    # "48هم بود بگیر": the leader takes the zone up to ..48 too (price 2 digits)
    m = re.fullmatch(r"(\d{2})\s*هم\s*(?:بود\s*)?(?:بگیر|بگیرید|بگیرین|بزن|بزنید|بزنین)[\s!.]*", s)
    if m:
        return Parsed(EXTEND, price=float(m.group(1)))
    # "صبر" / "فعلا صبر" / "صبر میگم کجا بگیری" / "میگم کجا بزنی": no entry now
    if len(s) <= 40 and (re.fullmatch(r"(?:فعلا\s*)?صبر(?:\s*کن(?:ید|ین)?)?(?:\s*بعدی)?[\s!.]*", s)
                         or re.match(r"صبر\s*(?:کن(?:ید|ین)?\s*)?(?:میگم|ده\s*پیپ)", s)
                         or re.search(r"(?:^|\s)میگم\s*کجا\s*(?:بگیر|بزن)", s)):
        return Parsed(WAIT)
    # "فریش کن رو4182" / "رو4119/4118فری کن" may specify a trigger or a
    # protection level. A generic BE call would silently discard that level.
    # A reason also keeps this deliberate refusal out of the LLM fallback.
    if _explicit_be_level(s):
        return Parsed(NOISE, reason="دستور فری سطح قیمتی صریح دارد؛ زمان اجرا یا محل استاپ مبهم است، فری فوری انجام نشد")
    if (re.search(r"(?:^|\s)هر\s*(?:جا|وقت|موقع|زمان)(?=\s|$)", s)
            and re.search(r"(?<![0-9a-zء-ی])" + _CLOSE_VERB + _END, s)):
        return Parsed(NOISE, reason="خروج به شرط رسیدن حساب یا قیمت است؛ شرط هنوز تایید نشده، خروج فوری انجام نشد")
    side = _side_words(s)
    be_hit = bool(re.search(r"فری\s*(?:ش\s*)?(?:هم\s*)?(?:خورد|زد|شد)", s))
    sl_hit = bool(re.search(r"استاپ\s*(?:ش\s*)?(?:هم\s*)?(?:خورد|تاچ|زد" + _END + r")", s))
    # "بگیر باز", "دوباره بگیرش", "مجدد بگیرش", "فری خورد. بگیرش", "میگریم باز" (typo of میگیریم)
    again = bool(re.search(r"(?:بگیر|بگیرید|بگیرش|بگیرین|بزن|بزنید|میگیریم|میگریم|مگیریم)\s*" + _AGAIN, s)
                 or re.search(r"(?:^|\s)" + _AGAIN + r"\s*(?:" + _SIDES + r"\s*)?(?:بگیر|بگیرید|بگیرش|بزن|بزنید)" + _END, s)
                 or re.search(r"(?:" + _SIDES + r")\s*بگی\s*" + _AGAIN, s)
                 or re.search(r"(?:فری|استاپ)\s*(?:ش\s*)?(?:خورد|زد)[\s.]*(?:بگیر|بگیرید|بگیرش)" + _END, s))
    if re.search(r"(?:^|\s)(?:اگر|اگه|اکر)(?:\s|$)", s):
        return _conditional(s, side, again)
    # the leader closes his own trade right here ("خودتون اینو مدیریت کنید من همینجا میبندمش"):
    # the bot cannot "manage it itself", it closes with him. ("من بستم 🙏" alone is the caption
    # of members' screenshots - not read.)
    if (len(s) <= 60 and not re.search(r"گفت|وقت|چرا|\d", s)
            and re.search(r"(?:^|\s)من\s*(?:همین\s*جا|اینجا)\s*(?:میبندمش|میبندم|بستمش|بستم)" + _END, s)):
        return Parsed(CLOSE)
    # narrative / long text are never orders ("تا گفتم ببند", "استاد گفتی ببند😂 بستم رفت بالا")
    if (len(s) > 40 or re.search(r"گفت|نخواهم|نمیگم|میگم|وقتی|چرا|نکردی|میخواد|قران", s)):
        # ... except the risk-free ORDER that opens a longer sentence: it only protects an open
        # trade ("ریسک فری کن نگهدار میگم کجا ببندی", "پرواز کرد ریسک فری کن جا موندی مارکت بزنش")
        if len(s) <= 160 and not be_hit and _be_order(s) and _be_opens(s):
            mn = len(s) <= 60 and _market_now(s)
            return Parsed(BE, also=[MARKET_NOW] if mn else [], missed=bool(mn) and _missed(s))
        # A longer NOW-close is accepted only when its first word is the order
        # and the remainder is plain management wording, without prices/stories.
        if _long_close(s):
            return Parsed(CLOSE, side=side)
        return Parsed(NOISE)

    kinds: list = []
    if (re.search(r"(?<![0-9a-zء-ی])" + _CLOSE_VERB + _END, s)
            and not re.search(r"دهن\S*\s*(?:رو\s*)?ببند|ببند\S*\s*دهن", s)) \
            or re.search(r"خروج\s*(?:بزن|بزنید|بگیر)", s):
        # "۴۵ رو با سود ببند", "4145 رو با سود ببند", "رسید 4180 ببندش": a leg / a target, not "close
        # now"; only "ببندید رو3975 عه" (close, it is at 3975) carries a price
        if re.search(r"\d", s) and not re.match(_CLOSE_VERB + r"\s*رو\s*\d{4}(?!\d)[^\d]*$", s):
            return Parsed(NOISE)
        kinds.append(CLOSE)
    # ("40 رو ریسک فری کن": a leg of an ULTRA signal, not the scalp)
    if not be_hit and _be_order(s) and not _BE_NOT.search(s) and not re.search(r"(?<!\d)\d{1,3}(?!\d)", s):
        kinds.append(BE)
    if again:
        kinds.append(REENTER)
    if _market_now(s):
        kinds.append(MARKET_NOW)
    # a side order without levels: "سل بزن", "بای بزنید", "gold buy now", "بزن سلشو", "سلش بزن",
    # "یه سل دیگه بزن", "یه سل تر تمیز بزنید"
    if side and (re.search(r"(?:" + _SIDES + r")(?:ش)?\s*" + _FILLER + _VERB + _END, s)
                 or re.search(_VERB + _END + r"\s*(?:" + _SIDES + r")", s)
                 or re.search(r"\bgold\s+(?:buy|sell)(?:\s+now)?$", s)
                 or re.search(r"^(?:buy|sell)(?:\s+now)?$", s)):
        kinds.append(HINT)
    if not kinds:
        if sl_hit:
            return Parsed(SL_HIT)
        if be_hit:
            return Parsed(BE_HIT)
        return Parsed(NOISE)
    order = [CLOSE, BE, HINT, REENTER, MARKET_NOW]
    kinds.sort(key=order.index)
    return Parsed(kinds[0], side=side, also=kinds[1:], missed=MARKET_NOW in kinds and _missed(s))


def _missed(s: str) -> bool:
    """The market order is for a zone the price did not come back to ("نرسیدی")."""
    return bool(re.search(r"(?:^|\s)(?:نرسید|نرسیدی|نرسیدید|نرسیدین)(?:\s|$)", s))


_SIDES = r"(?:" + _SELL_FA + r"|" + _BUY_FA + r")"          # grouped: "دوباره سل بزن" like "دوباره بای بزن"
_END = r"(?=[^0-9a-zء-ی]|$)"                               # a word ends (space, punctuation, emoji, end)
_FILLER = r"(?:(?:دیگه|دیگر|تر|تمیز|اسکلپ|رو|را|الان|فوری)\s*){0,3}"
_TAKE = r"(?:بگیر|بگیرید|بگیرین|بگیرش|میگیریم|بزن|بزنید|بزنین)"
_BE_VERB = r"(?:کن|کنش|کنید|کنیدش|کنین|کنن|بکن|بکنید|بکنین|بزار|بزارید|بزارین|بذار|بذارید|باش|باشید|باشین|بزن|بزنید|بزنین)"
_CLOSE_VERB = r"(?:ببند|ببندش|ببندشون|ببندید|ببندیدش|ببندیدشون|ببندین|ببندینش|ببندینشون)"


def _long_close(s: str) -> bool:
    if len(s) > 160 or not re.match(_CLOSE_VERB + _END, s):
        return False
    words = re.findall(r"[0-9a-zء-ی]+", s)
    allowed = {"دوستان", "بچه", "ها", "بچهها", "لطفا", "همین", "الان", "کامل", "همه", "تمام",
               "معامله", "معاملات", "پوزیشن", "پوزیشنها", "رو", "را", "دیگه", "سریع", "با", "سود",
               "بای", "سل", "خرید", "فروش", "کنید", "خروج", "بزنید", "بزن"}
    return all(re.fullmatch(_CLOSE_VERB, w) or w in allowed for w in words)


def _be_order(s: str) -> bool:
    """"فریش کن" / "ریسک فری بزار" / "ریسک فری رو بزار" / "ریسک فری بکنید" / "فری باشین" /
    "با ریسک فری برو جلو" / "فریش کم", "فری کم" (typo of کن) / "ریسک فری باز"."""
    return bool(re.search(r"(?:^|\s)(?:ریسک\s*)?فری\s*ش?\s*(?:(?:رو|هم)\s*)?" + _BE_VERB + _END, s)
                or re.search(r"(?:^|\s)فری\s*ش?\s*کم" + _END, s)
                or re.match(r"با\s*ریسک\s*فری\s*(?:برو|بمون|بمونید|نگه)", s)
                or re.fullmatch(r"ریسک\s*فری(?:\s*باز)?[\s!✅🙏👌]*", s))


def _explicit_be_level(s: str) -> bool:
    """Never flatten explicit numeric protection into an immediate generic BE.

    Full levels before the command can touch the word "فری". Ordinary progress
    after a BE order ("فری باشین تا4050میره") retains its existing reading.
    """
    level = r"\d{4}(?:\.\d+)?(?!\d)"
    before = (r"(?:^|\s)(?:رو|روی)\s*" + level
              + r"(?:\s*/\s*" + level + r")?\s*(?:ریسک\s*)?فری\s*ش?\s*"
              + _BE_VERB + _END)
    after = r"(?:^|\s)(?:رو|روی)\s*" + level
    # Also refuse a bare terminal level, "فریش کن 4182[/4181]". Requiring
    # it immediately after the imperative preserves ordinary price progress.
    terminal = (r"(?:^|\s)(?:ریسک\s*)?فری\s*ش?\s*(?:(?:رو|هم)\s*)?"
                + _BE_VERB + _END + r"\s+" + level
                + r"(?:\s*/\s*" + level + r")?[\s!.]*$")
    return bool(re.search(before, s) or re.search(terminal, s)
                or (_be_order(s) and re.search(after, s)))


# "نمیخواد ریسک فری کنید", "لازم نیست فری کنی", "نگه دار میگم کی ریسک فری کنید": no order to
# protect the trade now
# (the word must negate or defer the order itself: "جای خوبی نیست فریش کن" IS an order)
_BE_NOT = re.compile(r"نمیخواد|نمی خواد|(?:لازم|نیازی?|احتیاجی?|وقتش)\s*نیست|(?:زوده|بعدا)\s*(?:ریسک\s*)?فری"
                     r"|(?:^|\s)نه\s*الان|هر\s*(?:موقع|وقت|زمان)|میگم\s*(?:کی|کجا)\s*(?:ریسک\s*)?فری")


def _be_opens(s: str) -> bool:
    """The risk-free order of a LONGER sentence is an order only when it opens it - at most a
    short market remark before it ("ریخت", "پرواز کرد") or a finished sentence ("... تو سودن.") -
    and the sentence is not a story, a thank-you, advice about other trades or leg talk
    ("دیشب گفته بودم ...", "ممنون استاد که ...", "ورود 4145 رو ریسک فری کن 4140 رو نگه دار")."""
    m = re.search(r"(?:^|\s)(?:با\s*)?(?:ریسک\s*)?فری", s)
    if not m or _BE_NOT.search(s):
        return False
    pre = s[:m.start()].strip()
    if re.search(r"\d|میگم", pre) or (len(pre) > 16 and not re.search(r"[.!،]$", pre)):
        return False
    # ("حتما ریسک فری کنید بعد بالا رفتن", "ریسک فری کن همیشه بعد از اینکه رفت تو سود": his lectures)
    return not re.search(r"گفت|نخواهم|نمیگم|وقتی|چرا|نکردی|قران|دیروز|دیشب|ممنون|استاد|الترا|ultra|رفتی|همیشه"
                         r"|(?:^|\s)بعد\s*(?:از\s*)?(?:اینکه|رفتن|بالا|سود)|(?<!\d)\d{1,3}(?!\d)", s)


def _market_now(s: str) -> bool:
    """"جا موندی قیمت مارکت بزن" / "نرسیدی مارکت نزدیکش بگیر" / "جا موندی بپر تو": a positive
    entry verb is required and a negation ("جا موندی نزن", "بیخیال") cancels it
    ("برو سوپر مارکت بزن" is not a market order)."""
    mn = (re.search(r"(?:جا\s*موندی[نی]?|نرسیدی?|قیمت\s*مارکت|(?<!سوپر )مارکت|نزدیک\S*).*?(?:^|\s)"
                    r"(?:بزن|بزنش|بزنید|بزنین|بگیر|بگیرید|بپر\s*تو)" + _END, s)
          or re.search(r"(?:^|\s)بپر\s*تو" + _END, s))
    return bool(mn) and not re.search(r"(?:^|\s)(?:نزن|نزنش|نزنید|نزنین|نگیر|نگیرش|نگیرید|نپر|بیخیال|ولش|نه)" + _END, s)


def _conditional(s: str, side: Optional[str], again: bool) -> Parsed:
    """"اگر ..." orders; any other conditional is talk.
    "اگر فری خورد بگیر باز" / "اگر فری خوردی بگیر"           -> IF_BE_REENTER
    "اگه استاپ تاچ کرد بگیر باز" / "اگر استاپ بزنه دوباره بای بگیر" -> IF_SL_REENTER
    "اگر نرسیدی قیمت مارکت بزن" / "اگر نرسیدی نزدیکاش بزن"       -> MARKET_NOW
    "اگر نبستی ریسک فری کن نگه دار"                            -> BE"""
    # "take it again" - or "take it" right after the condition ("اگر فری خوردی بگیر");
    # "بعدی رو بزنید" (take the NEXT one) is not a re-entry of this zone
    take = (again or bool(re.search(r"(?:خورد|خوردی|خوردید|زد|شد|بخوره|بزنه|کرد|شده)\s*" + _TAKE + _END, s))) \
        and not re.search(r"بعدی", s)
    if take and re.search(r"فری[\s.]*(?:ش\s*)?(?:هم\s*)?(?:خورد|خوردی|زد|شد|بخوره)", s):
        return Parsed(IF_BE_REENTER, side=side)
    if take and re.search(r"استاپ\S*\s*(?:ش\s*)?(?:هم\s*)?(?:خورد|خوردی|تاچ|زد|بزنه|بخوره)", s):
        return Parsed(IF_SL_REENTER, side=side)
    if re.search(r"(?:^|\s)(?:نرسید|نرسیدی|نرسیدید|جا\s*موندی)(?:\s|$)", s) and _market_now(s):
        return Parsed(MARKET_NOW, side=side, missed=_missed(s))
    if re.search(r"(?:^|\s)(?:نبستی|نبستید|نبستین)(?:\s|$)", s) and _be_order(s):
        return Parsed(BE)
    return Parsed(NOISE)
