"""Core data model for a parsed trading signal."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class Side(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


class OrderType(str, Enum):
    MARKET = "MARKET"
    LIMIT = "LIMIT"
    STOP = "STOP"


@dataclass
class Signal:
    """A normalized trading signal extracted from a Telegram message.

    All prices are floats. ``entries`` may hold one price (single entry),
    two prices (an entry zone/range), or be empty for a pure market order.
    """

    symbol: Optional[str] = None
    side: Optional[Side] = None
    order_type: OrderType = OrderType.MARKET
    entries: list[float] = field(default_factory=list)
    stop_loss: Optional[float] = None
    take_profits: list[float] = field(default_factory=list)

    raw_text: str = ""
    source: str = ""
    confidence: float = 0.0
    warnings: list[str] = field(default_factory=list)
    take_profit_offsets: list[float] = field(default_factory=list) # price distances from the send quote
    take_profit_reference: Optional[float] = None                  # executor's original TP plan reference

    @property
    def entry(self) -> Optional[float]:
        """First/primary entry price, or None for a market order."""
        return self.entries[0] if self.entries else None

    def is_actionable(self) -> bool:
        """True only with a symbol, a direction, AND at least one price level.

        Requiring a level (entry, stop loss, or take profit) prevents chatter
        that merely mentions a symbol and 'buy'/'sell' — recaps, warnings,
        ads — from being executed as an unbounded market order.
        """
        return bool(
            self.symbol
            and self.side
            and (self.entries or self.stop_loss is not None or self.take_profits)
        )

    def summary(self) -> str:
        parts = [
            f"{self.symbol or '?'}",
            f"{self.side.value if self.side else '?'}",
            f"[{self.order_type.value}]",
        ]
        if self.entries:
            parts.append("entry=" + "/".join(str(e) for e in self.entries))
        if self.stop_loss is not None:
            parts.append(f"SL={self.stop_loss}")
        if self.take_profits:
            parts.append("TP=" + "/".join(str(t) for t in self.take_profits))
        if self.take_profit_offsets:
            parts.append("TP-distance=" + "/".join(str(t) for t in self.take_profit_offsets))
        parts.append(f"conf={self.confidence:.2f}")
        return " ".join(parts)
