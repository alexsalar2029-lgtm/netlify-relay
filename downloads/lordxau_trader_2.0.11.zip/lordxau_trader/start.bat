@echo off
chcp 65001 >nul
cd /d "%~dp0"
set PYTHONUTF8=1
title LORD XAU Trader
where python >nul 2>nul
if errorlevel 1 (
  py lordxau_gui.py
) else (
  python lordxau_gui.py
)
if errorlevel 1 pause
