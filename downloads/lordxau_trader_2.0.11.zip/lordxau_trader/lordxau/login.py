# -*- coding: utf-8 -*-
"""One-time Telegram login in the console (phone number, code, 2FA password):
only needed when no authorized session was copied from the previous program.

    python -m lordxau.login
"""
from __future__ import annotations

import asyncio
import os
import sys

from lordxau import settings as st_mod
from lordxau.runner import ROOT, _load_env, old_program_pids


async def _main() -> int:
    s = st_mod.load(ROOT)
    _load_env(ROOT)
    if not os.getenv("TG_API_ID") or not os.getenv("TG_API_HASH"):
        print("TG_API_ID / TG_API_HASH not found: put the previous program's .env next to start.bat")
        return 1
    if old_program_pids():
        print("The previous program is running - close it first (it uses the same Telegram account).")
        return 1
    from telethon import TelegramClient
    session = str(ROOT / str(s["telegram"].get("session_name") or "signal_trader"))
    client = TelegramClient(session, int(os.getenv("TG_API_ID")), os.getenv("TG_API_HASH"))
    await client.start()                  # asks for the phone / code / password in this window
    me = await client.get_me()
    print("OK - logged in as", getattr(me, "first_name", None) or getattr(me, "username", "?"))
    await client.disconnect()
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(_main()))
