"""Abstract execution backend."""
from __future__ import annotations

import abc
from typing import Any

from signal_trader.models import Signal


class Executor(abc.ABC):
    """A backend that consumes a parsed :class:`Signal`.

    Implementations must be safe to call from an asyncio event loop. Blocking
    I/O (HTTP) should be offloaded with ``asyncio.to_thread`` or an async HTTP
    client.
    """

    name = "base"

    @abc.abstractmethod
    async def execute(self, signal: Signal) -> dict[str, Any]:
        """Act on ``signal`` and return a small result dict for logging."""
        raise NotImplementedError
