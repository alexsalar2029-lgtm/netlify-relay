# -*- coding: utf-8 -*-
"""Real 05/06 October formats, with no Telegram account or broker connection."""
import json
from types import SimpleNamespace

import pytest

from lordxau.diagnostics import build_report
from lordxau.engine import Engine, EngineConfig, ULTRA_SOURCE
from lordxau.parse import NOISE, SIGNAL, parse
from signal_trader import filelog
from signal_trader.executors.fxtrendo import FxTrendoExecutor
from signal_trader.models import OrderType, Side, Signal
from signal_trader.risk import DailyGuard
from signal_trader.validation import validate_signal
from test_engine import Clock, make, run

LATEST = "GOLD SELL\n\n4160-  - 4165\n\nTp\n60pip - 100pip\n\nSl4169"
WRONG = "GOLD sell\n\n4153-4148\n\nTP 4160\nTP 4168\n\nSL 4144"
CORRECTED = WRONG.replace("sell", "buy")


@pytest.mark.parametrize("text,distances", [
    (LATEST, [60, 100]),
    ("GOLD BUY 4165-4160 TP 60 pips / 100 pips SL4156", [60, 100]),
    ("GOLD SELL 4160/4165 TP ۶۰پیپ - ۱۰۰پیپ SL4169", [60, 100]),
    ("GOLD SELL 4160/4165 TP 60.5pip SL4169", [60.5]),
    ("GOLD SELL 4160/4165 TP 1000pip SL4169", [1000]),
])
def test_explicit_pip_targets_are_distances(text, distances):
    p = parse(text)
    assert p.kind == SIGNAL and p.ultra and not p.tps
    assert p.tp_pips == distances


@pytest.mark.parametrize("text", [
    "GOLD SELL 4160/4165 TP 60pip TP4154 SL4169",
    "GOLD SELL 4160/4165 TP 0pip SL4169",
    WRONG,
])
def test_malformed_signal_has_an_explanation_and_never_opens(text):
    p = parse(text)
    assert p.kind == NOISE and p.reason
    eng, ex, clk = make(trade_ultra=True)
    lines = run(eng.handle(text, msg_id=1, ts=clk.t))
    assert not ex.calls and any(p.reason in s for s in lines)


def test_ultra_off_is_distinguished_from_a_broker_rejection():
    eng, ex, clk = make()
    lines = run(eng.handle(LATEST, msg_id=90350, ts=clk.t))
    assert not ex.calls
    assert any("ULTRA خاموش" in s and "رد بروکر نیست" in s for s in lines)


def test_fresh_author_correction_of_wrong_direction_opens_when_enabled():
    eng, ex, clk = make(trade_ultra=True)
    run(eng.handle(WRONG, msg_id=90025, ts=clk.t))
    assert not ex.calls
    clk.t += 8
    run(eng.handle_edit(CORRECTED, msg_id=90025, ts=clk.t - 8))
    assert ex.calls == [("execute", "BUY", [4153, 4148], 4144, [4160], ULTRA_SOURCE, "LIMIT")]
    run(eng.handle_edit(CORRECTED + " ", msg_id=90025, ts=clk.t - 8))
    assert len(ex.calls) == 1


@pytest.mark.parametrize("condition", ["stale", "unseen", "newer_ultra", "newer_scalp", "ultra_off"])
def test_an_edit_cannot_open_an_old_unknown_or_disabled_trade(condition):
    eng, ex, clk = make(trade_ultra=condition != "ultra_off")
    if condition != "unseen":
        run(eng.handle(WRONG, msg_id=90025, ts=clk.t))
    if condition == "stale":
        clk.t += 181
    if condition == "newer_ultra":
        run(eng.handle("Gold sell 4172-4177 TP4165 SL4181", msg_id=90026, ts=clk.t))
    if condition == "newer_scalp":
        ex.mid = 4162
        run(eng.handle("Xau Buy Enter:4161/4162", msg_id=90026, ts=clk.t))
    before = len(ex.calls)
    run(eng.handle_edit(CORRECTED, msg_id=90025, ts=1000))
    assert len(ex.calls) == before


def test_a_repost_edit_cannot_become_a_second_order():
    eng, ex, clk = make(trade_ultra=True)
    run(eng.handle(CORRECTED, msg_id=1, ts=clk.t))
    run(eng.handle(CORRECTED, msg_id=2, ts=clk.t))
    run(eng.handle_edit(CORRECTED.replace("4144", "4143"), msg_id=2, ts=clk.t))
    assert len(ex.calls) == 1


@pytest.mark.parametrize("state", ["waiting", "filled", "firing"])
def test_a_corrected_zone_replaces_only_its_own_unfilled_limit(state):
    eng, ex, clk = make(trade_ultra=True)
    run(eng.handle(CORRECTED, msg_id=1, ts=clk.t))
    if state == "filled":
        ex.fill("v1")
    if state == "firing":
        ex.firing.add("v1")
    lines = run(eng.handle_edit(CORRECTED.replace("4153", "4152"), msg_id=1, ts=clk.t))
    executes = [c for c in ex.calls if c[0] == "execute"]
    assert len(executes) == (2 if state == "waiting" else 1)
    assert any("ویرایش" in s for s in lines)


def test_pip_target_edit_keeps_a_single_waiting_order():
    eng, ex, clk = make(trade_ultra=True)
    run(eng.handle(LATEST, msg_id=1, ts=clk.t))
    run(eng.handle_edit(LATEST.replace("60pip", "70pip"), msg_id=1, ts=clk.t))
    assert ex.alive == {"v2"}
    assert eng.ultra_messages[1].tp_pips == [70, 100]


def test_an_explicitly_rejected_unfilled_signal_may_be_corrected_fresh():
    eng, ex, clk = make(trade_ultra=True)
    ex.next_action = "rejected"
    run(eng.handle(CORRECTED, msg_id=1, ts=clk.t))
    run(eng.handle_edit(CORRECTED.replace("4144", "4145"), msg_id=1, ts=clk.t))
    assert len(ex.calls) == 2 and eng.ultra_messages[1].placed


def test_an_uncertain_send_is_not_reopened_by_an_edit():
    eng, ex, clk = make(trade_ultra=True)
    ex.next_action = "unconfirmed"
    run(eng.handle(CORRECTED, msg_id=1, ts=clk.t))
    run(eng.handle_edit(CORRECTED.replace("4144", "4145"), msg_id=1, ts=clk.t))
    assert len(ex.calls) == 1


def test_editing_a_scalp_into_a_full_signal_never_opens_a_second_order():
    eng, ex, clk = make(trade_ultra=True)
    ex.mid = 4162
    run(eng.handle("Xau Buy Enter:4161/4162", msg_id=1, ts=clk.t))
    run(eng.handle_edit("Xau Buy Enter:4161/4162 TP4168 SL4159", msg_id=1, ts=clk.t))
    assert len(ex.calls) == 1


@pytest.mark.parametrize("pip_size", [0, -0.1, float("nan"), float("inf")])
def test_invalid_gold_pip_configuration_cannot_send(pip_size):
    eng, ex, clk = make(trade_ultra=True, gold_pip_size=pip_size)
    lines = run(eng.handle(LATEST, msg_id=1, ts=clk.t))
    assert not ex.calls and any("اندازهٔ پیپ" in s for s in lines)


class RecordingBroker:
    """Only the in-process client boundary; every network method fails if called."""
    connected = True
    use_real = False

    def __init__(self, quote=(4162, 4162.1)):
        self.quote = quote
        self.wallet = {"id": "demo-test", "balance": 1000, "is_real": False}
        self.wallet_data = {"balance": 1000, "equity": 1000}
        self.open_orders = {}
        self.sent = []
        self.reject = False

    def login(self):
        raise AssertionError("network login must never happen")

    connect = login

    def broker_symbol(self, symbol):
        return symbol.lower()

    def price(self, symbol):
        return self.quote

    def price_age(self, symbol):
        return 0

    def place_order(self, sig, *, dry_run, lot, tp):
        assert not dry_run
        self.sent.append({"side": sig.side.value, "sl": sig.stop_loss, "lot": lot, "tp": tp})
        if self.reject:
            return {"action": "rejected", "reason": "broker test rejection", "error": 2}
        order_id = len(self.sent)
        self.open_orders[order_id] = {"id": order_id, "symbol": "xauusd", "type": 1}
        return {"action": "placed", "order_id": order_id}


def executor(tmp_path, quote=(4162, 4162.1), split=False):
    client = RecordingBroker(quote)
    cfg = SimpleNamespace(
        fxtrendo={"enabled": True, "dry_run": False, "virtual_limits": True,
                  "max_open_positions": 1, "watchdog_sec": 0},
        risk={"sizing": "fixed", "split_take_profits": split}, channel_settings={})
    ex = FxTrendoExecutor(cfg, client)
    ex.daily = DailyGuard(state_path=str(tmp_path / "daily.json"))
    return ex, client


@pytest.mark.parametrize("side,quote,stop,target", [
    ("SELL", (4162, 4162.1), 4169, 4156),
    ("BUY", (4162, 4162.1), 4156, 4168.1),
])
def test_full_pipeline_sends_channel_pip_target_to_client(tmp_path, side, quote, stop, target):
    ex, client = executor(tmp_path, quote)
    clk = Clock()
    eng = Engine(ex, EngineConfig(trade_ultra=True), clock=clk)
    text = f"GOLD {side} 4160-4165 TP60pip - 100pip SL{stop}"
    lines = run(eng.handle(text, msg_id=1, ts=clk.t))
    assert len(client.sent) == 1
    assert client.sent[0] == {"side": side, "sl": stop, "lot": 0.01, "tp": target}
    assert eng.live and eng.live[0].placed and any("ارسال شد" in s for s in lines)


def test_virtual_limit_resolves_relative_target_only_when_it_fires(tmp_path):
    ex, client = executor(tmp_path, (4150, 4150.1))
    eng = Engine(ex, EngineConfig(trade_ultra=True), clock=Clock())
    run(eng.handle(LATEST, msg_id=1))
    assert not client.sent and ex.virtual_orders()
    client.quote = (4161, 4161.1)
    ex._fire_virtual(1)
    assert client.sent[0]["tp"] == 4155
    assert not ex.virtual_orders()


def test_author_direction_correction_reaches_the_executor_client(tmp_path):
    ex, client = executor(tmp_path, (4150, 4150.1))
    clk = Clock()
    eng = Engine(ex, EngineConfig(trade_ultra=True), clock=clk)
    run(eng.handle(WRONG, msg_id=90025, ts=clk.t))
    assert not client.sent
    clk.t += 8
    run(eng.handle_edit(CORRECTED, msg_id=90025, ts=clk.t - 8))
    assert client.sent == [{"side": "BUY", "sl": 4144, "lot": 0.01, "tp": 4160}]


@pytest.mark.parametrize("entries,stop", [
    ("4149/4148", 4146), ("4151/4152", 4149), ("4152/4153", 4150),
    ("4150/4149", 4147), ("4162/4161", 4158),
])
def test_each_october_fifth_scalp_can_reach_the_client(tmp_path, entries, stop):
    hi = max(map(float, entries.split("/")))
    ex, client = executor(tmp_path, (hi - 0.15, hi - 0.05))
    eng = Engine(ex, EngineConfig(), clock=Clock())
    run(eng.handle(f"Xau Buy Enter:{entries} Stop:{stop}", msg_id=1))
    assert len(client.sent) == 1 and client.sent[0]["sl"] == stop


def test_relative_targets_do_not_bypass_existing_min_lot_risk_guard(tmp_path):
    from signal_trader.risk import RiskConfig
    ex, client = executor(tmp_path, (4160, 4160.1))
    client.wallet_data["balance"] = 91
    ex.risk = RiskConfig(sizing="risk_pct", risk_pct=2)
    eng = Engine(ex, EngineConfig(trade_ultra=True), clock=Clock())
    lines = run(eng.handle(LATEST, msg_id=1))
    assert not client.sent and any("min_lot" in s for s in lines)


def test_relogin_refresh_preserves_each_relative_tp_distance(tmp_path):
    ex, client = executor(tmp_path, split=True)
    ex.default_lot = 0.02
    sig = Signal(symbol="XAUUSD", side=Side.SELL, order_type=OrderType.MARKET,
                 entries=[4160, 4165], stop_loss=4169, take_profit_offsets=[6, 10])
    plan, _ = ex._plan(sig, fill=4162)
    assert plan == [(0.01, 4156), (0.01, 4152)]
    client.quote = (4161.5, 4161.6)
    assert [ex._fresh_auto_tp(sig, tp) for lot, tp in plan] == [4155.5, 4151.5]


def test_a_real_broker_rejection_is_journalled_with_its_reason(tmp_path):
    ex, client = executor(tmp_path)
    client.reject = True
    filelog.setup(str(tmp_path / "logs"))
    try:
        eng = Engine(ex, EngineConfig(trade_ultra=True), clock=Clock())
        lines = run(eng.handle(LATEST, msg_id=90350))
        assert not eng.live and any("broker test rejection" in s for s in lines)
        rows = [json.loads(s) for p in (tmp_path / "logs").glob("decisions-*.jsonl") for s in p.read_text().splitlines()]
        assert rows[-1]["id"] == 90350
        assert any("broker test rejection" in s for s in rows[-1]["lines"])
    finally:
        filelog.shutdown()


def test_decision_journal_works_without_dashboard_and_scrubs_error_secrets(tmp_path):
    filelog.setup(str(tmp_path))
    try:
        eng, ex, clk = make()
        run(eng.handle(LATEST, msg_id=90350))
        filelog.decision({"type": "timer", "lines": ["password=example-secret api_key=example-key"]})
        raw = next(tmp_path.glob("decisions-*.jsonl")).read_text()
        assert "example-secret" not in raw and "example-key" not in raw
        rows = [json.loads(s) for s in raw.splitlines()]
        assert rows[0]["parsed"]["tp_pips"] == [60, 100]
        assert rows[0]["modes"] == {"trade_scalp": True, "trade_ultra": False}
    finally:
        filelog.shutdown()


def test_offline_diagnosis_omits_credentials_and_explains_missing_order_log(tmp_path):
    (tmp_path / "settings.json").write_text(json.dumps({
        "engine": {"trade_ultra": False}, "fxtrendo": {"enabled": True, "dry_run": False,
        "password": "broker-secret", "wallet_token": "private-token"}, "risk": {"risk_pct": 2}}))
    logs = tmp_path / "logs"
    logs.mkdir()
    (logs / "messages-2026-10-06.jsonl").write_text(json.dumps({"id": 90350, "text": LATEST}) + "\n")
    report = build_report(tmp_path)
    assert "ULTRA: خاموش" in report and "پیام 90350" in report
    assert "bot.log موجود نیست" in report
    assert "broker-secret" not in report and "private-token" not in report


@pytest.mark.parametrize("offset", [0, -1, float("nan"), float("inf")])
def test_invalid_relative_targets_are_rejected_by_execution_validation(offset):
    sig = Signal(symbol="XAUUSD", side=Side.SELL, entries=[4160], stop_loss=4169,
                 take_profit_offsets=[offset])
    assert validate_signal(sig, True, 0.05)


def test_backtest_and_live_relative_targets_use_the_same_entry_reference():
    from lordxau.backtest import SimBroker, SimConfig
    sim = SimBroker([(1000, 4162, 4162.1), (1001, 4155.9, 4156)],
                    SimConfig(sizing="fixed", auto_be={}, auto_tp={}))
    sim.advance(1000)
    eng = Engine(sim, EngineConfig(trade_ultra=True), clock=lambda: sim.now)
    run(eng.handle(LATEST, msg_id=90350, ts=1000))
    assert sim.pos[0]["tp"] == 4156
    sim.advance(1001)
    assert not sim.pos and sim.closed[0]["why"] == "TP"
