# -*- coding: utf-8 -*-
"""2.0.3: the engine on the message sequences the 4-week sync audit found handled
wrongly (real texts, by message id) - with the recording fake executor."""
from lordxau import settings as st_mod
from lordxau.backtest import _TEXT, _clean, SimBroker, SimConfig
from signal_trader.models import OrderType, Side, Signal
from test_backtest_settings import T0, ticks
from test_engine import feed, make, run


def execs(ex):
    return [c for c in ex.calls if c[0] == "execute"]


def test_zone_is_placed_at_once_and_takes_the_stop_when_it_comes():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau\n\nSell\n\nEnter:4190/4189")])
    assert execs(ex) == [("execute", "SELL", [4190.0, 4189.0], 4192.0, [], "lordxau", "LIMIT")]
    feed(eng, clk, [(5, "Stop:4191")])
    assert ex.calls[-1] == ("update_levels", 4191.0, ["v1"])


def test_stop_correction_moves_the_stop():                     # 88434 / 88435 / 88436
    eng, ex, clk = make()
    ex.mid = 4155.5
    feed(eng, clk, [(0, "Xau\n\nSell\n\nEnter:4157/4156"), (19, "Stop:4158")])
    assert ex.calls[-1] == ("update_levels", 4158.0, ["v1"])
    lines = feed(eng, clk, [(9, "Stop:4159")])
    assert ex.calls[-1] == ("update_levels", 4159.0, ["v1"]) and any("اصلاح استاپ" in l for l in lines)
    n = len(ex.calls)
    feed(eng, clk, [(3, "Stop:4159")])                          # the same stop again: nothing
    assert len(ex.calls) == n


def test_breakeven_before_the_fill_keeps_the_zone_at_breakeven():   # 85978 / 85979 / 85981
    eng, ex, clk = make(breakeven_at_zone=True)  # explicit legacy zone reference
    ex.mid = 4305.2
    lines = feed(eng, clk, [(0, "Xau\n\nBuy\n\nEnter:4304/4303"), (4, "Stop:4301"), (60, "فریش کن")])
    assert not [c for c in ex.calls if c[0] in ("breakeven", "cancel_virtual")]
    assert eng.setup.be_wait and any("می‌ماند" in l for l in lines)
    clk.t += 1
    run(eng.tick())                                             # still waiting: nothing
    assert not [c for c in ex.calls if c[0] == "breakeven"]
    ex.fill("v1")                                               # the leader's zone fills after his "فری"
    clk.t += 1
    lines = run(eng.tick())
    assert ex.calls[-1] == ("breakeven", ["v1"], 4304.0) and not eng.setup.be_wait
    assert eng.next_due() is None or eng.next_due() > clk.t + 1.5 or eng.reenter_due


def test_kept_zone_is_retried_until_the_fill_is_in_the_book_and_dropped_by_close():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192"), (30, "فریش کن")])
    ex.fill("v1")
    real = ex.breakeven

    async def not_yet(symbol, order_ids=None, ref_price=None):
        ex.calls.append(("breakeven", order_ids, ref_price))
        return {"action": "no_open_order"}
    ex.breakeven = not_yet
    clk.t += 1
    run(eng.tick())
    assert eng.setup.be_wait and eng.next_due() == clk.t + 1.0
    ex.breakeven = real
    clk.t += 1
    run(eng.tick())
    assert not eng.setup.be_wait
    # a kept zone that has not filled is dropped by "ببندش" / a new zone
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192"), (30, "فریش کن"), (20, "ببندش")])
    assert ("close", ["v1"]) in ex.calls
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192"), (30, "فریش کن"),
                    (20, "Xau Sell Enter:4186/4187")])
    assert ("cancel_virtual", ["v1"]) in ex.calls


def test_breakeven_cancels_a_pending_reentry():
    eng, ex, clk = make(reenter_wait_sec=60)
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192"), (60, "فری خورد بگیر باز")])
    assert eng.reenter_due is not None
    feed(eng, clk, [(10, "فریش کن")])
    assert eng.reenter_due is None
    clk.t += 70
    run(eng.tick())
    assert len(execs(ex)) == 1


def test_conditional_reentry_ends_with_close_or_a_new_zone():  # 85816 ... 85837
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192"), (30, "اگر فری خورد بگیر باز")])
    assert eng.if_be_armed is not None
    feed(eng, clk, [(20, "ببندش")])
    assert eng.if_be_armed is None
    feed(eng, clk, [(20, "فری خورد")])
    assert eng.reenter_due is None
    feed(eng, clk, [(20, "Xau Sell Enter:4190/4189"), (3, "اگر فری خورد بگیر باز"),
                    (20, "Xau Sell Enter:4188/4187")])
    assert eng.if_be_armed is None


def test_if_stop_touched_reenters_when_the_bot_was_stopped():   # 86436 ... 86441
    eng, ex, clk = make(reenter_wait_sec=60)
    ex.mid = 4368.0
    feed(eng, clk, [(0, "Xau\n\nBuy\n\nEnter:4366/4365"), (3, "Stop:4363")])
    ex.fill("v1")
    ex.alive.discard("v1")                                      # stopped at the broker
    lines = feed(eng, clk, [(50, "از دم استاپ برگشت بالا اگر با اسپرد استاپتون تاچ شده بگیرید باز")])
    assert eng.reenter_due is not None and any("ورود مجدد" in l for l in lines)
    clk.t += 61
    run(eng.tick())
    assert execs(ex)[-1][1:4] == ("BUY", [4366.0, 4365.0], 4363.0)


def test_if_stop_touched_is_armed_while_the_trade_is_open():
    eng, ex, clk = make(reenter_wait_sec=60)
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192")])
    ex.fill("v1")
    feed(eng, clk, [(30, "اگه استاپ تاچ کرد بگیر باز")])
    assert eng.if_sl_armed is not None and eng.reenter_due is None
    feed(eng, clk, [(40, "استاپ خورد")])
    assert eng.if_sl_armed is None and eng.reenter_due is not None


def test_late_stop_hit_reenters_nothing():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192")])
    ex.fill("v1")
    feed(eng, clk, [(30, "اگه استاپ تاچ کرد بگیر باز")])
    clk.t += 300
    run(eng.handle("استاپ خورد", msg_id=1, ts=clk.t - 250))    # a reconnect catch-up
    assert eng.reenter_due is None


def test_duplicate_zone_during_a_trade_is_kept_for_the_reentry():   # 87862 ... 87870
    eng, ex, clk = make(reenter_wait_sec=60)
    ex.mid = 4275.0
    feed(eng, clk, [(0, "Xau\n\nSell\n\nEnter:4277/4276")])
    ex.fill("v1")
    feed(eng, clk, [(12, "Stop:4279"), (38, "صبرکنید ده پیپ ورود ببرید بالا"),
                    (10, "Xau\n\nSell\n\nEnter:4277/4278"), (5, "Stop:4280")])
    assert len(execs(ex)) == 1                                   # never a second trade
    assert eng.setup.entries == [4277.0, 4278.0] and eng.setup.sl == 4280.0
    ex.alive.discard("v1")                                       # stopped out
    feed(eng, clk, [(120, "بگیر دوباره")])
    clk.t += 61
    run(eng.tick())
    assert execs(ex)[-1][1:4] == ("SELL", [4277.0, 4278.0], 4280.0)


def test_stop_posted_for_a_scheduled_reentry_is_used():         # 87754 ... 87758
    eng, ex, clk = make(reenter_wait_sec=60)
    ex.mid = 4281.0

    async def be(symbol, order_ids=None, ref_price=None):        # the waiting zone is dropped
        ex.calls.append(("breakeven", order_ids, ref_price))
        for i in order_ids or []:
            ex.pending.pop(int(str(i)[1:]), None)
            ex.alive.discard(i)
        return {"action": "pending_cancelled"}
    ex.breakeven = be
    feed(eng, clk, [(0, "Xau\n\nBuy\n\nEnter:4278/4277"), (5, "Stop:4276"), (41, "کشید بالا فریش کن"),
                    (97, "برگشت ورود فری خورد بگیر باز"), (53, "Stop:4275")])
    clk.t += 8
    run(eng.tick())
    assert execs(ex)[-1][1:4] == ("BUY", [4278.0, 4277.0], 4275.0)


def test_wait_drops_a_pending_reentry():                       # 87099 / 87100 / 87101
    eng, ex, clk = make(reenter_wait_sec=60)
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192"), (60, "اگر فری خورد بگیرید باز"),
                    (100, "فری خورد")])
    assert eng.reenter_due is not None
    feed(eng, clk, [(7, "صبر")])
    assert eng.reenter_due is None
    clk.t += 70
    run(eng.tick())
    assert len(execs(ex)) == 1


def test_wait_drops_a_zone_that_has_not_filled():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (20, "فعلا صبر")])
    assert ("cancel_virtual", ["v1"]) in ex.calls and eng.setup.done


def test_extension_moves_the_zone_edge():                       # 85849 / 85850 / 85851
    eng, ex, clk = make()
    ex.mid = 4348.4
    feed(eng, clk, [(0, "Xau\n\nBuy\n\nEnter:4346/4347"), (5, "Stop:4344"), (46, "48هم بود بگیر")])
    assert ("cancel_virtual", ["v1"]) in ex.calls
    assert execs(ex)[-1][1:4] == ("BUY", [4348.0, 4347.0], 4344.0)


def test_extension_never_moves_a_filled_zone_or_too_far():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau\n\nBuy\n\nEnter:4346/4347"), (5, "Stop:4344")])
    ex.fill("v1")
    feed(eng, clk, [(30, "48هم بود بگیر")])
    assert len(execs(ex)) == 1
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau\n\nBuy\n\nEnter:4346/4347"), (5, "Stop:4344"), (30, "52هم بود بگیر")])
    assert len(execs(ex)) == 1 and not [c for c in ex.calls if c[0] == "cancel_virtual"]


def test_missed_market_order_goes_further_than_a_late_one():    # 87906
    eng, ex, clk = make()
    ex.mid = 4268.5                                              # 2.5 below the SELL zone
    feed(eng, clk, [(0, "Xau\n\nSell\n\nEnter:4271/4272"), (4, "Stop:4274")])
    lines = feed(eng, clk, [(60, "جا‌موندی بپر تو")])
    assert not [c for c in ex.calls if c[0] == "market_now"] and any("دور است" in l for l in lines)
    feed(eng, clk, [(10, "نرسیدی قیمت مارکت بزن")])
    assert [c for c in ex.calls if c[0] == "market_now"] == [("market_now", "SELL", 4274.0)]


def test_missed_market_order_keeps_the_stop_and_distance_limits():   # 87957
    eng, ex, clk = make()
    ex.mid = 4265.9                                              # 1.9 past, but risk 6.9 > 6
    lines = feed(eng, clk, [(0, "Xau\n\nBuy\n\nEnter:4264/4263"), (4, "Stop:4259"),
                            (30, "اگر نرسید قیمت مارکت بزن")])
    assert not [c for c in ex.calls if c[0] == "market_now"] and any("ریسک" in l for l in lines)
    eng, ex, clk = make()
    ex.mid = 4268.4                                              # 4.4 past the zone
    feed(eng, clk, [(0, "Xau\n\nBuy\n\nEnter:4264/4263"), (4, "Stop:4261"), (30, "اگر نرسید قیمت مارکت بزن")])
    assert not [c for c in ex.calls if c[0] == "market_now"]


def test_sim_never_loosens_a_breakeven_stop():
    tk = ticks([(0, 4150.0), (20, 4152.0), (60, 4152.0)])
    sim = SimBroker(tk, SimConfig(auto_be={"lordxau": 1.5}))
    sim.advance(T0 + 1)
    run(sim.execute(Signal(symbol="XAUUSD", side=Side.BUY, order_type=OrderType.MARKET, entries=[4150.1],
                           stop_loss=4148.0, source="lordxau")))
    sim.advance(T0 + 30)                                        # +1.9: auto breakeven
    p = sim.pos[0]
    assert p.get("be") and p["sl"] == p["fill"]
    res = run(sim.update_levels(sl=4147.0, order_ids=[p["id"]]))
    assert res["action"] != "levels_updated" and p["sl"] == p["fill"]


def test_executor_never_loosens_a_breakeven_stop(tmp_path, monkeypatch):
    from types import SimpleNamespace
    import signal_trader.executors.fxtrendo as fxm
    monkeypatch.setattr(fxm, "PROJECT_ROOT", tmp_path)
    s = st_mod._deep_merge(st_mod.DEFAULTS, {})
    client = SimpleNamespace(wallet={"id": 7, "is_real": 0, "balance": 105.0}, wallet_data=None,
                             open_orders={}, balance=105.0)
    ex = fxm.FxTrendoExecutor(st_mod.broker_config(s), client=client)
    assert "breakeven" in ex._sl_update_reject(Side.BUY, 4150.0, 4150.0, 4147.0)
    assert "breakeven" in ex._sl_update_reject(Side.SELL, 4150.0, 4149.5, 4153.0)
    assert ex._sl_update_reject(Side.BUY, 4150.0, 4148.0, 4147.0) == ""      # widening a normal stop: allowed
    assert ex._sl_update_reject(Side.BUY, 4150.0, 4148.0, 4149.0) == ""      # tightening: allowed


def test_channel_page_reads_the_reply_not_the_quoted_message():
    html = ('<div class="tgme_widget_message_wrap"><a class="tgme_widget_message_reply" href="x">'
            '<div class="tgme_widget_message_text js-message_reply_text" dir="auto">Xau  Sell  Enter:4154/4155</div>'
            '</a><div class="tgme_widget_message_text js-message_text" dir="auto">ریخت فریش کن</div></div>')
    assert _clean(_TEXT.search(html).group(1)) == "ریخت فریش کن"
    plain = '<div class="tgme_widget_message_text js-message_text" dir="auto">Xau<br/><br/>Sell</div>'
    assert _clean(_TEXT.search(plain).group(1)) == "Xau\n\nSell"


def test_kept_zone_is_dropped_when_the_leader_reenters_with_a_new_stop():   # 87754 ... 87758 (round 3)
    eng, ex, clk = make(reenter_wait_sec=60)
    ex.mid = 4281.0
    feed(eng, clk, [(0, "Xau\n\nBuy\n\nEnter:4278/4277"), (5, "Stop:4276"), (41, "کشید بالا فریش کن")])
    assert eng.setup.be_wait and not [c for c in ex.calls if c[0] == "cancel_virtual"]
    feed(eng, clk, [(97, "برگشت ورود فری خورد بگیر باز")])
    assert ("cancel_virtual", ["v1"]) in ex.calls           # the kept zone is not the leader's re-entry
    feed(eng, clk, [(53, "Stop:4275")])
    clk.t += 8
    run(eng.tick())
    assert execs(ex)[-1][1:4] == ("BUY", [4278.0, 4277.0], 4275.0)


def test_kept_zone_is_dropped_on_breakeven_hit():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192"), (30, "فریش کن"), (60, "فری خورد")])
    assert ("cancel_virtual", ["v1"]) in ex.calls and not eng.live


def test_conditional_about_an_ultra_signal_leaves_the_scalp_zone_alone():   # 85555 (round 3)
    eng, ex, clk = make(reenter_wait_sec=60)
    ex.mid = 4283.0
    feed(eng, clk, [(0, "Xau Sell Enter:4284/4285"), (5, "Stop:4287")])
    ex.fill("v1")
    ex.alive.discard("v1")
    lines = feed(eng, clk, [(300, "Gold buy 4274_4269 Tp4281 Tp4291 Sl4265"),
                            (400, "هر ۲ ورود فعاله اگر استاپ بخوره دوباره بگیر هنوز نخورده")])
    assert eng.reenter_due is None and eng.if_sl_armed is None and any("ULTRA" in l for l in lines)
    feed(eng, clk, [(30, "اگر فری بخوره دوباره بگیر")])
    assert eng.if_be_armed is None
    clk.t += 70
    run(eng.tick())
    assert len(execs(ex)) == 1


def test_a_zone_refused_for_its_wide_stop_is_never_reentered():   # round 3
    eng, ex, clk = make(reenter_wait_sec=60, max_stop_pts=6.0)
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4191"), (5, "Stop:4199"), (40, "بگیر باز")])
    clk.t += 70
    run(eng.tick())
    assert len(execs(ex)) == 1 and ("cancel_virtual", ["v1"]) in ex.calls


def test_if_stop_touched_arms_when_the_order_state_is_unknown():   # live: order book reloading
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192")])
    ex.fill("v1")
    ex.trade_state = lambda ids: None
    feed(eng, clk, [(30, "اگه استاپ تاچ کرد بگیر باز")])
    assert eng.if_sl_armed is not None


def test_extension_keeps_the_breakeven_of_a_kept_zone_and_ignores_a_same_level_edit():   # round 3
    eng, ex, clk = make(breakeven_at_zone=True)  # explicit legacy zone reference
    ex.mid = 4349.0
    feed(eng, clk, [(0, "Xau\n\nBuy\n\nEnter:4346/4347"), (5, "Stop:4344"), (20, "فریش کن"),
                    (20, "48هم بود بگیر")])
    assert eng.setup.entries == [4348.0, 4347.0] and eng.setup.be_wait
    mid = eng.setup.msg_id
    n = len(ex.calls)
    run(eng.handle_edit("Xau\n\nBuy\n\nEnter:4346/4347\nStop:4344", msg_id=mid, ts=clk.t - 10))
    assert len(ex.calls) == n                                   # the extension is not undone
    ex.fill("v2")
    clk.t += 1
    run(eng.tick())
    assert ex.calls[-1] == ("breakeven", ["v2"], 4348.0)

