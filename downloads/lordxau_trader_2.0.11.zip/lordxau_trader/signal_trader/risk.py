"""Technical trading options: position sizing, allowlist, daily limits, hours.

All pure functions / small state holders so they can be unit-tested offline.

Sizing caveat: risk_pct sizing assumes the instrument is quoted in the wallet's
currency (or a near-1:1 one, e.g. USD-quoted gold in a EUR wallet). JPY-quoted
pairs are refused (fixed lot) because the maths would be ~150x off.
"""
from __future__ import annotations

import json
import math
import os
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from signal_trader.models import Signal

DEFAULT_CONTRACTS = {
    "XAUUSD": 100, "XAGUSD": 5000, "BTCUSD": 1, "ETHUSD": 1, "US30": 1, "NAS100": 1,
    "XTIUSD": 100, "USOIL": 100, "EURUSD": 100000, "GBPUSD": 100000, "USDJPY": 100000,
    "USDCAD": 100000, "USDCHF": 100000,
}


@dataclass
class RiskConfig:
    sizing: str = "fixed"            # fixed | risk_pct
    risk_pct: float = 1.0            # % of balance risked per trade (risk_pct mode)
    lot_step: float = 0.01
    min_lot: float = 0.01
    max_lot: float = 0.10
    contracts: dict = field(default_factory=lambda: dict(DEFAULT_CONTRACTS))
    allowed_symbols: list = field(default_factory=list)   # empty = all
    max_trades_per_day: int = 0      # 0 = unlimited
    max_daily_loss: float = 0.0      # account currency; 0 = off
    trading_hours: str = ""          # "HH:MM-HH:MM" local; empty = always
    split_take_profits: bool = False

    @classmethod
    def from_dict(cls, d: Optional[dict], max_lot: Optional[float] = None) -> "RiskConfig":
        d = d or {}
        cfg = cls(
            sizing=str(d.get("sizing", "fixed")).lower(),
            risk_pct=float(d.get("risk_pct", 1.0)),
            lot_step=float(d.get("lot_step", 0.01)),
            min_lot=float(d.get("min_lot", 0.01)),
            max_lot=float(max_lot if max_lot is not None else d.get("max_lot", 0.10)),
            allowed_symbols=[str(s).upper() for s in (d.get("allowed_symbols") or [])],
            max_trades_per_day=int(d.get("max_trades_per_day", 0) or 0),
            max_daily_loss=float(d.get("max_daily_loss", 0) or 0),
            trading_hours=str(d.get("trading_hours") or ""),
            split_take_profits=bool(d.get("split_take_profits", False)),
        )
        cfg.contracts.update({str(k).upper(): float(v) for k, v in (d.get("contracts") or {}).items()})
        if cfg.min_lot > cfg.max_lot:      # a config typo must never raise the cap
            cfg.min_lot = cfg.max_lot
        return cfg


def _round_step(x: float, step: float) -> float:
    if step <= 0:
        return x
    return math.floor(x / step + 1e-9) * step


def _clamp(cfg: RiskConfig, lot: float) -> float:
    """min_lot floor, then max_lot ceiling — max_lot always wins."""
    return round(min(max(lot, cfg.min_lot), cfg.max_lot), 4)


def compute_lot(cfg: RiskConfig, sig: Signal, balance: Optional[float],
                default_lot: float, fill: Optional[float] = None) -> tuple[float, str]:
    """Return (lot, note). lot == 0.0 means "refuse to trade" (note says why).

    Risk-based sizing needs balance, entry and SL. When the risk-sized lot is
    smaller than min_lot, min_lot is used only if that keeps the real risk
    within 3x the budget; otherwise the trade is refused instead of silently
    over-risking.

    The SL distance is the one the order can really lose: from ``fill`` (the
    live price a market order fills at) when known, else from the zone's entry
    FARTHEST from the stop (a zone fills anywhere inside it; entries[0] alone
    under-sized up to 1.55x, and a 4337/4346 BUY zone 4x - audit 2026-09-25).
    """
    fixed = _clamp(cfg, default_lot)
    if cfg.sizing != "risk_pct":
        return fixed, "fixed"
    if balance is None or balance <= 0:
        return fixed, "fixed (no balance yet)"
    if sig.stop_loss is None or (fill is None and not sig.entries):
        return fixed, "fixed (no entry/SL for risk sizing)"
    sym = (sig.symbol or "").upper()
    if sym.endswith("JPY"):
        return fixed, f"fixed (non-USD quote {sym}; risk sizing unsupported)"
    contract = cfg.contracts.get(sym)
    if contract is None:
        return fixed, f"fixed (no contract size for {sym})"
    if fill is not None:
        dist = abs(float(fill) - sig.stop_loss)
    else:
        dist = max(abs(float(e) - sig.stop_loss) for e in sig.entries)
    if dist <= 0:
        return fixed, "fixed (zero SL distance)"
    risk_amount = balance * cfg.risk_pct / 100.0
    lot = _round_step(risk_amount / (dist * float(contract)), cfg.lot_step)
    if lot < cfg.min_lot:
        actual_pct = cfg.min_lot * dist * float(contract) / balance * 100.0
        if actual_pct > cfg.risk_pct * 3:
            return 0.0, (f"rejected: min_lot {cfg.min_lot} would risk {actual_pct:.1f}% "
                         f"(> 3x the {cfg.risk_pct}% budget; SL dist {dist:g})")
        return _clamp(cfg, cfg.min_lot), (f"min_lot (actual risk {actual_pct:.1f}%, budget "
                                          f"{cfg.risk_pct}%, SL dist {dist:g})")
    out = _clamp(cfg, lot)
    return out, (f"risk {cfg.risk_pct}% of {balance:.0f} / SL dist {dist:g}"
                 + (f" (capped by max_lot: real risk {out * dist * float(contract) / balance * 100:.1f}%)"
                    if out < lot else ""))


def symbol_allowed(cfg: RiskConfig, symbol: Optional[str]) -> bool:
    if not cfg.allowed_symbols:
        return True
    return (symbol or "").upper() in cfg.allowed_symbols


def in_trading_hours(cfg: RiskConfig, now: Optional[datetime] = None) -> bool:
    if not cfg.trading_hours:
        return True
    try:
        a, b = cfg.trading_hours.split("-")
        h1, m1 = (int(x) for x in a.strip().split(":"))
        h2, m2 = (int(x) for x in b.strip().split(":"))
    except ValueError:
        return True  # malformed -> do not block
    now = now or datetime.now()
    cur = now.hour * 60 + now.minute
    start, end = h1 * 60 + m1, h2 * 60 + m2
    if start <= end:
        return start <= cur <= end
    return cur >= start or cur <= end  # overnight window


def split_volumes(total: float, n: int, lot_step: float, min_lot: float) -> list[float]:
    """Split ``total`` lots fairly across up to ``n`` orders.

    Every order is a whole number of lot_steps and at least max(min_lot,
    lot_step); the remainder goes to the first orders instead of being lost.
    Fewer than ``n`` orders are returned when the total cannot be split.
    """
    if n <= 1:
        return [round(total, 4)]
    floor = max(min_lot, lot_step)
    steps = int(round(total / lot_step))
    base, extra = divmod(steps, n)
    vols = [(base + 1) * lot_step] * extra + [base * lot_step] * (n - extra)
    vols = [round(v, 4) for v in vols if v >= floor - 1e-9]
    if vols:
        return vols
    k = int(total / floor + 1e-9)
    return [round(floor, 4)] * max(1, min(k, n))


@dataclass
class DailyGuard:
    """Counts trades per local day and watches a daily-loss ceiling.

    State is persisted to ``state_path`` (when given) so a restart mid-day does
    not reset the counter or re-baseline the loss limit.
    """
    max_trades: int = 0
    max_loss: float = 0.0
    state_path: Optional[str] = None
    day: str = ""
    trades: int = 0
    start_balance: Optional[float] = None
    # the wallet start_balance belongs to (None = not known yet). A DEMO
    # baseline must never judge the REAL wallet (9397 - 108 "lost" -> the
    # whole day blocked) nor the other way round - each wallet has its own.
    wallet: Optional[str] = None
    other_baselines: dict = field(default_factory=dict)

    def __post_init__(self):
        self._load()

    # -- persistence ----------------------------------------------------------
    def _load(self):
        if not self.state_path or not os.path.exists(self.state_path):
            return
        try:
            with open(self.state_path, "r", encoding="utf-8") as fh:
                st = json.load(fh)
            if st.get("day") == datetime.now().strftime("%Y-%m-%d"):
                self.day = st["day"]
                self.trades = int(st.get("trades", 0))
                sb = st.get("start_balance")
                self.start_balance = float(sb) if sb is not None else None
                w = st.get("wallet")
                self.wallet = str(w) if w is not None else None
                ob = st.get("other_baselines") or {}
                self.other_baselines = {str(k): float(v) for k, v in ob.items() if v is not None}
        except Exception:
            pass

    def _save(self):
        if not self.state_path:
            return
        try:
            with open(self.state_path, "w", encoding="utf-8") as fh:
                json.dump({"day": self.day, "trades": self.trades,
                           "start_balance": self.start_balance, "wallet": self.wallet,
                           "other_baselines": self.other_baselines}, fh)
        except Exception:
            pass

    # -- logic ----------------------------------------------------------------
    def _roll(self, now: Optional[datetime] = None):
        d = (now or datetime.now()).strftime("%Y-%m-%d")
        if d != self.day:
            self.day, self.trades, self.start_balance = d, 0, None
            self.other_baselines = {}
            self._save()

    def _switch_wallet(self, wallet) -> None:
        w = str(wallet)
        if w == self.wallet:
            return
        if self.wallet is not None and self.start_balance is not None:
            self.other_baselines[self.wallet] = self.start_balance
        # a baseline saved before wallets were recorded is of an unknown wallet:
        # never used for this one
        self.start_balance = self.other_baselines.pop(w, None)
        self.wallet = w
        self._save()

    def baseline(self, balance: Optional[float], now: Optional[datetime] = None,
                 wallet=None):
        """Record the day's starting balance once (first value seen today) -
        per ``wallet`` when it is given."""
        self._roll(now)
        if wallet is not None:
            self._switch_wallet(wallet)
        if balance is not None and self.start_balance is None:
            self.start_balance = balance
            self._save()

    def can_trade(self, balance: Optional[float], now: Optional[datetime] = None,
                  n: int = 1, equity: Optional[float] = None, wallet=None) -> tuple[bool, str]:
        """``n`` = how many orders are about to be sent; ``equity`` (if given)
        is used for the loss check so floating losses count."""
        self.baseline(balance, now, wallet)
        if self.max_trades and self.trades + n > self.max_trades:
            return False, f"daily trade limit reached ({self.trades}+{n} > {self.max_trades})"
        cur = equity if equity is not None else balance
        if (self.max_loss and cur is not None and self.start_balance is not None
                and (self.start_balance - cur) >= self.max_loss):
            basis = "equity" if equity is not None else "balance"
            return False, (f"daily loss limit reached ({self.start_balance - cur:.2f} >= "
                           f"{self.max_loss}, by {basis})")
        return True, ""

    def record_trade(self, now: Optional[datetime] = None, n: int = 1):
        self._roll(now)
        self.trades += n
        self._save()
