@echo off
chcp 65001 >nul
cd /d "%~dp0"
set PYTHONUTF8=1
echo Telegram login (only if the window says the session is not logged in)
python -m lordxau.login
pause
