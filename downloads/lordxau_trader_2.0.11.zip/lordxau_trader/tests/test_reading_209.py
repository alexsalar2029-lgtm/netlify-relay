# -*- coding: utf-8 -*-
"""Regression cases reproduced from the 2.0.8 code, without accounts/network."""
from types import SimpleNamespace

import pytest

from lordxau.engine import ULTRA_SOURCE
from lordxau.parse import BE, CLOSE, HINT, NOISE, STOP, ZONE, parse
from signal_trader.models import Side
from test_engine import feed, make, run


@pytest.mark.parametrize("text,kind,side", [
    ("🔴سل بگیر", HINT, "SELL"),
    ("📉سل بگیرید✅", HINT, "SELL"),
    ("🟢بای بگیر", HINT, "BUY"),
    ("سل،بگیر", HINT, "SELL"),
    ("سل رو بگیرید", HINT, "SELL"),
    ("بای الان بگیر", HINT, "BUY"),
    ("ریخت،فری کن", BE, None),
    ("✅فریش کنید", BE, None),
    ("فری بزن", BE, None),
    ("ریسک‌فری بزنید", BE, None),
    ("فریش کنش", BE, None),
    ("🛑ببندش", CLOSE, None),
    ("ببندشون", CLOSE, None),
    ("ببندینش", CLOSE, None),
    ("ببندیدشون الان", CLOSE, None),
    ("ببندید دوستان معامله رو همین الان کامل ببندید", CLOSE, None),
    ("ببندید لطفا دوستان همه پوزیشن ها رو کامل ببندید همین الان", CLOSE, None),
])
def test_direct_commands_with_decoration_and_inflections(text, kind, side):
    p = parse(text)
    assert (p.kind, p.side) == (kind, side)


@pytest.mark.parametrize("text,side,entries,sl", [
    ("Xau Sell Enter:4190/4189 SL:4192", "SELL", [4190, 4189], 4192),
    ("Xau Buy Entry:4190/4189 SL:4187", "BUY", [4190, 4189], 4187),
    ("طلا سل ورود:۴۱۹۰/۴۱۸۹ حدضرر:۴۱۹۲", "SELL", [4190, 4189], 4192),
    ("طلا بای ناحیه ورود:۴۱۸۹ تا ۴۱۹۰ حد ضرر:۴۱۸۷", "BUY", [4189, 4190], 4187),
    ("📉 XAUUSD\nSELL\nورود:۴٬۱۹۰/۴٬۱۸۹\nاستاپ لاس:۴٬۱۹۲", "SELL", [4190, 4189], 4192),
    ("Xau Sell Enter:4190/4189 Stop Loss:4192", "SELL", [4190, 4189], 4192),
    ("𝑿𝒂𝒖 𝑺𝒆𝒍𝒍 Enter:4190/4189 Stop:4192", "SELL", [4190, 4189], 4192),
    ("Xau Sell Enter:4190/4189 Stop:4192\n@lordxau", "SELL", [4190, 4189], 4192),
    ("Xau Sell Enter:4190/4189 Stop:4192\nhttps://t.me/lordxau", "SELL", [4190, 4189], 4192),
])
def test_labelled_scalps_remain_scalps(text, side, entries, sl):
    p = parse(text)
    assert p.kind == ZONE and not p.ultra
    assert (p.side, p.entries, p.sl) == (side, entries, sl)


@pytest.mark.parametrize("text", ["Stop Loss:4192", "حد ضرر:۴۱۹۲", "استاپ رو 4192 بزار", "استاپ لاس:4192",
                                   "Stop:4192 حتما"])
def test_explicit_stop_labels(text):
    p = parse(text)
    assert p.kind == STOP and p.sl == 4192


@pytest.mark.parametrize("text", [
    "Xau Sell Enter:4190/4189\nhttps://t.me/other_channel",
    "برای آموزش این سیگنال Xau Sell Enter:4190/4189 https://example.com",
    "ریسک فری نزنید",
    "گفتم فری بزن گوش نکردی",
    "ببندید وقتی به تارگت رسید دوستان معامله رو مدیریت کنید",
    "ببندید دوستان نه الان وقتی به سود رسید",
    "ببندشون؟",
    "سل بزنه میریزه",
    "بای بگیریم یا نه؟",
    "طلا سل ورود:۴۱۹۰/۴۱۸۹ حدضرر:۴۱۹۲؟",
    "Xau Sell Enter:4190/4189 SL:4192?",
])
def test_new_formats_do_not_turn_advice_questions_or_ads_into_orders(text):
    assert parse(text).kind == NOISE


def opened():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192")])
    ex.fill("v1")
    return eng, ex, clk


def restored():
    eng, ex, clk = make()
    ex.alive.update({41, 42, 99})
    ex.client = SimpleNamespace(
        bot_orders_of=lambda: {"lordxau": {"XAUUSD": [41]}, ULTRA_SOURCE: {"XAUUSD": [42]},
                              "other_channel": {"XAUUSD": [99]}},
        orders_for=lambda symbol: [{"id": 41, "type": 1}, {"id": 42, "type": 0}, {"id": 99, "type": 1}],
    )
    ex._order_side = lambda o: Side.SELL if o["type"] == 1 else Side.BUY
    return eng, ex, clk


def test_inline_sl_order_is_not_lost_with_ultra_disabled():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "🔴سل بگیر"), (5, "Xau Sell Enter:4190/4189 SL:4192")])
    assert ex.calls[-1] == ("execute", "SELL", [4190, 4189], 4192, [], "lordxau", "LIMIT")


def test_side_order_without_price_waits_for_channel_zone():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "🔴سل بگیر")])
    assert eng.hint[0] == "SELL" and not ex.calls


@pytest.mark.parametrize("action", ["refused", "no_open_order", "rejected"])
def test_failed_breakeven_is_not_recorded_as_done_and_is_retried(action):
    eng, ex, clk = opened()
    actual = ex.breakeven

    async def fail(*a, **kw):
        ex.calls.append(("breakeven", kw.get("order_ids"), kw.get("ref_price")))
        return {"action": action, "reason": "temporary broker error"}

    ex.breakeven = fail
    feed(eng, clk, [(5, "ریخت،فری کن")])
    assert not eng.setup.be and eng.be_retries
    ex.breakeven = actual
    clk.t += 5
    run(eng.tick())
    assert eng.setup.be and not eng.be_retries
    assert ex.calls[-1] == ("breakeven", ["v1"], None)  # default: actual broker fill


def test_breakeven_exception_uses_the_same_ids_and_can_recover():
    eng, ex, clk = opened()
    actual = ex.breakeven

    async def broken(*a, **kw):
        raise ConnectionError("offline")

    ex.breakeven = broken
    feed(eng, clk, [(5, "فری بزن")])
    assert not eng.setup.be and eng.next_due() == clk.t + 5
    ex.breakeven = actual
    clk.t += 5
    run(eng.tick())
    assert eng.setup.be and ex.calls[-1][1] == ["v1"]


def test_be_retry_does_not_protect_a_new_trade_after_the_old_one_closed():
    eng, ex, clk = opened()

    async def fail(*a, **kw):
        return {"action": "refused"}

    ex.breakeven = fail
    feed(eng, clk, [(1, "فری کن"), (1, "ببندش")])
    ex.calls.clear()
    clk.t += 5
    run(eng.tick())
    assert not eng.be_retries and not ex.calls


def test_be_retry_stops_after_one_minute():
    eng, ex, clk = opened()

    async def fail(*a, **kw):
        return {"action": "refused"}

    ex.breakeven = fail
    feed(eng, clk, [(1, "فری کن")])
    clk.t += 61
    lines = run(eng.tick())
    assert not eng.setup.be and not eng.be_retries and any("انجام نشد" in line for line in lines)


def test_failed_breakeven_after_a_late_fill_keeps_waiting_for_confirmation():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "فری کن")])
    actual = ex.breakeven
    ex.fill("v1")

    async def fail(*a, **kw):
        return {"action": "refused", "reason": "wallet loading"}

    ex.breakeven = fail
    clk.t += 1
    run(eng.tick())
    assert eng.setup.be_wait
    ex.breakeven = actual
    clk.t += 1
    run(eng.tick())
    assert eng.setup.be and not eng.setup.be_wait


@pytest.mark.parametrize("text,call", [("فری کن", "breakeven"), ("ببندشون", "close")])
def test_restored_orders_remain_manageable_after_a_new_order_was_refused(text, call):
    eng, ex, clk = restored()
    ex.next_action = "order_exists"
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, text)])
    assert ex.calls[-1][0:2] == (call, [41])  # other-channel and ULTRA ids untouched


def test_side_specific_close_after_restart_is_filtered_by_actual_order_side():
    eng, ex, clk = restored()
    feed(eng, clk, [(0, "سل ها ببندشون")])
    assert ex.calls[-1] == ("close", [41])
    assert ex.alive == {42, 99}


def test_restored_refused_close_is_retried_without_any_in_memory_setup():
    eng, ex, clk = restored()
    actual = ex.close

    async def fail(*a, **kw):
        return {"action": "refused", "reason": "temporary"}

    ex.close = fail
    feed(eng, clk, [(0, "ببندش")])
    assert eng.close_retry["ids"] == [41, 42]
    ex.close = actual
    clk.t += 5
    run(eng.tick())
    assert ex.calls[-1] == ("close", [41, 42]) and ex.alive == {99}
    assert eng.close_retry is None


def test_nested_rejected_close_ack_is_not_success():
    eng, ex, clk = opened()
    actual = ex.close

    async def fail(*a, **kw):
        return {"action": "close", "results": [{"action": "close", "results": [
            {"action": "rejected", "reason": "broker busy"}]}]}

    ex.close = fail
    lines = feed(eng, clk, [(5, "🛑ببندش")])
    assert eng.close_retry and not eng.setup.closed and not eng.setup.done
    assert not any("بسته شد" in line for line in lines)
    ex.close = actual
    clk.t += 5
    run(eng.tick())
    assert eng.close_retry is None and not eng.live


def test_sent_close_is_checked_again_while_the_order_is_still_open():
    eng, ex, clk = opened()
    actual = ex.close

    async def no_ack(*a, **kw):
        return {"action": "close", "results": [{"action": "emitted"}]}

    ex.close = no_ack
    feed(eng, clk, [(5, "ببندش")])
    assert eng.close_retry and eng.live
    ex.close = actual
    clk.t += 5
    run(eng.tick())
    assert eng.close_retry is None and not eng.live


@pytest.mark.parametrize("after_restart", [False, True])
def test_no_open_order_response_does_not_forget_a_trade_known_to_be_alive(after_restart):
    eng, ex, clk = restored() if after_restart else opened()
    actual = ex.close

    async def not_yet(*a, **kw):
        return {"action": "no_open_order"}

    ex.close = not_yet
    feed(eng, clk, [(1, "ببندش")])
    assert eng.close_retry is not None
    if not after_restart:
        assert not eng.setup.done and eng.live
    ex.close = actual
    clk.t += 5
    run(eng.tick())
    assert eng.close_retry is None
    assert ex.alive == ({99} if after_restart else set())


def test_stop_edited_in_telegram_updates_its_current_trade():
    eng, ex, clk = opened()
    stop_id = int(clk.t)
    clk.t += 2
    run(eng.handle_edit("Stop:4191", msg_id=stop_id, ts=clk.t - 2))
    assert ex.calls[-1] == ("update_levels", 4191, ["v1"])


def test_edit_of_old_stop_does_not_change_the_next_trade():
    eng, ex, clk = opened()
    stop_id = int(clk.t)
    ex.alive.clear()
    feed(eng, clk, [(2, "Xau Sell Enter:4187/4186")])
    before = list(ex.calls)
    run(eng.handle_edit("Stop:4189", msg_id=stop_id, ts=clk.t - 2))
    assert ex.calls == before


def test_edit_of_inline_sl_updates_the_stop_without_reopening_the_zone():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189 SL:4192")])
    zone_id = int(clk.t)
    ex.fill("v1")
    clk.t += 2
    run(eng.handle_edit("Xau Sell Enter:4190/4189 SL:4191", msg_id=zone_id, ts=clk.t - 2))
    assert ex.calls[-1] == ("update_levels", 4191, ["v1"])
    assert len([c for c in ex.calls if c[0] == "execute"]) == 1


def test_rejected_breakeven_does_not_block_a_later_channel_stop_update():
    eng, ex, clk = opened()

    async def fail(*a, **kw):
        return {"action": "refused"}

    ex.breakeven = fail
    feed(eng, clk, [(2, "فری کن"), (1, "Stop:4191")])
    assert ex.calls[-1] == ("update_levels", 4191, ["v1"])


def test_stale_skipped_messages_are_visible_on_the_dashboard():
    eng, ex, clk = make()
    events = []
    eng.on_event = events.append
    run(eng.handle("Xau Sell Enter:4190/4189", msg_id=1, ts=clk.t - 500))
    assert not ex.calls and events[-1]["kind"] == ZONE
    assert any("دیر رسید" in line for line in events[-1]["lines"])
