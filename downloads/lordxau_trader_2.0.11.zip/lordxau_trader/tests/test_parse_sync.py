# -*- coding: utf-8 -*-
"""2.0.3: every message the 4-week sync audit (2026-09-08..29, 3900 messages of the
channel, replayed on Trendo prices) found read wrongly - the real texts, by message id."""
import pytest

from lordxau.parse import (BE, BE_HIT, CLOSE, EXTEND, HINT, IF_BE_REENTER, IF_SL_REENTER, MARKET_NOW,
                           NOISE, REENTER, WAIT, ZONE, parse)


def test_zone_typo_entrt_and_double_separator():
    p = parse("Xau\n\nBuy\n\nEntrt:4143/4142")                       # 88599
    assert p.kind == ZONE and p.side == "BUY" and p.entries == [4143, 4142]
    p = parse("Xau\n\nSell\n\nEnter:4267/:4268")                     # 85367
    assert p.kind == ZONE and p.entries == [4267, 4268]


@pytest.mark.parametrize("text,side", [
    ("یه سل دیگه بزن", "SELL"),                                      # 85234, 85727, 86720, 88452
    ("یه سل دیگه بزن بدو", "SELL"),                                  # 85302, 87918
    ("یه بای دیگه بزن", "BUY"),                                      # 87954
    ("یه سل اسکلپ دیگه بزن", "SELL"),                                # 86811
    ("یه سل تر تمیز بزنید", "SELL"),                                 # 86888
])
def test_side_order_with_filler_words(text, side):
    p = parse(text)
    assert p.kind == HINT and p.side == side


@pytest.mark.parametrize("text,kind,side,also", [
    ("سل بگی باز", REENTER, "SELL", []),                             # 85511
    ("دم وروده. دوباره سل بزن", HINT, "SELL", [REENTER]),            # 85749 (round-2 audit)
    ("باز سل بزن", HINT, "SELL", [REENTER]),
    ("دوباره بای بزن", HINT, "BUY", [REENTER]),
    ("برگشت ورود دوباره بای بگیر", HINT, "BUY", [REENTER]),          # 85639
    ("ببببند", CLOSE, None, []),                                     # 85351
    ("هرجا حسابت سود شد ببند فشار فروش زیاده", NOISE, None, []),     # 85693: conditional, not an immediate close
    ("فریش کم", BE, None, []),                                       # 86508 (typo of "فریش کن")
    ("با ریسک فری برو جلو اذیت نشی", BE, None, []),                  # 84669
    ("اگر نبستی ریسک فری کن نگه دار", BE, None, []),                 # 84738
    ("فریش خورد", BE_HIT, None, []),                                 # 85880
])
def test_commands_found_in_the_audit(text, kind, side, also):
    p = parse(text)
    assert (p.kind, p.side, p.also) == (kind, side, also)


@pytest.mark.parametrize("text", [
    "اگر فری بخوره دوباره بگیر",                                     # 84671
    "اگر فری هم خورد میگیریم باز",                                   # 85349
    "اگر فری خوردی بگیر",                                            # 87537
    "اگر فری خورد بگیر باز",
])
def test_if_breakeven_hit_reenter(text):
    assert parse(text).kind == IF_BE_REENTER


@pytest.mark.parametrize("text", [
    "اگه استاپ تاچ کرد بگیر باز",                                    # 85750
    "اگه استاپ تاچ کرد بگیرید باز",                                  # 86438
    "از دم استاپ برگشت بالا اگر با اسپرد استاپتون تاچ شده بگیرید باز",  # 86441
    "اگر استاپ تاچ کرد میگیریم باز",                                 # 87430
    "اگر استاپ بزنه دوباره بای بگیر",                                # 84664
    "تا ۴۳ برگشت نشد اگر استاپ بخوره دوباره  بزن سل",                # 86787
])
def test_if_stop_hit_reenter(text):
    assert parse(text).kind == IF_SL_REENTER


@pytest.mark.parametrize("text,missed", [
    ("اگر نرسید مارکت بزن", True),                                   # 85372
    ("اگر نرسیدی نزدیکاش بزن", True),                                # 86527
    ("اگر نرسید قیمت مارکت بزن", True),                              # 87957
    ("نرسیدی قیمت مارکت بزن", True),                                 # 87906
    ("نرسیدی مارکت نزدیکش بگیر", True),                              # 88590
    ("جا‌موندی قیمت مارکت بزن. بین4357تا4355", False),               # 86476
    ("جا‌موندی بپر تو", False),                                      # 87977
])
def test_market_now_and_its_missed_flag(text, missed):
    p = parse(text)
    assert p.kind == MARKET_NOW and p.missed is missed


@pytest.mark.parametrize("text", [
    "صبر", "صبر میگم کجا بگیری", "میگم کجا بزنی", "صبر بعدی", "فعلا صبر",
    "صبرکنید ده پیپ ورود ببرید بالا", "رنجه از رنج خارج شه میگم‌کجا بزنی",
])
def test_wait(text):
    assert parse(text).kind == WAIT


def test_zone_extension():
    p = parse("48هم بود بگیر")                                       # 85851
    assert p.kind == EXTEND and p.price == 48


@pytest.mark.parametrize("text", [
    "برو سوپر مارکت بزن",                                            # 86171 (evening Q&A)
    "صبر درست میشه هر سختی بعدش خوشی هست!!!",
    "شکر خدا میترکونیمم صبر",
    "۴۸ رو فعال کرد تا ۴۳ ریخت هنگ کرد برگشت😒",
    "اگر بریزه بازم میخریم",
])
def test_still_chatter(text):
    assert parse(text).kind == NOISE


def test_gold_now_calls_stay_hints():
    assert (parse("GOLD BUY NOW").kind, parse("GOLD BUY NOW").side) == (HINT, "BUY")
    assert (parse("GOLD SELL").kind, parse("GOLD SELL").side) == (HINT, "SELL")


@pytest.mark.parametrize("text,not_kind", [
    ("Sell level: 4190", ZONE), ("Buy next: 4250", ZONE), ("sell exit: 4190", ZONE), ("ema: 4150 sell", ZONE),
    ("Stop level: 4190", ZONE),
    ("اگر استاپ خوردید ناراحت نباشید بعدی رو بزنید", IF_SL_REENTER),
    ("معامله قبلی با ریسک فری بسته شد", BE),
    ("صبر کنید ورود بخوره", WAIT),
])
def test_round3_chat_is_not_an_order(text, not_kind):
    assert parse(text).kind != not_kind


@pytest.mark.parametrize("text", ["باز سل بزنه میریزه", "مجدد سل بگیریم یا نه", "دوباره فروش بزنه فری میشه"])
def test_round3_again_needs_a_whole_verb(text):
    assert not parse(text).has(REENTER)


@pytest.mark.parametrize("text,side,entries", [
    ("Xau\n\nSell\n\nEnter;4081/4082", "SELL", [4081, 4082]),           # 77872 (3 months: 4 zones with ';')
    ("Xau\n\nSell\n\nEnter;4136/4137", "SELL", [4136, 4137]),           # 78186
    ("Xau:\n\nBuy\n\n4086/4085", "BUY", [4086, 4085]),                  # 80527: no word Enter
])
def test_three_month_zone_typos(text, side, entries):
    p = parse(text)
    assert p.kind == ZONE and p.side == side and p.entries == entries


@pytest.mark.parametrize("text", ["Xau Buy 4086", "Gold buy 4086/4085", "Xau;3961", "Xau/4071"])
def test_three_month_zone_typos_do_not_widen_the_zone_reading(text):
    assert parse(text).kind == NOISE
