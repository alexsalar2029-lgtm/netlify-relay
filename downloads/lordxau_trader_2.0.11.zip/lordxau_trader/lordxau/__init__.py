"""@lordxau follower: channel-specific parser + engine (rewritten 2026-09-28).

Only this channel is read and traded. The broker layer (Trendo client,
executor with virtual limits / breakeven guards, daily guard, fast Telegram
poll) is the proven package ``signal_trader`` kept from the original program.
"""

__version__ = "2.0.11"
CHANNEL = "lordxau"
SYMBOL = "XAUUSD"
