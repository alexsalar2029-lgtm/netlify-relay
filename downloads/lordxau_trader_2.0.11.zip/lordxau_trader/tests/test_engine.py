# -*- coding: utf-8 -*-
"""Engine behaviour with a recording fake executor (no broker, no network)."""
import asyncio

import pytest

from lordxau.engine import Engine, EngineConfig


class FakeEx:
    def __init__(self, mid=4187.0):
        self.calls = []
        self.mid = mid
        self.seq = 0
        self.pending = {}          # vid -> True while waiting
        self.alive = set()
        self.next_action = None
        self.firing = set()
        self.raise_next = 0
        self.mn_action = None

    async def execute(self, sig, *, _force_market=False):
        self.calls.append(("execute", sig.side.value, list(sig.entries), sig.stop_loss,
                           list(sig.take_profits), sig.source, sig.order_type.value))
        if self.raise_next:
            self.raise_next -= 1
            raise ConnectionError("broker down")
        if self.next_action:
            a, self.next_action = self.next_action, None
            return {"action": a, "reason": "test"}
        self.seq += 1
        self.pending[self.seq] = True
        self.alive.add(f"v{self.seq}")
        return {"action": "pending_virtual", "order_id": f"v{self.seq}", "orders": [{"order_id": f"v{self.seq}"}]}

    async def market_now(self, symbol, signal):
        self.calls.append(("market_now", signal.side.value, signal.stop_loss))
        if self.mn_action:
            return {"action": self.mn_action}
        self.seq += 1
        self.alive.add(self.seq)
        return {"action": "placed", "order_id": self.seq, "orders": [{"order_id": self.seq}]}

    async def close(self, symbol=None, order_id=None, fraction=1.0, close_all=False, order_ids=None):
        self.calls.append(("close", order_ids))
        if self.raise_next:
            self.raise_next -= 1
            raise ConnectionError("broker down")
        for i in order_ids or list(self.alive):
            self.alive.discard(i)
        return {"action": "close"}

    async def breakeven(self, symbol, order_ids=None, ref_price=None):
        self.calls.append(("breakeven", order_ids, ref_price))
        return {"action": "breakeven_virtual"}

    async def update_levels(self, symbol, sl=None, tp=None, order_ids=None):
        self.calls.append(("update_levels", sl, order_ids))
        return {"action": "levels_updated"}

    def cancel_virtual(self, symbol, ids, why=""):
        self.calls.append(("cancel_virtual", list(ids)))
        out = []
        for i in ids:
            if self.pending.pop(int(str(i)[1:]), None) and i not in self.firing:
                self.alive.discard(i)
                out.append({"order_id": i})
        return out

    def fill(self, vid):
        """The waiting zone vN filled: an open order now."""
        self.pending.pop(int(str(vid)[1:]), None)

    def trade_state(self, ids):
        return any(i in self.alive for i in ids)

    def virtual_orders(self):
        return {k: {} for k in self.pending}

    def live_quote_mid(self, symbol):
        return self.mid


class Clock:
    def __init__(self, t=1000.0):
        self.t = t

    def __call__(self):
        return self.t


def run(coro):
    return asyncio.run(coro)


def make(**kw):
    ex, clk = FakeEx(), Clock()
    return Engine(ex, EngineConfig(**kw), clock=clk), ex, clk


def feed(eng, clk, msgs):
    out = []
    for dt_, text in msgs:
        clk.t += dt_
        out += run(eng.handle(text, msg_id=int(clk.t)))
    return out


def test_zone_then_stop_places_once():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "سل بزن"), (20, "Xau\n\nSell\n\nEnter:4190/4189"), (8, "Stop:4192")])
    ex_calls = [c for c in ex.calls if c[0] == "execute"]
    assert ex_calls == [("execute", "SELL", [4190.0, 4189.0], 4192.0, [], "lordxau", "LIMIT")]


def test_no_stop_message_uses_default_after_wait():
    eng, ex, clk = make(stop_wait_sec=30, place_before_stop=False)
    feed(eng, clk, [(0, "Xau Sell  Enter:4185/4186")])
    assert not [c for c in ex.calls if c[0] == "execute"]
    clk.t += 31
    run(eng.tick())
    assert [c for c in ex.calls if c[0] == "execute"][0][3] == 4188.0


def test_stop_100_point_typo_is_corrected():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4292")])
    assert [c for c in ex.calls if c[0] == "execute"][0][3] == 4192.0


def test_stop_on_wrong_side_ignored():
    eng, ex, clk = make(place_before_stop=False)
    lines = feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4180")])
    assert not [c for c in ex.calls if c[0] == "execute"]
    assert any("نمی‌خواند" in l for l in lines)
    # placed at once: the default stop stays, nothing is edited
    eng, ex, clk = make()
    lines = feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4180")])
    assert [c[3] for c in ex.calls if c[0] == "execute"] == [4192.0]
    assert not [c for c in ex.calls if c[0] == "update_levels"]
    assert any("نمی‌خواند" in l for l in lines)


def test_wide_stop_refused():
    eng, ex, clk = make(max_stop_pts=6.0, place_before_stop=False)
    feed(eng, clk, [(0, "Xau Buy Enter:4150/4149"), (5, "Stop:4141")])
    assert not [c for c in ex.calls if c[0] == "execute"]
    # placed at once with the default stop: the waiting zone is cancelled
    eng, ex, clk = make(max_stop_pts=6.0)
    lines = feed(eng, clk, [(0, "Xau Buy Enter:4150/4149"), (5, "Stop:4141")])
    assert [c[3] for c in ex.calls if c[0] == "execute"] == [4147.0]
    assert ("cancel_virtual", ["v1"]) in ex.calls and any("لیمیت لغو شد" in l for l in lines)
    # ... unless it has filled: the trade keeps its (tighter) default stop
    eng, ex, clk = make(max_stop_pts=6.0)
    feed(eng, clk, [(0, "Xau Buy Enter:4150/4149")])
    ex.fill("v1")
    lines = feed(eng, clk, [(5, "Stop:4141")])
    assert not [c for c in ex.calls if c[0] in ("cancel_virtual", "update_levels", "close")]
    assert any("خیلی دور" in l for l in lines)


def test_breakeven_uses_zone_edge_and_scalp_ids():
    eng, ex, clk = make(keep_zone_on_be=False, breakeven_at_zone=True)
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192"), (30, "فریش کن")])
    assert ex.calls[-1] == ("breakeven", ["v1"], 4189.0)
    eng, ex, clk = make(breakeven_at_zone=True)  # explicit legacy zone reference
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192")])
    ex.fill("v1")
    feed(eng, clk, [(30, "فریش کن")])
    assert ex.calls[-1] == ("breakeven", ["v1"], 4189.0)


def test_close_targets_the_scalp():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192"), (60, "ببندش")])
    assert ex.calls[-1] == ("close", ["v1"])


def test_close_after_restart_closes_bot_orders_on_symbol():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "ببندش")])
    assert ex.calls[-1] == ("close", None)


def test_new_zone_drops_waiting_zone():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192"), (60, "Xau Sell Enter:4186/4187")])
    assert ("cancel_virtual", ["v1"]) in ex.calls


def test_reenter_waits_for_fresh_zone():
    eng, ex, clk = make(reenter_wait_sec=60)
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192"), (30, "فریش کن"), (60, "فری خورد بگیر باز")])
    ex.alive.clear()
    ex.pending.clear()
    feed(eng, clk, [(20, "Xau Sell Enter:4187/4188"), (5, "Stop:4190")])
    clk.t += 100
    run(eng.tick())
    execs = [c for c in ex.calls if c[0] == "execute"]
    assert [e[2] for e in execs] == [[4190.0, 4189.0], [4187.0, 4188.0]]      # the old zone never re-placed


def test_reenter_without_fresh_zone_replaces_old():
    eng, ex, clk = make(reenter_wait_sec=60)
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192"), (30, "فریش کن")])
    ex.alive.clear()
    ex.pending.clear()
    feed(eng, clk, [(30, "بگیر باز")])
    clk.t += 61
    run(eng.tick())
    execs = [c for c in ex.calls if c[0] == "execute"]
    assert len(execs) == 2 and execs[1][2] == [4190.0, 4189.0] and execs[1][3] == 4192.0


def test_conditional_reenter_fires_on_be_hit():
    eng, ex, clk = make(reenter_wait_sec=10)
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192"), (30, "اگر فری خورد بگیر باز")])
    ex.alive.clear()
    ex.pending.clear()
    feed(eng, clk, [(40, "فری خورد")])
    clk.t += 11
    run(eng.tick())
    assert len([c for c in ex.calls if c[0] == "execute"]) == 2


def test_market_now_only_near_the_zone():
    eng, ex, clk = make(market_now_max_past=1.0)
    ex.mid = 4186.0                         # 3 below a SELL zone at 4189
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192"), (20, "جا موندی قیمت مارکت نزدیکش بزن")])
    assert not [c for c in ex.calls if c[0] == "market_now"]
    ex.mid = 4188.5
    feed(eng, clk, [(5, "جا موندی بپر تو")])
    assert [c for c in ex.calls if c[0] == "market_now"] == [("market_now", "SELL", 4192.0)]


def test_ultra_off_by_default_and_reposts_ignored():
    eng, ex, clk = make()
    lines = feed(eng, clk, [(0, "Gold buy\n\n4145-4140\n\nTP 4162\nTP 4170\n\nSL 4135")])
    assert not ex.calls and any("ULTRA" in l for l in lines)
    assert feed(eng, clk, [(600, "Gold buy  4145-4140  TP 4162 TP 4170  SL 4135")]) == []


def test_ultra_on_uses_its_own_source():
    eng, ex, clk = make(trade_ultra=True)
    feed(eng, clk, [(0, "Gold buy\n\n4145-4140\n\nTP 4162\nTP 4170\n\nSL 4135")])
    assert ex.calls[0] == ("execute", "BUY", [4145.0, 4140.0], 4135.0, [4162.0], "lordxau_ultra", "LIMIT")
    feed(eng, clk, [(60, "بای ها کامل خروج بزن")])
    assert ex.calls[-1] == ("close", ["v1"])


def test_edit_that_fixes_a_cut_zone_is_a_new_zone():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau\n\nBuy\n\nEnter:4311/431")])
    lines = run(eng.handle_edit("Xau\n\nBuy\n\nEnter:4311/4310", msg_id=int(clk.t), ts=clk.t - 5, now=clk.t + 2))
    assert any("اصلاح" in l for l in lines)
    feed(eng, clk, [(4, "Stop:4308")])
    assert [c for c in ex.calls if c[0] == "execute"][0][2:4] == ([4311.0, 4310.0], 4308.0)


def test_reaction_edit_changes_nothing():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189")])
    mid = int(clk.t)
    feed(eng, clk, [(5, "Stop:4192")])
    n = len(ex.calls)
    run(eng.handle_edit("Xau Sell Enter:4190/4189", msg_id=mid, ts=clk.t, now=clk.t + 1))
    assert len(ex.calls) == n


def test_rejected_order_is_reported():
    eng, ex, clk = make()
    ex.next_action = "rejected"
    lines = feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192")])
    assert any("رد شد" in l for l in lines)


@pytest.mark.parametrize("text", ["سلام", "Xau:4185", "+80pip", "🌍🍬🛎🍬"])
def test_noise_is_silent(text):
    eng, ex, clk = make()
    assert feed(eng, clk, [(0, text)]) == [] and not ex.calls


def test_close_then_other_side_closes_the_open_scalp():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau Buy Enter:4186/4187"), (5, "Stop:4184")])
    ex.fill("v1")
    feed(eng, clk, [(60, "ببندش سلش بزن")])
    assert ("close", ["v1"]) in ex.calls


def test_late_messages_never_open_anything():
    eng, ex, clk = make()
    lines = run(eng.handle("Xau Sell Enter:4190/4189 Stop:4192", msg_id=5, ts=clk.t - 400))
    assert not ex.calls and any("دیر" in l for l in lines)


def test_late_close_leaves_a_newer_trade_alone():
    eng, ex, clk = make()
    run(eng.handle("Xau Sell Enter:4190/4189", msg_id=10, ts=clk.t))
    clk.t += 5
    run(eng.handle("Stop:4192", msg_id=11, ts=clk.t))
    ex.fill("v1")
    clk.t += 30
    run(eng.handle("ببندش", msg_id=9, ts=clk.t - 300))       # posted before the zone, delivered late
    assert not [c for c in ex.calls if c[0] == "close"]


def test_new_zone_keeps_the_open_trade_tracked():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192")])
    ex.fill("v1")                                              # the SELL is open
    feed(eng, clk, [(40, "بای بزن"), (10, "Xau Buy Enter:4186/4187"), (5, "Stop:4184")])
    feed(eng, clk, [(30, "فریش کن")])
    assert any(c[0] == "breakeven" and c[1] == ["v1"] for c in ex.calls)
    feed(eng, clk, [(30, "ببندش")])
    closes = [c for c in ex.calls if c[0] == "close"]
    assert closes and "v1" in closes[-1][1]


def test_zone_being_filled_is_not_marked_done():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192")])
    ex.firing.add("v1")                                        # the executor is sending it right now
    feed(eng, clk, [(20, "Xau Sell Enter:4185/4186"), (5, "Stop:4188")])
    ex.fill("v1")
    feed(eng, clk, [(30, "ببندش")])
    closes = [c for c in ex.calls if c[0] == "close"]
    assert closes and "v1" in closes[-1][1]


def test_market_now_refused_keeps_the_zone():
    eng, ex, clk = make()
    ex.mid = 4188.5
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192")])
    st = eng.setup
    ex.mn_action = "order_exists"
    feed(eng, clk, [(10, "جا موندی بپر تو")])
    assert eng.setup is st


def test_failed_placement_is_retried():
    eng, ex, clk = make()
    ex.raise_next = 1
    lines = feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192")])
    assert any("دوباره" in l for l in lines)
    clk.t += 6
    run(eng.tick())
    assert len([c for c in ex.calls if c[0] == "execute"]) == 2 and eng.setup.placed


def test_failed_close_is_retried():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192")])
    ex.fill("v1")
    ex.raise_next = 1
    feed(eng, clk, [(30, "ببندش")])
    clk.t += 6
    run(eng.tick())
    assert [c for c in ex.calls if c[0] == "close"] == [("close", ["v1"]), ("close", ["v1"])]
    assert eng.close_retry is None


def test_scalp_command_never_hits_ultra_when_the_scalp_was_refused():
    eng, ex, clk = make(trade_ultra=True)
    feed(eng, clk, [(0, "Gold buy\n\n4145-4140\n\nTP 4162\nTP 4170\n\nSL 4135")])
    ex.fill("v1")                                            # the ULTRA BUY is open
    ex.next_action = "skipped_max_open"
    feed(eng, clk, [(60, "Xau Sell Enter:4151/4152"), (5, "Stop:4154")])
    feed(eng, clk, [(30, "فریش کن"), (30, "ببندش")])
    assert not [c for c in ex.calls if c[0] in ("breakeven", "close")]


def test_ultra_breakeven_after_the_scalp_was_closed_by_the_channel():
    eng, ex, clk = make(trade_ultra=True)
    feed(eng, clk, [(0, "Gold buy\n\n4145-4140\n\nTP 4162\nTP 4170\n\nSL 4135")])
    ex.fill("v1")
    feed(eng, clk, [(60, "Xau Buy Enter:4150/4151"), (5, "Stop:4148")])
    ex.fill("v2")
    feed(eng, clk, [(60, "ببندش")])
    assert ex.calls[-1] == ("close", ["v2"])
    feed(eng, clk, [(600, "ریسک فری")])
    assert ex.calls[-1][:2] == ("breakeven", ["v1"])


def test_refused_close_keeps_the_trade_tracked_and_retries():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau Sell Enter:4190/4189"), (5, "Stop:4192")])
    ex.fill("v1")
    real_close = ex.close

    async def refused(*a, **k):
        ex.calls.append(("close", k.get("order_ids")))
        return {"action": "refused", "reason": "wallet"}
    ex.close = refused
    feed(eng, clk, [(30, "ببندش")])
    assert eng.close_retry is not None and any(s.ids == ["v1"] for s in eng.live)
    ex.close = real_close
    clk.t += 6
    run(eng.tick())
    assert ex.calls[-1] == ("close", ["v1"]) and eng.close_retry is None and not eng.live
