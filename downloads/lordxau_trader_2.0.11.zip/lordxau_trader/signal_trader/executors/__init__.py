"""Execution backends: turn a parsed Signal into an action."""
