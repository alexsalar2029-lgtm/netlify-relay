# -*- coding: utf-8 -*-
"""Live run: @lordxau (Telegram) -> Engine -> FxTrendoExecutor (Trendo).

One process, one channel. The GUI (lordxau_gui.py) runs a Runner in a worker
thread with its own asyncio loop; `python -m lordxau.runner` runs it in the
console.

Safety:
* one instance only: a machine-wide named mutex (any copy / folder of this
  program) plus data/lordxau.lock - two copies would open every trade twice;
* refuses to start while the previous program (telegram_signal_trader's gui.py /
  run.py) is running, and checks again every minute: both trade the same
  account and use the same Telegram session;
* one broker client per window: Stop -> Start reuses it (the broker allows one
  session per account), the new executor takes over the automatic breakevens;
* one Seen per window: a message handled before Stop is never traded again
  after Start;
* the Telegram session must already be authorized (copied from the previous
  program, or made once with login_telegram.bat) - no login prompt here;
* Stop: nothing new opens from the moment it is pressed (executor.retire),
  waiting zones are dropped; the open trades keep their stop / take profit at
  the broker.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any, Callable, Optional

from lordxau import CHANNEL, SYMBOL, __version__
from lordxau import settings as st_mod
from lordxau.engine import Engine

ROOT = st_mod.ROOT
log = logging.getLogger("signal_trader.lordxau")

_lock_fh = None
_mutex = None
MUTEX_NAME = "lordxau_trader_single_instance"


def _named_mutex() -> Optional[bool]:
    """Windows: True when this process holds the machine-wide mutex, False when
    another copy (any folder) holds it, None when it cannot be told."""
    global _mutex
    if os.name != "nt":
        return None
    if _mutex is not None:
        return True
    try:
        import ctypes
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.CreateMutexW.restype = ctypes.c_void_p
        for prefix in ("Global\\", "Local\\"):
            h = k32.CreateMutexW(None, False, prefix + MUTEX_NAME)
            err = ctypes.get_last_error()
            if not h:
                continue                                 # e.g. no right to create a Global object
            if err == 183:                               # ERROR_ALREADY_EXISTS
                k32.CloseHandle(ctypes.c_void_p(h))
                return False
            _mutex = h
            return True
    except Exception:  # noqa: BLE001
        return None
    return None


def acquire_lock(root: Path = ROOT) -> bool:
    """True when this is the only running copy (the lock is held until exit)."""
    global _lock_fh
    if _lock_fh is not None:
        return True
    if _named_mutex() is False:
        return False
    d = root / "data"
    d.mkdir(parents=True, exist_ok=True)
    fh = open(d / "lordxau.lock", "a+")
    try:
        if os.name == "nt":
            import msvcrt
            fh.seek(0)
            msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        fh.close()
        return False
    _lock_fh = fh
    return True


_OLD_CMD = re.compile(r"(?i)(?:^|[\s\\/\"'])(?:gui|run|scout_cli)\.py\b|signal_trader[./\\]app\b")


def is_old_cmd(cmd: str) -> bool:
    """A python command line of the previous program (never this one)."""
    cmd = cmd or ""
    return "lordxau" not in cmd.lower() and bool(_OLD_CMD.search(cmd))


def old_program_scan() -> Optional[dict]:
    """{"old": [pids of the previous program], "unknown": [python pids whose
    command line cannot be read]} - None when the process list could not be
    read at all. Windows only (elsewhere: nothing found)."""
    if os.name != "nt":
        return {"old": [], "unknown": []}
    ps = ("[Console]::OutputEncoding=[Text.Encoding]::UTF8; "
          "Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^pythonw?(\\d|\\.)*\\.exe$|^py\\.exe$' } | "
          "ForEach-Object { \"$($_.ProcessId)`t$($_.CommandLine)\" }")
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
                           capture_output=True, timeout=25,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception:  # noqa: BLE001
        return None
    out = (r.stdout or b"").decode("utf-8", "replace")
    me = os.getpid()
    rows = {}
    for line in out.splitlines():
        pid, _, cmd = line.partition("\t")
        try:
            rows[int(pid.strip())] = cmd.strip()
        except ValueError:
            continue
    if r.returncode != 0 or me not in rows:        # we are a python process too: a real list has us
        return None
    return {"old": [p for p, c in rows.items() if p != me and is_old_cmd(c)],
            "unknown": [p for p, c in rows.items() if p != me and not c]}


def old_program_pids() -> list:
    """PIDs of python processes running the previous program ([] when none or
    when it cannot be told - see old_program_scan)."""
    res = old_program_scan()
    return list(res["old"]) if res else []


def _load_env(root: Path) -> None:
    """(Re)read .env on every Start - a corrected file counts without closing the window."""
    try:
        from dotenv import load_dotenv
    except ImportError:
        load_dotenv = None
    path = root / ".env"
    if load_dotenv is not None and path.is_file():
        load_dotenv(path, override=True)
        return
    if path.is_file():                                   # minimal KEY=VALUE reader
        for raw in path.read_text(encoding="utf-8-sig", errors="replace").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ[k.strip()] = v.strip().strip('"').strip("'")


def _guards_open(ex) -> bool:
    """The executor still protects open trades in memory (automatic breakeven,
    breakeven guards, a breakeven edit being retried) - tied to its client."""
    if ex is None:
        return False
    # _be_closing / _be_deferred / _be_workers: a guard's close in flight - it re-arms if rejected
    for name in ("_auto_be", "_be_guards", "_be_retry", "_be_closing", "_be_deferred"):
        try:
            if getattr(ex, name, None):
                return True
        except Exception:  # noqa: BLE001
            return True
    try:
        return any(t.is_alive() for t in list(getattr(ex, "_be_workers", None) or []))
    except Exception:  # noqa: BLE001
        return True


def _client_key(cfg) -> str:
    """What the broker client is built from: a change needs a new client
    (kept in memory only, never logged)."""
    fx = cfg.fxtrendo or {}
    return json.dumps([fx.get("use_real_wallet"), fx.get("wallet_id"), fx.get("login"), fx.get("socket"),
                       fx.get("device"), fx.get("impersonate"), os.getenv("FXTRENDO_USERNAME"),
                       os.getenv("FXTRENDO_PASSWORD")], sort_keys=True, default=str)


def _creds_key(cfg) -> str:
    """_client_key without the wallet choice: the login / connection itself."""
    fx = cfg.fxtrendo or {}
    return json.dumps([fx.get("login"), fx.get("socket"), fx.get("device"), fx.get("impersonate"),
                       os.getenv("FXTRENDO_USERNAME"), os.getenv("FXTRENDO_PASSWORD")], sort_keys=True, default=str)


def same_account(client, cfg, creds_key: Optional[str]) -> bool:
    """``client`` (logged in with ``creds_key``) already trades the account
    ``cfg`` asks for: same login, same kind (REAL/DEMO) and - when a wallet id
    is given - the very same wallet."""
    if client is None or creds_key != _creds_key(cfg):
        return False
    fx = cfg.fxtrendo or {}
    if bool(getattr(client, "use_real", False)) != bool(fx.get("use_real_wallet")):
        return False
    wid = fx.get("wallet_id")
    if wid in (None, ""):
        return True
    live = getattr(client, "wallet", None) or {}
    return str(live.get("id")) == str(wid)


_TEHRAN_SEC = 3.5 * 3600                    # the leader's day ("برایند امروز"): Tehran, UTC+3:30


def tehran_day(ts: Optional[float] = None) -> str:
    return time.strftime("%Y-%m-%d", time.gmtime((time.time() if ts is None else ts) + _TEHRAN_SEC))


class Runner:
    def __init__(self, sink: Optional[Callable[[str], None]] = None, root: Path = ROOT):
        from signal_trader.fastpoll import Seen
        self.root = root
        self.sink = sink or (lambda line: print(line, flush=True))
        self.status: dict = {"running": False, "telegram": "—", "broker": "—", "wallet": "—",
                             "last_msg": None, "orders": 0, "llm": "—", "dashboard": None}
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self.broker = None
        self._broker_key: Optional[str] = None
        self.executor = None
        self.engine: Optional[Engine] = None
        self.settings: dict = {}
        self._seen = Seen()                  # ONE per window (fastpoll rule): no re-trade after Stop -> Start
        self._wallet_cache: list = []        # the wallets of the last login (kept when a client is dropped)
        self._execs: list = []               # earlier runs' executors on the current client (their guards)
        self.guard_poll_sec = 5.0            # account switch: how often the open-trade guards are checked
        self._closed_seen: set = set()       # bot orders whose close was already reported
        self._closed_lock = threading.Lock()
        self._unseen: set = set()            # bot orders reported as closed while disconnected
        self.llm_reader = None               # the gated LLM assistant (None = regex only, the proven 2.0.6 path)
        self.dashboard = None                # DashboardState while the live dashboard is on
        self._dash_srv = None                # its http server (127.0.0.1 only); kept across Stop -> Start
        self._dash_sym: Optional[str] = None # broker symbol used for the price() lookup
        self._dash_acct: Optional[tuple] = None  # (use_real, wallet_id) the dashboard is baselined to

    # ------------------------------------------------------------------ public
    def log(self, line: str) -> None:
        from signal_trader import filelog
        line = time.strftime("%H:%M:%S ") + str(line)
        filelog.gui_line(line)
        try:
            self.sink(line)
        except Exception:
            pass

    def start(self) -> bool:
        if self._thread is not None and self._thread.is_alive():
            return False
        self._stop.clear()
        self._thread = threading.Thread(target=self._thread_main, name="lordxau-runner", daemon=True)
        self._thread.start()
        return True

    def stop(self) -> None:
        """Nothing opens from now on: retire() needs no I/O and never raises."""
        self._stop.set()
        self._retire("توقف")

    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def wallets(self) -> list:
        """The account's wallets from the last broker login (for the window):
        [{id, is_real, balance, currency, active}]; [] before a login."""
        b = self.broker
        try:
            rows = list(getattr(b, "wallets", None) or []) if b is not None else list(self._wallet_cache)
            cur = (getattr(b, "wallet", None) or {}).get("id") if b is not None else None
            return [{"id": w.get("id"), "is_real": bool(w.get("is_real")), "balance": w.get("balance"),
                     "currency": w.get("currency") or "", "active": cur is not None and str(w.get("id")) == str(cur)}
                    for w in rows if isinstance(w, dict) and not w.get("is_archive")]
        except Exception:  # noqa: BLE001
            return []

    def _retire(self, why: str) -> None:
        ex = self.executor
        if ex is None or getattr(ex, "_retired", False):
            return
        for line in ex.retire(why):
            self.log(line)

    # ------------------------------------------------------------------ worker
    def _thread_main(self) -> None:
        self.status["running"] = True
        try:
            asyncio.run(self._main())
        except Exception as exc:  # never a silent death
            log.exception("runner crashed")
            self.log(f"❌ خطای غیرمنتظره: {exc!r}")
        finally:
            self.status["running"] = False
            self.status["telegram"] = "—"

    def _old_program_ok(self) -> bool:
        res = old_program_scan()
        if res is None:
            res = old_program_scan()                         # once more: PowerShell can be slow
        if res is None:
            self.log("⚠️ فهرست برنامه‌های در حال اجرا خوانده نشد — مطمئن شوید برنامهٔ قبلی "
                     "(telegram_signal_trader) بسته است؛ هر دقیقه دوباره بررسی می‌شود")
            return True
        if res["old"]:
            self.log(f"⛔ برنامهٔ قبلی (telegram_signal_trader) در حال اجراست (PID {', '.join(map(str, res['old']))}). "
                     "هر دو روی یک حساب معامله می‌کنند و یک نشست تلگرام دارند — اول پنجرهٔ برنامهٔ قبلی را ببندید، "
                     "بعد «شروع» را بزنید.")
            return False
        if res["unknown"]:
            self.log(f"⚠️ پایتون دیگری در حال اجراست که شناخته نشد (PID {', '.join(map(str, res['unknown']))}) — "
                     "اگر برنامهٔ قبلی است آن را ببندید")
        return True

    def _prepare(self) -> bool:
        from signal_trader import filelog
        filelog.setup(str(self.root / "logs"))
        self.log(f"LORD XAU Trader {__version__} — فقط کانال @{CHANNEL}، نماد {SYMBOL}")
        if not acquire_lock(self.root):
            self.log("⛔ یک نسخهٔ دیگر همین برنامه (در همین پوشه یا پوشهٔ دیگر) در حال اجراست — شروع نشد")
            return False
        if not self._old_program_ok():
            return False
        try:
            self.settings = st_mod.load(self.root, log=self.log)      # first run: imports the old program here
        except st_mod.SettingsError as exc:
            self.log(f"⛔ settings.json خراب است ({exc}) — اصلاحش کنید یا حذفش کنید "
                     "(حذف = برداشتن دوبارهٔ تنظیمات از برنامهٔ قبلی)")
            return False
        st_mod.sync_from_old(self.root, log=self.log, s=self.settings)
        fx = self.settings["fxtrendo"]
        src = st_mod.wallet_source(self.settings)
        kind = "واقعی (REAL)" if fx.get("use_real_wallet") else "دمو (DEMO)"
        wid = fx.get("wallet_id")
        self.log(f"حساب: {kind}" + (f" کیف‌پول {wid}" if wid not in (None, "") else "") + " — "
                 + {"user": "انتخاب‌شده در پنجره", "old_program": f"از برنامهٔ قبلی ({self.settings.get('imported_from')})"}
                 .get(src, "پیش‌فرض"))
        if src == "default":
            self.log("⚠️ برنامهٔ قبلی (telegram_signal_trader) پیدا نشد، پس حساب پیش‌فرض دمو است. "
                     "برای حساب واقعی از فهرست «حساب» بالای پنجره کیف‌پول REAL را انتخاب کنید.")
        _load_env(self.root)
        missing = [k for k in ("TG_API_ID", "TG_API_HASH") if not os.getenv(k)]
        if missing:
            self.log("⛔ فایل .env یا کلیدهای تلگرام (TG_API_ID / TG_API_HASH) پیدا نشد — پوشهٔ lordxau_trader را "
                     "داخل پوشهٔ telegram_signal_trader بگذارید، یا فایل .env برنامهٔ قبلی را کنار start.bat کپی کنید")
            return False
        fx = self.settings["fxtrendo"]
        if fx.get("enabled") and not fx.get("dry_run") and not (fx.get("order") or {}).get("event"):
            self.log("⛔ تنظیمات سفارش بروکر (fxtrendo.order.event) در settings.json نیست — سفارشی فرستاده نمی‌شد")
            return False
        if fx.get("enabled") and not fx.get("dry_run") and not (os.getenv("FXTRENDO_USERNAME")
                                                                and os.getenv("FXTRENDO_PASSWORD")):
            self.log("⛔ نام کاربری/رمز بروکر در .env نیست (FXTRENDO_USERNAME / FXTRENDO_PASSWORD)")
            return False
        return True

    def _drop_broker(self) -> None:
        """Retire the current client for good (its reconnect loop and watchdog too)."""
        prev, old = self.executor, self.broker
        if prev is not None:
            try:
                prev.stop_watchdog()
            except Exception:
                pass
        if old is not None:
            try:
                old._drop_socket()
            except Exception:
                try:
                    old.disconnect()
                except Exception:
                    pass
        for x in self._execs:
            try:
                x.stop_watchdog()
            except Exception:
                pass
        self.broker, self._broker_key, self._execs, self.executor = None, None, [], None

    def _guards_any(self) -> bool:
        """An executor on the current client (the live one or an earlier run's)
        still protects an open trade in memory."""
        return any(_guards_open(x) for x in [self.executor] + list(self._execs))

    # ------------------------------------------------------------ trade results
    def _trades_path(self) -> Path:
        return self.root / "logs" / "trades.jsonl"

    def _day_result(self, day: str, wallet) -> tuple:
        """(profit sum, closed count, count without a result) of the bot trades
        closed on ``day`` (Tehran) on ``wallet`` - one per order id; a later row
        with the broker's profit replaces a "closed while disconnected" one."""
        by: dict = {}
        try:
            with open(self._trades_path(), encoding="utf-8", errors="replace") as fh:
                for line in fh:
                    try:
                        r = json.loads(line)
                        if r.get("day") != day or str(r.get("wallet")) != str(wallet):
                            continue
                        if r.get("profit") is not None or r.get("id") not in by:
                            by[r.get("id")] = r
                    except (ValueError, TypeError, AttributeError):
                        continue
        except Exception:
            pass
        known = [float(r["profit"]) for r in by.values() if r.get("profit") is not None]
        return sum(known), len(by), len(by) - len(known)

    @staticmethod
    def _day_line(day: str, tot: float, n: int, unknown: int, cur: str) -> str:
        return (f"📊 نتیجهٔ امروز ربات (روز تهران {day}): {tot:+.2f} {cur} در {n} معامله"
                + (f" ({unknown} معامله بدون نتیجه — وقتی اتصال قطع بود بسته شد)" if unknown else ""))

    def _append_trade(self, row: dict) -> None:
        """Caller holds _closed_lock."""
        try:
            p = self._trades_path()
            p.parent.mkdir(parents=True, exist_ok=True)
            with open(p, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(row, ensure_ascii=False) + "\n")
        except OSError as exc:
            log.warning("trade journal not written: %s", exc)

    def _on_order_event(self, client, data: dict) -> None:
        """Socket thread (TrendoClient.on_order_event): one line for every bot
        order the broker reports closed (stop, take profit, breakeven, «ببند»)
        with the broker's own profit, then today's (Tehran) total - appended to
        logs/trades.jsonl. Never raises."""
        try:
            if not isinstance(data, dict) or data.get("close_time_current") in (0, None, "0", ""):
                return
            oid = int(data.get("id"))
            if oid not in set(getattr(client, "my_order_ids", ()) or ()):
                return
            with self._closed_lock:
                if oid in self._closed_seen:
                    return
                self._closed_seen.add(oid)
            profit = float(data.get("profit") or 0.0)
            w = getattr(client, "wallet", None) or {}
            cur = w.get("currency") or ""
            wd = data.get("wallet_data") if isinstance(data.get("wallet_data"), dict) else {}
            bal = wd.get("balance", getattr(client, "balance", None))
            side = {"0": "BUY", "1": "SELL"}.get(str(data.get("type")), str(data.get("type")))
            day = tehran_day()
            row = {"t": round(time.time(), 1), "day": day, "wallet": w.get("id"), "id": oid, "side": side,
                   "size": data.get("size"), "open": data.get("open"), "sl": data.get("sl"),
                   "tp": data.get("tp"), "profit": profit, "balance": bal, "currency": cur}
            with self._closed_lock:
                self._append_trade(row)
                tot, n, unk = self._day_result(day, w.get("id"))
            mark = "🟢" if profit > 0 else "🔴" if profit < 0 else "⚪"
            self.log(f"{mark} معامله بسته شد: {side} {SYMBOL} {data.get('size')} لات، ورود {data.get('open')}"
                     f" — نتیجه {profit:+.2f} {cur}" + (f" — موجودی {bal} {cur}" if bal is not None else ""))
            self.log(self._day_line(day, tot, n, unk, cur))
            if self.dashboard is not None:
                try:
                    lot = float(data.get("size") or 0.0)
                    entry = data.get("open")
                    exit_px = None
                    if lot > 0 and entry is not None:        # 1 price unit = lot*100 USD; recover the exit price
                        diff = profit / (lot * 100.0)
                        exit_px = round(float(entry) + (diff if side == "BUY" else -diff), 2)
                    self.dashboard.on_trade({"id": oid, "side": side, "fill": entry, "exit": exit_px,
                                             "lot": data.get("size"), "sl0": data.get("sl"), "tp": data.get("tp"),
                                             "usd": round(profit, 2), "balance": bal, "why": "بروکر"})
                except Exception:  # noqa: BLE001
                    pass
        except Exception:
            log.debug("order event report failed", exc_info=True)

    def _on_orders_vanished(self, client, ids) -> None:
        """Socket thread (TrendoClient.on_orders_vanished): bot orders missing
        from the order book after a reconnect - they closed while the link was
        down and the broker never sent their result. Never raises."""
        try:
            w = getattr(client, "wallet", None) or {}
            cur = w.get("currency") or ""
            bal = getattr(client, "balance", None)
            day = tehran_day()
            new = []
            with self._closed_lock:
                for oid in ids:
                    oid = int(oid)
                    if oid in self._closed_seen or oid in self._unseen:
                        continue
                    self._unseen.add(oid)
                    new.append(oid)
                    self._append_trade({"t": round(time.time(), 1), "day": day, "wallet": w.get("id"),
                                        "id": oid, "profit": None, "status": "closed_unseen",
                                        "balance": bal, "currency": cur})
                tot, n, unk = self._day_result(day, w.get("id"))
            for oid in new:
                self.log(f"⚪ معاملهٔ {oid} دیگر در بروکر باز نیست — وقتی اتصال قطع بود بسته شده و سود/زیانش "
                         f"نرسید" + (f" (موجودی فعلی {bal} {cur})" if bal is not None else ""))
            if new:
                self.log(self._day_line(day, tot, n, unk, cur))
        except Exception:
            log.debug("vanished order report failed", exc_info=True)

    async def _connect_broker(self, cfg) -> bool:
        from signal_trader.brokers.trendo_client import TrendoClient
        from signal_trader.executors.fxtrendo import FxTrendoExecutor
        fx = cfg.fxtrendo
        if not fx.get("enabled") or fx.get("dry_run"):
            self.log("⚠️ حالت آزمایشی (بدون ارسال سفارش) — در settings.json: enabled=true و dry_run=false")
        key = _creds_key(cfg)
        if self.broker is not None and not same_account(self.broker, cfg, self._broker_key):
            if self._guards_any():
                # breakeven guards only work on THIS client: never strand an open trade - switch after it
                self.status["broker"] = "منتظر پایان معاملهٔ باز"
                self.status["wallet"] = "در حال تعویض حساب"
                self.log("⏳ حساب عوض شده؛ معاملهٔ باز قبلی هنوز فری خودکار/گارد روی اتصال فعلی دارد — "
                         "تعویض حساب بعد از بسته شدن آن انجام می‌شود (تا آن موقع سیگنال تازه باز نمی‌شود)")
                while self._guards_any():
                    if self._stop.is_set():
                        self.status["broker"] = "—"
                        return False
                    await asyncio.sleep(self.guard_poll_sec)
            self.log("حساب/تنظیمات بروکر عوض شده — اتصال بروکر از نو ساخته می‌شود")
            self._drop_broker()
        fresh = False
        try:
            if self.broker is None:
                self.broker = TrendoClient(cfg)
                self._broker_key = key
                fresh = True
                self.log("اتصال به بروکر Trendo …")
                await asyncio.to_thread(self.broker.login)
            else:
                self.broker.ft = cfg.fxtrendo                 # lot limits etc. of the new settings
                if cfg.fxtrendo.get("wallet_id") not in (None, ""):
                    self.broker.wallet_id_cfg = cfg.fxtrendo.get("wallet_id")
                if self.broker.wallet is None or getattr(self.broker, "needs_relogin", False):
                    await asyncio.to_thread(self.broker.login)
            self._wallet_cache = list(getattr(self.broker, "wallets", None) or [])
            w = self.broker.wallet or {}
            kind = self.broker.wallet_kind()
            self.status["wallet"] = f"{kind} {w.get('balance')} {w.get('currency') or ''}".strip()
            self.log(f"✅ ورود به بروکر — کیف‌پول {kind} موجودی {w.get('balance')} {w.get('currency') or ''}")
            warn = getattr(self.broker, "wallet_warning", None)
            if warn:
                self.log("⚠️ " + str(warn))
            if not self.broker.is_alive():
                await asyncio.to_thread(self.broker.connect)
            self.broker.subscribe_prices([SYMBOL])
            self.status["broker"] = "متصل"
        except Exception as exc:
            self.status["broker"] = "خطا"
            self.log(f"⛔ اتصال بروکر ناموفق: {exc!r} (فایل .env در هر «شروع» دوباره خوانده می‌شود)")
            if getattr(self.broker, "wallets", None):
                self._wallet_cache = list(self.broker.wallets)   # the window can still offer them
            if fresh:
                self._drop_broker()                           # never a half-open second session
            # a reused client stays: the previous run's watchdog keeps reconnecting it and
            # its breakeven guards keep protecting the open trades; the next Start reuses it
            return False
        client = self.broker
        client.on_order_event = lambda data, c=client: self._on_order_event(c, data)
        client.on_orders_vanished = lambda ids, c=client: self._on_orders_vanished(c, ids)
        try:
            cw = getattr(client, "wallet", None) or {}
            tot, n, unk = self._day_result(tehran_day(), cw.get("id"))
            if n:
                self.log(self._day_line(tehran_day(), tot, n, unk, cw.get("currency") or "")
                         .replace("نتیجهٔ امروز ربات", "نتیجهٔ امروز ربات تا این لحظه", 1))
        except Exception:
            pass
        ex = FxTrendoExecutor(cfg, client=self.broker)
        ex.on_event = lambda line: self.log(f"[بروکر] {line}")
        n = ex.remember_orders(str(self.root / "data" / "bot_orders.json"))
        if n:
            self.log(f"♻️ {n} سفارش قبلی ربات شناخته شد (ببند / فری روی آن‌ها هم کار می‌کند)")
        prev = self.executor
        if prev is not None and prev is not ex:
            try:
                prev.stop_watchdog()
            except Exception:
                pass
            k = ex.adopt_auto_be(prev)
            if k:
                self.log(f"♻️ فری خودکار {k} معاملهٔ باز از اجرای قبلی ادامه دارد")
            self._execs.append(prev)              # its breakeven guards stay on this client
        self._execs = [x for x in self._execs if _guards_open(x)]
        self.executor = ex
        return True

    # ----------------------------------------------------------- LLM + dashboard
    def _setup_llm(self) -> None:
        """Attach the gated LLM assistant to the engine when settings.llm.enabled AND a key exists; otherwise the
        engine stays regex-only. Never raises (a broken LLM must never stop trading)."""
        reader = None
        try:
            reader = st_mod.build_llm_reader(self.settings, self.root, log=self.log)
        except Exception as exc:  # noqa: BLE001
            self.log(f"⚠️ راه‌اندازی LLM ناموفق ({type(exc).__name__}) — ربات فقط با regex کار می‌کند")
        self.llm_reader = reader
        if reader is not None and self.engine is not None:
            self.engine.llm = reader.classify            # engine consults it only on NOISE while a trade is open
            # hard cap on one consult under the engine lock: the reader's own wall-clock budget + 1s margin, so a
            # hung provider (DNS / slow body) cannot freeze the next message / timer for more than ~that long.
            self.engine.llm_hard_timeout = float(getattr(reader, "max_total", None) or 4.0) + 1.0
            self.status["llm"] = "روشن"
        else:
            if self.engine is not None:
                self.engine.llm = None
                self.engine.llm_hard_timeout = None
            self.status["llm"] = "خاموش"

    def _dash_balance0(self) -> float:
        try:
            return float((getattr(self.broker, "wallet", None) or {}).get("balance") or 105.0)
        except Exception:  # noqa: BLE001
            return 105.0

    def _setup_dashboard(self) -> None:
        """Start (once) the local live dashboard and point the new engine's events at it. Reused across
        Stop -> Start (one server per window). Never raises."""
        dcfg = st_mod.dashboard_config(self.settings)
        if not dcfg.get("enabled"):
            self.status["dashboard"] = None
            return
        try:
            from lordxau.dashboard import DashboardState, start_server
        except Exception as exc:  # noqa: BLE001
            self.log(f"⚠️ داشبورد در دسترس نیست ({type(exc).__name__})")
            return
        try:
            self._dash_sym = self.broker.broker_symbol(SYMBOL) if self.broker is not None else SYMBOL.lower()
            real = bool(self.settings["fxtrendo"].get("use_real_wallet"))
            src = "بروکر Trendo" + ("" if real else " (دمو)")
            acct = (real, (self.settings["fxtrendo"].get("wallet_id") or None))
            if self.dashboard is None:
                self.dashboard = DashboardState(balance0=self._dash_balance0(), source_price=src)
            elif acct != self._dash_acct:        # a wallet / REAL-DEMO switch: re-baseline P/L and label, clear the
                self.dashboard.reset(balance0=self._dash_balance0(), price_label=src)  # previous account's session
            self._dash_acct = acct
            if self.engine is not None:
                self.engine.on_event = self.dashboard.on_message       # re-point to the new engine every Start
            if self._dash_srv is None:
                self._dash_srv = start_server(self.dashboard, port=int(dcfg.get("port") or 8799),
                                              host=str(dcfg.get("host") or "127.0.0.1"), log=self.log)
            self.status["dashboard"] = f"http://{dcfg.get('host', '127.0.0.1')}:{int(dcfg.get('port') or 8799)}"
            if dcfg.get("open_browser"):
                self.open_dashboard()
        except Exception as exc:  # noqa: BLE001
            self.log(f"⚠️ داشبورد باز نشد ({type(exc).__name__}) — بدون داشبورد ادامه داد")

    def dashboard_url(self) -> Optional[str]:
        d = self.status.get("dashboard")
        return d if isinstance(d, str) else None

    def open_dashboard(self) -> Optional[str]:
        """Open the live dashboard in the default browser. Returns its URL, or None when it is not running yet
        (the dashboard starts with trading, so press «شروع» first)."""
        url = self.dashboard_url()
        if url:
            try:
                import webbrowser
                webbrowser.open(url)
            except Exception:  # noqa: BLE001
                pass
        return url

    def _dash_positions(self) -> list:
        """The bot's open trades on the broker, as the dashboard draws them. Best-effort, never raises."""
        b = self.broker
        if b is None:
            return []
        try:
            mine = {str(m) for m in (getattr(b, "my_order_ids", ()) or ())}
            out = []
            for o in b.orders_for(SYMBOL):
                oid = o.get("id")
                if mine and str(oid) not in mine:
                    continue
                side = {"0": "BUY", "1": "SELL"}.get(str(o.get("type")), str(o.get("type")))
                out.append({"id": str(oid), "side": side, "state": "open", "fill": o.get("open"),
                            "sl": o.get("sl"), "tp": o.get("tp"), "lot": o.get("size"), "be": None,
                            "edge": None, "entries": [], "opened": None})
            return out
        except Exception:  # noqa: BLE001
            return []

    async def _main(self) -> None:
        if not self._prepare():
            return
        cfg = st_mod.broker_config(self.settings)
        if not await self._connect_broker(cfg):
            return
        if self._stop.is_set():                               # Stop pressed while connecting
            self._retire("توقف")
            self.log("⏹ متوقف شد")
            return
        ecfg = st_mod.engine_config(self.settings)
        self.engine = Engine(self.executor, ecfg)
        self._setup_llm()
        self._setup_dashboard()
        self.log("تنظیمات موتور: " + ", ".join(f"{k}={getattr(ecfg, k)}" for k in (
            "trade_scalp", "trade_ultra", "place_before_stop", "default_stop_pts", "stop_wait_sec",
            "max_stop_pts", "reenter_wait_sec", "market_now_max_past", "market_now_missed_max_past",
            "breakeven_at_zone"))
            + f"، فری کانال روی {'ناحیهٔ کانال (روش قبلی)' if ecfg.breakeven_at_zone else 'ورود واقعی ربات'}، "
            + f"فری خودکار {self.settings.get('auto_breakeven_points')} واحد، "
            + f"حد سود خودکار {st_mod.take_profit_points(self.settings) or 'خاموش'} واحد، "
            + f"ریسک {cfg.risk.get('risk_pct')}% ({cfg.risk.get('sizing')})، "
            + f"حد ضرر روزانه {cfg.risk.get('max_daily_loss')}")
        try:
            await self._telegram()
        finally:
            self._retire("توقف")
            self.log("⏹ متوقف شد — معامله‌های باز با استاپ/تی‌پی خودشان در بروکر می‌مانند")

    async def _telegram(self) -> None:
        from telethon import TelegramClient, errors, events

        from signal_trader.fastpoll import ChannelPoller, MessageRouter
        tg = self.settings["telegram"]
        session = str(self.root / str(tg.get("session_name") or "signal_trader"))
        client = TelegramClient(session, int(os.getenv("TG_API_ID") or 0), os.getenv("TG_API_HASH") or "")
        self.status["telegram"] = "در حال اتصال"
        await client.connect()
        on_new = on_edit = None
        try:
            if not await client.is_user_authorized():
                self.status["telegram"] = "وارد نشده"
                self.log("⛔ نشست تلگرام وارد نشده — یک بار login_telegram.bat را اجرا کنید")
                return
            entity = await client.get_entity(CHANNEL)
            me = await client.get_me()
            self.status["telegram"] = "متصل"
            self.log(f"✅ تلگرام: «{getattr(me, 'first_name', None) or getattr(me, 'username', '?')}» — "
                     f"گوش دادن به @{CHANNEL}")

            def sink(_key: str, line: str) -> None:
                self.log(line)

            router = MessageRouter(self.engine, sink, seen=self._seen)
            stop = self._stop.is_set

            def parts(event):
                msg = getattr(event, "message", None)
                ts = msg.date.timestamp() if msg is not None and getattr(msg, "date", None) else None
                return event.raw_text or "", ts

            async def on_new(event):
                if stop():
                    return
                text, ts = parts(event)
                self.status["last_msg"] = time.time()
                await router.new(CHANNEL, event.id, ts, text)

            async def on_edit(event):
                if stop():
                    return
                text, ts = parts(event)
                await router.edit(CHANNEL, event.id, ts, text)

            client.add_event_handler(on_new, events.NewMessage(chats=entity))
            client.add_event_handler(on_edit, events.MessageEdited(chats=entity))

            async def poll_new(key, msg_id, ts, text, recv=None):
                if stop():
                    return
                self.status["last_msg"] = time.time()
                await router.new(key, msg_id, ts, text, recv=recv)

            async def poll_edit(*a, **k):
                if stop():
                    return
                await router.edit(*a, **k)

            poller = ChannelPoller(client, lambda: {CHANNEL: "@" + CHANNEL}, poll_new, poll_edit,
                                   interval=float(tg.get("fast_poll_sec") or st_mod.FAST_POLL[0]),
                                   on_line=lambda l: self.log(f"[تلگرام] {l}"),
                                   edit_max_age=300.0,
                                   max_wait=float(tg.get("fast_poll_max_wait_sec") or st_mod.FAST_POLL[1]))
            tasks = [asyncio.ensure_future(poller.run(stop)),
                     asyncio.ensure_future(self._ticker(stop)),
                     asyncio.ensure_future(self._reporter(stop, router)),
                     asyncio.ensure_future(self._guard(stop))]
            fails, next_try = 0, 0.0
            while not stop():
                if not client.is_connected() and time.time() >= next_try:
                    if not await self._reconnect(client, errors):
                        fails += 1
                        next_try = time.time() + min(60.0, 2.0 * fails)
                    else:
                        fails = 0
                await asyncio.sleep(0.3)
            # Stop: no handler may reach the engine any more, nothing opens (retire), then tidy up
            client.remove_event_handler(on_new)
            client.remove_event_handler(on_edit)
            self._retire("توقف")
            for t in tasks:
                t.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            await router.drain(timeout=10.0)
        finally:
            self.status["telegram"] = "—"
            for h in (on_new, on_edit):
                if h is not None:
                    try:
                        client.remove_event_handler(h)
                    except Exception:
                        pass
            try:
                await client.disconnect()
            except Exception:
                pass

    async def _reconnect(self, client, errors) -> bool:
        """Telegram dropped: reconnect, and report 'connected' only when the
        session is really still authorized (a revoked session ends the run)."""
        err = getattr(client, "_updates_error", None)
        if isinstance(err, (errors.UnauthorizedError, errors.AuthKeyError)):
            self.status["telegram"] = "وارد نشده"
            self.log("⛔ نشست تلگرام باطل شد (از گوشی خارج شده یا جای دیگری هم استفاده شده) — "
                     "login_telegram.bat را اجرا کنید؛ ربات متوقف شد")
            self._stop.set()
            self._retire("نشست تلگرام باطل شد")
            return False
        self.status["telegram"] = "قطع — اتصال دوباره"
        try:
            await client.connect()
            me = await client.get_me()
        except (errors.UnauthorizedError, errors.AuthKeyError):
            me = None
        except Exception as exc:  # noqa: BLE001
            self.log(f"[تلگرام] اتصال دوباره ناموفق: {exc!r}")
            return False
        if me is None:
            self.status["telegram"] = "وارد نشده"
            self.log("⛔ نشست تلگرام دیگر وارد نیست — login_telegram.bat را اجرا کنید؛ ربات متوقف شد")
            self._stop.set()
            self._retire("نشست تلگرام باطل شد")
            return False
        self.status["telegram"] = "متصل"
        self.log("[تلگرام] دوباره وصل شد")
        return True

    async def _guard(self, stop: Callable[[], bool]) -> None:
        """Every minute: the previous program must not have been started meanwhile."""
        while not stop():
            for _ in range(60):
                if stop():
                    return
                await asyncio.sleep(1.0)
            res = await asyncio.to_thread(old_program_scan)
            if res and res["old"]:
                self.log(f"⛔ برنامهٔ قبلی دوباره باز شد (PID {', '.join(map(str, res['old']))}) — "
                         "این برنامه متوقف شد تا هر معامله دو بار باز نشود")
                self._stop.set()
                self._retire("برنامهٔ قبلی باز شد")
                return

    async def _ticker(self, stop: Callable[[], bool]) -> None:
        """Engine timers (default stop, delayed re-entry) + the status line."""
        while not stop():
            try:
                for line in await self.engine.tick():
                    self.log(line)
                    from signal_trader import filelog
                    filelog.decision({"type": "timer", "t": time.time(), "lines": [line]})
                ex = self.executor
                if ex is not None:
                    try:
                        self.status["orders"] = len(ex.open_bot_ids(SYMBOL)) if ex.live else 0
                    except Exception:
                        pass
                    w = getattr(self.broker, "wallet", None) or {}
                    if w:
                        self.status["wallet"] = (f"{self.broker.wallet_kind()} {w.get('balance')} "
                                                 f"{w.get('currency') or ''}").strip()
                    self.status["broker"] = "متصل" if getattr(self.broker, "is_alive", lambda: False)() else "قطع"
                self._feed_dashboard()
            except Exception as exc:
                log.warning("tick failed: %r", exc)
            await asyncio.sleep(1.0)

    def _feed_dashboard(self) -> None:
        """Once a second: the latest broker quote, the open trade, balance and the status line -> the dashboard.
        Never raises (the dashboard must never affect trading)."""
        d = self.dashboard
        if d is None:
            return
        try:
            q = self.broker.price(self._dash_sym) if (self.broker is not None and self._dash_sym) else None
            live = bool(q and q[0] is not None and q[1] is not None)
            if live:
                d.push_tick(float(q[0]), float(q[1]))
            d.set_positions(self._dash_positions())
            w = getattr(self.broker, "wallet", None) or {}
            if w.get("balance") is not None:
                d.set_balance(float(w["balance"]))
            d.set_feed(telegram=self.status.get("telegram"), broker=self.status.get("broker"),
                       wallet=self.status.get("wallet"), market="باز" if live else "—")
        except Exception:  # noqa: BLE001
            pass

    async def _reporter(self, stop: Callable[[], bool], router: Any) -> None:
        last = time.time()
        while not stop():
            await asyncio.sleep(5.0)
            if time.time() - last >= 3600:
                last = time.time()
                line = router.latency_line()
                if line:
                    self.log(f"[تلگرام] {line}")


def main() -> int:
    r = Runner()
    r.start()
    try:
        while r.running():
            time.sleep(0.5)
    except KeyboardInterrupt:
        r.stop()
        while r.running():
            time.sleep(0.5)
    return 0


if __name__ == "__main__":
    sys.exit(main())
