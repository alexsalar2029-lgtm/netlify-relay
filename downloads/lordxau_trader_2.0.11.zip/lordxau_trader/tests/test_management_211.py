# -*- coding: utf-8 -*-
"""2.0.11 management regressions through the real engine/executor boundary.

The recording client cannot log in, connect, or contact a broker. Its order
book and quotes reproduce the audited fill/zone mismatch and rejected edits.
"""
import threading
from types import SimpleNamespace

import pytest

from lordxau.backtest import SimBroker, SimConfig
from lordxau.engine import Engine, EngineConfig
from signal_trader.executors.fxtrendo import FxTrendoExecutor
from signal_trader.risk import DailyGuard
from test_engine import Clock, run


CASES = [
    ("SELL", (4183.42, 4183.52), (4181.90, 4182.00), (4183.60, 4183.70), (4183.42, 4183.52), 4187.0),
    ("BUY", (4185.48, 4185.58), (4187.00, 4187.10), (4185.30, 4185.40), (4185.48, 4185.58), 4181.0),
]


class RecordingManagementClient:
    connected = True
    use_real = False

    def __init__(self, quote):
        self.quote, self.age = quote, 0.0
        self.wallet = {"id": "test-demo", "is_real": False, "balance": 1000.0}
        self.wallet_data = {"balance": 1000.0, "equity": 1000.0}
        self.open_orders, self.my_order_ids = {}, set()
        self._placed = {}
        self._orders_ready = threading.Event()
        self._orders_ready.set()
        self.calls, self.listeners = [], []
        self.modify_reply = None
        self.stop_level = 0.1

    def login(self):
        raise AssertionError("network login must never happen")

    connect = disconnect = login

    def broker_symbol(self, symbol):
        return symbol.lower()

    def price(self, symbol):
        return self.quote

    def price_age(self, symbol):
        return self.age

    def props_for(self, symbol):
        return {"digits": 2, "stop_level": self.stop_level}

    def orders_for(self, symbol):
        return [o for o in self.open_orders.values()
                if symbol is None or o["symbol"].upper() == symbol.upper()]

    def bot_orders_of(self):
        return {"lordxau": {"XAUUSD": [41]}}

    def add_price_listener(self, listener):
        self.listeners.append(listener)

    def subscribe_prices(self, symbols):
        pass

    def place_order(self, signal, *, dry_run, lot, tp):
        assert not dry_run
        fill = self.quote[1] if signal.side.value == "BUY" else self.quote[0]
        self.calls.append(("place", 41, fill, signal.stop_loss))
        self.my_order_ids.add(41)
        self.open_orders[41] = {"id": 41, "symbol": "xauusd", "type": 0 if signal.side.value == "BUY" else 1,
                                "open": fill, "sl": signal.stop_loss, "tp": tp}
        return {"action": "placed", "order_id": 41}

    def modify_order(self, order_id, sl=None, tp=None):
        self.calls.append(("modify", order_id, sl))
        if self.modify_reply is not None:
            return dict(self.modify_reply)
        if self.quote is None or self.age > 30:
            return {"action": "rejected_local", "reason": "no fresh quote"}
        order = self.open_orders[order_id]
        px = self.quote[0] if order["type"] == 0 else self.quote[1]
        if ((order["type"] == 0 and sl >= px) or (order["type"] == 1 and sl <= px)):
            return {"action": "rejected", "reason": "stop out of allowed range", "error": 2}
        order["sl"] = sl
        return {"action": "modified", "sl": sl}

    def close_order(self, *, order_id, symbol, only_mine, wait_sec):
        assert only_mine and order_id in self.my_order_ids
        self.calls.append(("close", order_id))
        self.open_orders.pop(order_id)
        return {"action": "closed", "order_id": order_id}

    def tick(self, executor, quote):
        self.quote, self.age = quote, 0.0
        executor._on_tick("xauusd", *quote)
        for worker in list(executor._be_workers):
            worker.join(timeout=2)
            assert not worker.is_alive()


def opened(tmp_path, case, legacy=False, virtual=False):
    side, quote, profit, loss, retrace, stop = case
    client = RecordingManagementClient(quote)
    cfg = SimpleNamespace(
        fxtrendo={"enabled": True, "dry_run": False, "virtual_limits": True,
                  "max_open_positions": 3, "watchdog_sec": 0,
                  "order": {"modify_event": "" if virtual else "order_edit"}},
        risk={"sizing": "fixed"}, channel_settings={})
    ex = FxTrendoExecutor(cfg, client)
    ex.daily = DailyGuard(state_path=str(tmp_path / "daily.json"))
    clk = Clock()
    eng = Engine(ex, EngineConfig(breakeven_at_zone=legacy), clock=clk)
    lines = run(eng.handle(f"Xau {side} Enter:4184/4185 SL:{stop:g}", msg_id=1, ts=clk.t))
    assert eng.setup.placed and eng.setup.ids == [41], lines
    return eng, ex, client, clk


@pytest.mark.parametrize("case", CASES)
@pytest.mark.parametrize("legacy", [False, True])
def test_generic_be_uses_actual_fill_by_default_and_explicit_zone_opt_in(tmp_path, case, legacy):
    eng, ex, client, clk = opened(tmp_path, case, legacy)
    client.quote = case[2]
    fill = client.open_orders[41]["open"]
    run(eng.handle("فریش کن", msg_id=2, ts=clk.t))
    expected = eng.setup.near if legacy else fill
    assert client.calls[-1] == ("modify", 41, expected)
    assert client.open_orders[41]["sl"] == expected
    assert not ex.guards()
    assert len([c for c in client.calls if c[0] == "place"]) == 1


def test_engine_default_and_config_legacy_override_are_explicit():
    assert EngineConfig().breakeven_at_zone is False
    assert EngineConfig.from_dict({}).breakeven_at_zone is False
    assert EngineConfig.from_dict({"breakeven_at_zone": True}).breakeven_at_zone is True


@pytest.mark.parametrize("case", CASES)
@pytest.mark.parametrize("mode", ["losing", "no_quote", "stale_quote", "broker_rejected", "session_expired"])
def test_rejected_be_waits_for_entry_before_retrace_and_preserves_original_stop(tmp_path, case, mode):
    eng, ex, client, clk = opened(tmp_path, case)
    original_sl = client.open_orders[41]["sl"]
    fill = client.open_orders[41]["open"]
    client.quote = None if mode == "no_quote" else case[3]
    if mode == "stale_quote":
        client.quote, client.age = case[2], 1000
    elif mode in ("broker_rejected", "session_expired"):
        client.modify_reply = {"action": "rejected", "reason": "test rejection",
                               "error": 1001 if mode == "session_expired" else 2}
    # Keep the retry ineligible during this activation/retrace test. The real
    # retry and the close have separate tests below.
    client.stop_level = 100.0
    lines = run(eng.handle("فریش کن", msg_id=2, ts=clk.t))
    assert ex.guards()[41]["entry"] == fill and ex.guards()[41]["armed"] is False
    assert client.open_orders[41]["sl"] == original_sl
    assert any("پس از رسیدن قیمت" in line for line in lines)
    assert not [c for c in client.calls if c[0] == "close"]
    client.tick(ex, case[3])
    assert ex.guards()[41]["armed"] is False and 41 in client.open_orders
    client.tick(ex, case[2])
    assert ex.guards()[41]["armed"] is True and 41 in client.open_orders
    client.tick(ex, case[4])
    assert client.calls[-1] == ("close", 41)
    assert 41 not in client.open_orders and not ex.guards()
    assert len([c for c in client.calls if c[0] == "place"]) == 1


@pytest.mark.parametrize("case", CASES)
def test_fresh_profitable_quote_arms_virtual_guard_immediately(tmp_path, case):
    eng, ex, client, clk = opened(tmp_path, case, virtual=True)
    client.quote = case[2]
    run(eng.handle("فریش کن", msg_id=2, ts=clk.t))
    assert ex.guards()[41]["armed"] is True
    client.tick(ex, case[4])
    assert client.calls[-1] == ("close", 41)


@pytest.mark.parametrize("case", CASES)
@pytest.mark.parametrize("old_stop_hit", [False, True])
def test_tightening_an_active_legacy_guard_waits_without_losing_old_protection(tmp_path, case, old_stop_hit):
    eng, ex, client, clk = opened(tmp_path, case, legacy=True, virtual=True)
    client.quote = case[2]
    run(eng.handle("فریش کن", msg_id=2, ts=clk.t))
    old_entry = ex.guards()[41]["entry"]
    fill = client.open_orders[41]["open"]
    between = (fill + old_entry) / 2
    client.quote = (between - 0.1, between) if case[0] == "SELL" else (between, between + 0.1)
    eng.cfg.breakeven_at_zone = False
    run(eng.handle("فریش کن", msg_id=3, ts=clk.t))
    run(eng.handle("فریش کن", msg_id=4, ts=clk.t))  # a repeat cannot lose the pending tighter level
    guard = ex.guards()[41]
    assert guard["armed"] is True and guard["entry"] == old_entry and guard["pending_entry"] == fill
    client.tick(ex, client.quote)
    assert not [c for c in client.calls if c[0] == "close"]
    if old_stop_hit:
        old_quote = (old_entry - 0.1, old_entry) if case[0] == "SELL" else (old_entry, old_entry + 0.1)
        client.tick(ex, old_quote)
    else:
        client.tick(ex, case[2])
        assert ex.guards()[41]["entry"] == fill and "pending_entry" not in ex.guards()[41]
        client.tick(ex, case[4])
    assert client.calls[-1] == ("close", 41)


@pytest.mark.parametrize("case", CASES)
def test_first_tick_at_entry_only_activates_and_next_return_closes(tmp_path, case):
    eng, ex, client, clk = opened(tmp_path, case, virtual=True)
    client.quote = case[3]
    run(eng.handle("فریش کن", msg_id=2, ts=clk.t))
    fill = client.open_orders[41]["open"]
    at_entry = (fill - 0.1, fill) if case[0] == "SELL" else (fill, fill + 0.1)
    client.tick(ex, at_entry)
    assert ex.guards()[41]["armed"] is True and 41 in client.open_orders
    client.tick(ex, case[4])
    assert client.calls[-1] == ("close", 41)


@pytest.mark.parametrize("case", CASES)
def test_existing_tighter_stop_is_never_loosened_by_generic_be(tmp_path, case):
    eng, ex, client, clk = opened(tmp_path, case)
    fill = client.open_orders[41]["open"]
    tightened = fill + (0.2 if case[0] == "BUY" else -0.2)
    client.open_orders[41]["sl"] = tightened
    client.quote = case[2]
    run(eng.handle("فریش کن", msg_id=2, ts=clk.t))
    assert client.open_orders[41]["sl"] == tightened
    assert not [c for c in client.calls if c[0] in ("modify", "close")]


def test_unknown_ownership_never_modifies_or_closes_manual_orders(tmp_path):
    eng, ex, client, clk = opened(tmp_path, CASES[0])
    client.my_order_ids.clear()
    client.quote = CASES[0][2]
    run(eng.handle("فریش کن", msg_id=2, ts=clk.t))
    assert not [c for c in client.calls if c[0] in ("modify", "close")]
    assert not ex.guards()


def test_retired_executor_preserves_existing_guard_but_opens_no_new_order(tmp_path):
    eng, ex, client, clk = opened(tmp_path, CASES[0], virtual=True)
    client.quote = CASES[0][3]
    run(eng.handle("فریش کن", msg_id=2, ts=clk.t))
    ex.retire("test stop")
    client.tick(ex, CASES[0][3])
    assert not [c for c in client.calls if c[0] == "close"]
    run(eng.handle("Xau Sell Enter:4180/4181 SL:4183", msg_id=3, ts=clk.t))
    assert len([c for c in client.calls if c[0] == "place"]) == 1
    client.tick(ex, CASES[0][2])
    client.tick(ex, CASES[0][4])
    assert client.calls[-1] == ("close", 41)


@pytest.mark.parametrize("case", CASES)
def test_deferred_guard_real_retry_still_sets_fill_stop_and_removes_guard(tmp_path, case):
    eng, ex, client, clk = opened(tmp_path, case)
    client.quote = case[3]
    run(eng.handle("فریش کن", msg_id=2, ts=clk.t))
    assert ex.retries() and ex.guards()[41]["armed"] is False
    client.tick(ex, case[2])
    assert not ex.guards() and not ex.retries()
    assert client.open_orders[41]["sl"] == client.open_orders[41]["open"]
    assert not [c for c in client.calls if c[0] == "close"]


@pytest.mark.parametrize("case", CASES)
@pytest.mark.parametrize("legacy", [False, True])
def test_sim_and_live_use_same_default_and_legacy_be_level(tmp_path, case, legacy):
    eng, ex, client, clk = opened(tmp_path, case, legacy)
    client.quote = case[2]
    run(eng.handle("فریش کن", msg_id=2, ts=clk.t))
    side, quote, profit, loss, retrace, stop = case
    sim = SimBroker([(1000.0, *quote), (1001.0, *profit)],
                    SimConfig(auto_be={"lordxau": 0.0}, auto_tp={"lordxau": 0.0}, sizing="fixed"))
    sim.advance(1000.0)
    sim_eng = Engine(sim, EngineConfig(breakeven_at_zone=legacy), clock=lambda: sim.now)
    run(sim_eng.handle(f"Xau {side} Enter:4184/4185 SL:{stop:g}", msg_id=1, ts=sim.now))
    assert len(sim.pos) == 1
    sim.advance(1001.0)
    run(sim_eng.handle("فریش کن", msg_id=2, ts=sim.now))
    assert sim.pos[0]["sl"] == client.open_orders[41]["sl"]


@pytest.mark.parametrize("case", CASES)
def test_sim_losing_be_retains_stop_then_activates_and_closes_on_retrace(case):
    side, quote, profit, loss, retrace, stop = case
    sim = SimBroker([(1000.0, *quote), (1001.0, *loss), (1002.0, *profit), (1003.0, *retrace)],
                    SimConfig(auto_be={"lordxau": 0.0}, auto_tp={"lordxau": 0.0}, sizing="fixed"))
    sim.advance(1000.0)
    eng = Engine(sim, clock=lambda: sim.now)
    run(eng.handle(f"Xau {side} Enter:4184/4185 SL:{stop:g}", msg_id=1, ts=sim.now))
    sim.advance(1001.0)
    run(eng.handle("فریش کن", msg_id=2, ts=sim.now))
    assert sim.pos[0]["sl"] == stop and sim.pos[0]["be_target"] == sim.pos[0]["fill"]
    assert not sim.closed
    sim.advance(1002.0)
    assert sim.pos[0]["sl"] == sim.pos[0]["fill"] and sim.pos[0].get("be")
    sim.advance(1003.0)
    assert len(sim.closed) == 1 and sim.closed[0]["why"] == "BE"


@pytest.mark.parametrize("case", CASES)
def test_sim_deferred_be_keeps_original_stop_effective_if_loss_worsens(case):
    side, quote, profit, loss, retrace, stop = case
    stop_quote = (stop - 0.1, stop) if side == "SELL" else (stop, stop + 0.1)
    sim = SimBroker([(1000.0, *quote), (1001.0, *loss), (1002.0, *stop_quote)],
                    SimConfig(auto_be={"lordxau": 0.0}, auto_tp={"lordxau": 0.0}, sizing="fixed"))
    sim.advance(1000.0)
    eng = Engine(sim, clock=lambda: sim.now)
    run(eng.handle(f"Xau {side} Enter:4184/4185 SL:{stop:g}", msg_id=1, ts=sim.now))
    sim.advance(1001.0)
    run(eng.handle("فریش کن", msg_id=2, ts=sim.now))
    sim.advance(1002.0)
    assert len(sim.closed) == 1 and sim.closed[0]["why"] == "SL"


@pytest.mark.parametrize("case", CASES)
def test_sim_deferred_target_cannot_loosen_a_newer_tighter_stop(case):
    side, quote, profit, loss, retrace, stop = case
    sim = SimBroker([(1000.0, *quote), (1001.0, *loss), (1002.0, *profit)],
                    SimConfig(auto_be={"lordxau": 0.0}, auto_tp={"lordxau": 0.0}, sizing="fixed"))
    sim.advance(1000.0)
    eng = Engine(sim, clock=lambda: sim.now)
    run(eng.handle(f"Xau {side} Enter:4184/4185 SL:{stop:g}", msg_id=1, ts=sim.now))
    sim.advance(1001.0)
    run(eng.handle("فریش کن", msg_id=2, ts=sim.now))
    position = sim.pos[0]
    tighter = position["fill"] + (0.2 if side == "BUY" else -0.2)
    position["sl"], position["be"] = tighter, True
    sim.advance(1002.0)
    assert sim.pos[0]["sl"] == tighter and "be_target" not in sim.pos[0]


@pytest.mark.parametrize("case", CASES)
def test_sim_existing_stop_hit_cannot_be_skipped_by_deferred_activation(case):
    side, quote, profit, loss, retrace, stop = case
    sim = SimBroker([(1000.0, *quote), (1001.0, *loss), (1002.0, *retrace)],
                    SimConfig(auto_be={"lordxau": 0.0}, auto_tp={"lordxau": 0.0}, sizing="fixed"))
    sim.advance(1000.0)
    eng = Engine(sim, clock=lambda: sim.now)
    run(eng.handle(f"Xau {side} Enter:4184/4185 SL:{stop:g}", msg_id=1, ts=sim.now))
    sim.advance(1001.0)
    run(eng.handle("فریش کن", msg_id=2, ts=sim.now))
    position = sim.pos[0]
    position["sl"] = position["fill"] + (0.2 if side == "BUY" else -0.2)
    position["be"] = True
    sim.advance(1002.0)
    assert not sim.pos and len(sim.closed) == 1 and sim.closed[0]["why"] == "BE"
