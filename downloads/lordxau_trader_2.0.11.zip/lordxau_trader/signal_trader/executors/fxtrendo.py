"""FxTrendo execution adapter — wraps the Socket.IO TrendoClient.

Guardrails: dry_run defaults True; enabled must be True and dry_run False to
send; validate_signal() rejects garbled signals; require_stop_loss; max_lot;
max_open_positions (open + still-unconfirmed orders); plus the technical
options in signal_trader.risk (allowlist, trading hours, daily trade/loss
limits, risk-based sizing, optional multi-TP split). Placement runs under a
lock so two simultaneous messages cannot both slip past the limits. A split
that fails part-way still reports the orders that were sent. Credentials come
only from .env.

Channel commands (see SignalEngine):
  * close(symbol, fraction)  — order_close for the bot's orders on the symbol.
  * breakeven(symbol)        — move the SL of the bot's open orders to their fill
    price. With fxtrendo.order.modify_event (= order_edit, captured) this is a
    REAL SL edit: "modified" -> breakeven_set. The broker rejects an SL closer
    than the symbol's stop_level to the current quote (error 2), so a
    rejection ("rejected" / "rejected_local" / "unconfirmed") arms the VIRTUAL
    guard AND an automatic retry: on ticks of that symbol, once price is
    stop_level past the entry (SELL: ask <= entry - stop_level, BUY: bid >=
    entry + stop_level), modify_order runs again on a worker thread (at most
    once per 2 s per order, one in flight); success drops the guard. The
    guard first waits for a fresh executable quote to reach the protected
    level (SELL: ask <= entry, BUY: bid >= entry), then closes at market on
    a return to it. A rejected edit while the trade is losing never becomes
    an immediate market close; the existing broker SL stays in place.
    Guard and retry live in
    memory only — a restart forgets them — and are thread-safe (ticks arrive
    on the Socket.IO thread; a lock + "closing"/"inflight" flags make the
    close / the edit run exactly once).
  * market_now(symbol, signal) — "مارکت بزن": place the tracked signal as a
    MARKET order, but only when the bot has NO order on that symbol yet. The
    pending-order cancel / limit->market protocol of Trendo is unverified, so
    an existing order is never touched.
"""
from __future__ import annotations

import asyncio
import dataclasses
import inspect
import logging
import threading
import time
from pathlib import Path
from typing import Any, Callable, Optional

from signal_trader.brokers.trendo_client import BrokerDisconnected, TrendoClient
from signal_trader.executors.base import Executor
from signal_trader.models import OrderType, Side, Signal
from signal_trader.validation import (ENTRY_TOLERANCE_FRAC, risk_too_small,  # noqa: F401
                                       validate_signal)
from signal_trader.risk import (DailyGuard, RiskConfig, compute_lot, in_trading_hours,
                                split_volumes, symbol_allowed)

log = logging.getLogger("signal_trader.fxtrendo")
PROJECT_ROOT = Path(__file__).resolve().parents[2]


# validate_signal lives in signal_trader.validation (shared with the scout/backtest);
# it is re-exported here so existing imports keep working.


class FxTrendoExecutor(Executor):
    name = "fxtrendo"

    def __init__(self, config: Any, client: Optional[TrendoClient] = None):
        self.config = config
        ft = getattr(config, "fxtrendo", {}) or {}
        self.enabled = bool(ft.get("enabled", False))
        self.dry_run = bool(ft.get("dry_run", True))
        self.require_sl = bool(ft.get("require_stop_loss", True))
        self.max_sl_pct = float(ft.get("max_sl_distance_pct", 0.05))
        # F3: apply new SL/TP levels that arrive after execution to the bot's own
        # open orders (per-channel override handled by the engine). F3: widening
        # the stop (further from entry) is allowed only when allow_sl_widening —
        # the user follows the channel's plan; otherwise only tightening.
        self.act_on_level_updates = bool(ft.get("act_on_level_updates", True))
        self.allow_sl_widening = bool(ft.get("allow_sl_widening", True))
        self.max_open = int(ft.get("max_open_positions", 3))
        self.default_lot = float(ft.get("default_lot", 0.01))
        self.close_only_mine = bool(ft.get("close_only_bot_orders", True))
        self._retired = False            # retire(): this run is over, nothing opens again
        self.risk = RiskConfig.from_dict(getattr(config, "risk", {}) or {},
                                         max_lot=float(ft.get("max_lot", 0.10)))
        self.daily = DailyGuard(max_trades=self.risk.max_trades_per_day,
                                max_loss=self.risk.max_daily_loss,
                                state_path=str(PROJECT_ROOT / "daily_state.json"))
        self.client = client or TrendoClient(config)
        self._lock = threading.Lock()
        # Virtual breakeven guards: order_id -> {side, entry, symbol, bsym}.
        # In-memory only (a restart forgets them). _be_lock protects the dicts;
        # _be_closing holds ids whose market close is in flight so a second
        # tick can never close the same order twice.
        self._be_guards: dict[int, dict] = {}
        self._be_closing: set[int] = set()
        # order_id -> time the guard emitted its close. The broker keeps the
        # order in open_orders until it confirms, so a channel "close" that
        # arrives in that window must not emit a second order_close.
        self._be_closed_at: dict[int, float] = {}
        # Automatic retry of a REAL breakeven edit the broker rejected (SL too
        # close to the quote): order_id -> {side, entry, symbol, bsym,
        # stop_level, last_try, inflight}. Ticks (socket thread) only decide;
        # the edit itself runs on a worker thread, at most once per
        # _BE_RETRY_SEC per order and never two at a time (inflight flag).
        self._be_retry: dict[int, dict] = {}
        self._be_workers: list[threading.Thread] = []
        # A channel close that arrived while the guard's own close was in flight
        # (order id -> fraction): sent if that guard close fails (BE1-C).
        self._be_deferred: dict[int, float] = {}
        self._be_lock = threading.Lock()
        self._be_listening = False
        # Automatic breakeven (per-channel auto_breakeven_points): recorded leg
        # id (int, or 'p<po>' until the ack) -> {symbol, bsym, points, source,
        # armed, inflight, last_try, tries}. Ticks (socket thread) only decide;
        # the one real SL edit runs on a worker thread. In memory only.
        self._auto_be: dict = {}
        # Virtual limit orders (see _add_virtual): vid -> {signal, symbol, bsym,
        # side, edge, tol, sl, tp1, tp_first, source, created, expires, firing,
        # tries}. _vfired: vid -> real broker ids once it was sent at market
        # ('p<primary_order>' for a leg whose ack came late - EXB-2).
        # A zone stays in _vpend (firing=True) while its worker sends it: a
        # cancel pops it, and the worker re-checks membership before every
        # emit, so a cancelled zone is never sent nor put back (VL-2).
        self.virtual_limits = bool(ft.get("virtual_limits", True))
        # A zone the price has just left is still entered at market while the
        # fill is within this fraction of the STOP DISTANCE past the zone edge
        # (0.2 -> 0.6 point on a 3-point stop: +20 % risk at most, sized from the
        # real fill). The channel's members enter there; a strict zone waited
        # for a retrace that often never came (server ledger 2026-09-15..23:
        # 32 of @lordxau's ~106 zones "never filled" while the channel traded
        # them). 0 = strict (fill only on a touch of the edge).
        try:
            self.zone_chase_frac = max(0.0, float(ft.get("zone_chase_frac", 0.2)))
        except (TypeError, ValueError):
            self.zone_chase_frac = 0.2
        # S4: lordxau closes a limit trade 20-25 min after posting it.
        self.vlimit_ttl = float(ft.get("virtual_limit_ttl_sec", 1800.0))
        self._vpend: dict[int, dict] = {}
        self._vfired: dict[int, list] = {}
        self._vseq = 0
        # S1: the active wallet's kind must match use_real_wallet before ANY
        # send (server 2026-09-23: the GUI switched to REAL, every order raised).
        self.use_real_wallet = bool(ft.get("use_real_wallet", False))
        self._wallet_block_reported = 0.0
        self._wallet_warning_seen: Optional[str] = None
        # Optional line callback for events that happen outside a message
        # handler (the automatic breakeven retry): the GUI/CLI wire it to
        # their log. Lines are Persian and never contain credentials.
        self.on_event: Optional[Callable[[str], None]] = None
        # Link health. A quote older than quote_max_age_sec is NOT a live quote
        # (2026-09-16..18: a silent socket drop froze the quote at 4304 for
        # three days - every BUY was "already beyond the stop", every real
        # order raised). The watchdog re-joins a silent feed and reconnects a
        # dead socket in the background; 0 disables it.
        self.quote_max_age = float(ft.get("quote_max_age_sec", 30.0))
        self.quote_wait = float(ft.get("quote_refresh_wait_sec", 2.0))
        self.watchdog_sec = float(ft.get("watchdog_sec", 20.0))
        self._wd_thread: Optional[threading.Thread] = None
        self._wd_stop = threading.Event()
        self._wd_backoff = 0.0
        self._wd_next_try = 0.0
        self._wd_last_rejoin = 0.0
        self._link_reported_down = False
        self._stale_reported = 0.0
        if hasattr(self.client, "on_link_event"):
            self.client.on_link_event = self._on_link_event
        self._start_watchdog()      # live + real client only; also (re)checked by every _ensure()

    _BE_RETRY_SEC = 2.0
    _SESSION_EXPIRED = 1001          # status ack "لطفاً دوباره وارد شوید" (captured 2026-09-15)
    _RELOGIN_SEC = 60.0              # F4: at most one automatic re-login per 60 s
    _last_relogin = 0.0

    @classmethod
    def _session_expired(cls, res: dict) -> bool:
        """True for a broker rejection whose error code means the session is
        gone (re-login needed): retrying the same emit is pointless."""
        try:
            return str(res.get("action")) == "rejected" and int(res.get("error")) == cls._SESSION_EXPIRED
        except (TypeError, ValueError):
            return False

    def _emit_event(self, line: str) -> None:
        log.warning("%s", line)
        cb = self.on_event
        if cb is not None:
            try:
                cb(line)
            except Exception:  # pragma: no cover - a log sink must never break trading
                log.debug("on_event sink failed", exc_info=True)

    @property
    def live(self) -> bool:
        return self.enabled and not self.dry_run

    # -- broker state ---------------------------------------------------------
    def _client_alive(self) -> bool:
        fn = getattr(self.client, "is_alive", None)
        if callable(fn):
            try:
                return bool(fn())
            except Exception:
                return False
        return bool(getattr(self.client, "connected", False))

    def _on_link_event(self, kind: str) -> None:
        """Socket thread: report link transitions once (never blocks)."""
        if kind == "down" and not self._link_reported_down:
            self._link_reported_down = True
            self._emit_event("⚠️ سوکت بروکر قطع شد — در حال اتصال دوباره…")
        elif kind == "up" and self._link_reported_down:
            self._link_reported_down = False
            self._emit_event("✅ سوکت بروکر دوباره وصل شد و اتاق‌های قیمت دوباره عضو شدند")

    def _ensure(self):
        was_up = bool(getattr(self.client, "connected", False))
        if not self._client_alive():
            if was_up or self._link_reported_down:
                self._link_reported_down = True
                self._emit_event("سوکت بروکر قطع بود — اتصال دوباره پیش از اقدام")
                drop = getattr(self.client, "_drop_socket", None)
                if callable(drop):
                    drop()
                else:
                    self.client.connected = False
            # F4: the session may have expired (error 1001) — a fresh login is
            # needed before reconnecting. Otherwise try the normal path and, if
            # connect() fails with an auth error, re-login once and retry.
            if getattr(self.client, "needs_relogin", False):
                self._relogin()
            else:
                try:
                    if self.client.wallet is None:
                        self.client.login()
                    self.client.connect()
                except Exception as exc:
                    # An expired session usually shows up as a refused/timed-out
                    # socket, not as a tidy auth message: after a DROP any connect
                    # failure earns one (throttled) fresh login; on a first
                    # connect only a recognisable auth error does.
                    if (was_up or self._is_auth_error(exc)) and self._relogin():
                        pass
                    else:
                        raise
            if self._link_reported_down and self._client_alive():
                self._link_reported_down = False
                self._emit_event("✅ اتصال بروکر برقرار شد")
        ww = getattr(self.client, "wallet_warning", None)
        if isinstance(ww, str) and ww and ww != self._wallet_warning_seen:
            self._wallet_warning_seen = ww
            self._emit_event("⚠️ " + ww)
        self._start_watchdog()
        self.daily.baseline(self._balance(), wallet=self._wallet_key())

    # -- wallet kind guard (S1) -------------------------------------------------
    def _wallet_mismatch(self) -> str:
        """'' when the active wallet's real/demo kind matches use_real_wallet;
        else a Persian reason. Never raises (the client's own assert stays the
        last guard)."""
        try:
            w = getattr(self.client, "wallet", None)
            if not isinstance(w, dict):
                return ""                          # not logged in yet: nothing to compare
            want = getattr(self.client, "use_real", None)
            want = self.use_real_wallet if not isinstance(want, bool) else want
            if bool(w.get("is_real")) == want:
                return ""
            if not want:
                return (f"کیف‌پول فعال بروکر ({w.get('id')}) REAL (واقعی) است ولی use_real_wallet=false — "
                        "برای ایمنی سفارشی ارسال نشد. در داشبورد کیف‌پول DEMO را انتخاب کنید")
            return (f"کیف‌پول فعال بروکر ({w.get('id')}) DEMO است ولی use_real_wallet=true — "
                    "سفارشی ارسال نشد. در داشبورد کیف‌پول درست را انتخاب کنید")
        except Exception:  # pragma: no cover - a guard must never break trading
            return ""

    def _wallet_blocked(self) -> str:
        """:meth:`_wallet_mismatch` plus an event at most once a minute."""
        why = self._wallet_mismatch()
        if why:
            now = time.time()
            if now - self._wallet_block_reported >= 60.0:
                self._wallet_block_reported = now
                self._emit_event("⛔ " + why)
        return why

    # -- link watchdog ----------------------------------------------------------
    def _start_watchdog(self) -> None:
        if (self._wd_thread is not None or self.watchdog_sec <= 0 or not self.live
                or not callable(getattr(self.client, "is_alive", None))):
            return
        self._wd_thread = threading.Thread(target=self._watchdog_loop, name="fxtrendo-watchdog",
                                           daemon=True)
        self._wd_thread.start()

    def stop_watchdog(self) -> None:
        self._wd_stop.set()

    def _watchdog_loop(self) -> None:
        while not self._wd_stop.wait(self.watchdog_sec):
            try:
                self.watchdog_tick()
            except Exception:  # pragma: no cover - the watchdog must never die
                log.debug("watchdog tick failed", exc_info=True)

    def watchdog_tick(self, now: Optional[float] = None) -> str:
        """One health check -> 'ok' | 'rejoined' | 'reconnected' | 'down' | 'busy'.
        A dead socket is reconnected (login when needed) with a growing backoff
        (20 s .. 5 min); a live socket whose feed went silent gets its price
        rooms re-joined (at most once a minute). Virtual limits past their TTL
        expire here too, so a zone on a dead feed does not wait forever."""
        self._sweep_virtual()
        now = time.time() if now is None else now
        if self._client_alive():
            self._wd_backoff = 0.0
            wanted = list(getattr(self.client, "_wanted", ()) or ())
            ages = [self.client.price_age(w) for w in wanted] if hasattr(self.client, "price_age") else []
            silent = [a for a in ages if a is None or a > max(60.0, 2 * self.quote_max_age)]
            if not (wanted and len(silent) == len(wanted)):
                self._wd_rejoin_gap = 60.0           # the feed ticks: next silence starts at 1 min again
                return "ok"
            # Silent feed on a live socket. A closed market is silent for hours:
            # the gap doubles (1 min .. 15 min) so a weekend costs a few joins.
            gap = getattr(self, "_wd_rejoin_gap", 60.0)
            if now - self._wd_last_rejoin >= gap:
                self._wd_last_rejoin = now
                self._wd_rejoin_gap = min(900.0, gap * 2)
                try:
                    self.client.rejoin_prices()
                except Exception as exc:  # pragma: no cover - network path
                    log.warning("price re-join failed: %s", exc)
                return "rejoined"
            return "ok"
        if now < self._wd_next_try:
            return "down"
        # Kick war guard: the broker allows ONE session per account. If the link
        # dies again within a minute of every reconnect, somebody is logged in
        # with the same account (web / mobile / a second bot): stop fighting for
        # 5 minutes instead of kicking each other forever. An order still
        # reconnects immediately through _ensure().
        last_up = getattr(self, "_wd_last_up", 0.0)
        flaps = getattr(self, "_wd_flaps", 0)
        if last_up and now - last_up < 60.0:
            flaps += 1
        elif last_up:
            flaps = 0
        self._wd_flaps, self._wd_last_up = flaps, 0.0
        if flaps >= 3:
            self._wd_flaps = 0
            self._wd_next_try = now + 300.0
            self._emit_event("⚠️ نشست بروکر پشت‌سرهم قطع می‌شود — احتمالاً با همین حساب در وب/موبایل یا "
                             "نسخهٔ دیگری از ربات وارد شده‌اید. ۵ دقیقه صبر می‌کنم (سفارش جدید بلافاصله وصل می‌شود)")
            return "down"
        if not self._lock.acquire(blocking=False):
            return "busy"                        # an order is in flight: it reconnects itself
        try:
            if not self._link_reported_down:
                self._link_reported_down = True
                self._emit_event("⚠️ سوکت بروکر قطع است — تلاش برای اتصال دوباره")
            try:
                self._ensure()
            except Exception as exc:
                self._wd_backoff = min(300.0, max(self.watchdog_sec or 20.0, self._wd_backoff * 2))
                self._wd_next_try = now + self._wd_backoff
                log.warning("broker reconnect failed (%r); next try in %.0f s", exc, self._wd_backoff)
                return "down"
            if self._client_alive():
                self._wd_last_up = now
                return "reconnected"
            # _ensure() can return without raising while the link is still dead
            # (expired session + failed re-login): back off here too, or the
            # watchdog would retry and report every tick for the whole outage.
            self._wd_backoff = min(300.0, max(self.watchdog_sec or 20.0, self._wd_backoff * 2))
            self._wd_next_try = now + self._wd_backoff
            return "down"
        finally:
            self._lock.release()

    @staticmethod
    def _is_auth_error(exc: Exception) -> bool:
        msg = str(exc).lower()
        return any(w in msg for w in ("auth", "login", "1001", "token", "unauthor", "لاگین", "نشست"))

    def _num(self, key: str) -> Optional[float]:
        try:
            wd = self.client.wallet_data or self.client.wallet or {}
            return float(wd[key]) if wd.get(key) is not None else None
        except (TypeError, ValueError, KeyError):
            return None

    def _balance(self) -> Optional[float]:
        return self._num("balance")

    BOOK_WAIT_SEC = 5.0        # _limits: how long a new trade waits for the book after a (re)connect

    def _wallet_key(self) -> Optional[str]:
        """The active wallet's id (the daily-loss baseline is per wallet)."""
        try:
            w = self.client.wallet or {}
            wid = w.get("id") if hasattr(w, "get") else None
            return str(wid) if wid is not None else None
        except Exception:
            return None

    @staticmethod
    def _fill_of(signal: Signal, quote) -> Optional[float]:
        """The live price a MARKET order of ``signal`` fills at (BUY ask, SELL
        bid); None when unknown or not a market order."""
        if quote is None or signal.order_type != OrderType.MARKET:
            return None
        try:
            bid, ask = quote
            return float(ask if signal.side == Side.BUY else bid)
        except (TypeError, ValueError):
            return None

    def _equity(self) -> Optional[float]:
        return self._num("equity")

    def _open_count(self, exclude_vid: Optional[int] = None) -> int:
        """Open + unconfirmed orders + waiting virtual limits (``exclude_vid``:
        the zone whose own fire-time check this is)."""
        self._sweep_virtual()
        pending = self.client.pending_count() if hasattr(self.client, "pending_count") else 0
        with self._be_lock:
            virtual = sum(1 for k in self._vpend if k != exclude_vid)
        return len(self.client.open_orders) + pending + virtual

    def _plan(self, signal: Signal, fill: Optional[float] = None) -> tuple[list[tuple[float, Optional[float]]], str]:
        """(lot, tp) per order — one order, or one per TP when split is on.
        An empty plan means sizing refused the trade (note says why). ``fill``:
        the live price a market order fills at (sizing measures the SL from it)."""
        lot, note = compute_lot(self.risk, signal, self._balance(), self.default_lot, fill=fill)
        if lot <= 0:
            return [], note
        mult = self._channel_multiplier(signal.source)
        if mult != 1.0:
            lot = round(max(self.risk.min_lot, min(self.risk.max_lot, lot * mult)), 4)
            step = self.risk.lot_step or 0.01
            lot = round(int(lot / step + 1e-9) * step, 4)
            note += f", ×{mult:g} channel"
            if lot < self.risk.min_lot:
                return [], note + f" -> below min lot {self.risk.min_lot}"
        tps = signal.take_profits or [None]
        if signal.take_profit_offsets:
            ref = fill if fill is not None else (max(signal.entries) if signal.side == Side.BUY
                                               else min(signal.entries))
            signal.take_profit_reference = float(ref)
            sign = 1 if signal.side == Side.BUY else -1
            tps = [round(float(ref) + sign * d, 2) for d in signal.take_profit_offsets]
            note += ", channel TP distances from entry"
        pts = self._tp_points(signal.source) if not (signal.take_profits or signal.take_profit_offsets) and fill is not None else 0.0
        if pts > 0:
            # per-channel take_profit_points: a signal without its own TP gets one
            # this far from the market fill (the price the order is sent at)
            tp = round(float(fill) + pts if signal.side == Side.BUY else float(fill) - pts, 2)
            tps = [tp]
            note += f", TP {tp:g} (+{pts:g})"
        if self.risk.split_take_profits and len(tps) > 1:
            vols = split_volumes(lot, len(tps), self.risk.lot_step, self.risk.min_lot)
            return list(zip(vols, tps[: len(vols)])), note + f", split over {len(vols)} TPs"
        return [(lot, tps[0])], note

    def _channel_multiplier(self, source: str) -> float:
        """Per-channel lot multiplier from config (1.0 when unknown)."""
        settings = getattr(self.config, "channel_settings", {}) or {}
        cs = settings.get(source) if source else None
        try:
            m = float(getattr(cs, "lot_multiplier", 1.0)) if cs is not None else 1.0
        except (TypeError, ValueError):
            m = 1.0
        return m if m > 0 else 1.0

    def _live_quote(self, symbol: str, refresh: bool = False) -> Optional[tuple[float, float]]:
        """(bid, ask) from the broker feed, or None when unknown OR stale (older
        than quote_max_age_sec - a frozen quote is worse than none). With
        ``refresh`` (worker thread only) a stale feed is re-joined and given
        quote_refresh_wait_sec to deliver a fresh tick."""
        try:
            bsym = self.client.broker_symbol(symbol)
            q = self._quote_if_fresh(bsym)
            if q is None and refresh and self._quote_known(bsym) and callable(getattr(self.client, "rejoin_prices", None)):
                try:
                    self.client.rejoin_prices([bsym])
                except Exception as exc:  # pragma: no cover - network path
                    log.warning("price re-join failed: %s", exc)
                deadline = time.time() + max(0.0, self.quote_wait)
                while q is None and time.time() < deadline:
                    time.sleep(0.05)
                    q = self._quote_if_fresh(bsym)
                if q is None:
                    now = time.time()
                    if now - self._stale_reported > 60.0:
                        self._stale_reported = now
                        self._emit_event(f"⚠️ قیمت زندهٔ {symbol} کهنه است و تازه نشد — بدون قیمت زنده ادامه می‌دهم")
            return q
        except (TypeError, ValueError, AttributeError):
            return None

    def _quote_known(self, bsym: str) -> bool:
        return bool(self.client.price(bsym)) if hasattr(self.client, "price") else False

    def _quote_if_fresh(self, bsym: str) -> Optional[tuple[float, float]]:
        q = self.client.price(bsym) if hasattr(self.client, "price") else None
        if not q or q[0] is None or q[1] is None:
            return None
        age_fn = getattr(self.client, "price_age", None)
        if callable(age_fn) and self.quote_max_age > 0:
            age = age_fn(bsym)
            if isinstance(age, (int, float)) and age > self.quote_max_age:
                return None
        return float(q[0]), float(q[1])

    def live_quote_mid(self, symbol: str) -> Optional[float]:
        """Mid price ((bid+ask)/2) from the broker feed, or None when unknown.
        Used by the engine as the reference price for abbreviated levels (F1)."""
        q = self._live_quote(symbol)
        if q is None:
            return None
        return (q[0] + q[1]) / 2.0

    # -- automatic re-login (F4) ----------------------------------------------
    def _wallet_kind(self) -> str:
        fn = getattr(self.client, "wallet_kind", None)
        try:
            return fn() if fn is not None else ("REAL" if self.client.use_real else "DEMO")
        except Exception:
            return "DEMO"

    def _relogin(self) -> bool:
        """Broker session expired (error 1001, e.g. the user logged into the web
        platform with the same account). MUST be called on the worker thread
        while holding ``self._lock``. Re-login with the .env credentials,
        reconnect the socket and re-select the SAME wallet kind (REAL only with
        use_real_wallet and the same wallet id).
        At most one re-login per ``_RELOGIN_SEC``. Returns True when the session
        is usable again (the caller then retries its action ONCE)."""
        now = time.time()
        if now - self._last_relogin < self._RELOGIN_SEC:
            self._emit_event("لاگین دوباره در ۶۰ ثانیه گذشته انجام شده — دوباره لاگین نمی‌کنم؛ "
                             "سفارش رد شد")
            return False
        self._last_relogin = now
        prev_kind = self._wallet_kind()
        prev_id = (getattr(self.client, "wallet", None) or {}).get("id")
        # Pin the running REAL wallet for login(): it may only re-select that
        # wallet, never switch to another REAL one (R9-D).
        pin = (prev_kind == "REAL" and prev_id is not None
               and getattr(self.client, "wallet_id_cfg", None) is None)
        if pin:
            self.client.wallet_id_cfg = prev_id
        try:
            self.client.login()
        except Exception as exc:
            self._emit_event(f"لاگین دوباره ناموفق بود: {exc!r}")
            return False
        finally:
            if pin:
                self.client.wallet_id_cfg = None
        new_kind = self._wallet_kind()
        new_id = (getattr(self.client, "wallet", None) or {}).get("id")
        # REAL only when use_real_wallet is on AND it is the very same wallet
        # (server 2026-09-24: on REAL every 1001 re-login was refused).
        if new_kind != prev_kind or (new_kind == "REAL" and (
                not getattr(self.client, "use_real", False) or new_id != prev_id)):
            self._emit_event("پس از لاگین دوباره نوع کیف‌پول عوض می‌شد یا REAL بود — برای ایمنی "
                             f"متوقف شد (قبلی={prev_kind} جدید={new_kind})")
            return False
        try:
            self.client.disconnect()
            self.client.connect()
        except Exception as exc:
            self._emit_event(f"اتصال دوباره پس از لاگین ناموفق بود: {exc!r}")
            return False
        self._emit_event(f"نشست بروکر منقضی شده بود (error 1001) — لاگین و اتصال دوباره به کیف‌پول "
                         f"{new_kind} انجام شد؛ اقدام دوباره تلاش می‌شود")
        return True

    def _place_live(self, sig: Signal, lot, tp,
                    stop: Optional[Callable[[], bool]] = None) -> dict:
        """One live order leg - never once this run is over (retire(), R9-1):
        checked in EVERY call (also _emit_with_relogin's retry after a reconnect
        / re-login, which take seconds) and, by a client that supports it, once
        more right before the emit (its own _ensure_socket may reconnect first).
        -> {"action": "cancelled_guard"} when stopped; else place_order's result."""
        stop = stop or (lambda: self._retired)
        if stop():
            return {"action": "cancelled_guard"}
        tp = self._fresh_auto_tp(sig, tp)
        fn = self.client.place_order
        try:
            guarded = "guard" in inspect.signature(fn).parameters
        except (TypeError, ValueError):
            guarded = False
        if guarded:
            return fn(sig, dry_run=False, lot=lot, tp=tp, guard=stop)
        return fn(sig, dry_run=False, lot=lot, tp=tp)

    def _emit_with_relogin(self, fn: Callable[[], dict]) -> dict:
        """Run ``fn`` (one broker emit returning a result dict); if it is
        rejected with error 1001, re-login once and retry ``fn`` a single time.
        Must run on the worker thread while holding ``self._lock``."""
        try:
            res = fn()
        except BrokerDisconnected as exc:
            # Nothing was sent (the socket was down): reconnect and retry ONCE.
            self._emit_event(f"سوکت بروکر هنگام ارسال قطع بود ({exc}) — اتصال دوباره و یک تلاش مجدد")
            self._ensure()
            res = fn()
        if self._session_expired(res) and self._relogin():
            res = fn()
        return res

    def _entry_reject(self, signal: Signal, fill: float) -> str:
        """'' when ``signal`` can still be entered at ``fill``; else why not.

        The single implementation of the SL/TP-passed check, shared by
        :meth:`_adjust_entry` (the zone rule) and :meth:`_stale_levels`
        (market-now). ``fill`` is the price the order would actually execute at
        — the live ask/bid for a MARKET fill, the zone edge for a resting LIMIT.
        BUY fills at ask, SELL at bid. A stop already at/through the fill, or a
        risk so small the fill hugs the stop, or a first target already beyond
        the fill, all make the entry pointless -> a rejection reason.
        """
        sl = signal.stop_loss
        tp = signal.take_profits[0] if signal.take_profits else None
        if signal.side == Side.BUY:
            if sl is not None and (fill <= sl or risk_too_small(fill, sl)):
                return f"price {fill:g} already at/beyond stop loss {sl:g} -> entry invalid"
            if tp is not None and fill >= tp:
                return f"price {fill:g} already beyond take profit {tp:g}"
        elif signal.side == Side.SELL:
            if sl is not None and (fill >= sl or risk_too_small(fill, sl)):
                return f"price {fill:g} already at/beyond stop loss {sl:g} -> entry invalid"
            if tp is not None and fill <= tp:
                return f"price {fill:g} already beyond take profit {tp:g}"
        return ""

    def _stale_levels(self, signal: Signal, quote: tuple[float, float]) -> str:
        """SL/TP-passed check for market-now against the live quote (BUY -> ask,
        SELL -> bid). Delegates to the one :meth:`_entry_reject` implementation."""
        bid, ask = quote
        fill = ask if signal.side == Side.BUY else bid
        return self._entry_reject(signal, fill)

    _FETCH = object()          # _adjust_entry: fetch the live quote itself

    def _chase_tol(self, signal: Signal, edge: float) -> float:
        """How far past the zone edge a LIMIT zone still fills at market: a
        fraction of the stop distance, never more than the MARKET tolerance;
        0 without a stop (nothing to scale by)."""
        sl = signal.stop_loss
        if sl is None or self.zone_chase_frac <= 0:
            return 0.0
        try:
            return max(0.0, min(ENTRY_TOLERANCE_FRAC * float(edge),
                                self.zone_chase_frac * abs(float(edge) - float(sl))))
        except (TypeError, ValueError):
            return 0.0

    def _adjust_entry(self, signal: Signal, force_market: bool = False,
                      quote: Any = _FETCH) -> tuple[Signal, str, str]:
        """Zone-aware entry adjust. Returns ``(signal, note, reject_reason)``.

        The zone is ``[lo, hi] = [min(entries), max(entries)]`` (a single level
        has ``lo == hi``). The live quote decides — for BOTH order types
        (MARKET and LIMIT), matching ``backtest._fill``:

          * price already at/through the stop or first target -> ``reject_reason``
            (the caller must return that rejection before sizing/placing);
          * price inside or better than the zone -> MARKET now (fill at the live
            price; the zone ``entries`` are kept so the ledger/GUI still show it);
          * price not reached yet -> a resting LIMIT at the nearest edge (BUY:
            ``hi``; SELL: ``lo``).

        A LIMIT signal whose price already sits in the zone therefore fills at
        market instead of resting forever below the bid — the @lordxau scalp.
        ``force_market`` (market_now) keeps the order a MARKET order but still
        honours the SL/TP rejection. ``quote`` = an already fetched live quote
        (None = none). The caller's signal is never mutated."""
        if quote is self._FETCH:
            quote = self._live_quote(signal.symbol, refresh=True)
        if force_market:
            reject = self._stale_levels(signal, quote) if quote is not None else ""
            return signal, "", reject
        if signal.order_type == OrderType.STOP or not signal.entries:
            return signal, "", ""
        lo, hi = min(signal.entries), max(signal.entries)
        single = lo == hi
        buy = signal.side == Side.BUY
        edge = hi if buy else lo

        if quote is None:
            # No live quote: MARKET stays MARKET; a LIMIT rests at the nearest
            # edge (never at entries[0] blindly).
            if signal.order_type == OrderType.MARKET or list(signal.entries) == [edge]:
                return signal, "", ""
            note = f"no live quote -> limit at nearest edge {edge:g}"
            log.warning("%s: %s", signal.symbol, note)
            return dataclasses.replace(signal, order_type=OrderType.LIMIT, entries=[edge]), note, ""

        bid, ask = quote
        fill = ask if buy else bid
        # A zone (LIMIT) fills only once the price reaches it - like the
        # channel's own limit (a BUY limit on the ask, a SELL limit on the bid;
        # backtest._fill models bid candles). The 0.05 % tolerance is for a
        # genuine MARKET signal only (server 2026-09-24: lordxau zones were
        # chased ~2 points past the edge, +50-70 % risk on a 3-point stop).
        wide = ENTRY_TOLERANCE_FRAC * edge
        tol = wide if signal.order_type == OrderType.MARKET else self._chase_tol(signal, edge)
        market = (ask <= hi + tol) if buy else (bid >= lo - tol)
        # Stale-level check at the live price whenever it is near the zone, so
        # a zone already past its first target is still rejected at once.
        near = (ask <= hi + wide) if buy else (bid >= lo - wide)

        reject = self._entry_reject(signal, fill if near else edge)
        if reject:
            log.warning("%s: %s", signal.symbol, reject)
            return signal, "", reject

        if market:
            if signal.order_type == OrderType.MARKET:
                return signal, "", ""          # a genuine MARKET signal, unchanged
            better = (ask < lo) if buy else (bid > hi)
            past = (ask - hi) if buy else (lo - bid)
            if past > 0:                       # just past the edge: the channel's fill too
                where = f"within {past:.2f} past"
                note = (f"market {fill:g} {where} zone {lo:g}/{hi:g} (chase <= {tol:.2f} = "
                        f"{self.zone_chase_frac:.0%} of SL) -> market")
            else:
                where = "better than" if better else "inside"
                note = f"market {fill:g} {where} zone {lo:g}/{hi:g} -> market"
            log.warning("%s: %s", signal.symbol, note)
            return dataclasses.replace(signal, order_type=OrderType.MARKET), note, ""

        # not reached -> resting limit at the nearest edge
        side = "buy limit" if buy else "sell limit"
        rel = "above" if buy else "below"
        if single:
            note = f"market {fill:g} {rel} entry {edge:g} -> {side}"
        else:
            note = f"market {fill:g} {rel} zone {lo:g}/{hi:g} -> {side} at {edge:g}"
        log.warning("%s: %s", signal.symbol, note)
        return dataclasses.replace(signal, order_type=OrderType.LIMIT, entries=[edge]), note, ""

    def _limits(self, plan_len: int, exclude_vid: Optional[int] = None) -> Optional[dict[str, Any]]:
        """Daily / open-position limits; None when the trade may proceed."""
        ok, why = self.daily.can_trade(self._balance(), n=plan_len, equity=self._equity(),
                                       wallet=self._wallet_key())
        if not ok:
            return {"action": "skipped_daily_limit", "reason": why}
        if self.live and self.max_open and not self._book_ready():
            # right after a (re)connect the book is empty until the broker's
            # snapshot arrives: "0 open" then is not known - never a second
            # position through that window (audit 2026-09-25)
            ready = getattr(self.client, "_orders_ready", None)
            try:
                ready.wait(self.BOOK_WAIT_SEC)
            except Exception:
                pass
            if not self._book_ready():
                return {"action": "skipped_max_open",
                        "reason": "دفتر سفارش‌های بروکر هنوز نرسیده — تعداد پوزیشن‌های باز معلوم نیست",
                        "open": None, "limit": self.max_open}
        n_open = self._open_count(exclude_vid) if self.max_open else 0
        if self.max_open and n_open + plan_len > self.max_open:
            return {"action": "skipped_max_open",
                    "reason": f"open positions {n_open} + {plan_len} > {self.max_open}",
                    "open": n_open, "limit": self.max_open}
        return None

    # -- executor API ---------------------------------------------------------
    async def execute(self, signal: Signal, *, _force_market: bool = False) -> dict[str, Any]:
        """Place ``signal``. ``_force_market`` (market_now) keeps a MARKET order
        a market order even when the live quote is far from the quoted level."""
        reason = validate_signal(signal, self.require_sl, self.max_sl_pct)
        if not reason and not symbol_allowed(self.risk, signal.symbol):
            reason = f"symbol {signal.symbol} not in allowed_symbols"
        if not reason and not in_trading_hours(self.risk):
            reason = f"outside trading hours ({self.risk.trading_hours})"
        if reason:
            log.warning("rejected (%s): %s", reason, signal.summary())
            return {"executor": self.name, "action": "rejected", "reason": reason}

        if not self.live:
            signal, entry_note, reject = self._adjust_entry(signal, force_market=_force_market)
            if reject:
                log.warning("rejected (%s): %s", reject, signal.summary())
                return {"executor": self.name, "action": "rejected", "reason": reject}
            plan, size_note = self._plan(signal)
            if not plan:
                return {"executor": self.name, "action": "rejected", "reason": size_note}
            limited = self._limits(len(plan))          # read-only preview of the guards
            if limited:
                return {"executor": self.name, **limited, "dry_run": True}
            results = [self.client.place_order(signal, dry_run=True, lot=lot, tp=tp)
                       for lot, tp in plan]
            log.warning("[DRY-RUN] %s (%s)", results, size_note)
            out = {"executor": self.name, **results[0], "orders": results, "sizing": size_note}
            if entry_note:
                out["entry_adjusted"] = entry_note
            return out

        def _do():
            with self._lock:
                if self._retired:
                    return {"action": "rejected", "reason": "ربات متوقف شده (توقف) — سفارشی باز نشد"}
                self._ensure()
                why = self._wallet_blocked()                        # S1: never raise, never REAL
                if why:
                    return {"action": "rejected", "reason": why}
                quote = self._live_quote(signal.symbol, refresh=True)   # live quote known only now
                sig, entry_note, reject = self._adjust_entry(
                    signal, force_market=_force_market, quote=quote)
                if reject:
                    return {"action": "rejected", "reason": reject}
                if _force_market and self._has_real_order(signal.symbol):
                    # market_now's check, repeated under the lock right before the
                    # send: a zone whose worker sent it between that check and now
                    # is a real order already - never a second position.
                    return {"action": "order_exists", "symbol": signal.symbol}
                # The channel's NEW signal replaces its own zone that never filled
                # (market_now: the zone it gives up -> replaced_virtual). Only the
                # SAME channel's zones, and only once this order goes ahead.
                dropped = self._cancel_virtual(symbol=signal.symbol, source=signal.source or "",
                                               why="superseded by a new signal of the channel")
                # A zone (LIMIT) is never sent blind (Trendo fills every order_add at
                # market wherever the price is): one a FRESH quote shows as not
                # reached waits virtually, and so does a zone with NO fresh quote
                # (VL-9) - it fires on the first fresh tick in the zone, and the
                # TTL sweep drops it even when no tick ever comes (dead feed). A
                # plain MARKET signal with no quote still goes out as before.
                if (self.virtual_limits and not _force_market and sig.entries
                        and sig.order_type == OrderType.LIMIT):
                    vplan, vnote = self._plan(sig)
                    if not vplan:           # it would be refused when it fires
                        out = {"action": "rejected", "reason": vnote}
                        return {**out, "replaced_virtual": dropped} if dropped else out
                    limited = self._limits(1)
                    if limited:
                        return {**limited, "replaced_virtual": dropped} if dropped else limited
                    edge = max(sig.entries) if sig.side == Side.BUY else min(sig.entries)
                    vid = self._add_virtual(signal, edge, quote=quote)
                    if vid is None:
                        return {"action": "rejected", "reason": "ربات متوقف شده (توقف) — لیمیت ثبت نشد"}
                    if quote is None:
                        note = (f"no live quote -> virtual limit at {edge:g}; sent at market on the "
                                "first fresh price in the zone (never blind)")
                    else:
                        note = (entry_note.replace(" limit", " virtual limit") if entry_note
                                else f"virtual limit at {edge:g}")
                        note += "; sent at market when the price reaches it (Trendo has no resting limit)"
                    if dropped:
                        note += f"; replaced {len(dropped)} unfilled zone(s)"
                    out = {"action": "pending_virtual", "order_id": f"v{vid}",
                           "orders": [{"order_id": f"v{vid}", "virtual": True}],
                           "sizing": "virtual limit", "entry_adjusted": note}
                    if dropped:
                        out["replaced_virtual"] = dropped
                    return out
                plan, size_note = self._plan(sig, fill=self._fill_of(sig, quote))   # live balance
                gone = {"replaced_virtual": dropped} if dropped else {}
                if not plan:
                    return {"action": "rejected", "reason": size_note, **gone}
                limited = self._limits(len(plan))
                if limited:
                    return {**limited, **gone}
                sent: list[dict] = []
                rejected: list[dict] = []
                err: Optional[Exception] = None
                for lot, tp in plan:
                    if self._retired:           # Stop: no reconnect / re-login either (R10-1)
                        if not sent:
                            return {"action": "rejected", "reason": "ربات متوقف شده (توقف) — سفارشی باز نشد", **gone}
                        break
                    try:
                        # Reconnect (if needed) BEFORE the Stop check, as _fire_virtual
                        # does; the check itself runs inside every emit call - also
                        # the retry after a reconnect / re-login (R8-2 / R9-1).
                        self._ensure()
                        r = self._emit_with_relogin(
                            lambda lot=lot, tp=tp: self._place_live(sig, lot, tp))
                    except Exception as exc:  # keep what was already sent
                        err = exc
                        log.exception("order %d/%d failed: %s", len(sent) + 1, len(plan), exc)
                        break
                    if r.get("action") == "cancelled_guard":     # Stop came meanwhile
                        if not sent:
                            return {"action": "rejected", "reason": "ربات متوقف شده (توقف) — سفارشی باز نشد", **gone}
                        break
                    if r.get("action") == "rejected":       # broker status ack: not a trade
                        r = {**r, "reason": "بروکر رد کرد: " + str(r.get("reason") or r.get("error"))}
                        rejected.append(r)
                        log.warning("order %d/%d rejected by broker: %s",
                                    len(sent) + 1, len(plan), r["reason"])
                        break
                    if r.get("order_id") is None:
                        # EXB-2: sent, ack late ("emitted"): the engine still gets an
                        # id for this leg ('p<primary_order>', mapped to the broker
                        # id once the echo arrives) - never nothing, or the trade
                        # would inherit its channel's previous trade's ids.
                        r = {**r, "order_id": self._placeholder(r), "unacked": True}
                    sent.append(r)
                    self.daily.record_trade()
                if not sent:
                    if rejected:
                        return {"action": "rejected", "reason": rejected[0]["reason"],
                                "error": rejected[0].get("error"), "orders": rejected,
                                "sizing": size_note}
                    raise err if err else RuntimeError("no order sent")
                abe = self._arm_auto_be(sig.symbol, [r.get("order_id") for r in sent],
                                        signal.source or "")
                out = {**sent[0], "orders": sent + rejected, "sizing": size_note}
                if abe:
                    out["auto_breakeven"] = abe
                if entry_note:
                    out["entry_adjusted"] = entry_note
                if dropped:
                    out["replaced_virtual"] = dropped
                if err is not None:
                    out["partial_error"] = repr(err)
                elif rejected:
                    out["partial_error"] = rejected[0]["reason"]
                return out
        result = await asyncio.to_thread(_do)
        return {"executor": self.name, **result}

    async def close(self, symbol: Optional[str] = None, order_id=None,
                    fraction: float = 1.0, close_all: bool = False,
                    order_ids: Optional[list] = None) -> dict[str, Any]:
        if symbol is None and order_id is None and not close_all:
            return {"executor": self.name, "action": "refused",
                    "reason": "no symbol / order id given (would close every position)"}
        if not self.live:
            return {"executor": self.name, "action": "dry_run_close",
                    "symbol": symbol, "order_id": order_id, "fraction": fraction}
        cancelled: list[dict] = []
        if fraction >= 1.0 and order_id is None:
            # A zone that never filled is simply dropped (nothing at the broker).
            cancelled = self._cancel_virtual(symbol=symbol, ids=order_ids, why="channel close")
        if order_ids and order_id is None and symbol:
            def _resolve():
                with self._lock:                  # after a virtual limit's in-flight send
                    return self._resolve_ids(symbol, order_ids)
            targets, _pend = await asyncio.to_thread(_resolve)
            if targets is not None:
                if not targets:
                    return {"executor": self.name, "action": "pending_cancelled" if cancelled
                            else "no_open_order", "symbol": symbol, "orders": cancelled}
                results = []
                for oid in sorted(targets):
                    r = await self.close(symbol=symbol, order_id=oid, fraction=fraction)
                    results.append(r)
                ok = [r for r in results if r.get("action") not in ("no_open_order", "refused")]
                return {"executor": self.name, "action": "close" if ok else results[0].get("action"),
                        "symbol": symbol, "results": results, "targeted": sorted(targets),
                        "cancelled": cancelled}
        # A channel "close" ends the trade: any virtual breakeven guard on it
        # must go too, or a later tick would try to close an order twice.
        self._drop_guards(symbol=symbol, order_id=order_id, all_=close_all)

        def _do():
            with self._lock:
                # again under the executor lock: an automatic-breakeven worker that
                # was inside its edit while this close waited may have armed a
                # guard + retry after the drop above
                self._drop_guards(symbol=symbol, order_id=order_id, all_=close_all)
                self._ensure()
                why = self._wallet_blocked()
                if why:
                    return {"action": "refused", "reason": why, "orders": cancelled}
                skip = self._guard_closed_ids()
                self._defer_for_guard(skip, symbol, order_id, fraction)
                if order_id is not None:
                    try:
                        oid = int(order_id)
                    except (TypeError, ValueError):
                        return {"action": "no_open_order", "order_id": order_id,
                                "reason": "not a broker order id"}
                    if oid in skip:
                        return {"action": "no_open_order", "order_id": order_id,
                                "reason": "already closed by the breakeven guard"}
                    # VL-1: an explicit id that is no longer open (its SL/TP hit at
                    # the broker after the targets were resolved) closes NOTHING -
                    # never a fallback to every order on the symbol.
                    if oid not in (getattr(self.client, "open_orders", None) or {}):
                        return {"action": "no_open_order", "order_id": order_id,
                                "reason": "order is no longer open"}
                    return self._emit_with_relogin(
                        lambda: self.client.close_order(order_id=order_id, symbol=symbol,
                                                        fraction=fraction,
                                                        only_mine=self.close_only_mine))
                if cancelled and symbol and not (self._my_orders(symbol) if self.close_only_mine
                                                 else self.client.orders_for(symbol)):
                    return {"action": "pending_cancelled", "symbol": symbol, "orders": cancelled}
                if not skip:
                    res = self.client.close_order(symbol=symbol, fraction=fraction,
                                                  only_mine=self.close_only_mine)
                    if cancelled and res.get("action") == "no_open_order":
                        return {**res, "action": "pending_cancelled", "orders": cancelled}
                    return res
                # A guard close is in flight / just emitted for an order on this
                # symbol: close the OTHER orders one by one, never that one twice.
                mine = getattr(self.client, "my_order_ids", set()) or set()
                targets = [o for o in self.client.orders_for(symbol)
                           if o.get("id") is not None and int(o["id"]) not in skip
                           and (not self.close_only_mine or int(o["id"]) in mine)]
                if not targets:
                    return {"action": "no_open_order", "symbol": symbol,
                            "reason": "already closed by the breakeven guard"}
                results: list[dict] = []
                for o in targets:
                    r = self.client.close_order(order_id=o["id"], symbol=symbol, fraction=fraction)
                    results += r.get("results") or [r]
                return {"action": "close", "results": results}
        result = await asyncio.to_thread(_do)
        return {"executor": self.name, **result}

    def _defer_for_guard(self, skip: set, symbol, order_id, fraction: float) -> None:
        """A channel close skips an order whose guard close is IN FLIGHT: keep
        the close, so it is sent if that guard close fails (BE1-C)."""
        if not skip:
            return
        try:
            ids = {int(order_id)} if order_id is not None else {
                int(o["id"]) for o in self.client.orders_for(symbol) if o.get("id") is not None}
        except (TypeError, ValueError):
            return
        with self._be_lock:
            for oid in ids & set(self._be_closing):
                self._be_deferred[oid] = max(float(fraction), self._be_deferred.get(oid, 0.0))

    def _guard_closed_ids(self) -> set[int]:
        """Orders whose market close the virtual guard is sending right now or
        sent in the last 2 minutes (the broker may not have confirmed yet)."""
        now = time.time()
        with self._be_lock:
            self._be_closed_at = {k: t for k, t in self._be_closed_at.items() if now - t < 120}
            return set(self._be_closing) | set(self._be_closed_at)

    # -- breakeven ------------------------------------------------------------
    def _modify_event(self) -> Optional[str]:
        od = (getattr(self.config, "fxtrendo", {}) or {}).get("order", {}) or {}
        return od.get("modify_event") or None

    def _my_orders(self, symbol: str) -> list[dict]:
        """The bot's own open orders on ``symbol`` (confirmed in this session)."""
        mine = getattr(self.client, "my_order_ids", set()) or set()
        return [o for o in self.client.orders_for(symbol)
                if o.get("id") is not None and int(o["id"]) in mine]

    def open_order_symbols(self) -> set[str]:
        """Canonical symbols on which the bot currently has its OWN open orders
        (used by the engine to resolve a symbol-less command / to block a
        re-entry while a position is still open). Best-effort: never raises."""
        out: set[str] = set()
        try:
            mine = getattr(self.client, "my_order_ids", set()) or set()
            for o in self.client.orders_for(None):
                oid = o.get("id")
                if oid is None or int(oid) not in mine:
                    if self.close_only_mine:
                        continue
                bsym = o.get("symbol")
                if bsym:
                    out.add(str(bsym).upper())
            self._sweep_virtual()                 # an expired zone is not an open order
            with self._be_lock:
                out.update(str(v["symbol"]).upper() for v in self._vpend.values())
        except Exception:
            return out
        return out

    def has_open_order(self, symbol: Optional[str]) -> bool:
        """True when the bot already has an order/position on ``symbol``."""
        if not symbol:
            return False
        try:
            return self._has_order(symbol)
        except Exception:
            return False

    def _order_side(self, o: dict) -> Optional[Side]:
        od = (getattr(self.config, "fxtrendo", {}) or {}).get("order", {}) or {}
        side_map = od.get("side_map", {"BUY": 0, "SELL": 1})
        t = o.get("type")
        if t is not None:
            for name, val in side_map.items():
                if str(t) == str(val):
                    try:
                        return Side(name)
                    except ValueError:
                        pass
        placed = (getattr(self.client, "_placed", {}) or {}).get(o.get("primary_order"))
        sig = placed.get("signal") if isinstance(placed, dict) else None
        return sig.side if sig is not None else None

    @staticmethod
    def _as_float(v, default: float = 0.0) -> float:
        try:
            return float(v) if v not in (None, "") else default
        except (TypeError, ValueError):
            return default

    @staticmethod
    def _order_entry(o: dict) -> Optional[float]:
        for key in ("open", "open_price", "price"):
            try:
                v = float(o.get(key))
                if v > 0:
                    return v
            except (TypeError, ValueError):
                continue
        return None

    def _drop_guards(self, symbol: Optional[str] = None, order_id=None, all_: bool = False) -> int:
        self._drop_auto_be(symbol=symbol, ids=[order_id] if order_id is not None else None,
                           all_=all_)
        with self._be_lock:
            if all_:
                n, self._be_guards = len(self._be_guards), {}
                self._be_retry = {}
                return n
            drop = [oid for oid, g in self._be_guards.items()
                    if (order_id is not None and oid == int(order_id))
                    or (order_id is None and symbol and g["symbol"] == symbol)]
            for oid in drop:
                self._be_guards.pop(oid, None)
                self._be_retry.pop(oid, None)
            return len(drop)

    def guards(self) -> dict[int, dict]:
        """Snapshot of the armed virtual breakeven guards (for the GUI / tests)."""
        with self._be_lock:
            return {k: dict(v) for k, v in self._be_guards.items()}

    def retries(self) -> dict[int, dict]:
        """Snapshot of the pending automatic breakeven retries (GUI / tests)."""
        with self._be_lock:
            return {k: dict(v) for k, v in self._be_retry.items()}

    def _props(self, o: dict) -> dict:
        """Symbol properties (digits, stop_level, ...) of an order's symbol —
        from the client's symbol_list_give cache, else from the order_change
        frame itself (it carries digits)."""
        props: dict = {}
        fn = getattr(self.client, "props_for", None)
        if fn is not None:
            try:
                props = dict(fn(o.get("symbol")) or {})
            except Exception:
                props = {}
        if props.get("digits") is None and o.get("digits") is not None:
            props["digits"] = o.get("digits")
        return props

    def _be_price(self, o: dict, entry: float) -> float:
        digits = self._props(o).get("digits")
        try:
            return round(float(entry), int(digits)) if digits is not None else float(entry)
        except (TypeError, ValueError):
            return float(entry)

    def _arm_virtual(self, symbol: str, orders: list[dict],
                     retry: Optional[dict[int, str]] = None,
                     ref_price: Optional[float] = None) -> list[dict]:
        """Arm the virtual guard on ``orders``. ``retry`` = {order_id: broker
        reason} for orders whose REAL edit was rejected: they also get an
        automatic retry once price is stop_level past the entry. ``ref_price``:
        the channel's entry level — the guard/retry level is _be_ref of it.
        A guard armed with no fresh executable quote or while price has not
        reached its level waits for that level before a retrace may close it."""
        armed: list[dict] = []
        bsym = self.client.broker_symbol(symbol).lower()
        quote = self._live_quote(symbol)
        with self._be_lock:
            for o in orders:
                oid = int(o["id"])
                side, fill = self._order_side(o), self._order_entry(o)
                if side is None or fill is None or oid in self._be_closing:
                    log.warning("breakeven: order %s skipped (side=%s entry=%s)", oid, side, fill)
                    continue
                entry = self._be_ref(o, fill, ref_price)
                old = self._be_guards.get(oid)
                if old is not None and old.get("side") == side:
                    # never loosen a virtual stop that is already tighter (armed at
                    # the fill by a rejected automatic breakeven)
                    previous = old.get("pending_entry", old["entry"])
                    entry = (min(entry, previous) if side == Side.SELL
                             else max(entry, previous))
                active = bool(old is not None and old.get("side") == side
                              and old.get("armed", True))
                reached = False
                if quote is not None:
                    reached = (quote[1] <= entry) if side == Side.SELL else (quote[0] >= entry)
                # An active guard at the legacy zone remains protective while
                # a tighter fill target waits to be reached. Its active state
                # cannot be transferred to an unreached new target.
                pending = active and not reached and abs(old["entry"] - entry) > 1e-9
                effective = old["entry"] if pending else entry
                active = active or reached
                self._be_guards[oid] = {"side": side, "entry": effective, "symbol": symbol,
                                        "bsym": bsym, "armed": active}
                if pending:
                    self._be_guards[oid]["pending_entry"] = entry
                row = {"order_id": oid, "side": side.value, "entry": effective, "armed": active,
                       "waiting_for_price": pending or not active}
                if pending:
                    row["target"] = entry
                if entry != fill:                    # the channel's level, not the bot's fill
                    row["fill"] = fill
                if retry is not None and oid in retry:
                    lvl = self._props(o).get("stop_level")
                    self._be_retry[oid] = {
                        "side": side, "entry": self._be_price(o, entry), "symbol": symbol,
                        "bsym": bsym, "stop_level": float(lvl) if lvl is not None else 0.0,
                        "last_try": 0.0, "inflight": False, "reason": retry[oid], "tries": 0,
                    }
                    row.update(retry=True, reason=retry[oid])
                armed.append(row)
        if armed:
            self._ensure_tick_feed(symbol)
        return armed

    # -- virtual limit orders -------------------------------------------------
    _VFIRE_TRIES = 3

    @staticmethod
    def _tp_first_rule(side: Side, tp1: Optional[float], quote) -> Optional[bool]:
        """S3: does "the first target was reached before the fill -> cancel"
        apply to a zone? Only when the price sits between the entry edge and
        TP1 (BUY: bid < tp1; SELL: ask > tp1). A price already beyond TP1 must
        cross it on its way to the entry, so the rule is off for good
        (server 06:35: 'BUY 4284/4279 TP 4292' at 4301 was cancelled after a
        dip under 4292 and a bounce). None = no quote yet: the first fresh
        tick decides."""
        if tp1 is None:
            return False
        if quote is None:
            return None
        bid, ask = quote
        return (bid < tp1) if side == Side.BUY else (ask > tp1)

    def _add_virtual(self, signal: Signal, edge: float, quote: Any = _FETCH) -> int:
        """Keep a not-yet-reached zone in the bot (Trendo has no resting limit).
        ``quote`` = the live quote the decision was made with (None = none)."""
        if quote is self._FETCH:
            quote = self._live_quote(signal.symbol)
        tp1 = signal.take_profits[0] if signal.take_profits else None
        now = time.time()
        with self._be_lock:
            if self._retired:
                return None                  # stopped meanwhile (R7-1)
            self._vseq += 1
            vid = self._vseq
            self._vpend[vid] = {
                "signal": dataclasses.replace(signal, entries=list(signal.entries),
                                              take_profits=list(signal.take_profits),
                                              take_profit_offsets=list(signal.take_profit_offsets),
                                              warnings=list(signal.warnings)),
                "symbol": signal.symbol,
                "bsym": str(self.client.broker_symbol(signal.symbol)).lower(),
                "side": signal.side, "edge": float(edge),
                # a resting limit fills on a touch of its edge - or within the
                # chase tolerance of it (a fraction of the stop distance)
                "tol": self._chase_tol(signal, edge),
                "sl": signal.stop_loss, "tp1": tp1,
                "tp_first": self._tp_first_rule(signal.side, tp1, quote),
                "source": signal.source or "", "created": now,
                "expires": now + self.vlimit_ttl if self.vlimit_ttl > 0 else float("inf"),
                "firing": False, "tries": 0}
        self._ensure_tick_feed(signal.symbol)
        return vid

    @staticmethod
    def _vid(x) -> Optional[int]:
        """'v12' -> 12 (a virtual order id), else None."""
        if isinstance(x, str) and x.startswith("v") and x[1:].isdigit():
            return int(x[1:])
        return None

    # -- EXB-2: orders sent whose ack came late -------------------------------
    # place_order returns "emitted" with NO order_id when the broker's echo
    # arrives after ack_wait_sec. Such a leg is recorded as "p<primary_order>"
    # (execute() results and _vfired alike), never as nothing: a trade whose ids
    # are missing would otherwise inherit its channel's PREVIOUS trade's ids and
    # a close / breakeven would act on those stale (closed) orders only.
    @staticmethod
    def _is_pid(x) -> bool:
        return isinstance(x, str) and x.startswith("p")

    @staticmethod
    def _placeholder(r: dict) -> str:
        """The id recorded for a sent leg with no acked order id: 'p<po>'
        ('p?' when the send reported no primary_order at all - never known)."""
        po = r.get("primary_order")
        try:
            return f"p{int(po)}"
        except (TypeError, ValueError):
            return "p?"

    def _acked_id(self, pid) -> tuple[str, Optional[int]]:
        """'p<po>' -> ('id', broker order id) once the broker's order_change echo
        of that order_add arrived; ('gone', None) when the broker rejected it
        late (nothing at the broker); ('unknown', None) while no verdict came
        (or the client keeps no record). Never raises."""
        try:
            po = int(str(pid)[1:])
        except (TypeError, ValueError):
            return "unknown", None
        placed = getattr(self.client, "_placed", None)
        if not isinstance(placed, dict):
            return "unknown", None
        lock = getattr(self.client, "_ack_lock", None)
        try:
            if lock is not None:
                with lock:
                    rec = placed.get(po)
            else:
                rec = placed.get(po)
            if not isinstance(rec, dict):
                return "unknown", None
            res = rec.get("result") or {}
            if "confirmed" in rec and isinstance(res, dict) and res.get("order_id") is not None:
                return "id", int(res["order_id"])
            if "error" in rec:
                return "gone", None
        except Exception:
            pass
        return "unknown", None

    def _map_id(self, x) -> tuple[str, Optional[int]]:
        """One recorded broker id (an int, or a 'p<po>' placeholder) ->
        ('id', n) | ('gone', None) | ('unknown', None)."""
        if self._is_pid(x):
            return self._acked_id(x)
        try:
            return "id", int(x)
        except (TypeError, ValueError):
            return "unknown", None

    def _fired_snapshot(self) -> dict[int, list]:
        """vid -> the recorded entries of a fired zone (ints / placeholders)."""
        with self._be_lock:
            return {k: list(f) for k, f in self._vfired.items()}

    def broker_ids(self, ids) -> list:
        """Engine API (restart memory): the broker order ids behind engine ids -
        a fired virtual limit's legs, an acked 'p<po>' leg, a plain id. A
        waiting / cancelled zone and an unacked leg have none (memory-only).
        Never raises."""
        out: list = []
        try:
            fired_all = self._fired_snapshot()
            for i in ids or []:
                vid = self._vid(i)
                if vid is not None:
                    for x in fired_all.get(vid) or []:
                        kind, n = self._map_id(x)
                        if kind == "id":
                            out.append(n)
                    continue
                if self._is_pid(i):
                    kind, n = self._acked_id(i)
                    if kind == "id":
                        out.append(n)
                    continue
                try:
                    out.append(int(i))
                except (TypeError, ValueError):
                    continue
        except Exception:
            pass
        return list(dict.fromkeys(out))

    def bot_order_ids(self) -> set:
        """Engine API (restart memory): every order id this bot opened (restored
        ones included), open or not. Never raises."""
        try:
            return {int(i) for i in (getattr(self.client, "my_order_ids", set()) or set())}
        except Exception:
            return set()

    def _book_ready(self) -> bool:
        ready = getattr(self.client, "_orders_ready", None)
        return ready is None or not callable(getattr(ready, "is_set", None)) or ready.is_set()

    def open_bot_ids(self, symbol) -> set:
        """Engine API: the bot's own OPEN order ids on ``symbol``. While the order
        book has not arrived, every remembered bot order that may be on
        ``symbol`` (recorded there, or symbol unknown) - never "none" just
        because nothing is loaded yet (RM2-R1). Never raises."""
        try:
            if not self._book_ready():
                sym_of = getattr(self.client, "bot_order_symbol", None)
                out = set()
                for i in (getattr(self.client, "my_order_ids", set()) or set()):
                    s = sym_of(int(i)) if callable(sym_of) else None
                    if s is None or s == symbol:
                        out.add(int(i))
                return out
            return {int(o["id"]) for o in self._my_orders(symbol)}
        except Exception:
            return set()

    def persist_ids(self, ids) -> list:
        """Engine API (restart memory): engine ids -> what survives a restart:
        broker ids, and 'p<po>' for a leg whose ack has not arrived (directly or
        as a fired zone's leg); a waiting zone has none. Never raises."""
        out: list = []
        try:
            fired_all = self._fired_snapshot()
            for i in ids or []:
                vid = self._vid(i)
                legs = (fired_all.get(vid) or []) if vid is not None else [i]
                for x in legs:
                    if self._is_pid(x):
                        kind, n = self._acked_id(x)
                        if kind == "id":
                            out.append(n)
                        elif kind == "unknown" and str(x)[1:].isdigit():
                            out.append(str(x))
                        continue
                    try:
                        out.append(int(x))
                    except (TypeError, ValueError):
                        continue
        except Exception:
            pass
        return list(dict.fromkeys(out))

    def bot_owned_detail(self) -> dict:
        """Engine API: {"ready": order book loaded, "orders": [(id, channel,
        symbol, primary_order, time)]} of the bot's own orders whose opening
        channel is known - only those still open once the book is loaded.
        Never raises."""
        try:
            fn = getattr(self.client, "bot_orders_detail", None)
            rows = list(fn()) if callable(fn) else []
            ready = self._book_ready()
            if ready:
                live: dict = {}
                rows = [r for r in rows
                        if r[0] in live.setdefault(r[2], self.open_bot_ids(r[2]))]
            return {"ready": ready, "orders": rows}
        except Exception:
            return {"ready": False, "orders": []}

    def retire(self, why: str = "") -> list:
        """This executor's run is over (GUI Stop; the next Start builds a new one
        on the same broker client): it never opens anything again - execute /
        market_now refuse, new zones are refused and its waiting virtual limits
        are dropped (RS-1, R7-1: also for a call still in flight at Stop).
        Breakeven guards (and the watchdog they need) keep protecting the open
        orders. Returns log lines. Never raises."""
        lines = []
        try:
            with self._be_lock:
                self._retired = True
            for z in self._cancel_virtual(why=why or "stopped"):
                e = z.get("entry")
                lines.append(f"⏹ لیمیت مجازی پرنشده با {why or 'توقف'} لغو شد: {z.get('order_id')}"
                             + (f"@{e:g}" if isinstance(e, (int, float)) else ""))
        except Exception:
            pass
        return lines

    def remember_orders(self, path: str) -> int:
        """Keep the ids of the orders this bot opened across a restart (see
        TrendoClient.remember_orders). Returns how many were restored."""
        fn = getattr(self.client, "remember_orders", None)
        if not callable(fn):
            return 0
        try:
            return int(fn(path) or 0)
        except Exception as exc:
            log.warning("order memory not enabled: %s", exc)
            return 0

    def cancel_virtual(self, symbol, ids, why: str = "") -> list:
        """Engine API (R3): drop ONLY the waiting virtual limits among ``ids``
        (engine ids like 'v12') of ``symbol``. A zone whose worker is sending it
        right now (firing) is left alone - it is being filled. Never resolves
        ids to broker orders, never closes or sends anything. Returns the
        dropped zones ({order_id, virtual, entry}, like _cancel_virtual)."""
        want = {self._vid(i) for i in (ids or [])} - {None}
        out: list[dict] = []
        if not want:
            return out
        with self._be_lock:
            for vid in sorted(want):
                v = self._vpend.get(vid)
                if v is None or v.get("firing"):
                    continue
                if symbol and v["symbol"] != symbol:
                    continue
                self._vpend.pop(vid, None)
                out.append({"order_id": f"v{vid}", "virtual": True, "entry": v["edge"]})
        for o in out:
            log.warning("virtual limit %s on %s cancelled: %s", o["order_id"], symbol, why)
        return out

    def _cancel_virtual(self, symbol: Optional[str] = None, ids=None, source: Optional[str] = None,
                        why: str = "") -> list[dict]:
        """Drop virtual limits (by symbol / ids / source). Returns what was dropped."""
        want = {self._vid(i) for i in ids} - {None} if ids else None
        out = []
        with self._be_lock:
            # A zone whose worker is in flight (firing) is still in _vpend and is
            # cancelled too: the worker re-checks membership before every emit,
            # so it sends nothing and never puts the zone back (VL-2).
            for vid, v in list(self._vpend.items()):
                if symbol and v["symbol"] != symbol:
                    continue
                if want is not None and vid not in want:
                    continue
                if source is not None and v["source"] != source:
                    continue
                self._vpend.pop(vid, None)
                out.append({"order_id": f"v{vid}", "virtual": True, "entry": v["edge"]})
        for o in out:
            log.warning("virtual limit %s on %s cancelled: %s", o["order_id"], symbol, why)
        return out

    def _drop_zone(self, vid: int, v: dict) -> bool:
        """Pop ``vid`` when it is still this very zone. False = a cancel took it."""
        with self._be_lock:
            if self._vpend.get(vid) is v:
                self._vpend.pop(vid, None)
                return True
        return False

    def _requeue_zone(self, vid: int, v: dict) -> bool:
        """Let the next tick decide again (never resurrects a cancelled zone)."""
        with self._be_lock:
            if self._vpend.get(vid) is v:
                v["firing"] = False
                return True
        return False

    def _expired_line(self, v: dict) -> str:
        return (f"⌛ لیمیت مجازی {v['symbol']} {v['edge']:g} بعد از "
                f"{self.vlimit_ttl / 60:.0f} دقیقه پر نشد — لغو شد")

    def _sweep_virtual(self) -> None:
        """Expire zones past their TTL without waiting for a tick: a zone on a
        dead feed (no tick at all) must not wait forever (VL-9). Runs from the
        watchdog and from every open-order query. Never raises."""
        try:
            if not self._vpend:
                return
            now = time.time()
            lines = []
            with self._be_lock:
                for vid, v in list(self._vpend.items()):
                    if not v["firing"] and now > v["expires"]:
                        self._vpend.pop(vid, None)
                        lines.append(self._expired_line(v))
            for line in lines:
                self._emit_event(line)
        except Exception:  # pragma: no cover - housekeeping must never break a caller
            log.debug("virtual limit sweep failed", exc_info=True)

    def _has_virtual(self, symbol: str) -> bool:
        self._sweep_virtual()
        with self._be_lock:
            return any(v["symbol"] == symbol for v in self._vpend.values())

    def virtual_orders(self) -> dict[int, dict]:
        self._sweep_virtual()
        with self._be_lock:
            return {k: dict(v) for k, v in self._vpend.items()}

    def _resolve_ids(self, symbol: str, ids) -> tuple[Optional[set], bool]:
        """Engine order ids -> (real broker ids to act on | None = every bot order
        on the symbol, whether any targeted virtual limit is still pending).

        * a target is open -> only those orders (never the OTHER orders);
        * every target is KNOWN - a bot order of this session, a fired virtual
          limit's orders, a zone that never filled - and none is open -> set():
          the channel's trade is over, act on nothing (VL-5, 03:56 again);
        * a target never seen in this session, or an order sent whose ack has
          not arrived yet ('p<po>' placeholder, EXB-2 - directly or through a
          fired virtual limit) -> None: every bot order on the symbol (old
          rule); once the echo arrived the placeholder maps to its order id."""
        if not ids:
            return None, False
        mine = set(getattr(self.client, "my_order_ids", set()) or set())
        fired_all = self._fired_snapshot()
        fired_ids: set = set()
        for f in fired_all.values():
            for x in f:
                kind, n = self._map_id(x)
                if kind == "id":
                    fired_ids.add(n)
        real: set = set()
        waiting = unknown = False
        for i in ids:
            vid = self._vid(i)
            if vid is not None:
                with self._be_lock:
                    waiting = waiting or vid in self._vpend
                fired = fired_all.get(vid)
                if fired is None:
                    continue                      # waiting / cancelled / expired: never at the broker
                if not fired:
                    unknown = True                # sent at market, nothing recorded
                for x in fired:
                    kind, n = self._map_id(x)
                    if kind == "id":
                        real.add(n)
                    elif kind == "unknown":
                        unknown = True            # sent at market, no id acked yet
                continue
            if self._is_pid(i):
                kind, n = self._acked_id(i)
                if kind == "id":
                    real.add(n)
                elif kind == "unknown":
                    unknown = True                # its echo has not arrived (yet)
                continue                          # 'gone': rejected late, nothing at the broker
            try:
                n = int(i)
            except (TypeError, ValueError):
                unknown = True
                continue
            real.add(n)
            if n not in mine and n not in fired_ids:
                unknown = True
        open_ids = {int(o["id"]) for o in self._my_orders(symbol)}
        live = real & open_ids
        if live:
            return live, waiting
        if unknown:
            return None, False                    # ids unknown: old behaviour
        return set(), waiting

    def trade_state(self, order_ids) -> Optional[bool]:
        """Is the trade behind these executor order ids still alive?

        True  = at least one id is a waiting virtual limit or an open order (a
                fired virtual limit counts through its broker ids, a 'p<po>'
                leg through the order its late echo named);
        False = every id is known to this executor (a bot order of this
                session, a fired / cancelled / expired virtual limit, an acked
                or late-rejected 'p<po>' leg) and none is open or waiting;
        None  = not every id is known - e.g. a leg sent whose echo has not
                arrived yet (EXB-2), or the order book is not loaded yet: the
                caller keeps its old behaviour. Never raises."""
        try:
            if not order_ids:
                return None
            self._sweep_virtual()
            ready = getattr(self.client, "_orders_ready", None)
            book_ok = ready is None or not callable(getattr(ready, "is_set", None)) or ready.is_set()
            open_ids: set[int] = set()
            for o in self.client.orders_for(None) or []:
                try:
                    open_ids.add(int(o.get("id")))
                except (TypeError, ValueError):
                    continue
            mine = {int(x) for x in (getattr(self.client, "my_order_ids", set()) or set())}
            with self._be_lock:
                pend = set(self._vpend)
                raw = {k: list(f) for k, f in self._vfired.items()}
                seq = self._vseq
            # Each recorded entry -> ('id', n) | ('gone', None) | ('unknown', None)
            # (EXB-2: a 'p<po>' leg maps through the client once its echo came).
            fired = {k: [self._map_id(x) for x in f] for k, f in raw.items()}
            fired_ids = {n for f in fired.values() for kind, n in f if kind == "id"}
            known = unknown = 0
            for i in order_ids:
                vid = self._vid(i)
                if vid is not None:
                    if vid in pend:
                        return True
                    if vid in fired:
                        legs = fired[vid]
                        if any(kind == "id" and n in open_ids for kind, n in legs):
                            return True
                        if legs and all(kind != "unknown" for kind, _n in legs):
                            known += 1
                        else:
                            unknown += 1          # sent, never acked: cannot tell
                    elif 0 < vid <= seq:
                        known += 1                # a zone of this session, cancelled / expired
                    else:
                        unknown += 1
                    continue
                if self._is_pid(i):
                    kind, n = self._acked_id(i)
                    if kind == "id" and n in open_ids:
                        return True
                    if kind == "unknown":
                        unknown += 1              # sent, its echo has not arrived: cannot tell
                    else:
                        known += 1                # acked (not open) or rejected late
                    continue
                try:
                    n = int(i)
                except (TypeError, ValueError):
                    unknown += 1
                    continue
                if n in open_ids:
                    return True
                if n in mine or n in fired_ids:
                    known += 1
                else:
                    unknown += 1
            if not book_ok:
                return None
            return False if known and not unknown else None
        except Exception:
            return None

    _TOUCH_GRACE_SEC = 10.0          # > ack_wait_sec: another command may hold the lock

    def _just_touched(self, v: dict, quote: tuple[float, float]) -> bool:
        """The zone was touched moments ago and the fresh price bounced only a
        little past the edge while the worker waited for the lock: still the
        channel's fill. At most one spread and 10 % of the stop distance
        (ENTRY-3) - never the old ~2-point chase."""
        t = v.get("touched")
        if not t or time.time() - t > self._TOUCH_GRACE_SEC or v.get("sl") is None:
            return False
        bid, ask = quote
        buy = v["side"] == Side.BUY
        slip = (ask - v["edge"]) if buy else (v["edge"] - bid)
        cap = min(0.1 * abs(v["edge"] - float(v["sl"])), max(ask - bid, 0.0))
        return slip <= cap

    def _in_zone(self, v: dict, quote: tuple[float, float]) -> bool:
        bid, ask = quote
        return (ask <= v["edge"] + v["tol"]) if v["side"] == Side.BUY else (bid >= v["edge"] - v["tol"])

    def _fire_virtual(self, vid: int) -> None:
        """Worker thread: the price reached a virtual limit -> market order.

        The zone stays in _vpend (firing=True) until an order went out, so a
        close / breakeven / new signal that cancels it meanwhile pops it; the
        membership check before EVERY emit - the re-login / reconnect retry
        included (EXB-1) - then sends nothing, and no failure path ever puts a
        cancelled zone back (VL-2). A send needs a FRESH quote
        taken under the lock that is still in the zone - never the tick's old
        quote alone (VL-4); otherwise the zone waits for the next tick. The
        signal is re-validated like a new one (VL-6)."""
        if self._retired:
            return
        with self._be_lock:
            v = self._vpend.get(vid)
        if v is None:
            return
        line = ""
        ids: list = []                            # broker ids; 'p<po>' = sent, ack late (EXB-2)
        sent = 0
        try:
            with self._lock:
                with self._be_lock:
                    if self._vpend.get(vid) is not v:
                        return                    # cancelled while we waited for the lock
                self._ensure()
                why = self._wallet_mismatch()     # S1: never raise, never REAL by accident
                if why:
                    if self._drop_zone(vid, v):
                        line = f"⛔ لیمیت مجازی {v['symbol']} لغو شد: {why}"
                    return
                with self._be_lock:               # levels may be edited by update_levels
                    market = dataclasses.replace(v["signal"], order_type=OrderType.MARKET,
                                                 entries=list(v["signal"].entries),
                                                 take_profits=list(v["signal"].take_profits),
                                                 warnings=list(v["signal"].warnings))
                quote = self._live_quote(v["symbol"], refresh=True)
                if quote is None or not (self._in_zone(v, quote) or self._just_touched(v, quote)):
                    if self._requeue_zone(vid, v):
                        log.warning("virtual limit v%s %s not sent: %s -> waiting for the next tick",
                                    vid, v["symbol"], "no fresh quote" if quote is None
                                    else f"price {quote[0]:g}/{quote[1]:g} left the zone {v['edge']:g}")
                    return
                reject = (validate_signal(market, self.require_sl, self.max_sl_pct)
                          or self._stale_levels(market, quote))
                if reject:
                    if self._drop_zone(vid, v):
                        line = f"⛔ لیمیت مجازی {v['symbol']} لغو شد: {reject}"
                    return
                plan, size_note = self._plan(market, fill=self._fill_of(market, quote))
                if not plan:
                    if self._drop_zone(vid, v):
                        line = f"⛔ لیمیت مجازی {v['symbol']} لغو شد: {size_note}"
                    return
                limited = self._limits(len(plan), exclude_vid=vid)
                if limited:
                    if self._drop_zone(vid, v):
                        line = f"⏸ لیمیت مجازی {v['symbol']} اجرا نشد: {limited.get('reason')}"
                    return
                rejected: list[str] = []
                cancelled = False
                abe = 0.0

                def _send(lot, tp):
                    # EXB-1: the membership check runs in EVERY call - also the
                    # retry _emit_with_relogin makes after a re-login (1001) or a
                    # reconnect (BrokerDisconnected), which take seconds; a close /
                    # breakeven that popped the zone meanwhile stops the send.
                    # _be_lock is released BEFORE place_order: the socket thread
                    # needs it (_on_tick) to deliver the order's ack.
                    with self._be_lock:
                        gone = self._vpend.get(vid) is not v or self._retired
                    if gone:
                        return {"action": "cancelled_virtual"}
                    r = self._place_live(market, lot, tp,
                                         stop=lambda: self._retired or self._vpend.get(vid) is not v)
                    return {"action": "cancelled_virtual"} if r.get("action") == "cancelled_guard" else r

                try:
                    for lot, tp in plan:
                        # Reconnect (if needed) BEFORE the check, so the client's own
                        # _ensure_socket inside place_order does not fall between the
                        # check and the emit.
                        self._ensure()
                        r = self._emit_with_relogin(lambda lot=lot, tp=tp: _send(lot, tp))
                        if r.get("action") == "cancelled_virtual":
                            cancelled = True      # a close / breakeven took it meanwhile
                            break
                        if r.get("action") == "rejected":
                            rejected.append(str(r.get("reason") or r.get("error")))
                            break
                        sent += 1
                        self.daily.record_trade()
                        # EXB-2: a leg sent without an acked id is recorded as
                        # 'p<primary_order>' (mapped once the broker's echo arrives).
                        ids.append(int(r["order_id"]) if r.get("order_id") is not None
                                   else self._placeholder(r))
                finally:
                    if sent:
                        with self._be_lock:
                            self._vfired[vid] = list(ids)
                            if len(self._vfired) > 500:
                                self._vfired.pop(next(iter(self._vfired)))
                            if self._vpend.get(vid) is v:
                                self._vpend.pop(vid, None)   # never re-queued after a (partial) send
                        abe = self._arm_auto_be(v["symbol"], list(ids), v.get("source") or "")
                if not sent:
                    if cancelled:
                        log.warning("virtual limit v%s cancelled while in flight: nothing sent", vid)
                    else:                         # the broker refused it: the zone ends here
                        self._drop_zone(vid, v)
                        line = (f"⛔ لیمیت مجازی {v['symbol']} رد شد (بروکر): "
                                f"{rejected[0] if rejected else 'no order sent'}")
                    return
                bid, ask = quote
                px = ask if market.side == Side.BUY else bid
                acked = [str(x) for x in ids if isinstance(x, int)]
                unacked = len(ids) - len(acked)
                line = (f"✅ لیمیت مجازی اجرا شد: {market.side.value} {v['symbol']} مارکت {px:g} "
                        f"(ورود {v['edge']:g}، SL {market.stop_loss:g}، {size_note})"
                        + (f" — سفارش {', '.join(acked)}" if acked else "")
                        + (f" — {unacked} سفارش هنوز تأیید نشده" if unacked else "")
                        + (f" — ریسک‌فری خودکار در +{abe:g} پوینت" if abe else "")
                        + (f" — رد جزئی: {rejected[0]}" if rejected else "")
                        + (" — بقیه لغو شد (دستور کانال)" if cancelled else ""))
        except Exception as exc:
            log.exception("virtual limit %s failed", vid)
            if sent:
                line = f"⚠️ لیمیت مجازی {v['symbol']}: {sent} سفارش ارسال شد، بقیه خطا داد: {exc!r}"
            else:
                line = ""
                with self._be_lock:
                    if self._vpend.get(vid) is v:     # a cancelled zone is never put back (VL-2)
                        v["tries"] += 1
                        if v["tries"] < self._VFIRE_TRIES:
                            v["firing"] = False       # transient (link): next tick tries again
                        else:
                            self._vpend.pop(vid, None)
                            line = f"❌ لیمیت مجازی {v['symbol']} بعد از {v['tries']} تلاش لغو شد: {exc!r}"
        finally:
            if line:
                self._emit_event(line)

    def _tick_virtual(self, bsym: str, bid: float, ask: float) -> None:
        """Socket thread: decide for every virtual limit on ``bsym`` (never
        takes self._lock; the market order is sent by a worker thread)."""
        if self._retired:
            return
        now = time.time()
        fire, lines = [], []
        with self._be_lock:
            for vid, v in list(self._vpend.items()):
                if v["bsym"] != bsym or v["firing"]:
                    continue
                buy = v["side"] == Side.BUY
                sl, tp = v["sl"], v["tp1"]
                if now > v["expires"]:
                    self._vpend.pop(vid, None)
                    lines.append(self._expired_line(v))
                    continue
                if sl is not None and ((buy and bid <= sl) or (not buy and ask >= sl)):
                    self._vpend.pop(vid, None)
                    lines.append(f"⛔ لیمیت مجازی {v['symbol']} لغو شد: قیمت از حد ضرر {sl:g} گذشت")
                    continue
                if tp is not None:
                    if v.get("tp_first") is None:
                        # registered without a live quote: the first fresh tick decides (S3)
                        v["tp_first"] = self._tp_first_rule(v["side"], tp, (bid, ask))
                    elif v["tp_first"] and ((bid >= tp) if buy else (ask <= tp)):
                        self._vpend.pop(vid, None)
                        lines.append(f"ℹ️ لیمیت مجازی {v['symbol']} لغو شد: قیمت بدون ورود ما به "
                                     f"حد سود {tp:g} رسید")
                        continue
                if self._in_zone(v, (bid, ask)):
                    v["firing"] = True
                    v["touched"] = time.time()
                    fire.append(vid)
        for vid in fire:
            self._spawn_virtual(vid)
        for line in lines:
            self._emit_event(line)

    def _update_virtual(self, symbol: str, sl, tp, ids=None) -> tuple[list[dict], list[str]]:
        """New SL/TP for a zone that has not filled yet, with the SAME guards as
        a real order (VL-6): side of the entry edge, max_sl_distance_pct and
        allow_sl_widening. A new TP1 re-decides the TP-first rule with the
        current quote (S3). Returns (updated zones, rejection reasons)."""
        want = {self._vid(i) for i in ids} - {None} if ids else None
        quote = self._live_quote(symbol) if tp is not None else None
        done: list[dict] = []
        rejected: list[str] = []
        with self._be_lock:
            for vid, v in self._vpend.items():
                if v["symbol"] != symbol or (want is not None and vid not in want):
                    continue
                side, edge = v["side"], v["edge"]
                changed = False
                if sl is not None:
                    why = self._sl_update_reject(side, edge, v["sl"], float(sl))
                    if why:
                        rejected.append(f"virtual limit v{vid}: {why}")
                    else:
                        v["sl"] = float(sl)
                        v["signal"].stop_loss = float(sl)
                        changed = True
                if tp is not None:
                    why = self._tp_update_reject(side, edge, float(tp))
                    if why:
                        rejected.append(f"virtual limit v{vid}: {why}")
                    else:
                        v["tp1"] = float(tp)
                        v["tp_first"] = self._tp_first_rule(side, float(tp), quote)
                        v["signal"].take_profits = [float(tp)] + list(v["signal"].take_profits[1:])
                        v["signal"].take_profit_offsets = [] # an explicit price replaces relative targets
                        changed = True
                if changed:
                    done.append({"order_id": f"v{vid}", "sl": v["sl"], "tp": v["tp1"], "virtual": True})
        return done, rejected

    def _spawn_virtual(self, vid: int) -> None:
        t = threading.Thread(target=self._fire_virtual, args=(vid,), name=f"vlimit-{vid}", daemon=True)
        self._be_workers = [w for w in self._be_workers if w.is_alive()] + [t]
        t.start()

    def _retry_allowed(self, r: dict, bid: float, ask: float) -> bool:
        """SELL: ask <= entry - stop_level; BUY: bid >= entry + stop_level."""
        lvl = r["stop_level"]
        if r["side"] == Side.SELL:
            return ask <= r["entry"] - lvl + 1e-9
        return bid >= r["entry"] + lvl - 1e-9

    def _retry_breakeven(self, oid: int) -> None:
        """Worker thread: one real SL edit for a guarded order. Success drops
        the guard; a rejection keeps it (the next allowed tick tries again);
        an order that is gone stops the retry."""
        with self._be_lock:
            r, g = self._be_retry.get(oid), self._be_guards.get(oid)
        if r is None or g is None:
            with self._be_lock:
                self._be_retry.pop(oid, None)
            return
        try:
            with self._lock:
                # Re-check under the executor lock: a channel close / the guard
                # itself may have dropped this order while we waited for the
                # lock — then no edit may be sent (the order is closing).
                with self._be_lock:
                    still = oid in self._be_retry and oid in self._be_guards
                if not still:
                    log.warning("breakeven retry of %s skipped: guard dropped meanwhile", oid)
                    return
                # The order book is only trusted once the broker's snapshot is
                # in (connect() empties open_orders until all_orders_wallet):
                # editing now would read "no_open_order" for a live order and
                # drop its guard. Keep guard + retry; the next allowed tick tries.
                ready = getattr(self.client, "_orders_ready", None)
                if ready is not None and not ready.is_set():
                    log.warning("breakeven retry of %s deferred: open-orders snapshot pending", oid)
                    return
                res = self.client.modify_order(oid, sl=r["entry"])
            action = str(res.get("action"))
            if action in ("modified", "emitted"):
                with self._be_lock:
                    had_guard = self._be_guards.pop(oid, None) is not None
                    self._be_retry.pop(oid, None)
                if had_guard:
                    self._emit_event(f"✅ استاپ به نقطهٔ ورود منتقل شد — {r['symbol']} سفارش {oid} "
                                     f"SL={res.get('sl', r['entry'])}")
                else:                        # the guard closed it while the edit was in flight
                    log.warning("breakeven retry of %s -> %s after the guard fired; nothing armed",
                                oid, action)
            elif action == "no_open_order":
                with self._be_lock:
                    self._be_guards.pop(oid, None)
                    self._be_retry.pop(oid, None)
                log.warning("breakeven retry: order %s is gone -> retry stopped", oid)
            elif self._session_expired(res):
                # error 1001: the broker session is gone. Re-sending the same
                # edit every tick would only be rejected again (and never
                # re-logs in): stop the retry, keep the virtual guard.
                with self._be_lock:
                    self._be_retry.pop(oid, None)
                self._emit_event(f"نشست بروکر منقضی شده (error 1001) — تلاش خودکار برای انتقال "
                                 f"استاپ سفارش {oid} متوقف شد؛ گارد مجازی می‌ماند، لاگین دوباره لازم است")
            else:
                with self._be_lock:
                    if oid in self._be_retry:
                        self._be_retry[oid]["reason"] = str(res.get("reason") or action)
                log.warning("breakeven retry of %s -> %s (%s); guard kept, will retry",
                            oid, action, res.get("reason") or "")
        except Exception:
            log.exception("breakeven retry of order %s failed", oid)
        finally:
            with self._be_lock:
                if oid in self._be_retry:
                    self._be_retry[oid]["inflight"] = False

    def _spawn_retry(self, oid: int) -> None:
        t = threading.Thread(target=self._retry_breakeven, args=(oid,),
                             name=f"be-retry-{oid}", daemon=True)
        self._be_workers = [w for w in self._be_workers if w.is_alive()] + [t]
        t.start()

    def wait_retries(self, timeout: float = 5.0) -> None:
        """Join the in-flight retry workers (tests / shutdown)."""
        for w in list(self._be_workers):
            w.join(timeout)

    def _ensure_tick_feed(self, symbol: str) -> None:
        if not self._be_listening and hasattr(self.client, "add_price_listener"):
            self.client.add_price_listener(self._on_tick)
            self._be_listening = True
        sub = getattr(self.client, "subscribe_prices", None)
        if sub is not None:
            try:
                sub([self.client.broker_symbol(symbol)])
            except Exception as exc:  # pragma: no cover - network path
                log.warning("price subscription for %s failed: %s", symbol, exc)

    def _on_tick(self, broker_symbol, bid, ask) -> None:
        """Socket.IO thread. Close a guarded order at market once price is back
        at its entry. Never takes self._lock (the socket thread must not wait
        on a connect() that itself waits for socket events)."""
        if not self._be_guards and not self._vpend and not self._auto_be:
            return
        try:
            bid, ask = float(bid), float(ask)
        except (TypeError, ValueError):
            return
        bsym = str(broker_symbol).lower()
        if self._vpend:
            self._tick_virtual(bsym, bid, ask)
        open_orders = getattr(self.client, "open_orders", None)
        # The order book is only trusted once the broker's snapshot is in:
        # connect() resets open_orders to {} until all_orders_wallet arrives,
        # and a tick in that window must not disarm a guard.
        ready = getattr(self.client, "_orders_ready", None)
        book_ok = isinstance(open_orders, dict) and (ready is None or ready.is_set())
        if self._auto_be:
            self._tick_auto_be(bsym, bid, ask, open_orders, book_ok)
        if not self._be_guards:
            return
        to_close: list[tuple[int, dict]] = []
        to_retry: list[int] = []
        now = time.time()
        with self._be_lock:
            for oid, g in list(self._be_guards.items()):
                if g["bsym"] != bsym:
                    continue
                if book_ok and oid not in open_orders:
                    self._be_guards.pop(oid, None)          # closed elsewhere (SL/TP/manual)
                    self._be_retry.pop(oid, None)
                    continue
                pending = g.get("pending_entry")
                if pending is not None and ((ask <= pending) if g["side"] == Side.SELL else (bid >= pending)):
                    g["entry"] = pending
                    g.pop("pending_entry", None)
                    continue                     # this tick first reached the tighter target
                if not g.get("armed", True):
                    reached = (ask <= g["entry"]) if g["side"] == Side.SELL else (bid >= g["entry"])
                    if reached:
                        g["armed"] = True
                    # Reaching the level activates protection; it is not a
                    # retrace on this same tick. The broker's original SL has
                    # continued protecting the trade while this guard waited.
                    continue
                hit = (ask >= g["entry"]) if g["side"] == Side.SELL else (bid <= g["entry"])
                if hit and oid not in self._be_closing and now >= g.get("next_try", 0.0):
                    self._be_closing.add(oid)
                    self._be_closed_at[oid] = now
                    self._be_guards.pop(oid, None)
                    self._be_retry.pop(oid, None)           # the guard won: no more edits
                    to_close.append((oid, g))
            # Real-breakeven retry: once price is stop_level past the entry the
            # broker will accept SL = entry. One edit at a time per order, at
            # most every _BE_RETRY_SEC; the worker thread does the emit.
            for oid, r in list(self._be_retry.items()):
                if r["bsym"] != bsym:
                    continue
                if oid not in self._be_guards:
                    self._be_retry.pop(oid, None)
                    continue
                if (not r["inflight"] and now - r["last_try"] >= self._BE_RETRY_SEC
                        and self._retry_allowed(r, bid, ask)):
                    r["inflight"], r["last_try"] = True, now
                    r["tries"] += 1
                    to_retry.append(oid)
        for oid in to_retry:
            self._spawn_retry(oid)
        for oid, g in to_close:
            # The ack of the close arrives on this socket thread, so it can only
            # be waited for on a worker (BE-1: the close was never confirmed).
            t = threading.Thread(target=self._guard_close, args=(oid, g, bid, ask),
                                 name=f"be-close-{oid}", daemon=True)
            self._be_workers = [w for w in self._be_workers if w.is_alive()] + [t]
            t.start()

    # ------------------------------------------------------------ automatic BE
    # Per-channel auto_breakeven_points ("when your position is 10-20 pips in
    # profit, risk-free it yourself at once" - the leader's member rule): the
    # legs a channel's signal sent are watched on ticks; once the bot's own
    # fill is that many points in profit (BUY: bid - fill, SELL: fill - ask)
    # ONE real SL edit moves the stop to the fill. A broker rejection arms the
    # same virtual guard + automatic retry as a rejected channel breakeven; a
    # channel breakeven / close on the order ends the watch. In memory only.
    _AUTO_BE_ACK_GRACE = 900.0      # s: a leg whose ack never comes is forgotten
    _AUTO_BE_BOOK_GRACE = 30.0      # s: a fresh id not yet in the order book is not "closed"

    def _fresh_auto_tp(self, sig: Signal, tp):
        """The auto take profit (take_profit_points, a signal without its own TP)
        measured from the quote of THIS send: a retry after a reconnect /
        re-login goes out seconds later at a moved price. Unchanged when there
        is no fresh quote or the TP is the channel's own."""
        if sig.take_profit_offsets:
            ref = sig.take_profit_reference
            if ref is None or tp is None:
                return tp
            sign = 1 if sig.side == Side.BUY else -1
            distances = [d for d in sig.take_profit_offsets if round(ref + sign * d, 2) == tp]
            fill = self._fill_of(sig, self._live_quote(sig.symbol))
            if distances and fill is not None:
                return round(fill + sign * distances[0], 2)
            return tp
        pts = self._tp_points(sig.source) if not sig.take_profits else 0.0
        if pts <= 0 or tp is None:
            return tp
        fill = self._fill_of(sig, self._live_quote(sig.symbol))
        if fill is None:
            return tp
        return round(fill + pts if sig.side == Side.BUY else fill - pts, 2)

    def _tp_points(self, source: str) -> float:
        """Per-channel take profit in points from the fill for signals that
        carry none (0 = off)."""
        settings = getattr(self.config, "channel_settings", {}) or {}
        cs = settings.get(source) if source else None
        try:
            pts = float(getattr(cs, "take_profit_points", 0.0) or 0.0) if cs is not None else 0.0
        except (TypeError, ValueError):
            pts = 0.0
        return pts if pts > 0 else 0.0

    def _auto_be_points(self, source: str) -> float:
        """Per-channel automatic-breakeven trigger in points (0 = off)."""
        settings = getattr(self.config, "channel_settings", {}) or {}
        cs = settings.get(source) if source else None
        try:
            pts = float(getattr(cs, "auto_breakeven_points", 0.0) or 0.0) if cs is not None else 0.0
        except (TypeError, ValueError):
            pts = 0.0
        return pts if pts > 0 else 0.0

    def _arm_auto_be(self, symbol: str, ids: list, source: str) -> float:
        """Watch the just-sent legs ``ids`` (broker ids / 'p<po>' placeholders)
        of the channel ``source``. -> the trigger in points (0 = none)."""
        pts = self._auto_be_points(source or "")
        ids = [x for x in (ids or ()) if x is not None]
        if pts <= 0 or not ids:
            return 0.0
        try:
            bsym = str(self.client.broker_symbol(symbol)).lower()
        except Exception:
            bsym = str(symbol).lower()
        now = time.time()
        with self._be_lock:
            for x in ids:
                self._auto_be[x] = {"symbol": symbol, "bsym": bsym, "points": float(pts),
                                    "source": source or "", "armed": now, "inflight": False,
                                    "last_try": 0.0, "tries": 0}
        self._ensure_tick_feed(symbol)
        return float(pts)

    def _drop_auto_be(self, symbol: Optional[str] = None, ids=None, all_: bool = False) -> int:
        """Forget the automatic breakeven of ``ids`` (broker ids and/or recorded
        keys - a placeholder is matched through its acked id), of every order
        on ``symbol`` (ids None), or of all. -> how many were dropped."""
        with self._be_lock:
            if all_:
                n, self._auto_be = len(self._auto_be), {}
                return n
            keys = list(self._auto_be.keys())
        want: set = set()
        for i in (ids or ()):
            want.add(i)
            try:
                want.add(int(i))
            except (TypeError, ValueError):
                pass
        drop: set = set()
        for key in keys:
            _kind, oid = self._map_id(key)           # no executor lock held here
            if key in want or (oid is not None and oid in want):
                drop.add(key)
        with self._be_lock:
            if ids is None and symbol:
                drop.update(k for k, w in self._auto_be.items() if w["symbol"] == symbol)
            n = 0
            for k in drop:
                n += self._auto_be.pop(k, None) is not None
            return n

    def adopt_auto_be(self, prev) -> int:
        """GUI Start: take over the automatic-breakeven watches of the retired
        executor ``prev`` (same broker client), so that a channel breakeven /
        close handled by THIS run ends them. -> how many. Never raises."""
        try:
            if prev is None or prev is self or getattr(prev, "client", None) is not self.client:
                return 0
            with prev._be_lock:
                rows, prev._auto_be = dict(prev._auto_be), {}
            if not rows:
                return 0
            with self._be_lock:
                for k, w in rows.items():
                    self._auto_be.setdefault(k, {**w, "inflight": False})
            for sym in {w["symbol"] for w in rows.values()}:
                self._ensure_tick_feed(sym)
            return len(rows)
        except Exception:  # pragma: no cover - a hand-over must never break a Start
            log.debug("automatic breakeven hand-over failed", exc_info=True)
            return 0

    def auto_breakevens(self) -> dict:
        """Snapshot of the armed automatic breakevens (GUI / tests)."""
        with self._be_lock:
            return {k: dict(v) for k, v in self._auto_be.items()}

    def _tick_auto_be(self, bsym: str, bid: float, ask: float, open_orders, book_ok: bool) -> None:
        """Socket thread: decide which watched orders reached their trigger;
        the edit runs on a worker (never waits for the executor lock here)."""
        with self._be_lock:
            rows = [(k, dict(w)) for k, w in self._auto_be.items() if w["bsym"] == bsym]
            owned = set(self._be_guards) | set(self._be_retry) | set(self._be_closing)
        if not rows:
            return
        now = time.time()
        fire: list = []
        drop: list = []
        for key, w in rows:
            kind, oid = self._map_id(key)            # 'p<po>' -> its acked id
            if kind == "gone" or (oid is None and now - w["armed"] > self._AUTO_BE_ACK_GRACE):
                drop.append(key)                     # rejected late / never acked
                continue
            if oid is None:
                continue                             # ack still pending
            if oid in owned:
                drop.append(key)                     # a channel breakeven / guard owns it
                continue
            o = open_orders.get(oid) if isinstance(open_orders, dict) else None
            if o is None:
                if book_ok and now - w["armed"] > self._AUTO_BE_BOOK_GRACE:
                    drop.append(key)                 # closed elsewhere (SL/TP/manual)
                continue
            side, fill = self._order_side(o), self._order_entry(o)
            if side is None or fill is None:
                continue
            gain = (bid - fill) if side == Side.BUY else (fill - ask)
            if (gain + 1e-9 >= w["points"] and not w["inflight"]
                    and now - w["last_try"] >= self._BE_RETRY_SEC):
                fire.append((key, oid))
        if not drop and not fire:
            return
        spawn: list = []
        with self._be_lock:
            for key in drop:
                self._auto_be.pop(key, None)
            for key, oid in fire:
                w = self._auto_be.get(key)
                if w is None or w["inflight"]:
                    continue
                w["inflight"], w["last_try"] = True, now
                w["tries"] += 1
                spawn.append((key, oid))
        for key, oid in spawn:
            t = threading.Thread(target=self._auto_be_fire, args=(key, oid),
                                 name=f"auto-be-{oid}", daemon=True)
            self._be_workers = [x for x in self._be_workers if x.is_alive()] + [t]
            t.start()

    def _auto_be_fire(self, key, oid: int) -> None:
        """Worker thread: the automatic breakeven's one real SL edit - the stop
        to the bot's own fill, never loosening a stop that is already tighter
        (_be_ref), and only while a fresh quote still shows the trigger.
        Accepted -> done; rejected / unconfirmed -> virtual guard + automatic
        retry at the fill (as a rejected channel breakeven); session expired ->
        one re-login + one retry, still expired -> guard only; no modify event
        configured -> guard only; order gone -> forgotten; a wallet mismatch
        forgets the watch (every command is refused then). Any other result
        keeps the watch for the next allowed tick."""
        with self._be_lock:
            w = self._auto_be.get(key)
        if w is None:
            return
        symbol, pts = w["symbol"], w["points"]
        try:
            with self._lock:
                with self._be_lock:
                    if key not in self._auto_be:
                        return
                    owned = (oid in self._be_guards or oid in self._be_retry
                             or oid in self._be_closing)
                if owned:
                    self._drop_auto_be(ids=[key])
                    return
                ready = getattr(self.client, "_orders_ready", None)
                if ready is not None and not ready.is_set():
                    log.warning("auto breakeven of %s deferred: open-orders snapshot pending", oid)
                    return
                why = self._wallet_blocked()
                if why:
                    self._drop_auto_be(ids=[key])
                    log.warning("auto breakeven of %s dropped: %s", oid, why)
                    return
                o = next((x for x in self._my_orders(symbol) if int(x["id"]) == oid), None)
                fill = self._order_entry(o) if o is not None else None
                if fill is None:
                    self._drop_auto_be(ids=[key])
                    log.warning("auto breakeven: order %s is gone / has no fill -> forgotten", oid)
                    return
                sl = self._be_price(o, self._be_ref(o, fill, None))
                cur = self._as_float(o.get("sl"), 0.0)
                if cur > 0 and abs(cur - sl) < 1e-9:     # already at / inside the fill
                    self._drop_auto_be(ids=[key])
                    log.warning("auto breakeven of %s: stop already at %s -> nothing to do", oid, cur)
                    return
                # The tick that triggered this worker may be old by now (it waited
                # for the executor lock): like a virtual limit (VL-4) the edit needs
                # a quote that still shows the trigger. Otherwise nothing is sent
                # and no guard is armed - the watch waits for the next tick.
                side, quote = self._order_side(o), self._live_quote(symbol)
                if side is not None and quote is not None:
                    gain = (quote[0] - fill) if side == Side.BUY else (fill - quote[1])
                    if gain + 1e-9 < pts:
                        log.warning("auto breakeven of %s: only %+.2f points in profit now "
                                    "(trigger %g) -> nothing sent, waiting for the next tick",
                                    oid, gain, pts)
                        return
                if not self._modify_event():
                    # virtual-only breakeven (modify_event empty): the guard, as breakeven()
                    self._drop_auto_be(ids=[key])
                    self._arm_virtual(symbol, [o])
                    self._emit_event(f"🛡 ریسک‌فری خودکار: {symbol} سفارش {oid} {pts:g} پوینت در سود — "
                                     f"ویرایش واقعی استاپ تنظیم نشده (modify_event)؛ گارد مجازی روی "
                                     f"ورود {sl:g} فعال شد")
                    return
                # error 1001 -> one re-login + one retry, as every other order / edit / close
                res = self._emit_with_relogin(lambda: self.client.modify_order(oid, sl=sl))
                action = str(res.get("action"))
                if action in ("modified", "emitted"):
                    self._drop_auto_be(ids=[key])
                    self._emit_event(f"🛡 ریسک‌فری خودکار: {symbol} سفارش {oid} {pts:g} پوینت در سود — "
                                     f"استاپ روی ورود ربات {sl:g} رفت (SL={res.get('sl', sl)})")
                elif action == "no_open_order":
                    ready = getattr(self.client, "_orders_ready", None)
                    if ready is not None and not ready.is_set():
                        log.warning("auto breakeven of %s deferred: open-orders snapshot "
                                    "pending after the re-login", oid)
                        return                   # the watch stays: the next tick tries again
                    self._drop_auto_be(ids=[key])
                    log.warning("auto breakeven: order %s is gone -> forgotten", oid)
                elif self._session_expired(res):
                    self._drop_auto_be(ids=[key])
                    self._arm_virtual(symbol, [o])
                    self._emit_event(f"نشست بروکر منقضی شده (error 1001) — ریسک‌فری خودکار سفارش {oid} "
                                     f"{symbol} رد شد؛ گارد مجازی روی ورود {sl:g} فعال شد، "
                                     "لاگین دوباره لازم است")
                elif action in ("rejected", "rejected_local", "unconfirmed"):
                    reason = str(res.get("reason") or action)
                    self._drop_auto_be(ids=[key])
                    self._arm_virtual(symbol, [o], retry={oid: reason})
                    self._emit_event(f"🛡 ریسک‌فری خودکار: استاپ سفارش {oid} {symbol} فعلاً به ورود "
                                     f"{sl:g} منتقل نشد ({reason}) — گارد مجازی فعال شد و خودکار "
                                     "دوباره تلاش می‌شود")
                else:
                    log.warning("auto breakeven of %s -> %s (%s); kept, the next tick tries again",
                                oid, action, res.get("reason") or "")
        except Exception:
            log.exception("auto breakeven of order %s failed", oid)
        finally:
            with self._be_lock:
                w = self._auto_be.get(key)
                if w is not None:
                    w["inflight"] = False

    _GUARD_CLOSE_WAIT = 4.0

    def _guard_close(self, oid: int, g: dict, bid: float, ask: float) -> None:
        """Worker thread: the virtual guard's market close, CONFIRMED. A close
        the broker rejects or never acks (server 2026-09-24: 25 socket drops in
        one session) re-arms the guard and clears the 120 s skip, so neither the
        guard nor a channel close is lost. ``_be_closing`` stays set meanwhile,
        so a channel close cannot send a second close in that window."""
        act, why = "error", ""
        try:
            res = self.client.close_order(order_id=oid, symbol=g["symbol"], only_mine=True,
                                          wait_sec=self._GUARD_CLOSE_WAIT)
            r0 = (res.get("results") or [res])[0]
            act = str(r0.get("action") or res.get("action"))
            why = str(r0.get("reason") or r0.get("error") or "")
        except Exception as exc:
            log.exception("virtual breakeven close of order %s failed", oid)
            why = repr(exc)
        if not self._close_done(oid, act):
            act, why = self._send_deferred_close(oid, g, act, why)
        if self._close_done(oid, act):
            with self._be_lock:
                self._be_closing.discard(oid)
                self._be_deferred.pop(oid, None)
            if act == "no_open_order":
                self._emit_event(f"ℹ️ گارد بریک‌ایون: سفارش {oid} {g['symbol']} دیگر باز نبود "
                                 "(SL/TP یا دستی)")
            else:
                self._emit_event(f"🟡 گارد بریک‌ایون: قیمت به ورود {g['entry']:g} برگشت — سفارش {oid} "
                                 f"{g['symbol']} به مارکت بسته شد (bid={bid:g} ask={ask:g})")
            return
        # re-arm: nothing sent -> the next tick at/through the entry retries at
        # once; after that (and after a rejected / unconfirmed close) with a
        # growing back-off, so a broker that keeps refusing (e.g. an expired
        # session) is not hit every 2 s forever (BE1-A).
        fails = int(g.get("fails", 0)) + 1
        delay = 0.0 if (act == "error" and fails == 1) else min(
            self._GUARD_MAX_BACKOFF, self._BE_RETRY_SEC * 2 ** min(fails - 1, 10))
        if getattr(self.client, "needs_relogin", False):
            delay = max(delay, 30.0)
        with self._be_lock:
            self._be_closed_at.pop(oid, None)        # a channel close may close it again
            self._be_guards.setdefault(oid, {**g, "next_try": time.time() + delay, "fails": fails})
            self._be_closing.discard(oid)
        if fails & (fails - 1) == 0:                 # 1st, 2nd, 4th, 8th ... failure only
            self._emit_event(f"❌ گارد بریک‌ایون: بستن سفارش {oid} {g['symbol']} تأیید نشد "
                             f"({act}{': ' + why if why else ''}) — گارد دوباره فعال شد"
                             + (f" (تلاش {fails})" if fails > 1 else ""))

    _GUARD_MAX_BACKOFF = 60.0

    def _close_done(self, oid: int, act: str) -> bool:
        """Acked, or the TRUSTED book no longer lists the order ('no_open_order'
        from an empty book during a reconnect proves nothing)."""
        return act == "closed" or (act in ("emitted", "no_open_order") and self._book_says_gone(oid))

    def _book_says_gone(self, oid: int) -> bool:
        """The order book shows ``oid`` closed - trusted only once the broker's
        snapshot is in (a reconnect during the ack wait empties it, BE1-B)."""
        ready = getattr(self.client, "_orders_ready", None)
        if ready is not None and not ready.is_set():
            return False
        open_orders = getattr(self.client, "open_orders", None)
        return (isinstance(open_orders, dict) and oid not in open_orders
                and (ready is None or ready.is_set()))

    def _send_deferred_close(self, oid: int, g: dict, act: str, why: str) -> tuple[str, str]:
        """The guard close failed: a channel close skipped meanwhile is sent now."""
        with self._be_lock:
            frac = self._be_deferred.pop(oid, None)
        if frac is None:
            return act, why
        try:
            res = self.client.close_order(order_id=oid, symbol=g["symbol"], fraction=frac,
                                          only_mine=True, wait_sec=self._GUARD_CLOSE_WAIT)
            r0 = (res.get("results") or [res])[0]
            act2 = str(r0.get("action") or res.get("action"))
            why2 = str(r0.get("reason") or r0.get("error") or "")
        except Exception as exc:
            log.exception("deferred channel close of order %s failed", oid)
            act2, why2 = "error", repr(exc)
        self._emit_event(f"🛑 دستور بستن کانال (رسیده هنگام بستن گارد) برای سفارش {oid} {g['symbol']} "
                         f"اکنون ارسال شد → {act2}")
        if frac < 1.0 and act2 in ("closed", "emitted"):
            return act, why                          # half closed: the guard stays for the rest
        return act2, why2

    def _be_ref(self, o: dict, entry: float, ref_price: Optional[float]) -> float:
        """The breakeven level of order ``o``: the channel's reference price when
        given (a member follows the leader's levels, not its own fill) unless it
        is more than half the order's stop distance WORSE than the fill, or on
        the profit side of the fill — then the fill itself. A stop that is
        already at or inside the level is kept (never loosened)."""
        entry = float(entry)
        side = self._order_side(o)
        sl0 = self._as_float(o.get("sl"), 0.0)
        level = entry
        if ref_price is not None and side is not None:
            try:
                ref = float(ref_price)
            except (TypeError, ValueError):
                ref = 0.0
            if ref > 0:
                if sl0 > 0 and abs(sl0 - ref) <= 1e-9:
                    return sl0                          # a second breakeven: already there
                worse = (ref - entry) if side == Side.SELL else (entry - ref)
                # A reference on the PROFIT side of the fill (the bot filled
                # better than the channel's edge) is never used: a stop past
                # the entry is rejected by the broker and its guard would
                # close the trade at market on the next tick. The fill it is.
                if worse > 1e-9:
                    dist = abs(entry - sl0) if sl0 > 0 else 0.0
                    if worse <= 0.5 * dist + 1e-9:
                        level = ref
        # Never loosen: a stop already at or inside the breakeven level (the
        # channel tightened it, or a second breakeven) stays where it is.
        if sl0 > 0 and side is not None:
            if (sl0 <= level + 1e-9) if side == Side.SELL else (sl0 >= level - 1e-9):
                return sl0
        return level

    async def breakeven(self, symbol: Optional[str], order_ids: Optional[list] = None,
                        ref_price: Optional[float] = None) -> dict[str, Any]:
        """Move the bot's open orders on ``symbol`` to breakeven (``order_ids``:
        only the orders of the channel's latest signal, when still open). A
        virtual limit that never filled is cancelled: the channel's trade is
        already at breakeven, entering it now would be a new trade.
        ``ref_price``: the channel's entry level (breakeven_ref: signal) — the
        stop goes there instead of the bot's own fill, see _be_ref.

        Result action: breakeven_set (real SL edit), breakeven_virtual (guard
        installed — waits to reach its level if currently losing/no fresh quote;
        in memory only), pending_cancelled, no_open_order, dry_run, refused."""
        if not symbol:
            return {"executor": self.name, "action": "refused",
                    "reason": "no symbol given (would touch every position)", "orders": []}
        if not self.live:
            return {"executor": self.name, "action": "dry_run", "symbol": symbol, "orders": []}
        cancelled = self._cancel_virtual(symbol=symbol, ids=order_ids, why="breakeven before the fill")

        def _do():
            with self._lock:
                self._ensure()
                orders = self._my_orders(symbol)
                targets, _pend = self._resolve_ids(symbol, order_ids)
                if targets is not None:
                    orders = [o for o in orders if int(o["id"]) in targets]
                if not orders:
                    if cancelled:
                        return {"action": "pending_cancelled", "symbol": symbol, "orders": cancelled}
                    return {"action": "no_open_order", "symbol": symbol, "orders": []}
                why = self._wallet_blocked()
                if why:
                    return {"action": "refused", "symbol": symbol, "reason": why, "orders": []}
                self._drop_auto_be(ids=[int(o["id"]) for o in orders])   # the channel's breakeven owns them now
                retry: dict[int, str] = {}
                expired: dict[int, str] = {}          # rejected with error 1001: guard, no retry
                done: list[dict] = []
                if self._modify_event():
                    rest: list[dict] = []
                    for o in orders:
                        entry = self._order_entry(o)
                        if entry is None:
                            rest.append(o)
                            continue
                        sl = self._be_price(o, self._be_ref(o, entry, ref_price))
                        cur = self._as_float(o.get("sl"), 0.0)
                        if cur > 0 and abs(cur - sl) < 1e-9:      # already there: no edit, no guard
                            done.append({"order_id": o["id"], "sl": sl, "action": "unchanged"})
                            continue
                        res = self.client.modify_order(o["id"], sl=sl)
                        action = str(res.get("action"))
                        if action in ("modified", "emitted"):
                            done.append({"order_id": o["id"], "sl": res.get("sl", sl), **res})
                        elif self._session_expired(res):
                            # error 1001: session expired. Guard only — a retry
                            # would be rejected on every tick until re-login.
                            expired[int(o["id"])] = str(res.get("reason") or action)
                            rest.append(o)
                        elif action in ("rejected", "rejected_local", "unconfirmed"):
                            # SL not yet stop_level past the entry (or no ack):
                            # virtual guard now + automatic real retry on ticks.
                            retry[int(o["id"])] = str(res.get("reason") or action)
                            rest.append(o)
                        else:                              # no_open_order etc.
                            log.warning("breakeven: order %s -> %s", o.get("id"), res)
                    if done and not rest:
                        out_set = {"action": "breakeven_set", "symbol": symbol, "orders": done}
                        if ref_price is not None:
                            out_set["ref_price"] = float(ref_price)
                        return out_set
                    orders = rest
                    if not orders:
                        return {"action": "no_open_order", "symbol": symbol, "orders": []}
                armed = self._arm_virtual(symbol, orders, retry=retry or None, ref_price=ref_price)
                if not armed:
                    return {"action": "no_open_order", "symbol": symbol, "orders": [],
                            "reason": "open orders lack a side/entry price"}
                out = {"action": "breakeven_virtual", "symbol": symbol, "orders": armed,
                       "note": "virtual guard: first reaches entry, then closes at market on a return; "
                               "in-memory only, lost on restart"}
                if ref_price is not None:
                    out["ref_price"] = float(ref_price)
                if retry:
                    reason = next(iter(retry.values()))
                    out.update(retry=True, reason=reason)
                    self._emit_event("استاپ فعلاً به نقطهٔ ورود منتقل نشد — گارد مجازی "
                                     f"ثبت شد و خودکار دوباره تلاش می‌شود ({symbol}: {reason})")
                if expired:
                    reason = next(iter(expired.values()))
                    out.update(session_expired=True, reason=out.get("reason", reason))
                    self._emit_event("نشست بروکر منقضی شده (error 1001) — ویرایش استاپ ارسال نشد؛ "
                                     f"گارد مجازی ثبت شد، لاگین دوباره لازم است ({symbol}: {reason})")
                if done:
                    out["set"] = done
                return out
        result = await asyncio.to_thread(_do)
        return {"executor": self.name, **result}

    # -- enter at market ------------------------------------------------------
    def _has_order(self, symbol: str) -> bool:
        """True when the bot already has an order (open, filled, still
        unconfirmed, or a virtual limit waiting for the price) on ``symbol``.
        With close_only_bot_orders=false any order on the symbol counts."""
        return self._has_virtual(symbol) or self._has_real_order(symbol)

    def _has_real_order(self, symbol: str) -> bool:
        orders = self.client.orders_for(symbol)
        if not self.close_only_mine and orders:
            return True
        mine = getattr(self.client, "my_order_ids", set()) or set()
        if any(o.get("id") is not None and int(o["id"]) in mine for o in orders):
            return True
        placed = getattr(self.client, "_placed", {}) or {}
        now = time.time()
        return any("confirmed" not in p and "error" not in p and now - p.get("t0", 0) < 60
                   and getattr(p.get("signal"), "symbol", None) == symbol
                   for p in placed.values())

    async def market_now(self, symbol: Optional[str], signal: Optional[Signal]) -> dict[str, Any]:
        """"مارکت بزن": open the tracked ``signal`` at market — only when no
        order for the symbol exists yet (the limit never got placed / was
        cancelled by hand). An existing order is left alone: converting a
        pending order needs a broker event that was never captured."""
        if not symbol or signal is None:
            return {"executor": self.name, "action": "refused", "reason": "no tracked signal"}
        market = dataclasses.replace(signal, order_type=OrderType.MARKET,
                                     warnings=list(signal.warnings))
        if not self.live:
            return {"executor": self.name, "action": "dry_run", "symbol": symbol,
                    "order_fields": self.client.build_order_fields(market)
                    if hasattr(self.client, "build_order_fields") else None}

        # "نرسید قیمت مارکت بزن": the zone we are waiting for is given up and the
        # trade is taken now. VL-7: nothing is cancelled before the checks below
        # (an order_exists / stale refusal leaves every zone waiting); execute()
        # drops THIS channel's zones under the lock when the market order goes
        # ahead and reports them as replaced_virtual. Other channels' zones stay.

        def _check():
            with self._lock:
                self._ensure()
                if self._has_real_order(symbol):
                    return {"action": "order_exists", "symbol": symbol}
                # The tracked levels are minutes old: a market order whose SL or
                # TP the price has already passed is refused, never sent. Same
                # SL/TP check as the entry adjust (_entry_reject).
                quote = self._live_quote(symbol)
                reject = self._stale_levels(market, quote) if quote is not None else ""
                if reject:
                    return {"action": "stale", "reason": reject}
                return None
        pre = await asyncio.to_thread(_check)
        if pre and pre.get("action") == "order_exists":
            return {"executor": self.name, **pre}
        if pre and pre.get("reason"):
            log.warning("market_now refused (%s): %s", pre["reason"], market.summary())
            return {"executor": self.name, "action": "refused", "symbol": symbol,
                    "reason": pre["reason"]}
        res = await self.execute(market, _force_market=True)
        res.setdefault("market_now", True)
        return res

    async def modify(self, order_id, sl=None, tp=None) -> dict[str, Any]:
        if not self.live:
            return {"executor": self.name, "action": "dry_run_modify", "order_id": order_id,
                    "sl": sl, "tp": tp}

        def _do():
            with self._lock:
                self._ensure()
                why = self._wallet_blocked()
                if why:
                    return {"action": "refused", "order_id": order_id, "reason": why}
                return self._emit_with_relogin(
                    lambda: self.client.modify_order(order_id, sl=sl, tp=tp))
        result = await asyncio.to_thread(_do)
        return {"executor": self.name, **result}

    # -- level updates on open orders (F3) ------------------------------------
    def _sl_update_reject(self, side: Optional[Side], entry: float, cur_sl: float,
                          new_sl: float) -> str:
        """'' when ``new_sl`` may replace ``cur_sl`` on an order opened at
        ``entry``; else the Persian-free reason. Guards: correct side of the
        open price, within ``max_sl_pct`` of it, and (unless allow_sl_widening)
        the stop may only tighten, never widen (move further from entry)."""
        if side == Side.BUY:
            if new_sl >= entry:
                return f"new SL {new_sl:g} not below BUY open {entry:g}"
            widening = cur_sl not in (0, None) and new_sl < cur_sl
        elif side == Side.SELL:
            if new_sl <= entry:
                return f"new SL {new_sl:g} not above SELL open {entry:g}"
            widening = cur_sl not in (0, None) and new_sl > cur_sl
        else:
            return "order side unknown"
        if abs(new_sl - entry) > self.max_sl_pct * entry:
            return (f"new SL {new_sl:g} is {abs(new_sl - entry) / entry:.1%} from open {entry:g} "
                    f"(> max {self.max_sl_pct:.0%})")
        # a stop already at / past the open price (breakeven) is never loosened again:
        # a late "Stop:" of the channel must not undo the automatic breakeven
        locked = cur_sl not in (0, None) and (cur_sl >= entry - 1e-6 if side == Side.BUY
                                               else cur_sl <= entry + 1e-6)
        if widening and locked:
            return f"new SL {new_sl:g} would undo the breakeven stop {cur_sl:g}"
        if widening and not self.allow_sl_widening:
            return f"new SL {new_sl:g} widens the stop (allow_sl_widening=false)"
        return ""

    def _tp_update_reject(self, side: Optional[Side], entry: float, new_tp: float) -> str:
        if side == Side.BUY and new_tp <= entry:
            return f"new TP {new_tp:g} not above BUY open {entry:g}"
        if side == Side.SELL and new_tp >= entry:
            return f"new TP {new_tp:g} not below SELL open {entry:g}"
        if side is None:
            return "order side unknown"
        return ""

    async def update_levels(self, symbol: Optional[str], sl: Optional[float] = None,
                            tp: Optional[float] = None, order_ids: Optional[list] = None) -> dict[str, Any]:
        """Apply a new SL/TP (that arrived after execution) to the bot's own open
        orders on ``symbol`` through the existing modify path. Guarded per F3.

        Result action: ``levels_updated`` (+what, orders), ``levels_rejected``
        (+reason), ``no_open_order`` (nothing of the bot's on the symbol),
        ``no_change`` (nothing to do) or ``dry_run`` (paper/dry-run)."""
        if not symbol or (sl is None and tp is None):
            return {"executor": self.name, "action": "no_change", "symbol": symbol}
        what = ", ".join(p for p in ((f"sl={sl:g}" if sl is not None else ""),
                                     (f"tp={tp:g}" if tp is not None else "")) if p)
        if not self.live:
            return {"executor": self.name, "action": "dry_run", "symbol": symbol,
                    "sl": sl, "tp": tp, "what": what}

        vdone, vrejected = self._update_virtual(symbol, sl, tp, order_ids)

        def _do():
            with self._lock:
                self._ensure()
                orders = self._my_orders(symbol)
                targets, _pend = self._resolve_ids(symbol, order_ids)
                if targets is not None:
                    orders = [o for o in orders if int(o["id"]) in targets]
                if not orders:
                    if vdone:
                        return {"action": "levels_updated", "symbol": symbol, "what": what + " (virtual limit)",
                                "orders": vdone,
                                "partial_error": "; ".join(vrejected) if vrejected else None}
                    if vrejected:
                        return {"action": "levels_rejected", "symbol": symbol, "what": what + " (virtual limit)",
                                "reason": "; ".join(vrejected)}
                    return {"action": "no_open_order", "symbol": symbol, "what": what}
                why = self._wallet_blocked()
                if why:
                    return {"action": "levels_rejected", "symbol": symbol, "what": what, "reason": why}
                applied: list[dict] = list(vdone)
                rejected: list[str] = list(vrejected)
                for o in orders:
                    side, entry = self._order_side(o), self._order_entry(o)
                    if entry is None:
                        rejected.append(f"order {o.get('id')} has no open price")
                        continue
                    use_sl, use_tp = sl, tp
                    if use_sl is not None:
                        reason = self._sl_update_reject(side, entry, self._as_float(o.get("sl")), use_sl)
                        if reason:
                            rejected.append(reason)
                            use_sl = None
                    if use_tp is not None:
                        reason = self._tp_update_reject(side, entry, use_tp)
                        if reason:
                            rejected.append(reason)
                            use_tp = None
                    if use_sl is None and use_tp is None:
                        continue
                    res = self._emit_with_relogin(
                        lambda oid=o["id"], s=use_sl, t=use_tp:
                        self.client.modify_order(oid, sl=s, tp=t))
                    action = str(res.get("action"))
                    if action in ("modified", "emitted"):
                        applied.append({"order_id": o.get("id"), "sl": res.get("sl", use_sl),
                                        "tp": res.get("tp", use_tp)})
                    else:
                        rej = str(res.get("reason") or action)
                        rejected.append(f"broker: {rej}")
                        log.warning("update_levels order %s -> %s (%s)", o.get("id"), action, rej)
                if applied:
                    return {"action": "levels_updated", "symbol": symbol, "what": what,
                            "orders": applied,
                            "partial_error": "; ".join(rejected) if rejected else None}
                return {"action": "levels_rejected", "symbol": symbol, "what": what,
                        "reason": "; ".join(rejected) or "no order updated"}
        result = await asyncio.to_thread(_do)
        return {"executor": self.name, **result}
