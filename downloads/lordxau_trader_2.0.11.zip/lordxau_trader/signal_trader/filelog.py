"""Persistent logs (the GUI log lived only in memory: the 2026-09-16..18 server
incident left no trace of WHY every order failed).

  logs/bot.log                 rotating text log (5 MB x 5): every GUI/engine
                               line + the python logging of signal_trader.*
  logs/messages-YYYY-MM-DD.jsonl  every message received from a followed
                               channel, verbatim (replay / audit without
                               touching Telegram again); kept 30 days.

Secrets never reach a file: tokens, passwords and JWTs are masked by a logging
filter and by :func:`scrub`. Nothing here runs at import time; tests pass their
own directory.
"""
from __future__ import annotations

import json
import logging
import os
import re
import threading
import time
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Optional

PROJECT_ROOT = Path(__file__).resolve().parents[1]
_KEEP_DAYS = 30
_lock = threading.Lock()
_dir: Optional[Path] = None
_gui_log = logging.getLogger("signal_trader.gui")

_SECRET_KV = re.compile(
    r"(?i)([\"']?(?<![A-Za-z0-9])(?:wallet_token|user_token|access_token|token|password|passwd|passphrase|"
    r"api_hash|api_id|api[_-]?key|api[_-]?secret|secret[_-]?key|authorization|auth_key|signature|sign|secret|"
    r"phone(?:_number)?|phone_code|login_code|otp|two_factor|2fa)"
    r"(?![A-Za-z0-9])[\"']?"
    r"\s*[:=]\s*(?:Bearer\s+)?)([\"']?)[^\"',\s}\]&;]+\2")
_JWT = re.compile(r"eyJ[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,}")


def scrub(text: str) -> str:
    """Mask credentials / tokens in a log line."""
    text = _JWT.sub("<jwt>", str(text))
    return _SECRET_KV.sub(lambda m: f"{m.group(1)}<redacted>", text)


class _ScrubFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            record.msg = scrub(record.getMessage())
            record.args = ()
        except Exception:  # pragma: no cover - a log line must never raise
            pass
        return True


def setup(base_dir: Optional[str] = None, level: int = logging.INFO) -> Path:
    """Attach the rotating file handler (idempotent). Returns the logs dir."""
    global _dir
    d = Path(base_dir) if base_dir else PROJECT_ROOT / "logs"
    d.mkdir(parents=True, exist_ok=True)
    with _lock:
        root = logging.getLogger("signal_trader")
        path = str(d / "bot.log")
        for h in list(root.handlers):
            if isinstance(h, RotatingFileHandler) and getattr(h, "_st_filelog", False):
                if h.baseFilename == os.path.abspath(path):
                    _dir = d
                    return d
                root.removeHandler(h)
                h.close()
        h = RotatingFileHandler(path, maxBytes=5_000_000, backupCount=5, encoding="utf-8")
        h._st_filelog = True
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)-7s %(name)s: %(message)s"))
        h.addFilter(_ScrubFilter())
        h.setLevel(level)
        root.addHandler(h)
        if root.level == logging.NOTSET or root.level > level:
            root.setLevel(level)
        _dir = d
    _prune(d)
    return d


def shutdown() -> None:
    """Detach the file handler (tests)."""
    global _dir
    with _lock:
        root = logging.getLogger("signal_trader")
        for h in list(root.handlers):
            if getattr(h, "_st_filelog", False):
                root.removeHandler(h)
                h.close()
        _dir = None


def gui_line(msg: str) -> None:
    """One GUI / engine log line -> bot.log (no-op until setup())."""
    if _dir is not None:
        _gui_log.info("%s", str(msg).replace("\n", " ⏎ "))


def journal(channel: str, msg_id, ts: Optional[float], text: str, edited: bool = False) -> None:
    """Append one received channel message to today's JSONL journal."""
    d = _dir
    if d is None:
        return
    now = time.time()
    row = {"recv": round(now, 3), "channel": channel, "id": msg_id,
           "ts": ts, "date": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now)),
           "edited": bool(edited), "text": text}
    try:
        with _lock:
            with open(d / f"messages-{time.strftime('%Y-%m-%d', time.localtime(now))}.jsonl",
                      "a", encoding="utf-8") as f:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
    except OSError:  # pragma: no cover - a full disk must never stop trading
        pass


def decision(event: dict) -> None:
    """Journal interpreted fields and outcomes, independently of dashboard availability."""
    d = _dir
    if d is None:
        return

    def clean(value):
        if isinstance(value, str):
            return scrub(value)
        if isinstance(value, dict):
            return {str(k): clean(v) for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            return [clean(v) for v in value]
        return value

    try:
        now = time.time()
        row = clean({k: event[k] for k in ("type", "t", "ts", "id", "text", "kind", "also", "edited",
                                         "llm", "lines", "setup", "parsed", "modes") if k in event})
        row["recv"] = round(now, 3)
        line = json.dumps(row, ensure_ascii=False) + "\n"
        with _lock:
            with open(d / f"decisions-{time.strftime('%Y-%m-%d', time.localtime(now))}.jsonl",
                      "a", encoding="utf-8") as f:
                f.write(line)
    except Exception:  # a broken/full journal must never prevent an order or a management action
        pass


def _prune(d: Path) -> None:
    cutoff = time.time() - _KEEP_DAYS * 86400
    for p in list(d.glob("messages-*.jsonl")) + list(d.glob("decisions-*.jsonl")):
        try:
            if p.stat().st_mtime < cutoff:
                p.unlink()
        except OSError:  # pragma: no cover
            pass
