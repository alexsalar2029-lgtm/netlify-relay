@echo off
chcp 65001 >nul
cd /d "%~dp0"
set PYTHONUTF8=1
where python >nul 2>nul
if errorlevel 1 (
  py -m lordxau.diagnostics
) else (
  python -m lordxau.diagnostics
)
if errorlevel 1 (
  pause
  exit /b 1
)
notepad "logs\diagnosis.txt"
