# -*- coding: utf-8 -*-
"""Backtest the @lordxau engine on a day of the channel and real ticks.

    python -m lordxau.backtest --day 2026-09-28             (fetch + replay one UTC day)
    python -m lordxau.backtest --from 2026-09-20 --to 2026-09-28
    python -m lordxau.backtest --journal logs\\messages-2026-09-28.jsonl --journal logs\\messages-2026-09-29.jsonl --day 2026-09-28
        (a journal file is named by the LOCAL day it was received: pass the neighbouring day too)

Messages: the channel's PUBLIC web page t.me/s/lordxau (no login, no session -
the bot's Telegram account is never used here), or a journal the bot wrote
(logs/messages-*.jsonl). Prices: Dukascopy's public XAUUSD tick feed, moved to
the Trendo quote (bid +0.24 / ask -0.35: calibrated on 2026-09-20..25 against
the server's own fills). Both are cached under data/backtest/.

The broker is simulated the way FxTrendoExecutor trades: a zone waits as a
virtual limit and is filled at market when the price reaches it (plus the
chase tolerance), the automatic breakeven at +1.5 points, "فری" moves the stop
to the bot's own fill (closing at once when the price is already past it), the
3 x risk_pct min-lot rule, one open position, the daily loss limit. Messages
arrive ``latency`` seconds after they were posted (server median 6-8 s).
"""
from __future__ import annotations

import argparse
import asyncio
import bisect
import datetime as dt
import html
import io
import json
import lzma
import os
import re
import struct
import sys
import time
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from lordxau import CHANNEL, SYMBOL
from lordxau.engine import ULTRA_SOURCE, Engine, EngineConfig
from signal_trader.models import OrderType, Side, Signal
from signal_trader.risk import RiskConfig, compute_lot
from signal_trader.validation import ENTRY_TOLERANCE_FRAC, risk_too_small

ROOT = Path(__file__).resolve().parents[1]
CACHE = ROOT / "data" / "backtest"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
BID_OFF, ASK_OFF = 0.24, -0.35


# ----------------------------------------------------------------- data: channel
_MSG = re.compile(r'<div class="tgme_widget_message_wrap.*?(?=<div class="tgme_widget_message_wrap|</section>)', re.S)
_POST = re.compile(r'data-post="' + CHANNEL + r'/(\d+)"', re.I)
_TIME = re.compile(r'<time datetime="([^"]+)"')
# the message's own text - never the quoted message of a reply ("js-message_reply_text"):
# a reply "ریخت فریش کن" to a zone would otherwise read as that zone again
_TEXT = re.compile(r'<div class="tgme_widget_message_text(?![^"]*reply)[^"]*"[^>]*>(.*?)</div>', re.S)


def _clean(fragment: str) -> str:
    s = re.sub(r"<br\s*/?>", "\n", fragment)
    s = re.sub(r"<[^>]+>", "", s)
    return html.unescape(s).strip()


def _get(url: str, timeout: float = 30.0) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept-Language": "en"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def fetch_channel(since: dt.datetime, until: Optional[dt.datetime] = None, log=print) -> list:
    """Every message of the public page posted in [since, until) (UTC), oldest first:
    [{id, ts, text}]. Pages back with ?before=<id>."""
    msgs: dict = {}
    before = None
    for n in range(1500):                   # ~20 messages a page: 3 weeks ~ 200-300 pages
        url = f"https://t.me/s/{CHANNEL}" + (f"?before={before}" if before else "")
        body = ""
        for attempt in range(4):
            try:
                body = _get(url).decode("utf-8", "replace")
                break
            except Exception as exc:  # noqa: BLE001
                log(f"channel page retry {attempt + 1}: {exc}")
                time.sleep(2 + 2 * attempt)
        if not body:                         # never a silently shortened range
            raise RuntimeError(f"t.me/s/{CHANNEL} page before={before} could not be read - try again later")
        blocks = _MSG.findall(body)
        ids, oldest = [], None
        for b in blocks:
            m, t = _POST.search(b), _TIME.search(b)
            if not m or not t:
                continue
            when = dt.datetime.fromisoformat(t.group(1)).astimezone(dt.timezone.utc)
            tx = _TEXT.search(b)
            mid = int(m.group(1))
            msgs[mid] = {"id": mid, "ts": when.timestamp(), "text": _clean(tx.group(1)) if tx else ""}
            ids.append(mid)
            oldest = when if oldest is None or when < oldest else oldest
        if not ids:
            break
        before = min(ids)
        if oldest < since:
            break
        time.sleep(1.0)
    else:
        raise RuntimeError(f"{since:%Y-%m-%d} not reached after 1500 pages of t.me/s/{CHANNEL}")
    lo = since.timestamp()
    hi = until.timestamp() if until else float("inf")
    return sorted((m for m in msgs.values() if lo <= m["ts"] < hi and m["text"]), key=lambda m: m["id"])


def read_journal(path: str) -> list:
    """The bot's own journal (logs/messages-YYYY-MM-DD.jsonl) -> [{id, ts, text, edited}]."""
    out = []
    with io.open(path, encoding="utf-8") as fh:
        for line in fh:
            try:
                r = json.loads(line)
            except ValueError:
                continue
            if str(r.get("channel", CHANNEL)).lstrip("@").lower() != CHANNEL:
                continue
            ts = r.get("ts") or r.get("recv")
            if ts is None or not r.get("text"):
                continue
            out.append({"id": r.get("msg_id", r.get("id")), "ts": float(ts), "text": r["text"],
                        "edited": bool(r.get("edited")), "recv": r.get("recv")})
    return sorted(out, key=lambda r: r["recv"] or r["ts"])


# ----------------------------------------------------------------- data: ticks
def fetch_ticks(day: dt.date, hours=range(0, 24), log=print) -> Path:
    """Cache Dukascopy's hourly tick files of ``day`` (UTC). Four downloads at a
    time, three tries each; a failed hour is not cached (tried again next time),
    an empty answer (no trading that hour) is."""
    from concurrent.futures import ThreadPoolExecutor
    d = CACHE / "ticks" / day.isoformat()
    d.mkdir(parents=True, exist_ok=True)
    now = dt.datetime.now(dt.timezone.utc)

    def one(h: int) -> None:
        path = d / f"{h:02d}h_ticks.bi5"
        start = dt.datetime(day.year, day.month, day.day, h, tzinfo=dt.timezone.utc)
        if path.exists() or start > now:
            return
        url = (f"https://datafeed.dukascopy.com/datafeed/XAUUSD/{day.year}/{day.month - 1:02d}/"
               f"{day.day:02d}/{h:02d}h_ticks.bi5")
        for attempt in range(3):
            try:
                body = _get(url, timeout=20.0)
            except Exception as exc:  # noqa: BLE001
                if attempt == 2:
                    log(f"ticks {day} {h:02d}h: not available ({exc})")
                    return
                time.sleep(2 + 3 * attempt)
                continue
            if start + dt.timedelta(hours=1) <= now:          # a finished hour: keep it
                path.write_bytes(body)
            return

    with ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(one, list(hours)))
    return d


def hours_of(rows: list, day: dt.date) -> range:
    """The UTC hours of ``day`` the replay needs: the messages' span +- 1 hour."""
    lo = dt.datetime(day.year, day.month, day.day, tzinfo=dt.timezone.utc).timestamp()
    hs = [int((float(r["ts"]) - lo) // 3600) for r in rows if lo <= float(r["ts"]) < lo + 86400]
    if not hs:
        return range(0)
    return range(max(0, min(hs) - 1), min(24, max(hs) + 2))


def load_ticks(days, base: Optional[Path] = None) -> list:
    """[(ts, bid, ask)] in the Trendo quote, sorted. ``base``: a folder of
    <YYYY-MM-DD>/HHh_ticks.bi5 (default: the cache)."""
    ticks = []
    for day in days:
        d = Path(base or (CACHE / "ticks")) / day.isoformat()
        if not d.exists():
            continue
        for f in sorted(d.iterdir()):
            if not f.name.endswith("h_ticks.bi5"):
                continue
            body = f.read_bytes()
            if not body:
                continue
            raw = lzma.decompress(body)
            h0 = dt.datetime(day.year, day.month, day.day, int(f.name[:2]), tzinfo=dt.timezone.utc).timestamp()
            for i in range(len(raw) // 20):
                ms, ask, bid, _a, _b = struct.unpack_from(">iiiff", raw, i * 20)
                b = bid / 1000.0 + BID_OFF
                ticks.append((h0 + ms / 1000.0, b, max(ask / 1000.0 + ASK_OFF, b + 0.05)))
    ticks.sort()
    return ticks


# ----------------------------------------------------------------- simulated broker
@dataclass
class SimConfig:
    balance: float = 105.0
    lot: float = 0.01               # the fixed lot (sizing "fixed", or no stop)
    contract: float = 100.0
    sizing: str = "risk_pct"        # like the live executor: risk_pct | fixed
    risk_pct: float = 2.0           # lot from the stop distance; min lot allowed while <= 3 x risk_pct
    min_lot: float = 0.01
    max_lot: float = 0.10
    lot_step: float = 0.01
    zone_chase_frac: float = 0.2
    virtual_ttl: float = 900.0
    max_open: int = 1
    max_daily_loss: float = 8.0     # account currency, 0 = off
    auto_be: dict = field(default_factory=lambda: {CHANNEL: 1.5, ULTRA_SOURCE: 0.0})
    # executor take_profit_points: a position without a TP gets one this far from its fill
    auto_tp: dict = field(default_factory=lambda: {CHANNEL: 2.75, ULTRA_SOURCE: 0.0})
    day_offset_h: float = 3.5       # the trading day for the daily guard (Tehran)
    max_sl_pct: float = 0.05        # executor max_sl_distance_pct (level updates)


def sim_config_from_settings(s: dict, balance: float = 105.0) -> SimConfig:
    """The SimConfig the live program would trade with ``s`` (settings.json as
    lordxau.settings loads it): the same risk / daily-loss / auto-breakeven
    (and the ULTRA risk bump) as settings.broker_config()."""
    from lordxau import settings as st_mod
    cfg = st_mod.broker_config(s)
    risk, fx = cfg.risk, cfg.fxtrendo
    rows = cfg.channel_settings
    return SimConfig(balance=float(balance), lot=float(fx.get("default_lot", 0.01)),
                     sizing=str(risk.get("sizing", "fixed")).lower(),
                     risk_pct=float(risk.get("risk_pct", 1.0)),
                     min_lot=float(risk.get("min_lot", 0.01)),
                     max_lot=float(fx.get("max_lot", 0.10)),
                     lot_step=float(risk.get("lot_step", 0.01)),
                     zone_chase_frac=float(fx.get("zone_chase_frac", 0.2)),
                     virtual_ttl=float(fx.get("virtual_limit_ttl_sec", 900)),
                     max_open=int(fx.get("max_open_positions", 1)),
                     max_daily_loss=float(risk.get("max_daily_loss", 0) or 0),
                     max_sl_pct=float(fx.get("max_sl_distance_pct", 0.05)),
                     auto_be={k: float(v.auto_breakeven_points) for k, v in rows.items()},
                     auto_tp={k: float(getattr(v, "take_profit_points", 0.0) or 0.0) for k, v in rows.items()})


class SimBroker:
    name = "sim"

    def __init__(self, ticks: list, cfg: Optional[SimConfig] = None):
        self.cfg = cfg or SimConfig()
        self.ticks = ticks
        self.tts = [t[0] for t in ticks]
        self.now = ticks[0][0] if ticks else 0.0
        self.q: Optional[tuple] = None
        self.pos: list = []
        self.closed: list = []
        self.events: list = []
        self.balance = self.cfg.balance
        self.day_pnl: dict = {}
        self._seq = 0
        c = self.cfg
        self.risk = RiskConfig(sizing=str(c.sizing).lower(), risk_pct=float(c.risk_pct), lot_step=float(c.lot_step),
                               min_lot=min(float(c.min_lot), float(c.max_lot)), max_lot=float(c.max_lot))

    # --------------------------------------------------------- time
    def quote_at(self, t: float) -> Optional[tuple]:
        i = bisect.bisect_right(self.tts, t) - 1
        if i < 0 or t - self.ticks[i][0] > 600:
            return None
        return self.ticks[i][1], self.ticks[i][2]

    def last_tick(self, t: Optional[float] = None) -> Optional[tuple]:
        """(ts, bid, ask) of the last tick at or before ``t`` (default now), however old."""
        i = bisect.bisect_right(self.tts, self.now if t is None else t) - 1
        return self.ticks[i] if i >= 0 else None

    def _exit_quote(self) -> tuple:
        """(bid, ask, stale) to close at now: the live quote, else the last known
        tick (labelled stale in the report - not a real fill)."""
        if self.q is not None:
            return self.q[0], self.q[1], False
        t = self.last_tick()
        if t is None:
            return None, None, True
        return t[1], t[2], True

    def advance(self, t: float) -> None:
        if t <= self.now:
            self.q = self.quote_at(t) if self.q is None else self.q
            return
        i = bisect.bisect_right(self.tts, self.now)
        j = bisect.bisect_right(self.tts, t)
        for k in range(i, j):
            ts, bid, ask = self.ticks[k]
            for p in list(self.pos):
                self._tick(p, ts, bid, ask)
        self.now = t
        self.q = self.quote_at(t)

    def _day(self, ts: float) -> str:
        return dt.datetime.fromtimestamp(ts + self.cfg.day_offset_h * 3600, dt.timezone.utc).strftime("%Y-%m-%d")

    def _t(self, ts: float) -> str:
        return dt.datetime.fromtimestamp(ts, dt.timezone.utc).strftime("%H:%M:%S")

    # --------------------------------------------------------- positions
    def _size(self, side: str, entries: list, sl: Optional[float], fill: Optional[float]) -> tuple:
        """(lot, reason) exactly as the live executor sizes (risk.compute_lot):
        lot 0 = refused, the reason says why."""
        sig = Signal(symbol=SYMBOL, side=Side(side), order_type=OrderType.LIMIT, entries=list(entries),
                     stop_loss=sl)
        lot, note = compute_lot(self.risk, sig, self.balance, self.cfg.lot, fill=fill)
        return lot, ("" if lot > 0 else note)

    def _guard(self) -> str:
        if self.cfg.max_daily_loss and self.day_pnl.get(self._day(self.now), 0.0) <= -self.cfg.max_daily_loss:
            return f"daily loss limit reached ({-self.day_pnl[self._day(self.now)]:.2f} >= {self.cfg.max_daily_loss})"
        return ""

    def _open(self, p: dict, px: float, ts: float, how: str, lot: float) -> None:
        buy = p["side"] == "BUY"
        p.update(state="open", fill=px, opened=ts, sl0=p["sl"], lot=lot,
                 past=((px - p["edge"]) if buy else (p["edge"] - px)) if p.get("edge") is not None else 0.0)
        tp_pts = float(self.cfg.auto_tp.get(p["source"], 0.0) or 0.0)
        if p.get("tp_offsets"):
            distance = p["tp_offsets"][0]
            p["tp"] = round(px + distance if buy else px - distance, 2)
        if p.get("tp") is None and tp_pts > 0:          # executor _plan: TP from the market fill
            p["tp"] = round(px + tp_pts if buy else px - tp_pts, 2)
        self.events.append(f"{self._t(ts)} FILL #{p['id']} {p['side']} {lot:g} lot @ {px:.2f} ({how})")

    def _tick(self, p: dict, ts: float, bid: float, ask: float) -> None:
        buy = p["side"] == "BUY"
        if p["state"] == "pending":
            if ts > p["expires"]:
                self.pos.remove(p)
                self.events.append(f"{self._t(ts)} EXPIRE #{p['id']}")
                return
            if p["sl"] is not None and ((buy and bid <= p["sl"]) or (not buy and ask >= p["sl"])):
                self.pos.remove(p)
                self.events.append(f"{self._t(ts)} CANCEL #{p['id']} (stop reached before the fill)")
                return
            tp = p["tp"]
            if p.get("armed") is None and tp is not None:    # registered without a quote: decided once
                p["armed"] = (bid < tp) if buy else (ask > tp)
            # the executor decides the TP-first rule ONCE, at registration: a zone
            # registered beyond TP1 keeps waiting even after the price dips back
            if tp is not None and p.get("armed") and ((bid >= tp) if buy else (ask <= tp)):
                self.pos.remove(p)
                self.events.append(f"{self._t(ts)} CANCEL #{p['id']} (TP {tp:g} reached before the fill)")
                return
            if (buy and ask <= p["edge"] + p["tol"]) or (not buy and bid >= p["edge"] - p["tol"]):
                px = ask if buy else bid
                bad = p["sl"] is not None and ((buy and (px <= p["sl"] or risk_too_small(px, p["sl"])))
                                               or (not buy and (px >= p["sl"] or risk_too_small(px, p["sl"]))))
                lot, why = (0.0, "stale at the fill") if bad else self._size(p["side"], p["entries"], p["sl"], px)
                why = why or self._guard()
                # executor _limits(exclude_vid): every other open order or waiting zone counts
                if not why and self.cfg.max_open and len([x for x in self.pos if x is not p]) + 1 > self.cfg.max_open:
                    why = "max open positions"
                if why:
                    self.pos.remove(p)
                    self.events.append(f"{self._t(ts)} CANCEL #{p['id']} ({why})")
                    return
                self._open(p, px, ts, f"virtual limit {p['edge']:g}", lot)
            return
        px = bid if buy else ask
        # A previously established broker stop remains effective while a
        # virtual BE target waits. Its hit must not be hidden by this tick
        # also reaching a newly deferred, weaker protection level.
        if p["sl"] is not None and ((buy and px <= p["sl"]) or (not buy and px >= p["sl"])):
            self._close(p, ts, px, "BE" if p.get("be") else "SL")
            return
        deferred = p.get("be_target")
        if deferred is not None and ((px >= deferred) if buy else (px <= deferred)):
            # The live executor's rejected-BE guard first reaches its level;
            # it cannot market-close a loss merely because it was installed.
            cur = p.get("sl")
            level = (max(cur, deferred) if buy else min(cur, deferred)) if cur is not None else deferred
            p["sl"], p["be"] = level, True
            p.pop("be_target", None)
            self.events.append(f"{self._t(ts)} BE-ACTIVE #{p['id']} at {deferred:.2f}")
            # At equality this tick only activates the new virtual protection.
            # Existing broker SL/TP checks still run below.
            just_armed = True
        else:
            just_armed = False
        pts = self.cfg.auto_be.get(p["source"], 0.0)
        if pts and not p.get("be") and ((px - p["fill"]) if buy else (p["fill"] - px)) >= pts:
            p["sl"], p["be"] = p["fill"], True
            p.pop("be_target", None)
            self.events.append(f"{self._t(ts)} AUTO-BE #{p['id']} at {p['fill']:.2f}")
        if (not just_armed and p["sl"] is not None
                and ((buy and px <= p["sl"]) or (not buy and px >= p["sl"]))):
            self._close(p, ts, px, "BE" if p.get("be") else "SL")
        elif p["tp"] is not None and ((buy and px >= p["tp"]) or (not buy and px <= p["tp"])):
            self._close(p, ts, p["tp"], "TP")          # booked at the level: a gap past it is no gift

    def _close(self, p: dict, ts: float, px: float, why: str) -> None:
        pts = (px - p["fill"]) if p["side"] == "BUY" else (p["fill"] - px)
        usd = pts * p.get("lot", self.cfg.lot) * self.cfg.contract
        self.balance += usd
        d = self._day(ts)
        self.day_pnl[d] = self.day_pnl.get(d, 0.0) + usd
        self.pos.remove(p)
        self.events.append(f"{self._t(ts)} {why} #{p['id']} {p['side']} closed @ {px:.2f} ({pts:+.2f} pts)")
        self.closed.append({"id": p["id"], "day": d, "open": self._t(p["opened"]), "close": self._t(ts),
                            "side": p["side"], "source": p["source"], "fill": p["fill"], "exit": px,
                            "pts": pts, "usd": usd, "why": why, "sl0": p.get("sl0"), "lot": p.get("lot", self.cfg.lot),
                            "past": p.get("past", 0.0), "hold": ts - p["opened"]})

    def _targets(self, ids) -> Optional[list]:
        if not ids:
            return None
        want = set()
        for i in ids:
            s = str(i)
            try:
                want.add(int(s[1:]) if s.startswith("v") else int(s))
            except ValueError:
                pass
        return [p for p in self.pos if p["id"] in want]

    # --------------------------------------------------------- executor API
    async def execute(self, sig: Signal, *, _force_market: bool = False) -> dict:
        if self.q is None:
            return {"action": "rejected", "reason": "no live quote"}
        bid, ask = self.q
        buy = sig.side == Side.BUY
        entries = list(sig.entries) or [ask if buy else bid]
        lo, hi = min(entries), max(entries)
        edge = hi if buy else lo
        sl = sig.stop_loss
        tp = sig.take_profits[0] if sig.take_profits else None
        wide = ENTRY_TOLERANCE_FRAC * edge
        if sig.order_type == OrderType.MARKET:
            tol = wide
        else:
            tol = 0.0 if sl is None or self.cfg.zone_chase_frac <= 0 else \
                min(wide, self.cfg.zone_chase_frac * abs(edge - sl))
        px = ask if buy else bid
        market = _force_market or ((ask <= hi + tol) if buy else (bid >= lo - tol))
        near = _force_market or ((ask <= hi + wide) if buy else (bid >= lo - wide))
        chk = px if near else edge
        if sl is not None and ((buy and (chk <= sl or risk_too_small(chk, sl)))
                               or (not buy and (chk >= sl or risk_too_small(chk, sl)))):
            return {"action": "rejected", "reason": f"price {chk:g} already at/beyond stop loss {sl:g}"}
        if tp is not None and ((buy and chk >= tp) or (not buy and chk <= tp)):
            return {"action": "rejected", "reason": f"price {chk:g} already beyond take profit {tp:g}"}
        dropped = [p for p in self.pos if p["state"] == "pending" and p["source"] == (sig.source or "")]
        for p in dropped:
            self.pos.remove(p)
            self.events.append(f"{self._t(self.now)} CANCEL #{p['id']} (superseded)")
        # sizing: from the fill, or the zone entry farthest from the stop
        lot, why = self._size(sig.side.value, entries, sl, px if market else None)
        if why:
            return {"action": "rejected", "reason": why}
        why = self._guard()
        if why:
            return {"action": "skipped_daily_limit", "reason": why}
        # executor _limits(1): open orders + every waiting zone (the same source's were just dropped)
        if self.cfg.max_open and len(self.pos) + 1 > self.cfg.max_open:
            return {"action": "skipped_max_open", "reason": f"open positions {len(self.pos)} + 1 > {self.cfg.max_open}"}
        self._seq += 1
        p = {"id": self._seq, "side": sig.side.value, "sl": sl, "tp": tp, "source": sig.source or "",
             "edge": edge, "entries": entries, "tp_offsets": list(sig.take_profit_offsets)}
        if market:
            self.pos.append(p)
            self._open(p, px, self.now, "market", lot)
            return {"action": "placed", "order_id": p["id"], "orders": [{"order_id": p["id"]}],
                    "entry_adjusted": f"market {px:.2f}"}
        armed = True if tp is None else ((bid < tp) if buy else (ask > tp))
        p.update(state="pending", tol=tol, armed=armed, expires=self.now + self.cfg.virtual_ttl)
        self.pos.append(p)
        return {"action": "pending_virtual", "order_id": f"v{p['id']}", "orders": [{"order_id": f"v{p['id']}"}],
                "entry_adjusted": f"market {px:.2f} -> virtual limit at {edge:g} (chase {tol:.2f})"}

    async def market_now(self, symbol, signal) -> dict:
        if [p for p in self.pos if p["state"] == "open"]:
            return {"action": "order_exists"}
        if signal is None:
            return {"action": "refused", "reason": "no tracked signal"}
        return await self.execute(signal, _force_market=True)

    async def close(self, symbol=None, order_id=None, fraction=1.0, close_all=False, order_ids=None) -> dict:
        tg = self._targets(order_ids)
        todo = list(self.pos) if tg is None else tg
        bid, ask, stale = self._exit_quote()
        for p in todo:
            if p["state"] == "open":
                if bid is None:
                    continue
                self._close(p, self.now, bid if p["side"] == "BUY" else ask, "CLOSE-stale" if stale else "CLOSE")
            else:
                self.pos.remove(p)
                self.events.append(f"{self._t(self.now)} CANCEL #{p['id']} (close)")
        return {"action": "close" if todo else "no_open_order"}

    async def breakeven(self, symbol=None, order_ids=None, ref_price=None) -> dict:
        tg = self._targets(order_ids)
        todo = list(self.pos) if tg is None else tg
        act = "no_open_order"
        for p in todo:
            if p["state"] == "pending":
                self.pos.remove(p)
                self.events.append(f"{self._t(self.now)} CANCEL #{p['id']} (breakeven before the fill)")
                act = "pending_cancelled" if act == "no_open_order" else act
                continue
            bid, ask, stale = self._exit_quote()
            buy = p["side"] == "BUY"
            level = self._be_ref(p, ref_price)
            reached = bid is not None and not stale and ((bid >= level) if buy else (ask <= level))
            if not reached:
                # Keep the broker's original stop while the virtual BE waits
                # for an executable quote to reach the desired protection.
                old = p.get("be_target")
                p["be_target"] = (max(old, level) if buy else min(old, level)) if old is not None else level
                self.events.append(f"{self._t(self.now)} BE-WAIT #{p['id']} for {level:.2f}")
            else:
                p["sl"], p["be"] = level, True
                p.pop("be_target", None)
            act = "breakeven_virtual"
        return {"action": act}

    @staticmethod
    def _be_ref(p: dict, ref_price) -> float:
        """FxTrendoExecutor._be_ref: the channel's level when it is worse than
        the fill by at most half the stop distance, else the fill; never loosen."""
        buy = p["side"] == "BUY"
        fill, sl0 = p["fill"], p["sl"]
        level = fill
        if ref_price is not None:
            ref = float(ref_price)
            if sl0 is not None and abs(sl0 - ref) <= 1e-9:
                return sl0
            worse = (fill - ref) if buy else (ref - fill)
            if worse > 1e-9:
                dist = abs(fill - sl0) if sl0 is not None else 0.0
                if worse <= 0.5 * dist + 1e-9:
                    level = ref
        if sl0 is not None and ((sl0 >= level - 1e-9) if buy else (sl0 <= level + 1e-9)):
            return sl0
        return level

    async def update_levels(self, symbol=None, sl=None, tp=None, order_ids=None) -> dict:
        tg = self._targets(order_ids)
        todo = list(self.pos) if tg is None else tg
        if not todo:
            return {"action": "no_open_order"}
        done, why = 0, []
        for p in todo:
            buy = p["side"] == "BUY"
            ref = p["fill"] if p["state"] == "open" else p["edge"]    # executor: open price / zone edge
            if sl is not None:
                s = float(sl)
                if (buy and s >= ref) or (not buy and s <= ref):
                    why.append(f"new SL {s:g} not {'below' if buy else 'above'} {p['side']} open {ref:g}")
                elif abs(s - ref) > self.cfg.max_sl_pct * ref:
                    why.append(f"new SL {s:g} too far from open {ref:g}")
                elif p["state"] == "open" and self.q is not None and (
                        (buy and self.q[0] <= s) or (not buy and self.q[1] >= s)):
                    why.append(f"new SL {s:g} already past the price (broker refuses)")
                elif (p["state"] == "open" and p.get("be") and p.get("sl") is not None
                      and ((buy and s < p["sl"]) or (not buy and s > p["sl"]))):
                    why.append(f"new SL {s:g} would undo the breakeven stop {p['sl']:g}")   # executor rule
                else:
                    p["sl"] = s
                    if p["state"] == "open" and not p.get("be"):
                        p["sl0"] = s
                    done += 1
            if tp is not None:
                t = float(tp)
                if (buy and t <= ref) or (not buy and t >= ref):
                    why.append(f"new TP {t:g} not {'above' if buy else 'below'} {p['side']} open {ref:g}")
                else:
                    p["tp"] = t
                    if p["state"] == "pending" and self.q is not None:   # _update_virtual re-decides it
                        p["armed"] = (self.q[0] < t) if buy else (self.q[1] > t)
                    done += 1
        if done:
            return {"action": "levels_updated"}
        return {"action": "levels_rejected", "reason": "; ".join(why) or "nothing to change"}

    def cancel_virtual(self, symbol, ids, why: str = "") -> list:
        out = []
        for p in self._targets(ids) or []:
            if p["state"] == "pending":
                self.pos.remove(p)
                self.events.append(f"{self._t(self.now)} CANCEL #{p['id']} ({why})")
                out.append({"order_id": f"v{p['id']}"})
        return out

    def trade_state(self, ids) -> Optional[bool]:
        tg = self._targets(ids)
        return bool(tg)

    def virtual_orders(self) -> dict:
        return {p["id"]: p for p in self.pos if p["state"] == "pending"}

    def live_quote_mid(self, symbol) -> Optional[float]:
        return None if self.q is None else (self.q[0] + self.q[1]) / 2

    def has_open_order(self, symbol) -> bool:
        return bool(self.pos)


# ----------------------------------------------------------------- replay
def _recv(r: dict, latency: float) -> float:
    """When the bot got the message: the journal's own receipt time when it
    has one, else the post time + ``latency``."""
    return float(r["recv"]) if r.get("recv") else float(r["ts"]) + latency


def replay(rows: list, ticks: list, ecfg: Optional[EngineConfig] = None, scfg: Optional[SimConfig] = None,
           latency: float = 6.0, trace: Optional[list] = None) -> dict:
    """Run ``rows`` ([{id, ts, text, edited?}]) through a fresh engine + SimBroker.
    Returns {"trades": [...], "pnl": usd, "by_day": {...}, "balance": end, "counts": {...}}."""
    sim = SimBroker(ticks, scfg)
    clock = {"t": 0.0}
    eng = Engine(sim, ecfg or EngineConfig(), clock=lambda: clock["t"])
    tr = trace if trace is not None else []
    seen_text: dict = {}                 # like fastpoll.Seen: an edit acts only on a message delivered as NEW
    unpriced: list = []

    async def run():
        for i, r in enumerate(rows):
            t = _recv(r, latency)
            if r.get("edited"):
                if r.get("id") not in seen_text or seen_text[r.get("id")] == r["text"]:
                    continue
            seen_text[r.get("id")] = r["text"]
            while True:                                        # timers due before this message
                due = eng.next_due()
                if due is None or due > t:
                    break
                sim.advance(due)
                clock["t"] = due
                for line in await eng.tick(due):
                    tr.append(f"      timer {sim._t(due)}: {line}")
            sim.advance(t)
            clock["t"] = t
            ev0 = len(sim.events)
            if r.get("edited"):
                lines = await eng.handle_edit(r["text"], msg_id=r.get("id"), ts=r["ts"], now=t)
            else:
                lines = await eng.handle(r["text"], msg_id=r.get("id"), ts=r["ts"])
            nxt = _recv(rows[i + 1], latency) if i + 1 < len(rows) else t + 3600
            if lines:
                q = sim.q
                qs = "--" if q is None else f"{q[0]:.2f}/{q[1]:.2f}"
                tr.append(f"{sim._t(t)} q={qs} [{r.get('id')}] {r['text'].replace(chr(10), ' / ')[:90]}")
                tr.extend("      " + str(x) for x in lines)
            while True:
                due = eng.next_due()
                if due is None or due > nxt:
                    break
                sim.advance(due)
                clock["t"] = due
                for line in await eng.tick(due):
                    tr.append(f"      timer {sim._t(due)}: {line}")
            sim.advance(nxt - 0.001)
            tr.extend("      sim " + e for e in sim.events[ev0:])
        # anything still open at the end is closed at the last tick - never dropped unbooked
        last = sim.last_tick()
        for p in list(sim.pos):
            if p["state"] != "open":
                sim.pos.remove(p)
                sim.events.append(f"{sim._t(sim.now)} CANCEL #{p['id']} (end of data)")
            elif last is None:
                sim.pos.remove(p)
                unpriced.append(p)
            else:
                stale = sim.now - last[0] > 600
                sim._close(p, last[0] if stale else sim.now, last[1] if p["side"] == "BUY" else last[2],
                           "END-stale" if stale else "END")

    asyncio.run(run())
    by_day: dict = {}
    for c in sim.closed:
        d = by_day.setdefault(c["day"], {"usd": 0.0, "n": 0, "win": 0, "loss": 0})
        d["usd"] += c["usd"]
        d["n"] += 1
        d["win"] += c["pts"] > 0.3
        d["loss"] += c["pts"] < -0.3
    late = [r for r in rows if ticks and _recv(r, latency) > ticks[-1][0] + 600]
    return {"trades": sim.closed, "pnl": sum(c["usd"] for c in sim.closed), "by_day": by_day,
            "balance": sim.balance, "counts": dict(eng.counts), "unpriced": len(unpriced),
            "after_ticks": len(late)}


def report(res: dict, title: str = "") -> str:
    out = [title] if title else []
    for c in res["trades"]:
        out.append(f"  {c['day']} {c['open']}->{c['close']} {c['side']:4} {c['source']:13} "
                   f"{c.get('lot', 0.01):g} lot fill={c['fill']:.2f} "
                   f"exit={c['exit']:.2f} {c['pts']:+6.2f} pts {c['usd']:+6.2f}$ {c['why']}")
    for d, v in sorted(res["by_day"].items()):
        out.append(f"  {d}: {v['usd']:+7.2f}$  trades={v['n']} win={v['win']} loss={v['loss']}")
    out.append(f"  TOTAL {res['pnl']:+.2f}$ over {len(res['trades'])} trades; balance {res['balance']:.2f}")
    stale = sum(1 for c in res["trades"] if str(c["why"]).endswith("-stale"))
    if stale:
        out.append(f"  ⚠️ {stale} trade(s) closed at an old tick (no prices there) - not a real exit")
    if res.get("unpriced"):
        out.append(f"  ⚠️ {res['unpriced']} open trade(s) without any price - not booked")
    if res.get("after_ticks"):
        out.append(f"  ⚠️ {res['after_ticks']} message(s) after the last tick (+10 min) - not tradable here")
    return "\n".join(out)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Backtest the @lordxau engine on real ticks")
    ap.add_argument("--day", help="one UTC day (YYYY-MM-DD)")
    ap.add_argument("--from", dest="d0")
    ap.add_argument("--to", dest="d1")
    ap.add_argument("--journal", action="append",
                    help="the bot's logs/messages-*.jsonl instead of the web page (repeatable)")
    ap.add_argument("--latency", type=float, default=6.0)
    ap.add_argument("--balance", type=float, default=105.0)
    ap.add_argument("--ultra", action="store_true", help="trade ULTRA signals too")
    ap.add_argument("--settings", help="settings.json whose engine section is used")
    ap.add_argument("--trace", help="write the message-by-message trace here")
    a = ap.parse_args(argv)
    ecfg, scfg = EngineConfig(), SimConfig(balance=a.balance)
    if a.settings and os.path.isfile(a.settings):         # the live program's own settings
        from lordxau import settings as st_mod
        s = st_mod.read_file(Path(a.settings))
        ecfg = st_mod.engine_config(s)
        scfg = sim_config_from_settings(s, a.balance)
        print(f"settings: {a.settings} (risk {scfg.risk_pct:g}% {scfg.sizing}, daily loss {scfg.max_daily_loss:g}, "
              f"auto breakeven {scfg.auto_be.get(CHANNEL, 0):g})", flush=True)
    elif a.settings:
        print(f"{a.settings} not found - default settings", flush=True)
    if a.ultra:
        ecfg.trade_ultra = True
        scfg.risk_pct = max(scfg.risk_pct, 3.5)
    if a.day:
        d0 = d1 = dt.date.fromisoformat(a.day)
    elif a.d0:
        d0 = dt.date.fromisoformat(a.d0)
        d1 = dt.date.fromisoformat(a.d1) if a.d1 else d0
    else:
        d0 = d1 = dt.datetime.now(dt.timezone.utc).date()
    days = [d0 + dt.timedelta(n) for n in range((d1 - d0).days + 1)]
    since = dt.datetime(d0.year, d0.month, d0.day, tzinfo=dt.timezone.utc)
    until = dt.datetime(d1.year, d1.month, d1.day, tzinfo=dt.timezone.utc) + dt.timedelta(days=1)
    if a.journal:
        allr: dict = {}
        for j in a.journal:
            for r in read_journal(j):
                allr[(r["id"], r["text"], r["edited"])] = r
        every = sorted(allr.values(), key=lambda r: r["recv"] or r["ts"])
        rows = [r for r in every if since.timestamp() <= r["ts"] < until.timestamp()]
        if every and (min(r["ts"] for r in every) > since.timestamp() + 3600
                      or max(r["ts"] for r in every) < until.timestamp() - 3600):
            lo_, hi_ = (dt.datetime.fromtimestamp(f(r["ts"] for r in every), dt.timezone.utc) for f in (min, max))
            print(f"WARNING: the journal covers only {lo_:%m-%d %H:%M}..{hi_:%m-%d %H:%M} UTC - a file is named "
                  "by the LOCAL day it was received: pass the neighbouring day's messages-*.jsonl too", flush=True)
    else:
        print(f"reading t.me/s/{CHANNEL} (public page) {since:%Y-%m-%d} .. {until:%Y-%m-%d} …", flush=True)
        rows = fetch_channel(since, until)
    print(f"{len(rows)} messages", flush=True)
    for d in days:
        print(f"ticks {d} …", flush=True)
        fetch_ticks(d, hours_of(rows, d))
    ticks = load_ticks(days)
    if not ticks:
        print("no ticks")
        return 1
    tr: list = []
    res = replay(rows, ticks, ecfg, scfg, latency=a.latency, trace=tr)
    print(report(res, f"@{CHANNEL} {d0}..{d1} latency {a.latency:g}s ultra={'on' if ecfg.trade_ultra else 'off'}"))
    if a.trace:
        p = Path(a.trace)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("\n".join(tr), encoding="utf-8")
        print("trace ->", a.trace)
    return 0


if __name__ == "__main__":
    sys.exit(main())
