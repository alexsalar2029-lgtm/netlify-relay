# -*- coding: utf-8 -*-
"""2.0.6: the posts of 3 months (2026-06-30 .. 10-02) that a person reads without thinking and
the 2.0.5 parser / engine did not - found by comparing the bot with a message-by-message human
reading of every trading day. Each case is a real post (its id in the comment)."""
import pytest

from lordxau.parse import BE, BE_HIT, CLOSE, MARKET_NOW, NOISE, SL_HIT, STOP, ZONE, parse
from test_engine import feed, make, run


def execs(ex):
    return [c for c in ex.calls if c[0] == "execute"]


# ---------------------------------------------------------------- zone posts with one keystroke wrong
@pytest.mark.parametrize("text,side,entries,alt", [
    ("Xau\n\nSell\n\nEnter::4189/4190", "SELL", [4189, 4190], []),            # 89656 (2026-10-02, live)
    ("Xau\n\nBuy\n\nEnter:5072/4071", "BUY", [4072, 4071], [5072, 5071]),      # 74221
    ("Xau\n\nSell\n\nEnter:4158/5159", "SELL", [5158, 5159], [4158, 4159]),    # 74517
    ("Xau\n\nSell\n\nEnter:5152/4153", "SELL", [4152, 4153], [5152, 5153]),    # 74553
    ("Xau\n\nSell\n\nEnter:5056/4057", "SELL", [4056, 4057], [5056, 5057]),    # 78601
    ("Xau\n\nBuy\n\nEnter:5372/4371", "BUY", [4372, 4371], [5372, 5371]),      # 81889
    ("Xau\n\nBuy\n\nEnter:4463/4664", "BUY", [4663, 4664], [4463, 4464]),      # 82758
    ("Xqu\n\nBuy\n\nEnter:4634:4435", "BUY", [4434, 4435], [4634, 4635]),      # 83680
    ("Xau\n\nBuy\n\nEnter:4093/49094", "BUY", [4093, 4094], []),               # 78793: a digit too many
    ("Xau\n\nBuy\n\nEnter:4009/40010", "BUY", [4009, 4010], []),               # 77743
    ("Xau\n\nBuy\n\nEnter:4331/43330", "BUY", [4331, 4330], []),               # 81178
    ("Xau\n\nBuy\n\nEntet:4113.4112", "BUY", [4113, 4112], []),                # 75610: '.' for '/'
    ("Xau\n\nBuy\n\nEntet:4111.4112", "BUY", [4111, 4112], []),                # 75617
    ("Xau\n\nSell\n\nEnter:4054/4045", "SELL", [4044, 4045], [4054, 4055]),    # 75978: the tens digit
    ("Xau\n\nSlel\n\nEnter:4031/4032", "SELL", [4031, 4032], []),              # 80252: the side word
    ("Xau\n\nSell\n\nEnter:4363/4262", "SELL", [4263, 4262], [4363, 4362]),    # the 100-point slip, as before
])
def test_zone_typos_are_read(text, side, entries, alt):
    p = parse(text)
    assert p.kind == ZONE and p.side == side and p.entries == entries and p.alt == alt


@pytest.mark.parametrize("text,entries", [
    ("Xau Buy Enter:4190/4189", [4190, 4189]),
    ("Xau Buy Enter:4263/64", [4263, 4264]),            # 2-digit shorthand borrows the head
    ("Xau Buy Enter:4263/4258", [4263, 4258]),          # a wider zone stays as typed
    ("Xau Buy Enter:4134/4129", [4134, 4129]),          # ... also when one keystroke would make it 4130/4129
    ("Xau Sell Enter:4190/4200", [4190, 4200]),
    ("GOLD BUY\n\nEntry\n4304_ 4299\n\nTp 4310 _ 4317\n\nSl 4924", [4304, 4299]),   # an ULTRA layout, stop unreadable
    ("Xau Sell Enter:4186.50/4187", [4186.5, 4187]),
    ("Xau Buy Enter:4190", [4190]),
])
def test_normal_zones_are_unchanged(text, entries):
    p = parse(text)
    assert p.kind == ZONE and p.entries == entries and p.alt == []


@pytest.mark.parametrize("text", ["Xau Buy Enter:4190/3050", "Xau Buy Enter:4190/430", "Enter:4190/41899999"])
def test_unreadable_second_level_is_not_guessed(text):
    assert parse(text).kind != ZONE or parse(text).entries == [4190]


# ---------------------------------------------------------------- stop posts
@pytest.mark.parametrize("text,sl", [
    ("Stop;4578", 4578),            # 82598
    ("Stip;5053", 5053),            # 75213 (the engine brings it to 4053)
    ("Stop:438p", 4380),            # 81439: 'p' next to '0'
    ("Stop:4192", 4192),
])
def test_stop_typos_are_read(text, sl):
    p = parse(text)
    assert p.kind == STOP and p.sl == sl


# ---------------------------------------------------------------- risk-free / close / stop-hit wording
@pytest.mark.parametrize("text", [
    "ریسک فری رو بزار",                                              # 73414
    "اونایی که گرفتن تو سودن. ریسک فری کنن هرکی نگرفته بگیره",       # 73455
    "ریسک فری کن نگهدار میگم کجا ببندی",                             # 73498
    "ریسک فری کن اوناییم که رو قیمت مارکت گرفتن",                    # 73627
    "کشید بالا ریسک فری بکنید",                                      # 75150
    "ریسک فری کن بریم ببینیم 4080رو بهمون میده",                     # 75857
    "فری کم",                                                        # 75981
    "فری باشین",                                                     # 76279
    "ریسک فری باز",                                                  # 76772
    "فری باشین تا4050میره",                                          # 79356
    "فریی کن",                                                       # 80141
    "پرواز کرد ریسک فری کن جا‌موندی مارکت بزنش",                     # 81018
    "فری بزار", "فری باش", "فریش کن", "ریسک فری کن",
])
def test_risk_free_orders_are_read(text):
    assert parse(text).has(BE)


def test_risk_free_with_a_market_order_for_the_late_ones():          # 79571
    p = parse("ریخت فریش کن جا‌موندی قیمت مارکت نزدیکش بزن")
    assert p.kind == BE and p.also == [MARKET_NOW]


@pytest.mark.parametrize("text", [
    "هر ۲ورود فعال هست ۴۵ رو با سود ببند الان ۴۰ رو ریسک فری کن",    # 88347: ULTRA legs, not the scalp
    "سوده ریسک فری  و سیو سود یادت نره مدیریت کن همیشه",            # 89472: advice, no order verb
    "گفتم ریسک فری کن گوش نکردی",
    "ریسک فری کنیم؟",
    "چرا ریسک فری نکردی",
    "ریسک فری نکن",
    "استاد من ریسک فری کردم",
    "فری خورد",
    "خواهشا تمام معاملات رو ریسک فری کنید بعد رفتن سود",             # 86104: advice, 18 min after an ULTRA signal
    "نمیخواد ریسک فری کنید", "لازم نیست فری کنید", "هنوز فری نکنید",
    "نگه دار میگم کی ریسک فری کنید", "خودم میگم کی فری کن",
    "ممنون استاد که گفتی ریسک فری کن وگرنه استاپ میخوردم",
    "دیشب گفته بودم ریسک فری کن ولی خیلیا گوش ندادن",
    "الترا رو ریسک فری کن اسکلپ رو نگه دار تا بگم چیکار کنی",
    "ورود 4145 رو ریسک فری کن 4140 رو نگه دار ببینیم چی میشه",
    "لازم نیست ریسک فری کنید بذارید بره تا تارگت بعدی",
    "هر موقع قیمت به 4193 رسید اون موقع ریسک فری کنید",
    "رفتی سود حتما ریسک فری کن شب نباید ترید کرد",                   # 88547 without its first word
    "هر موقع رفت تو سود ریسک فری کنید نه الان دوستان عزیز",
    "نیاز نیست فری کنید", "زوده فری کنید", "بعدا ریسک فری کن",
])
def test_talk_about_risk_free_is_not_an_order(text):
    assert not parse(text).has(BE)


def test_risk_free_hit_stays_a_report():
    assert parse("فری خورد").kind == BE_HIT


@pytest.mark.parametrize("text", ["صلوات بفرستین ببندید🤣", "ببندید رو3975 عه", "ببند✅", "ببندش", "ببندید"])
def test_close_orders_are_read(text):                                 # 73610, 73686
    assert parse(text).has(CLOSE)


@pytest.mark.parametrize("text", ["ببنذ", "خودتون اینو مدیریت کنید من همینجا میبندمش", "من همینجا بستمش"])
def test_the_leader_closing_his_own_trade_is_a_close(text):           # 84303, 76014
    assert parse(text).kind == CLOSE


@pytest.mark.parametrize("text", ["۴۵ رو با سود ببند", "ببند 45 رو", "4145 و 4140 رو ببند", "تا گفتم ببند",
                                  "من بستمش \nالهی شکر ❤️‍🔥", "من بستم 🙏🏻🙏🏻🌺",      # 82082, 81718: screenshot captions
                                  "من بستم با سود استاد دمت گرم", "کامنتارو من میبندم", "من میبندم کانالو",
                                  "رسید به تارگت من میبندم", "هر وقت برگشت ورود من میبندم", "من بستم ولی شما نگه دارید",
                                  "4145 رو با سود ببند", "رسید 4180 ببندش", "تا 4180 نگه دار بعد ببند",
                                  "تا تارگت4036 نگه دار بعد ببند", "تارگت 4148 ببندید", "4145 رو ببند",
                                  "تو سود ببندش من دنبال 4110 ام", "تیپی 4195 ببندید",
                                  "برسه به تارگت من میبندم", "نصفشو من میبندم بقیه بمونه",
                                  "دهنتو ببند🤣", "استاد گفتی ببند😂 بستم رفت بالا", "ببندم؟", "ببند؟",
                                  "دمت گرم دشت اول من زودتر بستم البته", "ترکید تا بستم", "ببنید احمق ها نمیزارن من سیگنال بدم",
                                  "خفن ترین سیستم ایرانو بستم نیست در خاورمیانه🔥", "اگر میخاید میتونید ببندید",
                                  "عشقی بخدا عشق امشب هم رو اسپانیا بستم ایول", "من 4150 میبندم"])
def test_leg_management_and_talk_are_not_a_close(text):
    assert not parse(text).has(CLOSE)


@pytest.mark.parametrize("text", ["استاپ زد", "استاپ خورد", "استاپ تاچ کرد", "نزاشت ورودو بدم استاپ زد"])
def test_stop_hit_reports(text):                                      # 89492, 78144
    assert parse(text).kind == SL_HIT


def test_stop_hit_wording_is_not_a_stop_order():
    assert parse("استاپ زدم 4190").kind in (NOISE, SL_HIT) and parse("استاپ زد").sl is None


# ---------------------------------------------------------------- engine: the price settles the typo
def test_thousand_slip_takes_the_reading_next_to_the_price():         # 74517 with gold at 4160
    eng, ex, clk = make()
    ex.mid = 4157.0
    feed(eng, clk, [(0, "Xau\n\nSell\n\nEnter:4158/5159"), (4, "Stop:4161")])
    assert execs(ex)[0][1:4] == ("SELL", [4158.0, 4159.0], 4161.0)


def test_both_levels_300_points_off_follow_the_price():               # 80957 / 80958: gold at 4361
    eng, ex, clk = make()
    ex.mid = 4362.0
    out = feed(eng, clk, [(0, "Xau\nBuy\n\nEnter:4061/4060"), (5, "Stop:4058")])
    assert execs(ex)[0][1:3] == ("BUY", [4361.0, 4360.0])
    assert ("update_levels", 4358.0, ["v1"]) in ex.calls or execs(ex)[0][3] == 4358.0, out


def test_a_zone_near_the_price_is_never_shifted():
    eng, ex, clk = make()
    ex.mid = 4187.0
    feed(eng, clk, [(0, "Xau Buy Enter:4185/4184")])
    assert execs(ex)[0][2] == [4185.0, 4184.0]


def test_a_far_zone_that_no_hundreds_shift_explains_is_left_alone():
    eng, ex, clk = make()
    ex.mid = 4187.0
    feed(eng, clk, [(0, "Xau Buy Enter:4135/4134")])                  # 52 away: not a hundreds slip
    assert execs(ex)[0][2] == [4135.0, 4134.0]


def test_stop_with_the_thousand_digit_wrong():                        # 75212 / 75213
    eng, ex, clk = make()
    ex.mid = 4049.0
    feed(eng, clk, [(0, "Xau\n\nSell\n\nEntet:4050/4051"), (4, "Stip;5053")])
    assert execs(ex)[0][1:3] == ("SELL", [4050.0, 4051.0])
    assert execs(ex)[0][3] == 4053.0 or ("update_levels", 4053.0, ["v1"]) in ex.calls


def test_stop_with_the_tens_digit_wrong_is_the_stop_behind_the_zone():   # 80614: "Stop:4167" for 4154/4155
    eng, ex, clk = make(place_before_stop=False)
    ex.mid = 4153.0
    feed(eng, clk, [(0, "Xau Sell Enter:4154/4155"), (4, "Stop:4167")])
    assert execs(ex)[0][3] == 4157.0


def test_a_wider_stop_is_still_refused_not_repaired():
    eng, ex, clk = make(place_before_stop=False, max_stop_pts=6.0)
    feed(eng, clk, [(0, "Xau Buy Enter:4150/4149"), (5, "Stop:4141")])
    assert not execs(ex)


# ---------------------------------------------------------------- engine: the side word mistyped
def test_buy_typed_in_the_reentry_of_a_sell_waits_for_the_stop():     # 78339 .. 78344
    eng, ex, clk = make()
    ex.mid = 4126.0
    feed(eng, clk, [(0, "سل بگیر"), (5, "Xau\n\nSell\n\nEnter:4124/4125"), (4, "Stop:4127")])
    ex.fill("v1"); ex.alive.discard("v1")                             # filled and stopped out
    out = feed(eng, clk, [(60, "استاپ تاچ کرد"), (3, "بگیرش باز"), (8, "Xau\n\nBuy\n\nEnter:4128/4129")])
    assert len(execs(ex)) == 1, out                                   # nothing placed on the doubtful side
    out = feed(eng, clk, [(5, "Stop:4131")])
    assert execs(ex)[-1][1:4] == ("SELL", [4128.0, 4129.0], 4131.0), out


def test_a_real_change_of_side_with_the_price_behind_it_is_placed_at_once():   # 84107, 89315
    eng, ex, clk = make()
    feed(eng, clk, [(0, "سل بزن"), (5, "Xau Sell Enter:4190/4191"), (4, "Stop:4193")])
    ex.fill("v1"); ex.alive.discard("v1")
    feed(eng, clk, [(60, "بگیر باز"), (6, "Xau Buy Enter:4186/4185")])      # gold at 4187: a BUY zone waits below it
    assert execs(ex)[-1][1:3] == ("BUY", [4186.0, 4185.0])


def test_a_real_change_of_side_inside_the_zone_is_confirmed_by_its_stop():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "سل بزن"), (5, "Xau Sell Enter:4190/4191"), (4, "Stop:4193")])
    ex.fill("v1"); ex.alive.discard("v1")
    ex.mid = 4185.5                                                   # inside the new zone: the price says nothing
    feed(eng, clk, [(60, "بگیر باز"), (6, "Xau Buy Enter:4186/4185")])
    assert len(execs(ex)) == 1
    feed(eng, clk, [(5, "Stop:4183")])
    assert execs(ex)[-1][1:4] == ("BUY", [4186.0, 4185.0], 4183.0)


def _doubt(eng, ex, clk):
    """A SELL stopped out, "بگیرش باز", then the zone typed "Buy" with gold below it (78343)."""
    ex.mid = 4126.0
    feed(eng, clk, [(0, "سل بگیر"), (5, "Xau\n\nSell\n\nEnter:4124/4125"), (4, "Stop:4127")])
    ex.fill("v1"); ex.alive.discard("v1")
    return feed(eng, clk, [(60, "استاپ تاچ کرد"), (3, "بگیرش باز"), (8, "Xau\n\nBuy\n\nEnter:4128/4129")])


def test_a_doubtful_side_waits_two_minutes_for_its_stop_then_is_not_traded():
    eng, ex, clk = make()
    _doubt(eng, ex, clk)
    clk.t += 45
    assert not any("معامله نشد" in l for l in run(eng.tick()))
    out = feed(eng, clk, [(5, "Stop:4131")])                          # 50 s after the zone: still its stop
    assert execs(ex)[-1][1:4] == ("SELL", [4128.0, 4129.0], 4131.0), out
    eng, ex, clk = make()
    _doubt(eng, ex, clk)
    clk.t += 125
    out = run(eng.tick())
    assert len(execs(ex)) == 1 and any("معامله نشد" in l for l in out)


@pytest.mark.parametrize("post", ["جا موندی قیمت مارکت بزن", "30هم بود بگیر", "Xau\n\nBuy\n\nEnter:4128/4129",
                                  "فری خورد بگیر باز", "بگیر باز"])
def test_nothing_opens_a_doubtful_side_before_its_stop(post):
    eng, ex, clk = make()
    _doubt(eng, ex, clk)
    ex.mid = 4129.5 if "مارکت" in post else 4126.0
    out = feed(eng, clk, [(5, post)])
    clk.t += 70
    out += run(eng.tick())
    assert len(execs(ex)) == 1 and not [c for c in ex.calls if c[0] == "market_now"], out


def test_a_doubt_that_was_given_up_is_not_reentered_and_a_late_stop_still_shows_the_side():
    eng, ex, clk = make()
    _doubt(eng, ex, clk)
    clk.t += 125
    run(eng.tick())                                                   # given up
    out = feed(eng, clk, [(5, "بگیر باز")])
    clk.t += 70
    out += run(eng.tick())
    assert len(execs(ex)) == 1, out
    eng, ex, clk = make()
    _doubt(eng, ex, clk)
    out = feed(eng, clk, [(10, "فریش کن"), (20, "Stop:4131"), (30, "فری خورد بگیر باز")])   # dropped, then its stop
    clk.t += 70
    out += run(eng.tick())
    assert execs(ex)[-1][1:4] == ("SELL", [4128.0, 4129.0], 4131.0), out


def test_a_stop_typo_that_looks_like_the_other_side_does_not_turn_the_zone():   # 80328 / 80329
    eng, ex, clk = make()
    ex.mid = 4066.0
    feed(eng, clk, [(0, "سل بزن"), (6, "Xau\n\nSell\n\nEnter:4068/4069"), (5, "Stop:4071")])
    ex.fill("v1"); ex.alive.discard("v1")
    out = feed(eng, clk, [(90, "فری زد بگیرش باز"), (12, "Xau\n\nBuy\n\nEnter:4065/4064"), (6, "Stop:4067")])
    assert execs(ex)[-1][1:3] == ("BUY", [4065.0, 4064.0]), out       # gold above the zone: a BUY, as typed
    assert not [c for c in execs(ex) if c[1] == "SELL" and c[2] == [4065.0, 4064.0]]


def test_the_edit_of_a_doubtful_zone():
    eng, ex, clk = make()
    _doubt(eng, ex, clk)
    zid = int(clk.t)
    out = run(eng.handle_edit("Xau\n\nBuy\n\nEnter:4128/4130", msg_id=zid))   # levels edited, side as before
    assert len(execs(ex)) == 1, out
    out = run(eng.handle_edit("Xau\n\nSell\n\nEnter:4128/4131", msg_id=zid))  # the leader corrects the side
    assert execs(ex)[-1][1:3] == ("SELL", [4128.0, 4131.0]), out


@pytest.mark.parametrize("between", [[(22, "نه سل نزن"), (1, "صبرکن")], [(20, "ببندش")], [(70, "چه بازاری")]])
def test_an_order_taken_back_or_old_does_not_put_the_next_zone_in_doubt(between):   # 79897 .. 79902
    eng, ex, clk = make()
    ex.mid = 4027.5                                                   # inside the zone: the price says nothing
    feed(eng, clk, [(0, "سل بزنید دوباره")] + between + [(10, "Xau\n\nBuy\n\nEnter:4028/4027")])
    assert execs(ex)[-1][1:3] == ("BUY", [4028.0, 4027.0])


def test_the_side_order_after_its_own_zone_is_not_the_next_zones_order():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "Xau Sell Enter:4188/4189"), (4, "Stop:4191"), (6, "سل بزن"), (20, "ببندش")])
    ex.alive.clear(); ex.pending.clear()
    ex.mid = 4185.5
    feed(eng, clk, [(15, "Xau Buy Enter:4186/4185")])
    assert execs(ex)[-1][1:3] == ("BUY", [4186.0, 4185.0])


def test_the_usual_order_and_zone_are_placed_at_once():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "بای بزنید"), (8, "Xau\n\nBuy\n\nEnter:4185/4184")])
    assert execs(ex)[0][1:3] == ("BUY", [4185.0, 4184.0])


def test_a_used_hint_does_not_put_the_next_zone_in_doubt():
    eng, ex, clk = make()
    feed(eng, clk, [(0, "سل بزن"), (5, "Xau Sell Enter:4190/4191"), (4, "Stop:4193"), (30, "ببندش")])
    ex.alive.clear(); ex.pending.clear()
    feed(eng, clk, [(20, "Xau Buy Enter:4186/4185")])                 # no new order word: the zone speaks
    assert execs(ex)[-1][1:3] == ("BUY", [4186.0, 4185.0])


# ---------------------------------------------------------------- engine: a zone with two readings
def test_two_readings_near_the_price_wait_for_the_stop():             # 75978 / 75979: 4054/4055 or 4044/4045
    for mid in (4049.4, 4052.0, 4043.0, None):
        eng, ex, clk = make()
        ex.mid = mid
        out = feed(eng, clk, [(0, "Xau\n\nSell\n\nEnter:4054/4045")])
        assert not execs(ex), (mid, out)                              # not placed on a guess
        out = feed(eng, clk, [(7, "Stop:4057")])
        assert execs(ex)[-1][1:4] == ("SELL", [4054.0, 4055.0], 4057.0), (mid, out)
        assert not any("غلط تایپی" in l for l in out), out            # the stop is used as written


def test_two_readings_the_stop_takes_the_other_one():                 # the mirror slip: 4045/4044 typed 4055/4044
    eng, ex, clk = make()
    ex.mid = 4053.4
    out = feed(eng, clk, [(0, "بای بزن"), (8, "Xau\n\nBuy\n\nEnter:4055/4044"), (5, "Stop:4042")])
    assert execs(ex)[-1][1:4] == ("BUY", [4045.0, 4044.0], 4042.0), out


def test_thousand_slip_without_a_price_is_read_by_its_stop():         # 74517 / 74518 with a stale quote
    eng, ex, clk = make()
    ex.mid = None
    out = feed(eng, clk, [(0, "Xau\n\nSell\n\nEnter:4158/5159"), (4, "Stop:4161")])
    assert execs(ex)[-1][1:4] == ("SELL", [4158.0, 4159.0], 4161.0), out


def test_two_readings_without_a_fitting_stop_are_not_traded():
    eng, ex, clk = make()
    ex.mid = 4049.4
    out = feed(eng, clk, [(0, "Xau\n\nSell\n\nEnter:4054/4045"), (6, "جا موندی قیمت مارکت بزن"), (3, "بگیر باز")])
    clk.t += 125
    out += run(eng.tick())
    assert not execs(ex) and not [c for c in ex.calls if c[0] == "market_now"], out
    eng, ex, clk = make()
    ex.mid = 4049.4
    out = feed(eng, clk, [(0, "Xau\n\nSell\n\nEnter:4054/4045"), (6, "Stop:4051"), (30, "بگیر باز")])
    clk.t += 70
    out += run(eng.tick())
    assert not execs(ex), out                                         # 4051 fits neither reading


# ---------------------------------------------------------------- engine: only his usual stop is a repair
def test_the_tens_repair_is_only_the_usual_stop():
    eng, ex, clk = make(place_before_stop=False)
    ex.mid = 4094.0
    out = feed(eng, clk, [(0, "Xau Sell Enter:4095/4096"), (5, "Stop:4110")])   # 4100 would be 4 behind: not his stop
    assert not execs(ex), out
    eng, ex, clk = make(place_before_stop=False)
    ex.mid = 4151.0
    out = feed(eng, clk, [(0, "Xau Buy Enter:4150/4149"), (5, "Stop:4137")])    # 4147 = exactly 2 behind
    assert execs(ex)[-1][3] == 4147.0, out


def test_a_repaired_stop_does_not_settle_a_doubtful_side():
    eng, ex, clk = make()
    _doubt(eng, ex, clk)
    out = feed(eng, clk, [(5, "Stop:4137")])                          # above the zone, fits BUY only after a repair
    assert len(execs(ex)) == 1, out
    out = feed(eng, clk, [(5, "Stop:4131")])
    assert execs(ex)[-1][1:4] == ("SELL", [4128.0, 4129.0], 4131.0), out


def test_an_edit_does_not_turn_back_the_side_his_stop_showed():
    eng, ex, clk = make()
    _doubt(eng, ex, clk)
    zid = int(clk.t)
    feed(eng, clk, [(5, "Stop:4131")])
    assert execs(ex)[-1][1] == "SELL"
    out = run(eng.handle_edit("Xau\n\nBuy\n\nEnter:4127/4128", msg_id=zid))     # levels edited, the word still "Buy"
    assert execs(ex)[-1][1:3] == ("SELL", [4127.0, 4128.0]), out


def test_a_zone_moved_by_hundreds_says_so():
    eng, ex, clk = make()
    ex.mid = 4362.0
    out = feed(eng, clk, [(0, "Xau\nBuy\n\nEnter:4061/4060")])
    assert any("4061/4060" in l and "4361/4360" in l for l in out), out


# ---------------------------------------------------------------- second review round
def test_typed_side_placed_on_the_price_is_dropped_when_its_stop_shows_the_other_side():
    eng, ex, clk = make()
    ex.mid = 4126.0
    feed(eng, clk, [(0, "سل بگیر"), (5, "Xau\n\nSell\n\nEnter:4124/4125"), (4, "Stop:4127")])
    ex.fill("v1"); ex.alive.discard("v1")
    ex.mid = 4129.25                                                  # gold just past the zone: the price says BUY
    out = feed(eng, clk, [(60, "استاپ تاچ کرد"), (3, "بگیرش باز"), (8, "Xau\n\nBuy\n\nEnter:4128/4129")])
    assert execs(ex)[-1][1] == "BUY", out
    out = feed(eng, clk, [(5, "Stop:4131"), (30, "بگیر باز")])        # his order said SELL, his stop fits only SELL
    clk.t += 70
    out += run(eng.tick())
    assert any(c[0] == "cancel_virtual" for c in ex.calls) and execs(ex)[-1][1] == "BUY" and len(execs(ex)) == 2, out


def test_an_edit_that_corrects_only_the_side_word_is_taken():
    eng, ex, clk = make()
    ex.mid = 4126.0
    feed(eng, clk, [(0, "Xau\n\nBuy\n\nEnter:4128/4129")])
    zid = int(clk.t)
    clk.t += 5
    out = run(eng.handle_edit("Xau\n\nSell\n\nEnter:4128/4129", msg_id=zid))
    out += feed(eng, clk, [(4, "Stop:4131")])
    assert execs(ex)[-1][1:3] == ("SELL", [4128.0, 4129.0]), out
    assert execs(ex)[-1][3] == 4131.0 or any(c[0] == "update_levels" and c[1] == 4131.0 for c in ex.calls), out


def test_the_zone_posted_again_after_its_stop_keeps_what_the_stop_showed():
    eng, ex, clk = make()
    _doubt(eng, ex, clk)
    feed(eng, clk, [(5, "Stop:4131")])
    n = len(execs(ex))
    out = feed(eng, clk, [(8, "Xau\n\nBuy\n\nEnter:4128/4129")])      # the same post again, the same slip
    assert execs(ex)[-1][1:4] == ("SELL", [4128.0, 4129.0], 4131.0) and not [c for c in execs(ex)[n:] if c[1] == "BUY"], out
    eng, ex, clk = make()
    ex.mid = 4049.4
    feed(eng, clk, [(0, "Xau\n\nSell\n\nEnter:4054/4045"), (5, "Stop:4057")])
    out = feed(eng, clk, [(6, "Xau\n\nSell\n\nEnter:4054/4045")])
    assert execs(ex)[-1][1:4] == ("SELL", [4054.0, 4055.0], 4057.0), out


def test_a_doubt_is_settled_by_the_stop_although_the_price_ran_through_the_zone():
    eng, ex, clk = make()
    _doubt(eng, ex, clk)
    ex.mid = 4129.3                                                   # filling a SELL zone looks like this
    out = feed(eng, clk, [(5, "Stop:4131")])
    assert execs(ex)[-1][1:4] == ("SELL", [4128.0, 4129.0], 4131.0), out


def test_an_edit_to_one_of_two_readings_settles_the_zone():
    eng, ex, clk = make()
    ex.mid = 4052.0
    feed(eng, clk, [(0, "Xau\n\nSell\n\nEnter:4054/4045")])
    zid = int(clk.t)
    assert not execs(ex)
    clk.t += 4
    out = run(eng.handle_edit("Xau\n\nSell\n\nEnter:4054/4055", msg_id=zid))
    assert execs(ex)[-1][1:3] == ("SELL", [4054.0, 4055.0]), out


def test_a_reading_whose_stop_the_price_has_passed_is_never_taken():
    eng, ex, clk = make()
    ex.mid = 4124.4                                                   # his trade: SELL 4126/4127 SL 4129
    out = feed(eng, clk, [(0, "Xau\n\nSell\n\nEnter:4116/4127"), (5, "Stop:4119")])   # the slip repeated in the stop
    assert not execs(ex), out
    out = feed(eng, clk, [(5, "Stop:4129")])                          # corrected: still within its 2 minutes
    assert execs(ex)[-1][1:4] == ("SELL", [4126.0, 4127.0], 4129.0), out


def test_a_repaired_stop_inside_the_zone_post_does_not_clear_the_doubt():
    eng, ex, clk = make()
    ex.mid = 4127.0
    out = feed(eng, clk, [(0, "سل بزن"), (5, "Xau\n\nBuy\n\nEnter:4128/4129\n\nStop:4137")])
    assert not execs(ex), out


def test_a_formatting_edit_of_a_zone_moved_by_hundreds_changes_nothing():
    eng, ex, clk = make()
    ex.mid = 4362.0
    feed(eng, clk, [(0, "Xau\nBuy\n\nEnter:4061/4060")])
    zid = int(clk.t)
    feed(eng, clk, [(4, "Stop:4058")])
    n = len(ex.calls)
    ex.mid = 4374.0
    clk.t += 5
    out = run(eng.handle_edit("Xau Buy\nEnter:4061/4060", msg_id=zid))
    assert len(ex.calls) == n, out


@pytest.mark.parametrize("text", [
    "ریسک فری کنید بعد رفتن سود خواهشا تمام معاملات رو",
    "حتما ریسک فری کن بعد رفتن سود شب نباید ترید کرد",
    "حتما ریسک فری کنید بعد بالا رفتن جای حساسه دوستان",             # 87278 + 87279
    "ریسک فری کن همیشه بعد از اینکه رفت تو سود این اصل اوله",
    "اینجا کازینو نیس!!! ریسک فری کن همیشه بعد سود دوستان",
    "40 رو ریسک فری کن",                                             # a leg of an ULTRA signal
])
def test_lectures_and_leg_talk_are_not_a_risk_free_order(text):
    assert not parse(text).has(BE)


@pytest.mark.parametrize("text", [
    "داریمش هنوز فری باشید", "فعاله هنوز فریش کن", "جای خوبی نیست فریش کن", "معلوم نیست فری کن",
    "فریش کن بعدا میبندیم", "ریسک فری کن هنوز جا داره", "داره تثبیت میکنه الان فری کن",
    "بوم پرواز کرد ریسک فری کن جا موندی مارکت بزنش", "کشید بالا دوباره ریسک فری کن نگهدار میگم کجا ببندی",
    "ریسک فری کن بعد میگم کجا ببندی",
])
def test_real_risk_free_orders_with_extra_words_are_kept(text):
    assert parse(text).has(BE)


@pytest.mark.parametrize("text", ["دهنشو سرویس کرد ببندش", "ببندید رو 3975 عه 🙏", "ببند رو 4190 استاپ نخوریم",
                                  "خودتون اینو مدیریت کنید من همینجا میبندمش ❤️‍🔥"])
def test_close_orders_with_extra_words_are_kept(text):
    assert parse(text).has(CLOSE)


@pytest.mark.parametrize("text,kind", [
    ("دوباره بگیرش", "REENTER"), ("مجدد بگیرش", "REENTER"), ("فری‌خورد دوباره بگیرش", "REENTER"),       # 75284, 76390, 79503
    ("فری خورد. بگیرش", "REENTER"), ("فری خورد باز بگیرش. دوباره", "REENTER"),                         # 76046, 75826
    ("اگر فری خورد میگریم باز", "IF_BE_REENTER"), ("اگر فری‌خورد مگیریم باز", "IF_BE_REENTER"),         # 76038, 80275
    ("اگر فری. خورد بگیر باز", "IF_BE_REENTER"),                                                       # 76940
])
def test_reentry_orders_with_the_leaders_typos(text, kind):
    assert parse(text).has(kind)
