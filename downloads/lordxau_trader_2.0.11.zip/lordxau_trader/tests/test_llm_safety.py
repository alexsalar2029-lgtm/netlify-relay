# -*- coding: utf-8 -*-
"""Safety regressions for the gated LLM assistant + live dashboard (2.0.7).

These lock in the guarantees an adversarial review checked on 2026-10-03:
  * a reconnect-replayed STALE NOISE line never reaches the LLM (age guard), a fresh one does;
  * a hung provider can never freeze the engine past the hard wall-clock cap, and leaves the trade untouched;
  * a wallet / REAL-vs-DEMO switch re-baselines and clears the dashboard;
  * a take-profit outcome written with the نیم‌فاصله (ZWNJ) is still recognised as an outcome, not a command;
  * the in-panel key box writes/replaces/removes ONE provider's key in .env.llm and keeps the others, and the
    «test key» button can probe a typed-but-unsaved key — without ever writing settings.json or the key to a log.
All offline: a SimBroker on synthetic ticks, a local stub LLM, no network."""
import asyncio
import time

from lordxau import backtest as bt
from lordxau import settings as st_mod
from lordxau.dashboard import DashboardState
from lordxau.engine import Engine, EngineConfig
from lordxau.llm_gate import _OUTCOME, likely_command
from lordxau.llm_reader import Reading


def _ticks(series):
    return [(float(t), float(p), float(p) + 0.05) for t, p in series]


def _fresh():
    series = ([(0, 4001), (10, 4000.0), (20, 4000.6), (30, 4001.2), (40, 4001.6), (50, 4001.8)]
              + [(t, 4001.8) for t in range(60, 1500, 10)])
    sim = bt.SimBroker(_ticks(series), bt.SimConfig(balance=105.0, max_daily_loss=0.0))
    clock = {"t": 0.0}
    return sim, clock, Engine(sim, EngineConfig(), clock=lambda: clock["t"])


async def _open_trade(eng, sim, clock):
    async def feed(t, text, ts=None):
        while True:
            due = eng.next_due()
            if due is None or due > t:
                break
            sim.advance(due); clock["t"] = due; await eng.tick(due)
        sim.advance(t); clock["t"] = t
        return await eng.handle(text, msg_id=int(t * 1000), ts=t if ts is None else ts)
    await feed(1, "Xau Buy Enter:4000/3999")
    await feed(2, "Stop:3997")
    for t in (30, 60, 120, 180):
        while True:
            due = eng.next_due()
            if due is None or due > t:
                break
            sim.advance(due); clock["t"] = due; await eng.tick(due)
        sim.advance(t); clock["t"] = t
    return feed


def _open_count(sim):
    return len([p for p in sim.pos if p["state"] == "open"])


def test_stale_reconnect_noise_never_reaches_llm():
    async def go():
        sim, clock, eng = _fresh()
        calls = []
        eng.llm = lambda text: (calls.append(text),
                                Reading(kind="close", confidence=0.9, why="x", source="stub"))[1]
        feed = await _open_trade(eng, sim, clock)
        assert _open_count(sim) == 1
        await feed(200, "جمعش کن دیگه", ts=200 - 1000)      # hours-old replayed line
        assert not calls and _open_count(sim) == 1          # guard held: no consult, trade still open
        await feed(260, "جمعش کن دیگه")                     # same text, fresh
        assert len(calls) == 1 and _open_count(sim) == 0    # now it closes
    asyncio.run(go())


def test_hung_provider_cannot_freeze_engine_past_cap():
    async def go():
        sim, clock, eng = _fresh()
        eng.llm_hard_timeout = 0.3
        eng.llm = lambda text: (time.sleep(1.0), Reading(kind="close", confidence=0.9, source="stub"))[1]
        feed = await _open_trade(eng, sim, clock)
        t0 = time.time()
        await feed(200, "جمعش کن سریع")
        assert time.time() - t0 < 0.8                       # released at the ~0.3s cap, not after 1.0s
        assert _open_count(sim) == 1 and eng.llm_actions == 0  # fail-safe to regex, trade untouched
    asyncio.run(go())


def test_dashboard_reset_on_account_switch():
    d = DashboardState(balance0=10000.0, source_price="بروکر Trendo (دمو)")
    d.on_message({"type": "message", "t": 1.0, "ts": 1.0, "id": 1, "text": "x", "kind": "NOISE",
                  "also": [], "edited": False, "llm": None, "lines": [], "setup": None})
    d.on_trade({"id": 1, "usd": -5.0, "balance": 9995.0})
    assert d.events and d.trades
    d.reset(balance0=105.0, price_label="بروکر Trendo")
    import json
    day = next(iter(json.loads(d.to_json()).values()))
    assert d.balance0 == 105.0 and day["pnl"] == 0.0
    assert not d.events and not d.trades and day["source"]["price"] == "بروکر Trendo"


def test_zwnj_take_profit_is_an_outcome_not_a_command():
    zwnj = "تی‌پی خورد"                                # 'تی‌پی خورد' with the real نیم‌فاصله
    assert _OUTCOME.search(zwnj) is not None
    assert likely_command(zwnj) is False
    assert _OUTCOME.search("تی پی خورد") is not None
    assert likely_command("جمعش کن") is True               # a real terse command still passes


def test_in_panel_key_box_writes_only_its_provider(tmp_path):
    env = ".env.llm"
    st_mod.set_llm_key("gemini", "AIza-aaa", tmp_path, env)
    st_mod.set_llm_key("openrouter", "sk-or-bbb", tmp_path, env)
    body = (tmp_path / env).read_text(encoding="utf-8")
    assert "GEMINI_API_KEY=AIza-aaa" in body and "OPENROUTER_API_KEY=sk-or-bbb" in body
    assert body.count("GEMINI_API_KEY=") == 1

    st_mod.set_llm_key("gemini", "AIza-ccc", tmp_path, env)                 # replace, keep the other
    body = (tmp_path / env).read_text(encoding="utf-8")
    assert "GEMINI_API_KEY=AIza-ccc" in body and "AIza-aaa" not in body
    assert "OPENROUTER_API_KEY=sk-or-bbb" in body

    st_mod.set_llm_key("gemini", "", tmp_path, env)                        # empty value removes the line
    body = (tmp_path / env).read_text(encoding="utf-8")
    assert "GEMINI_API_KEY" not in body and "OPENROUTER_API_KEY=sk-or-bbb" in body
    assert not (tmp_path / "settings.json").exists()                       # keys never touch settings.json


def test_test_key_button_can_probe_a_typed_unsaved_key(monkeypatch):
    seen = {}

    class FakeReader:
        def __init__(self, *, providers, env, **kw):
            seen["env"] = dict(env)                                        # the key the GUI passed in

        def classify(self, text):
            return Reading(kind="close", confidence=0.9, source="fake", latency=0.2)

    monkeypatch.setattr("lordxau.llm_reader.LLMReader", FakeReader)
    # no file, no env var — a saved-key probe would short-circuit, but a typed key must reach the reader
    ok, msg = st_mod.probe_llm_key("gemini", root=".", env_file="___nope.llm", key="AIza-typed")
    assert ok is True and seen["env"].get("GEMINI_API_KEY") == "AIza-typed"
    ok2, _ = st_mod.probe_llm_key("gemini", root=".", env_file="___nope.llm", key="   ")
    assert ok2 is False                                                    # blank typed key = nothing to test
