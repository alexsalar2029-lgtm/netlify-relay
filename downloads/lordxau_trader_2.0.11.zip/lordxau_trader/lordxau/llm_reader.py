# -*- coding: utf-8 -*-
"""Hybrid LLM signal reader for LORD XAU Trader.

Design (validated 2026-10-03):
  * the fast deterministic regex parser (lordxau.parse) reads clear numeric zones/stops at ~99.7% with zero latency;
  * an LLM is consulted ONLY for messages the regex is unsure about -- no-number / tone management
    ("ببندش", "سوده فری کن", "بذار بره", a buy call with no area yet) -- where regex is fragile and the LLM is strong;
  * every LLM-derived ACTION passes a safety gate before it can touch a trade (right side vs price, an open trade must
    exist to close/BE, no invented entry numbers), so a hallucination cannot place or move real money on its own.

Providers are tried in order with fallback; responses are cached by message text (the channel repeats phrases).
Keys come from the environment (.env). Nothing here prints or logs a key.
Latency measured 2026-10-03: gemini-flash-lite-latest ~1.3s median; zhipu glm-4.5-flash ~6-12s; openrouter rate-limited.
"""
import json, os, re, time, urllib.request, urllib.error, hashlib
from dataclasses import dataclass, field
from typing import Optional

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"

# kinds the reader speaks (mapped to engine actions by the caller)
KINDS = ("zone", "stop", "risk_free", "close", "reenter", "market_now", "hint", "result", "noise")

SYSTEM = (
    "You read a Persian (Farsi) Telegram channel that posts FAST gold (XAUUSD) scalp signals and then manages the open "
    "trade with short, casual messages, OFTEN WITHOUT NUMBERS, by tone. Decide what ONE message tells a follower to do "
    "RIGHT NOW. Reply with ONLY compact JSON, no prose:\n"
    '{"kind":k,"side":s,"entries":[nums],"stop":num|null,"tp":[nums],"confidence":0..1,"why":"<=6 words"}\n'
    "k is exactly one of:\n"
    "  zone       = an entry area to place an order (e.g. 'Xau Sell 4193/4194', 'بای بزن رو 4185').\n"
    "  stop       = the stop-loss line for the current trade ('Stop 4196', 'استاپ 4184').\n"
    "  risk_free  = move the stop to entry / lock the trade ('فری کن', 'ریسک فری', 'سیو سود', 'بی‌ریسکش کن').\n"
    "  close      = exit the trade now / in profit ('ببند', 'ببندش', 'من همینجا میبندمش', 'خروج بزن').\n"
    "  reenter    = take the same trade again ('بگیر باز', 'دوباره بگیرش', 'مجدد').\n"
    "  market_now = enter immediately at market ('مارکت بزن', 'اگه نرسیدی بزن نزدیکش').\n"
    "  hint       = only a direction, no area yet ('سل بزنید', 'بای میگیریم').\n"
    "  result     = a past outcome / pip tally / #pnl, NOT an instruction.\n"
    "  noise      = chatter, ads, motivation, lessons, prices of OTHER assets (tether/dollar/car/domestic gold), "
    "talk ABOUT past trades, or 'let it run / بذار بره' with no action.\n"
    "Rules: side is buy, sell, or null. entries/tp are numbers only if the message states them, else []. "
    "If it is talk and not an order, it is noise or result. Never guess a number that is not written. "
    "Be strict: when unsure between an action and chatter, prefer noise with low confidence."
)


@dataclass
class ProviderCfg:
    name: str
    url: str
    model: str
    key_env: str
    kind: str = "openai"          # "openai" (chat/completions) or "gemini"
    headers: dict = field(default_factory=dict)


# fallback order reflects the 2026-10-03 probe: Gemini flash-lite fast+accurate, Zhipu slow but works,
# OpenRouter rate-limited, Groq key currently invalid (regenerate it to use).
DEFAULT_PROVIDERS = [
    ProviderCfg("gemini", "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                "gemini-flash-lite-latest", "GEMINI_API_KEY", "gemini"),
    ProviderCfg("zhipu", "https://open.bigmodel.cn/api/paas/v4/chat/completions", "glm-4.5-flash", "ZHIPU_API_KEY"),
    ProviderCfg("openrouter", "https://openrouter.ai/api/v1/chat/completions", "qwen/qwen3.8-27b:free",
                "OPENROUTER_API_KEY", headers={"HTTP-Referer": "http://localhost", "X-Title": "lordxau"}),
    ProviderCfg("groq", "https://api.groq.com/openai/v1/chat/completions", "llama-3.3-70b-versatile", "GROQ_API_KEY"),
]


def load_env(path):
    out = {}
    try:
        for line in open(path, encoding="utf-8"):
            m = re.match(r"\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$", line)
            if m and m.group(2) and not m.group(1).startswith("#"):
                out[m.group(1)] = m.group(2)
    except FileNotFoundError:
        pass
    return out


@dataclass
class Reading:
    kind: str = "noise"
    side: Optional[str] = None
    entries: list = field(default_factory=list)
    stop: Optional[float] = None
    tp: list = field(default_factory=list)
    confidence: float = 0.0
    why: str = ""
    source: str = ""          # "regex", "cache", or provider name; "" = not read
    latency: float = 0.0


class LLMReader:
    def __init__(self, providers=None, env=None, timeout=20.0, log=print, max_total=None):
        self.providers = providers or DEFAULT_PROVIDERS
        self.env = env or {k: os.getenv(k, "") for p in self.providers for k in [p.key_env]}
        self.timeout = timeout
        # total wall-clock budget across the whole fallback chain (None = unbounded, for offline probes/eval). The
        # live engine consults this UNDER its lock, so a slow/hung provider would freeze trading: the runner caps
        # it so classify() stops trying providers once the budget is spent (and falls back to the regex verdict).
        self.max_total = max_total
        self.log = log
        self.cache = {}
        self.calls = 0
        self.errors = 0

    # ---- provider calls -------------------------------------------------
    def _post(self, url, headers, payload, timeout=None):
        req = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"),
                                     headers={**headers, "Content-Type": "application/json", "User-Agent": UA})
        t = time.time()
        with urllib.request.urlopen(req, timeout=timeout or self.timeout) as r:
            return time.time() - t, json.loads(r.read())

    def _call(self, p: ProviderCfg, text: str, timeout=None):
        key = self.env.get(p.key_env, "")
        if not key:
            return None
        if p.kind == "gemini":
            url = p.url.format(model=p.model) + "?key=" + key
            payload = {"system_instruction": {"parts": [{"text": SYSTEM}]},
                       "contents": [{"parts": [{"text": text}]}],
                       "generationConfig": {"temperature": 0, "responseMimeType": "application/json"}}
            dt, d = self._post(url, {}, payload, timeout)
            return dt, d["candidates"][0]["content"]["parts"][0]["text"]
        payload = {"model": p.model, "temperature": 0, "response_format": {"type": "json_object"},
                   "messages": [{"role": "system", "content": SYSTEM}, {"role": "user", "content": text}]}
        dt, d = self._post(p.url, {"Authorization": "Bearer " + key, **p.headers}, payload, timeout)
        return dt, d["choices"][0]["message"]["content"]

    @staticmethod
    def _parse_json(s):
        m = re.search(r"\{.*\}", s, re.S)
        try:
            return json.loads(m.group(0)) if m else {}
        except Exception:
            return {}

    def classify(self, text: str) -> Reading:
        """Ask the LLM (with fallback + cache). Returns a Reading; kind='noise'/source='' on total failure."""
        h = hashlib.sha1(text.strip().encode("utf-8")).hexdigest()
        if h in self.cache:
            r = self.cache[h]
            return Reading(**{**r.__dict__, "source": "cache", "latency": 0.0})
        start = time.time()
        for p in self.providers:
            if not self.env.get(p.key_env):
                continue
            timeout = self.timeout
            if self.max_total is not None:                # hard wall-clock cap across the whole chain
                remaining = self.max_total - (time.time() - start)
                if remaining <= 0.1:
                    break                                 # budget spent: stop, keep the regex verdict (fail-safe)
                timeout = min(self.timeout, remaining)
            try:
                got = self._call(p, text, timeout)
                if got is None:
                    continue
                dt, raw = got
                j = self._parse_json(raw)
                kind = j.get("kind") if j.get("kind") in KINDS else "noise"
                side = j.get("side") if j.get("side") in ("buy", "sell") else None
                r = Reading(kind=kind, side=side,
                            entries=[float(x) for x in (j.get("entries") or []) if _num(x)],
                            stop=float(j["stop"]) if _num(j.get("stop")) else None,
                            tp=[float(x) for x in (j.get("tp") or []) if _num(x)],
                            confidence=float(j.get("confidence") or 0.0), why=str(j.get("why") or "")[:40],
                            source=p.name, latency=dt)
                self.calls += 1
                self.cache[h] = r
                return r
            except urllib.error.HTTPError as e:
                self.errors += 1
                self.log(f"LLM {p.name} HTTP {e.code}")
            except Exception as e:                       # noqa: BLE001 - network/JSON: fall through to next provider
                self.errors += 1
                self.log(f"LLM {p.name} err {type(e).__name__}")
        return Reading(source="")                        # nothing worked: caller keeps the regex verdict


def _num(x):
    try:
        float(x); return True
    except (TypeError, ValueError):
        return False
