# -*- coding: utf-8 -*-
"""2.0.4: @lordxau is asked every ~1.5 s (was ~5.1 s). The live journal 09-25..10-01
had a median delay of 5.7 s, about half of it the poll wait. On a Telegram flood the
poller first falls back to the 5 s cadence that ran for days without one; only a flood
at that cadence makes the server's 300 s hint count in full (C3)."""
import asyncio
import json
import time
from types import SimpleNamespace

from telethon import TelegramClient
from telethon.sessions import MemorySession
from telethon.tl.functions.channels import GetFullChannelRequest
from telethon.tl.functions.updates import GetChannelDifferenceRequest
from telethon.tl.types import Channel, ChatPhotoEmpty, InputChannel
from telethon.tl.types.messages import ChatFull
from telethon.tl.types.updates import ChannelDifferenceEmpty

from lordxau import settings as st_mod
from signal_trader.fastpoll import SAFE_MAX_WAIT, ChannelPoller


class FakeSender:
    def __init__(self, answer):
        self.answer = answer
        self.sent: list = []

    def send(self, request, ordered=False):
        self.sent.append(request)
        fut = asyncio.get_running_loop().create_future()
        fut.set_result(self.answer(request))
        return fut


CHAN = Channel(id=111, title="lordxau", photo=ChatPhotoEmpty(), date=None, access_hash=222,
               broadcast=True, megagroup=False)


def client(hint=300):
    def answer(req):
        if isinstance(req, GetFullChannelRequest):
            return ChatFull(full_chat=SimpleNamespace(pts=100), chats=[CHAN], users=[])
        if isinstance(req, GetChannelDifferenceRequest):
            return ChannelDifferenceEmpty(pts=req.pts, final=True, timeout=hint)
        raise AssertionError(type(req).__name__)
    c = TelegramClient(MemorySession(), 1, "x")
    c._sender = FakeSender(answer)
    c.session.process_entities(SimpleNamespace(chats=[CHAN], users=[]))
    return c


async def nop(*a, **k):
    pass


def poller(c, lines, interval, max_wait):
    p = ChannelPoller(c, lambda: {"lordxau": 111}, nop, nop, interval=interval, max_wait=max_wait,
                      on_line=lines.append)
    p._state["lordxau"] = {"input": InputChannel(111, 222), "pts": 100, "ident": 111, "due": 0.0}
    return p


def fast(lines):
    tg = st_mod.DEFAULTS["telegram"]
    return poller(client(), lines, tg["fast_poll_sec"], tg["fast_poll_max_wait_sec"])


def test_defaults_ask_telegram_every_one_and_a_half_seconds():
    tg = st_mod.DEFAULTS["telegram"]
    assert (tg["fast_poll_sec"], tg["fast_poll_max_wait_sec"]) == (1.0, 1.5) == st_mod.FAST_POLL

    async def go():
        lines: list = []
        p = fast(lines)
        await p.poll_once()
        assert 1.2 < p._next_delay(time.time()) <= 1.6
        assert 1.2 < p._state["lordxau"]["due"] - time.time() <= 1.6
        assert any("300" in l and "1.5 ثانیه" in l for l in lines), lines   # the log shows the cadence
    asyncio.run(go())


def test_settings_saved_with_the_old_defaults_are_upgraded(tmp_path):
    for old, want in (({"fast_poll_sec": 3.0, "fast_poll_max_wait_sec": 5.0}, (1.0, 1.5)),
                      ({"fast_poll_sec": 3, "fast_poll_max_wait_sec": 5}, (1.0, 1.5)),
                      ({"fast_poll_sec": 2.0, "fast_poll_max_wait_sec": 2.0}, (2.0, 2.0)),   # a chosen value stays
                      ({"fast_poll_sec": 3.0}, (3.0, 1.5))):
        p = tmp_path / "settings.json"
        p.write_text(json.dumps({"telegram": dict(old, session_name="s")}), encoding="utf-8")
        tg = st_mod.read_file(p)["telegram"]
        assert (tg["fast_poll_sec"], tg["fast_poll_max_wait_sec"]) == want, old
        assert tg["session_name"] == "s"
    p.write_text(json.dumps({"telegram": {"fast_poll_sec": "x", "fast_poll_max_wait_sec": 5.0}}), encoding="utf-8")
    assert st_mod.read_file(p)["telegram"]["fast_poll_sec"] == "x"          # unreadable: left alone


def test_first_flood_falls_back_to_the_proven_five_seconds_not_to_300():
    async def go():
        lines: list = []
        p = fast(lines)
        p._flood(time.time() + 1, 1.0)
        assert p.max_wait == SAFE_MAX_WAIT == 5.0 and p.base_interval >= 3.0
        assert not p._flooded_at
        assert any("حالت امن" in l for l in lines), lines
        p._pause_until = 0.0
        await p.poll_once()
        assert 4.0 < p._state["lordxau"]["due"] - time.time() <= 5.2       # 5 s, never the 300 s hint
        # a second flood, now at the proven cadence: the server's hint in full (C3)
        p._flood(time.time() + 2, 2.0)
        assert p._flooded_at
        p._pause_until = 0.0
        p._state["lordxau"]["due"] = 0.0
        await p.poll_once()
        assert 290 < p._state["lordxau"]["due"] - time.time() <= 300.5
    asyncio.run(go())


def test_a_poller_at_the_old_cadence_keeps_the_old_flood_rule():
    async def go():
        lines: list = []
        p = poller(client(), lines, 3.0, 5.0)
        p._flood(time.time() + 1, 1.0)
        assert p.max_wait == 5.0 and p._flooded_at
        p._pause_until = 0.0
        await p.poll_once()
        assert 290 < p._state["lordxau"]["due"] - time.time() <= 300.5
    asyncio.run(go())


def test_the_same_flood_seen_twice_backs_off_once():
    lines: list = []
    p = fast(lines)
    due = time.time() + 1
    p._flood(due, 1.0)
    iv = p.interval
    p._flood(due, 1.0)
    assert p.interval == iv and not p._flooded_at
