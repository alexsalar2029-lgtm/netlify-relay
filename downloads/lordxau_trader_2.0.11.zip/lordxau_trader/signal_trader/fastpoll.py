"""Fast delivery for the channels the bot TRADES.

Telegram does not push every update of a big channel to a client right away.
The server journal of 2026-09-20..23 showed @lordxau messages reaching the bot
25-32 s late on median (p90 55 s, max 66 s), in bursts about once a minute,
while smaller channels arrived in 5-8 s - fatal for a 2-3 point scalper.

The official apps poll ``updates.getChannelDifference`` for the channel that is
open on screen; :class:`ChannelPoller` does the same for the trade channels:
every ``interval`` seconds one small request per channel returns only what is
new since the last answer (new messages and edits). The request is read-only
and stateless on Telegram's side, so the client's own update stream is not
disturbed; the push update that arrives later for the same message is dropped
by :class:`Seen` (first delivery wins, edits only when the text changed).

Rules (review 2026-09-23b / 23d):

* ONE :class:`Seen` per process: the GUI hands the same one to the router of
  every Start, so the late push of a message a previous run already handled
  (the poller delivered it first) is dropped - never traded a second time.
* An edit of a message THIS router never delivered as NEW (a reaction or a
  correction after a restart or a Stop/Start, an edit of a post from before the
  start) is only journaled - it never reaches the engine, so it can never trade
  a post twice (a new engine re-processes an edited message it does not know).
* The poller drops NEW messages older than ``max_age`` and edits of posts older
  than ``max(max_age, edit_max_age)`` (the engine's edit window), so a late
  SL/TP correction inside the window is not left to the slow push path.
* Telethon sleeps a FLOOD_WAIT of up to ``flood_sleep_threshold`` (60 s) INSIDE
  ``client(request)`` and keeps one flood record per request TYPE, shared with
  its own channel catch-up. The poller reads that record: it never sends while
  a getChannelDifference flood is active, stops until the wait is over plus a
  margin, doubles its interval and later brings it back step by step. A longer
  wait still arrives as FloodWaitError. The ``timeout`` of a channel difference
  (Telegram's HINT for how long a viewing client may wait: 30 s for a small
  channel, 300 s for @lordxau) is honoured only up to ``max_wait``
  (config fast_poll_max_wait_sec, 5 s): the server log of 2026-09-24 showed the
  fully honoured 300 s left @lordxau to the ~60 s push batches again - the
  poller had no effect on the one channel it was built for. A flood wait, not
  the hint, is the real limit and is handled above. A poller set faster than
  SAFE_MAX_WAIT (lordxau_trader 2.0.4: 1.5 s) first falls back to that proven
  cadence; only a flood at it makes the hint count in full.
* Anything that goes wrong while STARTING one channel (flood wait, error,
  timeout) delays only that channel - never the others, the pause or the interval.
  A start is held back only by the flood records of the requests it would
  really send: getFullChannel always, resolveUsername / getChannels only when
  the channel is not in the client's entity cache (the scout's floods on those
  must not stop a cached trade channel).
* A chat that is not a broadcast channel (supergroup / megagroup / user) is never
  polled, like the push path (``channels.event_channel_key``).
* An engine call, once started, always finishes and its lines reach the sink:
  a Stop that cancels the caller waits for it (an order may be on its way).
"""
from __future__ import annotations

import asyncio
import inspect
import logging
import time
from collections import OrderedDict
from typing import Any, Awaitable, Callable, Optional

log = logging.getLogger("signal_trader.fastpoll")

OnMessage = Callable[[str, int, Optional[float], str], Awaitable[None]]

FLOOD_MARGIN = 5.0          # s after a flood wait has expired before the poller asks again
# The cadence that ran for days without a single flood (VPS 2026-09-25..10-01: up to
# 4 channels every ~5.1 s, ~0.8 requests/s). A poller set faster than this falls back
# to it on its first flood; only a flood AT this cadence makes it honour the server's
# full hint for the rest of the run (C3).
SAFE_MAX_WAIT = 5.0
SAFE_INTERVAL = 3.0
RESTORE_AFTER = 120.0       # s without a flood before one backoff step (x2) is undone
MAX_INTERVAL = 30.0         # the backoff never goes beyond this
SLOW_CALL = 20.0            # a client without Telethon's flood record: an answer this slow = a slept flood
FAILED_RETRY = 300.0        # s before a channel that failed is tried again
INIT_TIMEOUT = 10.0         # s one channel start may take (it may sit in a Telethon flood sleep)
INIT_TIMEOUT_RETRY = 30.0   # s before a channel start that timed out is tried again
SEEN_CAP = 20000            # messages remembered per Seen / router (oldest dropped first)


def _short(text: str) -> str:
    return (text or "").replace("\n", " / ")[:120]


def _accepts(fn: Any, name: str) -> bool:
    """Whether ``fn`` takes a keyword argument ``name`` (or **kwargs)."""
    try:
        params = inspect.signature(fn).parameters
    except (TypeError, ValueError):
        return False
    return name in params or any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values())


class Seen:
    """First-delivery-wins bookkeeping shared by the push handlers and the
    poller: a message id is processed once; an edit only when its text differs
    from the text already processed for that message AND the message itself was
    delivered as NEW here (see :meth:`edited`)."""

    SAME = ""               # nothing new: a reaction / view-count edit, a duplicate
    JOURNAL = "journal"     # text of a message never delivered as NEW here: record only
    CHANGED = "changed"     # changed text of a message delivered as NEW here: act on it

    def __init__(self, cap: int = SEEN_CAP):
        self._new: OrderedDict = OrderedDict()
        self._text: OrderedDict = OrderedDict()
        self._cap = cap

    def _trim(self, d: OrderedDict) -> None:
        while len(d) > self._cap:
            d.popitem(last=False)

    def first(self, key: str, msg_id: Any, text: str) -> bool:
        k = (key, msg_id)
        if k in self._new:
            return False
        self._new[k] = time.time()
        self._text[k] = text
        self._trim(self._new)
        self._trim(self._text)
        return True

    def edited(self, key: str, msg_id: Any, text: str) -> str:
        """``SAME`` (falsy) when the text is the one already known, else
        ``CHANGED`` for a message delivered as NEW here, ``JOURNAL`` for one that
        was not (its text is kept so a later identical edit is a no-op, but it
        is NOT marked as seen-new: a late NEW delivery still counts)."""
        k = (key, msg_id)
        if self._text.get(k) == text:
            return self.SAME
        self._text[k] = text
        self._trim(self._text)
        return self.CHANGED if k in self._new else self.JOURNAL

    def forget(self, key: str, msg_id: Any) -> None:
        """Undo :meth:`first` for a message whose engine call never started (its
        caller was cancelled while waiting its turn): a later delivery counts."""
        k = (key, msg_id)
        self._new.pop(k, None)
        self._text.pop(k, None)


def _ts(msg) -> Optional[float]:
    d = getattr(msg, "date", None)
    try:
        return d.timestamp() if d is not None else None
    except Exception:
        return None


def _flood_errors() -> tuple:
    from telethon import errors
    return tuple(c for c in (getattr(errors, "FloodWaitError", None),
                             getattr(errors, "FloodPremiumWaitError", None)) if c is not None)


class _Paused(Exception):
    """Internal: a getChannelDifference flood wait is active - end this round."""


_NO_IDENT = object()


class ChannelPoller:
    """Poll getChannelDifference for ``targets()`` -> {channel key: ident}."""

    def __init__(self, client: Any, targets: Callable[[], dict], on_new: OnMessage,
                 on_edit: OnMessage, interval: float = 3.0, max_channels: int = 6,
                 on_line: Optional[Callable[[str], None]] = None, max_age: float = 180.0,
                 edit_max_age: float = 0.0, max_wait: float = 5.0):
        self.client = client
        self.targets = targets
        self.on_new = on_new
        self.on_edit = on_edit
        self.interval = max(1.0, float(interval))
        self.base_interval = self.interval          # a backed-off interval returns to this
        # the server's per-channel timeout hint is honoured up to this (0 = ignored)
        try:
            self.max_wait = max(0.0, float(max_wait))
        except (TypeError, ValueError):
            self.max_wait = 5.0
        self.max_channels = max(1, int(max_channels))
        self.on_line = on_line
        # The poller only makes delivery FASTER: anything older than this (a
        # resync after a long gap) is left to the normal update stream / never
        # replayed, so an old signal can never be traded late.
        self.max_age = float(max_age)
        # An EDIT is delivered while the engine would still act on it (its
        # edit_window_sec): a late SL/TP correction must not wait for the push.
        # The router / engine keep edits of unknown or old posts from trading.
        try:
            self.edit_max_age = max(self.max_age, float(edit_max_age or 0.0))
        except (TypeError, ValueError):
            self.edit_max_age = self.max_age
        self.init_timeout = INIT_TIMEOUT
        self._slow_logged: set = set()              # channels whose first slow diff timeout was logged
        self._cap_logged: set = set()               # trade channels over max_channels (logged once)
        self._state: dict[str, dict] = {}
        self._pause_until = 0.0
        self._failed: dict[str, float] = {}         # key -> do not (re)start the channel before this time
        self._skip: dict[str, Any] = {}             # key -> ident of a chat that is not a broadcast channel
        self._flood_due = 0.0                       # end of the last flood wait acted on
        self._backoff_at = 0.0                      # when the interval was last doubled / restored
        # after ONE flood on getChannelDifference the server's hint is honoured
        # in full for the rest of the run: a repeated flood also holds Telethon's
        # own channel catch-up (the record is per request type) - review C3
        self._flooded_at = 0.0
        self._hint_logged: set = set()
        # the callbacks may take the batch receipt time (review C2)
        self._new_recv = _accepts(on_new, "recv")
        self._edit_recv = _accepts(on_edit, "recv")
        self.polls = 0

    def _line(self, text: str, level: int = logging.WARNING) -> None:
        log.log(level, text)
        if self.on_line is not None:
            try:
                self.on_line(text)
            except Exception:
                pass

    # -- Telethon flood records ---------------------------------------------------
    def _records(self) -> Optional[dict]:
        """Telethon's ``{request CONSTRUCTOR_ID: flood wait end}``; None when the
        client has no such record (then a very slow answer counts as a flood)."""
        rec = getattr(self.client, "_flood_waited_requests", None)
        return rec if isinstance(rec, dict) else None

    def _active_flood(self, *cids: int) -> float:
        """End time of a flood wait Telethon still holds for one of these request
        types, 0 when none (Telethon itself ignores a record with <= 3 s left)."""
        rec = self._records()
        if not rec:
            return 0.0
        now, due = time.time(), 0.0
        for cid in cids:
            try:
                v = float(rec.get(cid) or 0.0)
            except (TypeError, ValueError):
                continue
            if v - now > 3 and v > due:
                due = v
        return due

    async def _cached(self, ident: Any) -> bool:
        """Can ``get_input_entity(ident)`` answer without a request? The same
        lookups Telethon makes first: its in-memory entity cache (a channel id),
        then the session. True when the client has neither (a test double):
        :meth:`_init` then tells by itself."""
        mb = getattr(self.client, "_mb_entity_cache", None)
        session = getattr(self.client, "session", None)
        lookup = getattr(session, "get_input_entity", None)
        if mb is None and lookup is None:
            return True
        if isinstance(ident, int) and mb is not None:
            try:
                if mb.get(ident) is not None:
                    return True
            except Exception:
                pass
        if lookup is None:
            return False
        from telethon.tl.types import PeerChannel
        try:
            res = lookup(PeerChannel(ident) if isinstance(ident, int) else ident)
            if inspect.isawaitable(res):
                await res
            return True
        except Exception:
            return False

    async def _start_cids(self, ident: Any) -> tuple:
        """Request types whose Telethon flood record holds back starting ``ident``:
        getFullChannel always; resolveUsername (an @name) or getChannels (a bare
        channel id) only when :meth:`_init` would really send it - a cached
        channel sends neither, so the scout's flood on them must not stop it."""
        from telethon.tl.functions.channels import GetChannelsRequest, GetFullChannelRequest
        from telethon.tl.functions.contacts import ResolveUsernameRequest
        cids = [GetFullChannelRequest.CONSTRUCTOR_ID]
        if not await self._cached(ident):
            cids.append(GetChannelsRequest.CONSTRUCTOR_ID if isinstance(ident, int)
                        else ResolveUsernameRequest.CONSTRUCTOR_ID)
        return tuple(cids)

    def _flood(self, due: float, secs: float) -> None:
        """A flood wait on getChannelDifference (the poller's own or Telethon's
        catch-up): no request until it has expired plus a margin, and a doubled
        interval that :meth:`_restore` brings back step by step."""
        now = time.time()
        self._pause_until = max(self._pause_until, max(due, now) + FLOOD_MARGIN)
        if due == self._flood_due:
            return                                   # the same flood seen again
        self._flood_due = due
        if self.max_wait < SAFE_MAX_WAIT:
            # faster than the proven cadence: back to it first (never straight to the
            # server's 300 s hint, which would leave @lordxau to the ~60 s push batches)
            self.max_wait = SAFE_MAX_WAIT
            self.base_interval = max(self.base_interval, SAFE_INTERVAL)
            self.interval = max(self.interval, self.base_interval)
            self._line(f"⚠️ دریافت سریع تلگرام: محدودیت تلگرام — سرعت خواندن به حالت امن قبلی "
                       f"(هر {SAFE_MAX_WAIT:g} ثانیه) برگشت")
        else:
            self._flooded_at = now
        self.interval = min(MAX_INTERVAL, self.interval * 2)
        self._backoff_at = now
        self._line(f"⚠️ دریافت سریع تلگرام: محدودیت تلگرام ({secs:.0f} ثانیه) — "
                   f"{self._pause_until - now:.0f} ثانیه درخواستی فرستاده نمی‌شود و فاصلهٔ "
                   f"درخواست‌ها {self.interval:g} ثانیه شد؛ پیام‌ها از مسیر عادی می‌رسند")

    def _restore(self) -> None:
        now = time.time()
        if self.interval <= self.base_interval or now < self._pause_until:
            return
        if now - self._backoff_at < RESTORE_AFTER:
            return
        self.interval = max(self.base_interval, self.interval / 2)
        self._backoff_at = now
        self._line(f"ℹ️ دریافت سریع تلگرام: فاصلهٔ درخواست‌ها به {self.interval:g} ثانیه برگشت",
                   logging.INFO)

    async def _diff(self, req) -> Any:
        """``client(GetChannelDifferenceRequest)`` with flood detection."""
        cid = type(req).CONSTRUCTOR_ID
        due = self._active_flood(cid)
        if due:                                      # Telethon would sleep (or refuse) inside client()
            self._flood(due, due - time.time())
            raise _Paused()
        rec = self._records()
        before = rec.get(cid) if rec is not None else None
        t0 = time.time()
        try:
            diff = await self.client(req)
        except _flood_errors() as exc:              # longer than flood_sleep_threshold
            secs = float(getattr(exc, "seconds", 30) or 30)
            self._flood(time.time() + secs, secs)
            raise _Paused() from None
        t1 = time.time()
        rec = self._records()
        if rec is not None:
            after = rec.get(cid)
            if after is not None and after != before:
                # A FLOOD_WAIT <= flood_sleep_threshold was slept INSIDE client()
                # (this request's, or Telethon's own catch-up of another channel).
                self._flood(float(after), max(0.0, float(after) - t0))
        elif t1 - t0 >= SLOW_CALL:
            self._flood(t1, t1 - t0)
        return diff

    # -- channel start ------------------------------------------------------------
    def _not_polled(self, key: str, ident: Any, why: str) -> None:
        self._skip[key] = ident
        self._state.pop(key, None)
        self._line(f"⚠️ «{key}» {why} — دریافت سریع برایش خاموش است "
                   "(پیام‌های گروه هیچ‌وقت معامله نمی‌شوند)")

    async def _init(self, key: str, ident: Any) -> Optional[dict]:
        from telethon.tl.functions.channels import GetFullChannelRequest
        from telethon.tl.types import InputChannel, PeerChannel
        # A stored chat_id is the bare channel id (auto-scouted rows): resolve it
        # as a channel peer from the session cache, never as a user id.
        ent = await self.client.get_input_entity(PeerChannel(ident) if isinstance(ident, int) else ident)
        if getattr(ent, "channel_id", None) is None:
            self._not_polled(key, ident, "کانال نیست")
            return None
        chan = InputChannel(ent.channel_id, ent.access_hash)
        full = await self.client(GetFullChannelRequest(chan))
        ch = next((c for c in (getattr(full, "chats", None) or [])
                   if getattr(c, "id", None) == chan.channel_id), None)
        if ch is not None and hasattr(ch, "broadcast") and not getattr(ch, "broadcast"):
            self._not_polled(key, ident, "یک گروه (سوپرگروه) است، نه کانال")
            return None
        st = {"input": chan, "pts": int(full.full_chat.pts), "ident": ident, "due": 0.0}
        self._state[key] = st
        return st

    async def _start(self, key: str, ident: Any) -> None:
        """Start one channel from "now". A flood wait, an error or a timeout here
        delays only THIS channel: never the others, the pause or the interval."""
        now = time.time()
        if now < self._failed.get(key, 0.0):
            return
        cids = await self._start_cids(ident)
        due = self._active_flood(*cids)
        if due:                                      # e.g. left by the scout on the shared client
            self._failed[key] = due + FLOOD_MARGIN
            self._line(f"⚠️ دریافت سریع برای {key}: محدودیت تلگرام ({due - now:.0f} ثانیه) — "
                       "این کانال بعد از آن شروع می‌شود؛ پیام‌ها از مسیر عادی می‌رسند")
            return
        try:
            await asyncio.wait_for(self._init(key, ident), timeout=self.init_timeout)
        except asyncio.TimeoutError:
            due = self._active_flood(*cids)
            self._failed[key] = max(time.time() + INIT_TIMEOUT_RETRY, (due + FLOOD_MARGIN) if due else 0.0)
            self._state.pop(key, None)
            self._line(f"⚠️ دریافت سریع برای {key}: شروع کانال طول کشید — "
                       f"{self._failed[key] - time.time():.0f} ثانیهٔ دیگر دوباره امتحان می‌شود؛ "
                       "پیام‌ها از مسیر عادی می‌رسند")
        except Exception as exc:
            self._state.pop(key, None)
            if isinstance(exc, _flood_errors()):
                secs = float(getattr(exc, "seconds", 30) or 30)
                self._failed[key] = time.time() + secs + FLOOD_MARGIN
                self._line(f"⚠️ دریافت سریع برای {key}: محدودیت تلگرام ({secs:.0f} ثانیه) — "
                           "این کانال بعد از آن شروع می‌شود؛ پیام‌ها از مسیر عادی می‌رسند")
            else:
                self._failed[key] = time.time() + FAILED_RETRY
                self._line(f"⚠️ دریافت سریع تلگرام برای {key} متوقف شد ({exc.__class__.__name__}) — "
                           "۵ دقیقهٔ دیگر دوباره امتحان می‌شود؛ پیام‌ها از مسیر عادی می‌رسند")

    # -- rounds -------------------------------------------------------------------
    async def poll_once(self) -> int:
        """One round over the targets; returns how many messages/edits it delivered.
        Started channels are polled first, then new ones are started."""
        if time.time() < self._pause_until:
            return 0
        n = 0
        allt = list((self.targets() or {}).items())
        targets = dict(allt[: self.max_channels])
        over = [k for k, _i in allt[self.max_channels:] if k not in self._cap_logged]
        if over:
            self._cap_logged.update(over)
            self._line(f"ℹ️ دریافت سریع حداکثر {self.max_channels} کانال را می‌خواند — "
                       + "، ".join(over) + " فقط از جریان عادی تلگرام می‌رسند", logging.INFO)
        for key in [k for k in self._state if k not in targets]:
            self._state.pop(key, None)                 # no longer a trade channel
        starts = []
        for key, ident in targets.items():
            if self._skip.get(key, _NO_IDENT) == ident:
                continue                               # not a broadcast channel
            st = self._state.get(key)
            if st is None or st.get("ident") != ident:
                starts.append((key, ident))
                continue
            if time.time() < self._pause_until:
                break
            if time.time() + 0.05 < float(st.get("due") or 0.0):
                continue                               # the server's timeout for this channel
            try:
                n += await self._poll_channel(key, st)
            except _Paused:
                break
            except Exception as exc:
                self._failed[key] = time.time() + FAILED_RETRY
                self._state.pop(key, None)
                self._line(f"⚠️ دریافت سریع تلگرام برای {key} متوقف شد ({exc.__class__.__name__}) — "
                           "۵ دقیقهٔ دیگر دوباره امتحان می‌شود؛ پیام‌ها از مسیر عادی می‌رسند")
        for key, ident in starts:
            if time.time() < self._pause_until:
                break
            await self._start(key, ident)               # start from "now"
        self._restore()
        self.polls += 1
        return n

    @staticmethod
    def _fresh(m, max_age: float) -> bool:
        ts = _ts(m)
        return ts is None or time.time() - ts <= max_age

    async def _new(self, key: str, m, recv: Optional[float] = None) -> int:
        if not self._fresh(m, self.max_age):
            return 0
        if self._new_recv:
            await self.on_new(key, m.id, _ts(m), m.message or "", recv=recv)
        else:
            await self.on_new(key, m.id, _ts(m), m.message or "")
        return 1

    async def _edit(self, key: str, m, recv: Optional[float] = None) -> int:
        if not self._fresh(m, self.edit_max_age):
            return 0                                   # an edit of an old post: left to the update stream
        if self._edit_recv:
            await self.on_edit(key, m.id, _ts(m), m.message or "", recv=recv)
        else:
            await self.on_edit(key, m.id, _ts(m), m.message or "")
        return 1

    async def _poll_channel(self, key: str, st: dict) -> int:
        from telethon.tl.functions.updates import GetChannelDifferenceRequest
        from telethon.tl.types import (ChannelMessagesFilterEmpty, Message,
                                       UpdateEditChannelMessage, UpdateNewChannelMessage)
        from telethon.tl.types.updates import (ChannelDifference, ChannelDifferenceEmpty,
                                               ChannelDifferenceTooLong)
        n = 0
        for _ in range(5):                               # follow non-final answers a little
            sent = time.time()
            diff = await self._diff(GetChannelDifferenceRequest(
                channel=st["input"], filter=ChannelMessagesFilterEmpty(),
                pts=st["pts"], limit=100, force=False))
            recv = time.time()                           # one receipt time for the whole answer (C2)
            # The server's hint for the delay before this channel is asked again.
            try:
                timeout = float(getattr(diff, "timeout", None) or 0.0)
            except (TypeError, ValueError):
                timeout = 0.0
            if self._flooded_at and timeout > self.max_wait:
                wait = timeout                           # after a flood: the hint in full (C3)
                if key not in self._hint_logged:
                    self._hint_logged.add(key)
                    self._line(f"ℹ️ دریافت سریع برای {key}: به‌خاطر محدودیت تلگرام، از این پس فاصلهٔ "
                               f"پیشنهادی تلگرام ({timeout:g} ثانیه) رعایت می‌شود (تا اجرای بعدی برنامه)؛ "
                               "پیام‌ها از جریان عادی تلگرام می‌رسند")
            else:
                wait = min(timeout, self.max_wait)
            # the server's (capped) hint holds this channel back from a round;
            # its own cadence (interval after ITS request) drives the wake-ups -
            # never a shared round grid that made channels alternate rounds (C1)
            st["due"] = recv + wait if wait > 0 else 0.0
            st["next"] = sent + self.interval
            if timeout > max(self.base_interval, self.max_wait) and key not in self._slow_logged:
                # The hint is above the cap: this channel is read every max(interval, cap).
                self._slow_logged.add(key)
                every = max(self.base_interval, wait)
                self._line(f"ℹ️ دریافت سریع برای {key}: تلگرام فاصلهٔ {timeout:g} ثانیه پیشنهاد داد — "
                           f"این کانال هر {every:g} ثانیه خوانده می‌شود (سقف fast_poll_max_wait_sec؛ "
                           "اگر تلگرام محدودیت بگذارد، خودکار کندتر می‌شود)", logging.INFO)
            if isinstance(diff, ChannelDifferenceEmpty):
                st["pts"] = diff.pts
                return n
            if isinstance(diff, ChannelDifferenceTooLong):
                # Too far behind: take the latest messages the answer carries
                # (the Seen filter drops those already processed) and resync.
                st["pts"] = int(getattr(diff.dialog, "pts", st["pts"]) or st["pts"])
                for m in sorted((m for m in diff.messages if isinstance(m, Message)), key=lambda m: m.id):
                    n += await self._new(key, m, recv)
                return n
            if not isinstance(diff, ChannelDifference):
                return n
            for m in sorted((m for m in diff.new_messages if isinstance(m, Message)), key=lambda m: m.id):
                n += await self._new(key, m, recv)
            for u in diff.other_updates:
                m = getattr(u, "message", None)
                if not isinstance(m, Message):
                    continue
                if isinstance(u, UpdateNewChannelMessage):
                    n += await self._new(key, m, recv)
                elif isinstance(u, UpdateEditChannelMessage):
                    n += await self._edit(key, m, recv)
            st["pts"] = diff.pts
            if diff.final or diff.final is None or time.time() < self._pause_until:
                return n
        return n

    def _next_delay(self, t0: float) -> float:
        """Seconds until the next round: the earliest started channel's own next
        time (each is polled every max(interval, capped hint) on its own clock,
        C1), ``interval`` after this round when a target still has to start,
        at most MAX_INTERVAL, or the end of a pause."""
        times = [max(float(st.get("next") or 0.0), float(st.get("due") or 0.0))
                 for st in self._state.values()]
        wake = min(times) if times else t0 + self.interval
        try:
            allt = list((self.targets() or {}).items())[: self.max_channels]
        except Exception:
            allt = []
        for key, ident in allt:                      # a target still to be started
            if key in self._state or self._skip.get(key, _NO_IDENT) == ident:
                continue
            wake = min(wake, max(t0 + self.interval, float(self._failed.get(key, 0.0))))
        wake = min(wake, t0 + max(self.interval, MAX_INTERVAL))
        wake = max(wake, self._pause_until)
        return max(0.2, wake - time.time())

    async def run(self, stop: Callable[[], bool]) -> None:
        while not stop():
            t0 = time.time()
            try:
                await self.poll_once()
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # pragma: no cover - never let the loop die
                log.warning("fast poll round failed: %r", exc)
            end = time.time() + self._next_delay(t0)
            while not stop():                         # short slices: a Stop is seen quickly
                left = end - time.time()
                if left <= 0:
                    break
                await asyncio.sleep(min(1.0, left))


def trade_targets(rows: dict, only_manual: bool = False) -> dict:
    """{key: ident} of the followed channels that TRADE (enabled rows only).
    A numeric chat_id (auto-scouted rows) is preferred over the @name."""
    out, scouted = {}, {}
    for key, cs in list((rows or {}).items()):
        if not getattr(cs, "trade", False) or not getattr(cs, "enabled", True):
            continue
        if only_manual and getattr(cs, "managed", False):
            continue
        cid = getattr(cs, "chat_id", None)
        ident = int(cid) if cid else (getattr(cs, "ident", None) or key)
        if isinstance(ident, str) and not ident.startswith("@") and not ident.lstrip("-").isdigit():
            ident = "@" + ident
        # the user's own rows first: the poller's channel cap never pushes one
        # out for an auto-scouted row (F4)
        (scouted if getattr(cs, "managed", False) else out)[key] = ident
    out.update(scouted)
    return out


class LatencyMeter:
    """Delivery delay (receipt - Telegram's message date) per channel, for the
    hourly log line: the one number that tells whether the trade channels'
    messages still arrive too late for a scalp (server 2026-09-20..24: @lordxau
    median 27 s, p90 56 s)."""
    KEEP = 200

    def __init__(self):
        self._lat: dict[str, list] = {}
        self._skew = 0                            # samples dropped: the clock is behind Telegram

    def note(self, channel: str, ts: Optional[float], now: Optional[float] = None) -> None:
        if ts is None:
            return
        try:
            d = (now if now is not None else time.time()) - float(ts)
        except (TypeError, ValueError):
            return
        if d < -5.0:
            self._skew += 1
            return
        if d > 3600.0:
            return                                # a resync of old posts, not a delay
        lst = self._lat.setdefault(channel, [])
        lst.append(max(0.0, d))
        if len(lst) > self.KEEP:
            del lst[: len(lst) - self.KEEP]

    @staticmethod
    def _q(v: list, q: float) -> float:
        s = sorted(v)
        return s[min(len(s) - 1, int(q * len(s)))]

    def line(self, reset: bool = True) -> str:
        parts = []
        for ch, v in sorted(self._lat.items(), key=lambda kv: -len(kv[1])):
            if not v:
                continue
            parts.append(f"{ch} میانه {self._q(v, 0.5):.1f}s، p90 {self._q(v, 0.9):.1f}s "
                         f"(بیشینه {max(v):.0f}s، {len(v)} پیام)")
        skew = self._skew
        if reset:
            self._lat.clear()
            self._skew = 0
        if not parts:
            if skew:
                return (f"⏱ تأخیر دریافت پیام‌ها: اندازه‌گیری ممکن نیست — ساعت این کامپیوتر بیش از 5 ثانیه از "
                        f"تلگرام عقب است ({skew} پیام)؛ ساعت سرور را همگام کنید")
            return ""
        return "⏱ تأخیر دریافت پیام‌ها: " + "؛ ".join(parts)


class MessageRouter:
    """The one entry point for followed-channel messages, from the push updates
    AND the poller: first delivery wins (:class:`Seen`), every message is
    journaled (filelog), and messages are handled one at a time in arrival order
    (a split signal's "Stop:" must never overtake its header).

    ``seen``: the process-wide :class:`Seen` (the GUI passes the same one to the
    router of every Start). Edits still reach the engine only for messages THIS
    router delivered as NEW - its engine has the record of those."""

    def __init__(self, engine: Any, sink: Callable[[str, str], None], seen: Optional[Seen] = None):
        self.engine = engine
        self.sink = sink                       # (channel key, log line)
        self.seen = seen if seen is not None else Seen()
        self._mine: OrderedDict = OrderedDict()   # (key, msg_id) delivered as NEW by this router
        self._lock: Optional[asyncio.Lock] = None
        self._inflight: set = set()
        self.latency = LatencyMeter()

    def latency_line(self, reset: bool = True) -> str:
        return self.latency.line(reset)

    def _get_lock(self) -> asyncio.Lock:
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    async def _call(self, key: str, fn, text: str, msg_id: Any, ts: Optional[float],
                    err: str, what: str) -> None:
        try:
            lines = await fn(text, msg_id=msg_id, channel=key, ts=ts)
        except Exception as exc:  # never let one message kill the listener
            lines = [err + repr(exc)]
            log.exception(what)
        for line in lines or []:
            self.sink(key, line)

    async def _handle(self, key: str, fn, text: str, msg_id: Any, ts: Optional[float],
                      err: str, what: str, on_drop: Optional[Callable[[], None]] = None) -> None:
        """Run one engine call, one at a time. Once started it always finishes
        and its lines always reach the sink: a Stop that cancels the caller (the
        poll task) waits for it - it may be sending an order - and the
        cancellation is re-raised afterwards. A caller cancelled while still
        waiting for its turn drops the message (nothing was done for it yet;
        ``on_drop`` lets a later delivery of it count)."""
        lock = self._get_lock()
        try:
            await lock.acquire()
        except asyncio.CancelledError:
            if on_drop is not None:
                on_drop()
            raise
        try:
            job = asyncio.ensure_future(self._call(key, fn, text, msg_id, ts, err, what))
            self._inflight.add(job)
            job.add_done_callback(self._inflight.discard)
            cancelled = False
            while True:
                try:
                    await asyncio.shield(job)
                    break
                except asyncio.CancelledError:
                    if job.done():                 # the call itself was cancelled (loop shutdown)
                        raise
                    cancelled = True
            if cancelled:
                raise asyncio.CancelledError()
        finally:
            lock.release()

    async def drain(self, timeout: Optional[float] = None) -> bool:
        """Wait until no engine call is in flight (for a Stop that wants every
        order already on its way reported). True when nothing is left."""
        pending = {t for t in self._inflight if not t.done()}
        if pending:
            _, pending = await asyncio.wait(pending, timeout=timeout)
        return not pending

    async def new(self, key: str, msg_id: Any, ts: Optional[float], text: str,
                  recv: Optional[float] = None) -> None:
        """``recv``: when the message really arrived (a poll answer's receipt,
        the same for every message of that answer) - else now."""
        from signal_trader import filelog
        text = text or ""
        if not text.strip() or not self.seen.first(key, msg_id, text):
            return                               # empty, or already handled (this run or an earlier one)
        k = (key, msg_id)
        self._mine[k] = True
        while len(self._mine) > SEEN_CAP:
            self._mine.popitem(last=False)

        def dropped() -> None:                   # cancelled before its turn: nothing was done
            self._mine.pop(k, None)
            self.seen.forget(key, msg_id)
        self.latency.note(key, ts, now=recv)
        filelog.journal(key, msg_id, ts, text)
        await self._handle(key, self.engine.handle, text, msg_id, ts,
                           "خطای پردازش پیام: ", "handler error", on_drop=dropped)

    async def edit(self, key: str, msg_id: Any, ts: Optional[float], text: str,
                   recv: Optional[float] = None) -> None:
        from signal_trader import filelog
        text = text or ""
        kind = self.seen.edited(key, msg_id, text)
        if not kind:
            return                               # a reaction / view-count edit
        filelog.journal(key, msg_id, ts, text, edited=True)
        if kind != Seen.CHANGED or (key, msg_id) not in self._mine:
            # Never delivered as NEW by THIS router (a reaction or a correction
            # after a restart or a Stop/Start, an edit of a post from before the
            # start): this engine has no record of it and would process the edited
            # text as a new signal - that post could be traded a second time.
            if text.strip():
                self.sink(key, f"✏️ پیام {msg_id}: ویرایش/واکنش روی پیامی که در این اجرا "
                               "دریافت نشده — کاری انجام نشد: " + _short(text))
            return
        fn = getattr(self.engine, "handle_edit", None)
        if fn is None:
            self.sink(key, f"✏️ پیام {msg_id} ویرایش شد (فقط ثبت شد): " + _short(text))
            return
        await self._handle(key, fn, text, msg_id, ts, "خطای پردازش ویرایش: ", "edit handler error")
